package com.example

import com.example.data.model.Note
import com.example.export.ExportManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExportManagerTest {

    private val sampleNote = Note(
        id = "test-123",
        title = "Test Title",
        content = "console.log('hello world');",
        tags = listOf("code", "sample"),
        fileExtension = "js"
    )

    @Test
    fun testJsonExportFormat() {
        val jsonOutput = ExportManager.generateExportContent(sampleNote, "json")
        assertTrue(jsonOutput.contains("\"id\": \"test-123\""))
        assertTrue(jsonOutput.contains("\"title\": \"Test Title\""))
        assertTrue(jsonOutput.contains("\"content\": \"console.log('hello world');\""))
        assertTrue(jsonOutput.contains("\"code\""))
    }

    @Test
    fun testHtmlExportFormat() {
        val htmlOutput = ExportManager.generateExportContent(sampleNote, "html")
        assertTrue(htmlOutput.contains("<!DOCTYPE html>"))
        assertTrue(htmlOutput.contains("<title>Test Title</title>"))
        assertTrue(htmlOutput.contains("console.log('hello world');"))
    }

    @Test
    fun testJsExportFormat() {
        val jsOutput = ExportManager.generateExportContent(sampleNote, "js")
        assertTrue(jsOutput.contains("Title: Test Title"))
        assertTrue(jsOutput.contains("console.log('hello world');"))
    }

    @Test
    fun testPyExportFormat() {
        val pyOutput = ExportManager.generateExportContent(sampleNote, "py")
        assertTrue(pyOutput.contains("\"\"\""))
        assertTrue(pyOutput.contains("Title: Test Title"))
    }

    @Test
    fun testDefaultFileName() {
        val fileName = ExportManager.getDefaultFileName(sampleNote, "py")
        assertEquals("Test_Title.py", fileName)
    }

    @Test
    fun testWordCountAndStats() {
        val note = Note(content = "Satu dua tiga empat lima")
        assertEquals(5, note.wordCount)
        assertEquals(1, note.lineCount)
        assertEquals(24, note.charCount)
    }
}
