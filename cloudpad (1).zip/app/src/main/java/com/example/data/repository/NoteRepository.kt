package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.local.NoteEntity
import com.example.data.model.Note
import com.example.data.remote.FirestoreNote
import com.example.data.remote.OperationType
import com.example.data.remote.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

enum class SyncStatus {
    GUEST_LOCAL,
    SYNCING,
    SYNCED,
    ERROR
}

class NoteRepository(
    private val context: Context,
    private val database: AppDatabase = AppDatabase.getDatabase(context)
) {
    private val noteDao = database.noteDao()
    private val auth = Firebase.auth
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val firestoreDb: FirebaseFirestore by lazy {
        val dbId = context.getString(R.string.firestore_database_id)
        FirebaseFirestore.getInstance(dbId)
    }

    private val _syncStatus = MutableStateFlow(SyncStatus.GUEST_LOCAL)
    val syncStatus: StateFlow<SyncStatus> = _syncStatus.asStateFlow()

    private var activeSnapshotListener: ListenerRegistration? = null

    init {
        // Observe auth state changes to toggle sync
        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            if (user != null) {
                _syncStatus.value = SyncStatus.SYNCING
                scope.launch {
                    try {
                        migrateGuestNotes(user.uid)
                        attachFirestoreListener(user.uid)
                    } catch (e: Exception) {
                        Log.e("NoteRepo", "Error starting cloud sync", e)
                        _syncStatus.value = SyncStatus.ERROR
                    }
                }
            } else {
                detachFirestoreListener()
                _syncStatus.value = SyncStatus.GUEST_LOCAL
            }
        }
    }

    fun observeNotes(currentUserId: String?): Flow<List<Note>> {
        val flow = if (currentUserId.isNullOrBlank()) {
            noteDao.observeGuestNotes()
        } else {
            noteDao.observeNotesForUser(currentUserId)
        }
        return flow.map { entities -> entities.map { it.toDomain() } }
    }

    suspend fun getNote(id: String): Note? = withContext(Dispatchers.IO) {
        noteDao.getNoteById(id)?.toDomain()
    }

    suspend fun saveNote(note: Note): Unit = withContext(Dispatchers.IO) {
        val currentUser = auth.currentUser
        val effectiveUserId = currentUser?.uid ?: ""
        val noteToSave = note.copy(
            userId = effectiveUserId,
            updatedAt = System.currentTimeMillis(),
            isSynced = currentUser != null
        )

        // 1. Save to local Room database immediately
        noteDao.upsertNote(NoteEntity.fromDomain(noteToSave))

        // 2. If signed in, sync to Firestore
        if (currentUser != null) {
            val path = "users/${currentUser.uid}/notes/${noteToSave.id}"
            try {
                _syncStatus.value = SyncStatus.SYNCING
                val docRef = firestoreDb.collection("users")
                    .document(currentUser.uid)
                    .collection("notes")
                    .document(noteToSave.id)

                val updatePayload = mapOf(
                    "title" to noteToSave.title,
                    "content" to noteToSave.content,
                    "tags" to noteToSave.tags,
                    "isPinned" to noteToSave.isPinned,
                    "fileExtension" to noteToSave.fileExtension,
                    "updatedAt" to FieldValue.serverTimestamp()
                )

                try {
                    // Try update first so immutable createdAt is preserved
                    docRef.update(updatePayload).await()
                } catch (e: Exception) {
                    // Document doesn't exist yet, create initial document
                    val createPayload = mapOf(
                        "userId" to currentUser.uid,
                        "title" to noteToSave.title,
                        "content" to noteToSave.content,
                        "tags" to noteToSave.tags,
                        "isPinned" to noteToSave.isPinned,
                        "fileExtension" to noteToSave.fileExtension,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                    docRef.set(createPayload).await()
                }

                noteDao.upsertNote(NoteEntity.fromDomain(noteToSave.copy(isSynced = true)))
                _syncStatus.value = SyncStatus.SYNCED
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.WRITE, path)
                _syncStatus.value = SyncStatus.ERROR
            }
        }
    }

    suspend fun deleteNote(id: String): Unit = withContext(Dispatchers.IO) {
        val currentUser = auth.currentUser
        noteDao.deleteNoteById(id)

        if (currentUser != null) {
            val path = "users/${currentUser.uid}/notes/$id"
            try {
                firestoreDb.collection("users")
                    .document(currentUser.uid)
                    .collection("notes")
                    .document(id)
                    .delete()
                    .await()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.DELETE, path)
            }
        }
    }

    suspend fun togglePin(id: String): Unit = withContext(Dispatchers.IO) {
        val existing = noteDao.getNoteById(id)?.toDomain() ?: return@withContext
        saveNote(existing.copy(isPinned = !existing.isPinned))
    }

    private suspend fun migrateGuestNotes(userId: String) = withContext(Dispatchers.IO) {
        val unsyncedGuestNotes = noteDao.getUnsyncedNotes("")
        if (unsyncedGuestNotes.isNotEmpty()) {
            noteDao.migrateGuestNotesToUser(userId)
            for (entity in unsyncedGuestNotes) {
                val note = entity.toDomain().copy(userId = userId)
                val docRef = firestoreDb.collection("users")
                    .document(userId)
                    .collection("notes")
                    .document(note.id)

                val payload = mapOf(
                    "userId" to userId,
                    "title" to note.title,
                    "content" to note.content,
                    "tags" to note.tags,
                    "isPinned" to note.isPinned,
                    "fileExtension" to note.fileExtension,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                try {
                    docRef.set(payload).await()
                    noteDao.upsertNote(NoteEntity.fromDomain(note.copy(isSynced = true)))
                } catch (e: Exception) {
                    handleFirestoreError(e, OperationType.CREATE, docRef.path)
                }
            }
        }
    }

    private fun attachFirestoreListener(userId: String) {
        detachFirestoreListener()
        val path = "users/$userId/notes"
        val query = firestoreDb.collection("users").document(userId).collection("notes")

        activeSnapshotListener = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                handleFirestoreError(error, OperationType.LIST, path)
                _syncStatus.value = SyncStatus.ERROR
                return@addSnapshotListener
            }

            if (snapshot != null) {
                scope.launch {
                    for (change in snapshot.documentChanges) {
                        when (change.type) {
                            DocumentChange.Type.ADDED, DocumentChange.Type.MODIFIED -> {
                                try {
                                    val note = change.document.toObject(FirestoreNote::class.java).toDomain()
                                    noteDao.upsertNote(NoteEntity.fromDomain(note))
                                } catch (e: Exception) {
                                    Log.e("NoteRepo", "Error deserializing note change", e)
                                }
                            }
                            DocumentChange.Type.REMOVED -> {
                                noteDao.deleteNoteById(change.document.id)
                            }
                        }
                    }
                    _syncStatus.value = SyncStatus.SYNCED
                }
            }
        }
    }

    private fun detachFirestoreListener() {
        activeSnapshotListener?.remove()
        activeSnapshotListener = null
    }
}
