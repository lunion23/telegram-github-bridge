package com.example.data.repository

import com.example.data.local.ReportDao
import com.example.data.model.PartItem
import com.example.data.model.TechnicalReport
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject

class ReportRepository(private val reportDao: ReportDao) {

    val allReports: Flow<List<TechnicalReport>> = reportDao.getAllReports()

    suspend fun getReportById(id: Long): TechnicalReport? = reportDao.getReportById(id)

    suspend fun saveReport(report: TechnicalReport): Long {
        return if (report.id == 0L) {
            reportDao.insertReport(report.copy(createdAt = System.currentTimeMillis(), updatedAt = System.currentTimeMillis()))
        } else {
            reportDao.updateReport(report.copy(updatedAt = System.currentTimeMillis()))
            report.id
        }
    }

    suspend fun deleteReport(report: TechnicalReport) = reportDao.deleteReport(report)

    suspend fun deleteReportById(id: Long) = reportDao.deleteReportById(id)

    suspend fun duplicateReport(report: TechnicalReport): Long {
        val newReport = report.copy(
            id = 0,
            noLaporan = report.noLaporan + " (Copy)",
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        return reportDao.insertReport(newReport)
    }

    companion object {
        fun partsToJson(items: List<PartItem>): String {
            val jsonArray = JSONArray()
            items.forEach { item ->
                val obj = JSONObject()
                obj.put("no", item.no)
                obj.put("noParts", item.noParts)
                obj.put("namaParts", item.namaParts)
                obj.put("jenisPengadaan", item.jenisPengadaan)
                jsonArray.put(obj)
            }
            return jsonArray.toString()
        }

        fun jsonToParts(json: String?): List<PartItem> {
            if (json.isNullOrBlank()) return PartItem.defaultList()
            return try {
                val array = JSONArray(json)
                val list = mutableListOf<PartItem>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        PartItem(
                            no = obj.optInt("no", i + 1),
                            noParts = obj.optString("noParts", ""),
                            namaParts = obj.optString("namaParts", ""),
                            jenisPengadaan = obj.optString("jenisPengadaan", "")
                        )
                    )
                }
                while (list.size < 5) {
                    list.add(PartItem(no = list.size + 1))
                }
                list.take(5)
            } catch (e: Exception) {
                PartItem.defaultList()
            }
        }
    }
}
