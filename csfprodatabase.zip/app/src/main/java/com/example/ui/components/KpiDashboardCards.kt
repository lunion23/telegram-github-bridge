package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FleetKpiStats
import java.text.NumberFormat
import java.util.Locale

/**
 * Compact Executive KPI summary strip.
 * Designed to provide full financial & operational visibility in a sleek ~50dp profile.
 */
@Composable
fun KpiDashboardCards(
    stats: FleetKpiStats,
    modifier: Modifier = Modifier
) {
    val intFormat = NumberFormat.getIntegerInstance(Locale("id", "ID"))
    val scrollState = rememberScrollState()

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState)
                .padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 1. Total Work Order
            CompactKpiItem(
                icon = Icons.Default.Assignment,
                iconColor = MaterialTheme.colorScheme.primary,
                bgColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                label = "Total WO",
                value = "${intFormat.format(stats.totalWorkOrders)}",
                detail = "${intFormat.format(stats.totalLineItems)} Item"
            )

            VerticalDivider(
                modifier = Modifier
                    .height(28.dp)
                    .width(1.dp),
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
            )

            // 2. Armada Aktif
            CompactKpiItem(
                icon = Icons.Default.DirectionsBus,
                iconColor = MaterialTheme.colorScheme.secondary,
                bgColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                label = "Armada",
                value = "${intFormat.format(stats.totalVehicles)} Unit",
                detail = "Di Bengkel"
            )

            VerticalDivider(
                modifier = Modifier
                    .height(28.dp)
                    .width(1.dp),
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
            )

            // 3. Total Biaya
            CompactKpiItem(
                icon = Icons.Default.Payments,
                iconColor = MaterialTheme.colorScheme.tertiary,
                bgColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f),
                label = "Total Biaya",
                value = formatCompactIdr(stats.totalExpenditure),
                detail = "Rata2: ${formatCompactIdr(stats.averageCostPerWo)}"
            )

            VerticalDivider(
                modifier = Modifier
                    .height(28.dp)
                    .width(1.dp),
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
            )

            // 4. Part vs Jasa
            CompactKpiItem(
                icon = Icons.Default.Build,
                iconColor = Color(0xFF8B5CF6),
                bgColor = Color(0xFFEDE9FE),
                label = "Part / Jasa",
                value = "${formatCompactIdr(stats.totalPartCost)}",
                detail = "Jasa: ${formatCompactIdr(stats.totalJasaCost)}"
            )
        }
    }
}

@Composable
private fun CompactKpiItem(
    icon: ImageVector,
    iconColor: Color,
    bgColor: Color,
    label: String,
    value: String,
    detail: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(bgColor),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = iconColor,
                modifier = Modifier.size(14.dp)
            )
        }

        Spacer(modifier = Modifier.width(7.dp))

        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "$label: ",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = value,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Text(
                text = detail,
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f)
            )
        }
    }
}

private fun formatCompactIdr(amount: Double): String {
    if (amount <= 0.0) return "Rp 0"
    val localeId = Locale("id", "ID")
    return when {
        amount >= 1_000_000_000.0 -> String.format(localeId, "Rp %.1f M", amount / 1_000_000_000.0)
        amount >= 1_000_000.0 -> String.format(localeId, "Rp %.1f Jt", amount / 1_000_000.0)
        amount >= 1_000.0 -> String.format(localeId, "Rp %.0f Rb", amount / 1_000.0)
        else -> String.format(localeId, "Rp %.0f", amount)
    }
}
