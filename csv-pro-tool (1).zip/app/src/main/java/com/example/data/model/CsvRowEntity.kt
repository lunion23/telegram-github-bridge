package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "csv_rows",
    indices = [
        Index(value = ["recordId"]),
        Index(value = ["datasetId"]),
        Index(value = ["col0"]),
        Index(value = ["col1"]),
        Index(value = ["col2"]),
        Index(value = ["col9"])
    ]
)
data class CsvRowEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val datasetId: String = "default",
    val recordId: String = "",
    val col0: String = "",
    val col1: String = "",
    val col2: String = "",
    val col3: String = "",
    val col4: String = "",
    val col5: String = "",
    val col6: String = "",
    val col7: String = "",
    val col8: String = "",
    val col9: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun getCell(index: Int): String {
        return when (index) {
            0 -> col0
            1 -> col1
            2 -> col2
            3 -> col3
            4 -> col4
            5 -> col5
            6 -> col6
            7 -> col7
            8 -> col8
            9 -> col9
            else -> ""
        }
    }

    fun withCell(index: Int, value: String): CsvRowEntity {
        return when (index) {
            0 -> copy(col0 = value, recordId = if (recordId.isEmpty() || recordId == col0) value else recordId)
            1 -> copy(col1 = value)
            2 -> copy(col2 = value)
            3 -> copy(col3 = value)
            4 -> copy(col4 = value)
            5 -> copy(col5 = value)
            6 -> copy(col6 = value)
            7 -> copy(col7 = value)
            8 -> copy(col8 = value)
            9 -> copy(col9 = value)
            else -> this
        }
    }

    fun toList(): List<String> {
        return listOf(col0, col1, col2, col3, col4, col5, col6, col7, col8, col9)
    }

    companion object {
        fun fromList(values: List<String>, id: Long = 0, datasetId: String = "default"): CsvRowEntity {
            val c0 = values.getOrNull(0)?.trim() ?: ""
            val c1 = values.getOrNull(1)?.trim() ?: ""
            val c2 = values.getOrNull(2)?.trim() ?: ""
            val c3 = values.getOrNull(3)?.trim() ?: ""
            val c4 = values.getOrNull(4)?.trim() ?: ""
            val c5 = values.getOrNull(5)?.trim() ?: ""
            val c6 = values.getOrNull(6)?.trim() ?: ""
            val c7 = values.getOrNull(7)?.trim() ?: ""
            val c8 = values.getOrNull(8)?.trim() ?: ""
            val c9 = values.getOrNull(9)?.trim() ?: ""
            return CsvRowEntity(
                id = id,
                datasetId = datasetId,
                recordId = c0,
                col0 = c0,
                col1 = c1,
                col2 = c2,
                col3 = c3,
                col4 = c4,
                col5 = c5,
                col6 = c6,
                col7 = c7,
                col8 = c8,
                col9 = c9
            )
        }
    }
}
