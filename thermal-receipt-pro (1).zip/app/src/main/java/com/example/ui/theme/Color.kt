package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ExpressRed = Color(0xFFDC2626)
val ExpressRedDark = Color(0xFF991B1B)
val ExpressNavy = Color(0xFF0F172A)
val ExpressSlate = Color(0xFF1E293B)
val ExpressCardBg = Color(0xFFFFFFFF)
val ExpressSurface = Color(0xFFF8FAFC)
val ExpressBorder = Color(0xFFE2E8F0)

val AccentTeal = Color(0xFF0EA5E9)
val AccentGreen = Color(0xFF10B981)
val AccentAmber = Color(0xFFF59E0B)

val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF151D2C)
val DarkBorder = Color(0xFF233045)
