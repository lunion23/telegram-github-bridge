package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.WorkOrderItem

@Database(
    entities = [WorkOrderItem::class],
    version = 1,
    exportSchema = false
)
abstract class WorkOrderDatabase : RoomDatabase() {

    abstract fun workOrderDao(): WorkOrderDao

    companion object {
        @Volatile
        private var INSTANCE: WorkOrderDatabase? = null

        fun getInstance(context: Context): WorkOrderDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    WorkOrderDatabase::class.java,
                    "fleet_work_orders.db"
                )
                    .setJournalMode(JournalMode.WRITE_AHEAD_LOGGING)
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
