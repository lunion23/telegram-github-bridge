package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "csv_rows",
    indices = [
        Index(value = ["recordId"]),
        Index(value = ["col0"]),
        Index(value = ["col1"]),
        Index(value = ["col2"]),
        Index(value = ["col3"]),
        Index(value = ["col9"])
    ]
)
data class CsvRowEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val datasetId: String = "default",
    val recordId: String = "",
    val col0: String = "",
    val col1: String = "",
    val col2: String = "",
    val col3: String = "",
    val col4: String = "",
    val col5: String = "",
    val col6: String = "",
    val col7: String = "",
    val col8: String = "",
    val col9: String = "",
    val col10: String = "",
    val col11: String = "",
    val col12: String = "",
    val col13: String = "",
    val col14: String = "",
    val col15: String = "",
    val col16: String = "",
    val col17: String = "",
    val col18: String = "",
    val col19: String = "",
    val extraData: String = "", // Delimited storage for col20+
    val createdAt: Long = System.currentTimeMillis()
) {
    fun getCell(index: Int): String {
        return when (index) {
            0 -> col0
            1 -> col1
            2 -> col2
            3 -> col3
            4 -> col4
            5 -> col5
            6 -> col6
            7 -> col7
            8 -> col8
            9 -> col9
            10 -> col10
            11 -> col11
            12 -> col12
            13 -> col13
            14 -> col14
            15 -> col15
            16 -> col16
            17 -> col17
            18 -> col18
            19 -> col19
            else -> {
                val extras = extraData.split("\u001F")
                val extraIdx = index - 20
                if (extraIdx in extras.indices) extras[extraIdx] else ""
            }
        }
    }

    fun withCell(index: Int, value: String): CsvRowEntity {
        return when (index) {
            0 -> copy(col0 = value, recordId = if (recordId.isEmpty() || recordId == col0) value else recordId)
            1 -> copy(col1 = value)
            2 -> copy(col2 = value)
            3 -> copy(col3 = value)
            4 -> copy(col4 = value)
            5 -> copy(col5 = value)
            6 -> copy(col6 = value)
            7 -> copy(col7 = value)
            8 -> copy(col8 = value)
            9 -> copy(col9 = value)
            10 -> copy(col10 = value)
            11 -> copy(col11 = value)
            12 -> copy(col12 = value)
            13 -> copy(col13 = value)
            14 -> copy(col14 = value)
            15 -> copy(col15 = value)
            16 -> copy(col16 = value)
            17 -> copy(col17 = value)
            18 -> copy(col18 = value)
            19 -> copy(col19 = value)
            else -> {
                val extraIdx = index - 20
                val extras = extraData.split("\u001F").toMutableList()
                while (extras.size <= extraIdx) extras.add("")
                extras[extraIdx] = value
                copy(extraData = extras.joinToString("\u001F"))
            }
        }
    }

    fun toList(maxColumns: Int = 10): List<String> {
        val list = mutableListOf<String>()
        for (i in 0 until maxColumns) {
            list.add(getCell(i))
        }
        return list
    }

    companion object {
        fun fromList(values: List<String>, id: Long = 0, datasetId: String = "default"): CsvRowEntity {
            val c0 = values.getOrNull(0)?.trim() ?: ""
            val c1 = values.getOrNull(1)?.trim() ?: ""
            val c2 = values.getOrNull(2)?.trim() ?: ""
            val c3 = values.getOrNull(3)?.trim() ?: ""
            val c4 = values.getOrNull(4)?.trim() ?: ""
            val c5 = values.getOrNull(5)?.trim() ?: ""
            val c6 = values.getOrNull(6)?.trim() ?: ""
            val c7 = values.getOrNull(7)?.trim() ?: ""
            val c8 = values.getOrNull(8)?.trim() ?: ""
            val c9 = values.getOrNull(9)?.trim() ?: ""
            val c10 = values.getOrNull(10)?.trim() ?: ""
            val c11 = values.getOrNull(11)?.trim() ?: ""
            val c12 = values.getOrNull(12)?.trim() ?: ""
            val c13 = values.getOrNull(13)?.trim() ?: ""
            val c14 = values.getOrNull(14)?.trim() ?: ""
            val c15 = values.getOrNull(15)?.trim() ?: ""
            val c16 = values.getOrNull(16)?.trim() ?: ""
            val c17 = values.getOrNull(17)?.trim() ?: ""
            val c18 = values.getOrNull(18)?.trim() ?: ""
            val c19 = values.getOrNull(19)?.trim() ?: ""
            val extras = if (values.size > 20) {
                values.subList(20, values.size).joinToString("\u001F") { it.trim() }
            } else ""

            return CsvRowEntity(
                id = id,
                datasetId = datasetId,
                recordId = c0,
                col0 = c0,
                col1 = c1,
                col2 = c2,
                col3 = c3,
                col4 = c4,
                col5 = c5,
                col6 = c6,
                col7 = c7,
                col8 = c8,
                col9 = c9,
                col10 = c10,
                col11 = c11,
                col12 = c12,
                col13 = c13,
                col14 = c14,
                col15 = c15,
                col16 = c16,
                col17 = c17,
                col18 = c18,
                col19 = c19,
                extraData = extras
            )
        }
    }
}
