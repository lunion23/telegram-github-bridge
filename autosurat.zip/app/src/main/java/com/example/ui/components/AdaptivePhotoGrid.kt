package com.example.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

@Composable
fun AdaptivePhotoSection(
    photos: List<String>,
    onAddPhotos: (List<String>) -> Unit,
    onRemovePhoto: (Int) -> Unit,
    onClearAll: () -> Unit
) {
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 4)
    ) { uris ->
        if (uris.isNotEmpty()) {
            val newPaths = uris.map { it.toString() }
            onAddPhotos(newPaths)
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .testTag("photo_section_card"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Foto Kerusakan (Maks 4 Foto)",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Tata letak adaptif otomatis mengisi bingkai tanpa celah kosong",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Adaptive Preview Box (matching document aspect ratio ~4:3)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(4f / 3f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White)
                    .border(2.dp, Color.Black, RoundedCornerShape(8.dp))
                    .testTag("adaptive_photo_frame")
            ) {
                if (photos.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .clickable {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = "Pilih foto kerusakan",
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Ketuk untuk memilih foto kerusakan",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Mendukung 1, 2 (berdampingan), 3, atau 4 (grid 2x2)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }
                } else {
                    AdaptiveLayoutGrid(photos = photos, onRemovePhoto = onRemovePhoto)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier.testTag("add_photo_btn")
                ) {
                    Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (photos.isEmpty()) "Pilih Foto" else "Ubah / Tambah Foto")
                }

                if (photos.isNotEmpty()) {
                    OutlinedButton(
                        onClick = onClearAll,
                        modifier = Modifier.testTag("clear_photos_btn")
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Hapus Semua")
                    }
                }
            }
        }
    }
}

@Composable
private fun AdaptiveLayoutGrid(photos: List<String>, onRemovePhoto: (Int) -> Unit) {
    val count = photos.size
    when {
        count == 1 -> {
            PhotoItemWithBadge(uri = photos[0], index = 0, onRemove = { onRemovePhoto(0) }, modifier = Modifier.fillMaxSize())
        }
        count == 2 -> {
            Row(modifier = Modifier.fillMaxSize()) {
                PhotoItemWithBadge(
                    uri = photos[0],
                    index = 0,
                    onRemove = { onRemovePhoto(0) },
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .border(width = 0.5.dp, color = Color.Black)
                )
                PhotoItemWithBadge(
                    uri = photos[1],
                    index = 1,
                    onRemove = { onRemovePhoto(1) },
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .border(width = 0.5.dp, color = Color.Black)
                )
            }
        }
        count == 3 -> {
            Column(modifier = Modifier.fillMaxSize()) {
                PhotoItemWithBadge(
                    uri = photos[0],
                    index = 0,
                    onRemove = { onRemovePhoto(0) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .border(width = 0.5.dp, color = Color.Black)
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    PhotoItemWithBadge(
                        uri = photos[1],
                        index = 1,
                        onRemove = { onRemovePhoto(1) },
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .border(width = 0.5.dp, color = Color.Black)
                    )
                    PhotoItemWithBadge(
                        uri = photos[2],
                        index = 2,
                        onRemove = { onRemovePhoto(2) },
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .border(width = 0.5.dp, color = Color.Black)
                    )
                }
            }
        }
        else -> {
            // 4 photos (2x2 grid)
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    PhotoItemWithBadge(
                        uri = photos[0],
                        index = 0,
                        onRemove = { onRemovePhoto(0) },
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .border(width = 0.5.dp, color = Color.Black)
                    )
                    PhotoItemWithBadge(
                        uri = photos[1],
                        index = 1,
                        onRemove = { onRemovePhoto(1) },
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .border(width = 0.5.dp, color = Color.Black)
                    )
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    PhotoItemWithBadge(
                        uri = photos[2],
                        index = 2,
                        onRemove = { onRemovePhoto(2) },
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .border(width = 0.5.dp, color = Color.Black)
                    )
                    PhotoItemWithBadge(
                        uri = photos[3],
                        index = 3,
                        onRemove = { onRemovePhoto(3) },
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .border(width = 0.5.dp, color = Color.Black)
                    )
                }
            }
        }
    }
}

@Composable
private fun PhotoItemWithBadge(
    uri: String,
    index: Int,
    onRemove: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier) {
        AsyncImage(
            model = uri,
            contentDescription = "Foto kerusakan ${index + 1}",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        IconButton(
            onClick = onRemove,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(4.dp)
                .size(28.dp)
                .background(Color.Black.copy(alpha = 0.6f), CircleShape)
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Hapus foto",
                tint = Color.White,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
