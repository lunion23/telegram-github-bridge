package com.example.data.model

import java.util.UUID

data class Note(
    val id: String = UUID.randomUUID().toString(),
    val userId: String = "",
    val title: String = "",
    val content: String = "",
    val tags: List<String> = emptyList(),
    val isPinned: Boolean = false,
    val fileExtension: String = "txt",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isSynced: Boolean = false
) {
    val wordCount: Int
        get() = if (content.isBlank()) 0 else content.trim().split("\\s+".toRegex()).size

    val charCount: Int
        get() = content.length

    val lineCount: Int
        get() = if (content.isEmpty()) 0 else content.lines().size

    val readingTimeMinutes: Int
        get() = maxOf(1, (wordCount / 200))
}
