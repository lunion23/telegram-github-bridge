package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RawQuery
import androidx.sqlite.db.SupportSQLiteQuery
import com.example.data.model.WorkOrderItem
import com.example.data.model.WorkOrderSummary
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkOrderDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBatch(items: List<WorkOrderItem>)

    @Query("DELETE FROM work_order_items")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM work_order_items")
    fun getItemCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM work_order_items")
    suspend fun getItemCount(): Int

    @Query("SELECT COUNT(DISTINCT name) FROM work_order_items")
    suspend fun getDistinctWoCount(): Int

    @Query("SELECT COUNT(DISTINCT mobilName) FROM work_order_items")
    suspend fun getDistinctVehicleCount(): Int

    @Query("SELECT COALESCE(SUM(totalPrice), 0.0) FROM work_order_items")
    suspend fun getTotalExpenditure(): Double

    @Query("SELECT COALESCE(SUM(totalPrice), 0.0) FROM work_order_items WHERE LOWER(tipe) LIKE '%part%'")
    suspend fun getTotalPartExpenditure(): Double

    @Query("SELECT COALESCE(SUM(totalPrice), 0.0) FROM work_order_items WHERE LOWER(tipe) LIKE '%jasa%'")
    suspend fun getTotalJasaExpenditure(): Double

    @Query("SELECT * FROM work_order_items WHERE name = :woName ORDER BY id ASC")
    suspend fun getItemsForWorkOrder(woName: String): List<WorkOrderItem>

    @Query("SELECT DISTINCT tipe FROM work_order_items WHERE tipe != '' ORDER BY tipe ASC")
    fun getDistinctTypes(): Flow<List<String>>

    @Query("SELECT DISTINCT productClass FROM work_order_items WHERE productClass != '' ORDER BY productClass ASC")
    fun getDistinctProductClasses(): Flow<List<String>>

    @RawQuery
    suspend fun getGroupedWorkOrdersRaw(query: SupportSQLiteQuery): List<WorkOrderSummary>

    @RawQuery
    suspend fun getItemsRaw(query: SupportSQLiteQuery): List<WorkOrderItem>

    @RawQuery
    suspend fun countFilteredItemsRaw(query: SupportSQLiteQuery): Int

    @RawQuery
    suspend fun countFilteredGroupedRaw(query: SupportSQLiteQuery): Int

    @Query("SELECT id, name, kode, description, tipe FROM work_order_items WHERE name IN (:names)")
    suspend fun getExistingItemKeys(names: List<String>): List<ExistingItemKey>
}

data class ExistingItemKey(
    val id: Long,
    val name: String,
    val kode: String,
    val description: String,
    val tipe: String
)
