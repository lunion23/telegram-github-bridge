package com.example

import com.example.data.analyzer.VideoAnalyzerEngine
import com.example.data.model.VideoMoment
import com.example.data.model.VideoSourceType
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testYouTubeVideoIdExtraction() {
        val standardUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
        val extracted1 = VideoAnalyzerEngine.extractYouTubeVideoId(standardUrl)
        assertEquals("dQw4w9WgXcQ", extracted1)

        val shortUrl = "https://youtu.be/dQw4w9WgXcQ"
        val extracted2 = VideoAnalyzerEngine.extractYouTubeVideoId(shortUrl)
        assertEquals("dQw4w9WgXcQ", extracted2)

        val shortsUrl = "https://youtube.com/shorts/dQw4w9WgXcQ"
        val extracted3 = VideoAnalyzerEngine.extractYouTubeVideoId(shortsUrl)
        assertEquals("dQw4w9WgXcQ", extracted3)
    }

    @Test
    fun testVideoMomentFormatTime() {
        assertEquals("00:00", VideoMoment.formatTime(0))
        assertEquals("00:35", VideoMoment.formatTime(35))
        assertEquals("01:15", VideoMoment.formatTime(75))
        assertEquals("10:05", VideoMoment.formatTime(605))
    }

    @Test
    fun testVideoAnalyzerEngineGeneratesCompleteData() {
        val result = VideoAnalyzerEngine.analyzeVideo(
            titleInput = "Test Podcast Kreator",
            source = "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
            sourceType = VideoSourceType.YOUTUBE,
            customDurationSec = 300,
            userNotes = "podcast tips algoritma"
        )

        assertNotNull(result)
        assertTrue(result.moments.isNotEmpty())
        assertTrue(result.hooks.isNotEmpty())
        assertTrue(result.titleSuggestions.isNotEmpty())
        assertTrue(result.socialCaptions.isNotEmpty())
        assertTrue(result.summaryPoints.isNotEmpty())
        assertTrue(result.audienceMetrics.overallScore > 0)
        assertTrue(result.seoData.primaryKeywords.isNotEmpty())
    }
}
