package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val StudioCyan = Color(0xFF00E5FF)
val StudioCyanDim = Color(0xFF00B0FF)
val StudioViolet = Color(0xFF7C4DFF)
val StudioVioletDark = Color(0xFF5E35B1)

val DarkBackground = Color(0xFF101216)
val DarkSurface = Color(0xFF181B22)
val DarkSurfaceVariant = Color(0xFF222630)
val DarkBorder = Color(0xFF2C3240)

val LightTextPrimary = Color(0xFFF0F3F8)
val LightTextSecondary = Color(0xFFA0AAB8)
val LightTextMuted = Color(0xFF6B7685)

val SuccessGreen = Color(0xFF00E676)
val WarningAmber = Color(0xFFFFB300)
val ErrorRed = Color(0xFFFF5252)
