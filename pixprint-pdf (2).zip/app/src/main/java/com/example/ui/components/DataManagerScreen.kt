package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BookmarkAdded
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.DriveFileRenameOutline
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.GeneratedPdfFileItem
import com.example.data.SavedLabelRecord
import com.example.model.ShippingLabelData
import com.example.viewmodel.DataManagerControlState
import com.example.viewmodel.DataManagerTab
import com.example.viewmodel.SavedLabelsStreamState
import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DataManagerScreen(
    streamState: SavedLabelsStreamState,
    controlState: DataManagerControlState,
    currentStudioLabel: ShippingLabelData,
    userEmail: String?,
    snackbarHostState: SnackbarHostState,
    onSelectTab: (DataManagerTab) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onPinnedFilterChange: (Boolean) -> Unit,
    onSaveStudioAsNew: () -> Unit,
    onUpdateActiveRecord: (SavedLabelRecord) -> Unit,
    onLoadRecordToStudio: (SavedLabelRecord) -> Unit,
    onPrintRecord: (SavedLabelRecord) -> Unit,
    onExportAndShareRecordPdf: (SavedLabelRecord) -> Unit,
    onTogglePin: (SavedLabelRecord) -> Unit,
    onRenameRecord: (SavedLabelRecord, String) -> Unit,
    onDuplicateRecord: (SavedLabelRecord) -> Unit,
    onDeleteRecord: (String) -> Unit,
    onGeneratePdfArchiveFromStudio: () -> Unit,
    onPrintLocalPdfFile: (GeneratedPdfFileItem) -> Unit,
    onShareLocalPdfFile: (GeneratedPdfFileItem) -> Unit,
    onDeleteLocalPdfFile: (GeneratedPdfFileItem) -> Unit,
    onClearAllLocalPdfs: () -> Unit,
    onSignOut: (() -> Unit)?,
    onClose: () -> Unit
) {
    BackHandler(onBack = onClose)

    var recordToRename by remember { mutableStateOf<SavedLabelRecord?>(null) }
    var renameInput by remember { mutableStateOf("") }

    val allRecords = when (streamState) {
        is SavedLabelsStreamState.Success -> streamState.records
        else -> emptyList()
    }
    val pinnedCount = remember(allRecords) { allRecords.count { it.pinned } }
    val activeRecord = remember(allRecords, controlState.activeRecordId) {
        allRecords.firstOrNull { it.id == controlState.activeRecordId }
    }

    val filteredRecords by remember(allRecords, controlState.searchQuery, controlState.pinnedOnly) {
        derivedStateOf {
            val q = controlState.searchQuery.trim().lowercase(Locale.ROOT)
            allRecords.filter { item ->
                val matchesPin = !controlState.pinnedOnly || item.pinned
                val matchesSearch = q.isEmpty() ||
                    item.title.lowercase(Locale.ROOT).contains(q) ||
                    item.waybillNumber.lowercase(Locale.ROOT).contains(q) ||
                    item.recipientName.lowercase(Locale.ROOT).contains(q) ||
                    item.senderName.lowercase(Locale.ROOT).contains(q) ||
                    item.destinationBanner.lowercase(Locale.ROOT).contains(q) ||
                    item.orderNumber.lowercase(Locale.ROOT).contains(q)
                matchesPin && matchesSearch
            }
        }
    }

    if (recordToRename != null) {
        val target = recordToRename!!
        AlertDialog(
            onDismissRequest = { recordToRename = null },
            title = { Text(stringResource(R.string.dialog_rename_title)) },
            text = {
                OutlinedTextField(
                    value = renameInput,
                    onValueChange = { renameInput = it },
                    label = { Text(stringResource(R.string.field_record_title)) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("rename_title_input")
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRenameRecord(target, renameInput)
                        recordToRename = null
                    },
                    modifier = Modifier.testTag("rename_confirm_button")
                ) {
                    Text(stringResource(R.string.action_save_changes))
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { recordToRename = null },
                    modifier = Modifier.testTag("rename_cancel_button")
                ) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.data_manager_title),
                                style = MaterialTheme.typography.titleLarge
                            )
                            if (!userEmail.isNullOrBlank()) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.secondaryContainer
                                ) {
                                    Text(
                                        text = userEmail,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier
                                            .widthIn(max = 150.dp)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = stringResource(R.string.data_manager_subtitle),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("data_manager_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back)
                        )
                    }
                },
                actions = {
                    if (onSignOut != null) {
                        IconButton(
                            onClick = onSignOut,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("data_manager_sign_out_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Outlined.Logout,
                                contentDescription = stringResource(R.string.cd_sign_out)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxSize()
            ) {
                TabRow(
                    selectedTabIndex = controlState.selectedTab.ordinal,
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    Tab(
                        selected = controlState.selectedTab == DataManagerTab.SAVED_LABELS,
                        onClick = { onSelectTab(DataManagerTab.SAVED_LABELS) },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("tab_saved_labels"),
                        text = {
                            Text(
                                text = stringResource(R.string.tab_saved_labels, allRecords.size),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    )
                    Tab(
                        selected = controlState.selectedTab == DataManagerTab.GENERATED_PDFS,
                        onClick = { onSelectTab(DataManagerTab.GENERATED_PDFS) },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("tab_generated_pdfs"),
                        text = {
                            Text(
                                text = stringResource(
                                    R.string.tab_generated_pdfs,
                                    controlState.pdfFiles.size
                                ),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    )
                }

                when (controlState.selectedTab) {
                    DataManagerTab.SAVED_LABELS -> {
                        SavedLabelsTabContent(
                            streamState = streamState,
                            filteredRecords = filteredRecords,
                            totalCount = allRecords.size,
                            pinnedCount = pinnedCount,
                            pdfFilesCount = controlState.pdfFiles.size,
                            currentStudioLabel = currentStudioLabel,
                            activeRecord = activeRecord,
                            isBusy = controlState.isSavingOrWorking,
                            activeRecordId = controlState.activeRecordId,
                            searchQuery = controlState.searchQuery,
                            pinnedOnly = controlState.pinnedOnly,
                            onSearchQueryChange = onSearchQueryChange,
                            onPinnedFilterChange = onPinnedFilterChange,
                            onSaveStudioAsNew = onSaveStudioAsNew,
                            onUpdateActiveRecord = { activeRecord?.let(onUpdateActiveRecord) },
                            onLoadRecord = onLoadRecordToStudio,
                            onPrintRecord = onPrintRecord,
                            onExportRecordPdf = onExportAndShareRecordPdf,
                            onTogglePin = onTogglePin,
                            onOpenRenameDialog = { rec ->
                                renameInput = rec.title
                                recordToRename = rec
                            },
                            onDuplicateRecord = onDuplicateRecord,
                            onDeleteRecord = onDeleteRecord
                        )
                    }

                    DataManagerTab.GENERATED_PDFS -> {
                        GeneratedPdfsTabContent(
                            pdfFiles = controlState.pdfFiles,
                            isBusy = controlState.isSavingOrWorking,
                            onGeneratePdfArchive = onGeneratePdfArchiveFromStudio,
                            onPrintFile = onPrintLocalPdfFile,
                            onShareFile = onShareLocalPdfFile,
                            onDeleteFile = onDeleteLocalPdfFile,
                            onClearAllFiles = onClearAllLocalPdfs
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StatSummaryPill(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = MaterialTheme.shapes.small,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ActiveStudioQuickSaveBanner(
    currentStudioLabel: ShippingLabelData,
    activeRecord: SavedLabelRecord?,
    isBusy: Boolean,
    onSaveAsNew: () -> Unit,
    onUpdateActive: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.BookmarkAdded,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.active_studio_banner_title),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${currentStudioLabel.waybillNumber} • ${currentStudioLabel.recipientName}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (activeRecord != null) {
                    Button(
                        onClick = onUpdateActive,
                        enabled = !isBusy,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("update_active_record_button")
                    ) {
                        Text(stringResource(R.string.action_update_in_manager))
                    }
                    FilledTonalButton(
                        onClick = onSaveAsNew,
                        enabled = !isBusy,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("save_new_record_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Add,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(stringResource(R.string.action_save_as_new))
                    }
                } else {
                    Button(
                        onClick = onSaveAsNew,
                        enabled = !isBusy,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("save_new_record_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Add,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(stringResource(R.string.action_save_to_manager))
                    }
                }
            }
        }
    }
}

@Composable
private fun SavedLabelsTabContent(
    streamState: SavedLabelsStreamState,
    filteredRecords: List<SavedLabelRecord>,
    totalCount: Int,
    pinnedCount: Int,
    pdfFilesCount: Int,
    currentStudioLabel: ShippingLabelData,
    activeRecord: SavedLabelRecord?,
    isBusy: Boolean,
    activeRecordId: String?,
    searchQuery: String,
    pinnedOnly: Boolean,
    onSearchQueryChange: (String) -> Unit,
    onPinnedFilterChange: (Boolean) -> Unit,
    onSaveStudioAsNew: () -> Unit,
    onUpdateActiveRecord: () -> Unit,
    onLoadRecord: (SavedLabelRecord) -> Unit,
    onPrintRecord: (SavedLabelRecord) -> Unit,
    onExportRecordPdf: (SavedLabelRecord) -> Unit,
    onTogglePin: (SavedLabelRecord) -> Unit,
    onOpenRenameDialog: (SavedLabelRecord) -> Unit,
    onDuplicateRecord: (SavedLabelRecord) -> Unit,
    onDeleteRecord: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("saved_labels_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "header_stats_and_quick_save") {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatSummaryPill(
                        label = stringResource(R.string.stats_total_saved),
                        value = totalCount.toString(),
                        modifier = Modifier.weight(1f)
                    )
                    StatSummaryPill(
                        label = stringResource(R.string.stats_pinned_saved),
                        value = pinnedCount.toString(),
                        modifier = Modifier.weight(1f)
                    )
                    StatSummaryPill(
                        label = stringResource(R.string.stats_pdf_files),
                        value = pdfFilesCount.toString(),
                        modifier = Modifier.weight(1f)
                    )
                }

                ActiveStudioQuickSaveBanner(
                    currentStudioLabel = currentStudioLabel,
                    activeRecord = activeRecord,
                    isBusy = isBusy,
                    onSaveAsNew = onSaveStudioAsNew,
                    onUpdateActive = onUpdateActiveRecord
                )
            }
        }

        item(key = "header_search_and_filter") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = { Text(stringResource(R.string.search_labels_placeholder)) },
                    leadingIcon = {
                        Icon(imageVector = Icons.Filled.Search, contentDescription = null)
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(
                                onClick = { onSearchQueryChange("") },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("clear_search_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Clear,
                                    contentDescription = stringResource(R.string.cd_clear_search)
                                )
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("data_manager_search_input")
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !pinnedOnly,
                        onClick = { onPinnedFilterChange(false) },
                        label = { Text(stringResource(R.string.filter_all_labels)) },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("filter_all_chip")
                    )
                    FilterChip(
                        selected = pinnedOnly,
                        onClick = { onPinnedFilterChange(!pinnedOnly) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.Star,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        label = { Text(stringResource(R.string.filter_pinned_only)) },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("filter_pinned_chip")
                    )
                }
            }
        }

        when (streamState) {
            is SavedLabelsStreamState.Loading -> {
                item(key = "state_loading") {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
            }

            is SavedLabelsStreamState.Error -> {
                item(key = "state_error") {
                    EmptyOrErrorStateCard(
                        title = stringResource(R.string.data_manager_title),
                        subtitle = streamState.message
                    )
                }
            }

            is SavedLabelsStreamState.Success -> {
                if (totalCount == 0) {
                    item(key = "state_empty") {
                        EmptyOrErrorStateCard(
                            title = stringResource(R.string.empty_labels_title),
                            subtitle = stringResource(R.string.empty_labels_subtitle),
                            actionLabel = stringResource(R.string.action_save_to_manager),
                            actionTestTag = "empty_save_first_label_button",
                            onAction = onSaveStudioAsNew
                        )
                    }
                } else if (filteredRecords.isEmpty()) {
                    item(key = "state_empty_search") {
                        EmptyOrErrorStateCard(
                            title = stringResource(R.string.empty_search_title),
                            subtitle = stringResource(R.string.empty_search_subtitle)
                        )
                    }
                } else {
                    items(filteredRecords, key = { it.id }) { record ->
                        SavedLabelRecordCard(
                            record = record,
                            isActiveInStudio = record.id == activeRecordId,
                            onLoadRecord = { onLoadRecord(record) },
                            onPrintRecord = { onPrintRecord(record) },
                            onExportRecordPdf = { onExportRecordPdf(record) },
                            onTogglePin = { onTogglePin(record) },
                            onRename = { onOpenRenameDialog(record) },
                            onDuplicate = { onDuplicateRecord(record) },
                            onDelete = { onDeleteRecord(record.id) }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SavedLabelRecordCard(
    record: SavedLabelRecord,
    isActiveInStudio: Boolean,
    onLoadRecord: () -> Unit,
    onPrintRecord: () -> Unit,
    onExportRecordPdf: () -> Unit,
    onTogglePin: () -> Unit,
    onRename: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    val displayTime = remember(record.updatedAt, record.createdAt) {
        val ts = record.updatedAt ?: record.createdAt ?: Timestamp(0, 0)
        if (ts.seconds == 0L) "" else formatEpochMillis(ts.toDate().time)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("saved_label_card_${record.id}"),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = if (isActiveInStudio) {
            BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
        } else {
            BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
        },
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Text(
                            text = record.waybillNumber,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer
                    ) {
                        Text(
                            text = record.paperPresetName.replace('_', ' '),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }

                IconButton(
                    onClick = onTogglePin,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("pin_label_button_${record.id}")
                ) {
                    Icon(
                        imageVector = if (record.pinned) Icons.Filled.Star else Icons.Outlined.StarOutline,
                        contentDescription = stringResource(R.string.cd_pin_record),
                        tint = if (record.pinned) {
                            MaterialTheme.colorScheme.tertiary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }
            }

            Text(
                text = record.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = buildString {
                    append("${record.recipientName}")
                    if (record.destinationBanner.isNotBlank()) {
                        append(" (${record.destinationBanner})")
                    }
                    if (record.senderName.isNotBlank()) {
                        append(" • Dari: ${record.senderName}")
                    }
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${record.shippingFeeAmount} • ${record.paymentMethod} • ${record.weight}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (displayTime.isNotBlank()) {
                    Text(
                        text = displayTime,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onLoadRecord,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("load_label_button_${record.id}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.FolderOpen,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.action_load_to_studio))
                }

                FilledTonalButton(
                    onClick = onPrintRecord,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("print_saved_label_button_${record.id}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Print,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.action_print_now))
                }

                OutlinedButton(
                    onClick = onExportRecordPdf,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("export_saved_label_button_${record.id}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.PictureAsPdf,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.action_export_share_pdf))
                }

                IconButton(
                    onClick = onRename,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("rename_label_button_${record.id}")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.DriveFileRenameOutline,
                        contentDescription = stringResource(R.string.action_rename_record)
                    )
                }

                IconButton(
                    onClick = onDuplicate,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("duplicate_label_button_${record.id}")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ContentCopy,
                        contentDescription = stringResource(R.string.action_duplicate_record)
                    )
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("delete_label_button_${record.id}")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.DeleteOutline,
                        contentDescription = stringResource(R.string.action_delete_record),
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}

@Composable
private fun GeneratedPdfsTabContent(
    pdfFiles: List<GeneratedPdfFileItem>,
    isBusy: Boolean,
    onGeneratePdfArchive: () -> Unit,
    onPrintFile: (GeneratedPdfFileItem) -> Unit,
    onShareFile: (GeneratedPdfFileItem) -> Unit,
    onDeleteFile: (GeneratedPdfFileItem) -> Unit,
    onClearAllFiles: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = onGeneratePdfArchive,
                enabled = !isBusy,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("generate_local_pdf_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.PictureAsPdf,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(stringResource(R.string.action_generate_pdf_archive))
            }

            if (pdfFiles.isNotEmpty()) {
                OutlinedButton(
                    onClick = onClearAllFiles,
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("clear_all_pdfs_button")
                ) {
                    Text(stringResource(R.string.action_clear_all_pdfs))
                }
            }
        }

        if (pdfFiles.isEmpty()) {
            EmptyOrErrorStateCard(
                title = stringResource(R.string.empty_pdfs_title),
                subtitle = stringResource(R.string.empty_pdfs_subtitle)
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("generated_pdfs_list"),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(pdfFiles, key = { _, item -> item.file.absolutePath }) { idx, pdf ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pdf_file_card_$idx"),
                        shape = MaterialTheme.shapes.medium,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Description,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = pdf.name,
                                    style = MaterialTheme.typography.titleSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${formatFileSize(pdf.sizeBytes)} • ${formatEpochMillis(pdf.lastModifiedMillis)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = { onPrintFile(pdf) },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("print_pdf_file_button_$idx")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Print,
                                    contentDescription = stringResource(R.string.cd_print_pdf)
                                )
                            }
                            IconButton(
                                onClick = { onShareFile(pdf) },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("share_pdf_file_button_$idx")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Share,
                                    contentDescription = stringResource(R.string.cd_share_pdf)
                                )
                            }
                            IconButton(
                                onClick = { onDeleteFile(pdf) },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("delete_pdf_file_button_$idx")
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.DeleteOutline,
                                    contentDescription = stringResource(R.string.action_delete_record),
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyOrErrorStateCard(
    title: String,
    subtitle: String,
    actionLabel: String? = null,
    actionTestTag: String = "empty_state_action",
    onAction: (() -> Unit)? = null
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.widthIn(max = 380.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Outlined.Inventory2,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(48.dp)
            )
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            if (actionLabel != null && onAction != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Button(
                    onClick = onAction,
                    modifier = Modifier
                        .height(48.dp)
                        .testTag(actionTestTag)
                ) {
                    Text(actionLabel)
                }
            }
        }
    }
}

private fun formatFileSize(bytes: Long): String {
    return if (bytes >= 1024 * 1024) {
        String.format(Locale.US, "%.2f MB", bytes / (1024f * 1024f))
    } else {
        val kb = (bytes / 1024f).coerceAtLeast(1f)
        String.format(Locale.US, "%.1f KB", kb)
    }
}

private fun formatEpochMillis(millis: Long): String {
    return runCatching {
        SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.forLanguageTag("id-ID")).format(Date(millis))
    }.getOrDefault("")
}
