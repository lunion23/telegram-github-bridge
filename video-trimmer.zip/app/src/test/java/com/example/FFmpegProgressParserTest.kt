package com.example

import com.example.ffmpeg.FFmpegProgressParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * Unit test untuk memverifikasi logika parsing 'time=' dan perhitungan persentase FFmpeg.
 */
class FFmpegProgressParserTest {

    @Test
    fun parseTimeSeconds_standardFfmpegLine_parsesCorrectly() {
        val sampleLine = "frame=  120 fps=0.0 q=-1.0 size=    1024kB time=00:00:04.50 bitrate=1864.2kbits/s speed=8.95x"
        val timeSeconds = FFmpegProgressParser.parseTimeSeconds(sampleLine)

        assertNotNull("Harus berhasil mengekstrak waktu dari log FFmpeg standar", timeSeconds)
        assertEquals(4.5, timeSeconds!!, 0.001)
    }

    @Test
    fun parseTimeSeconds_hoursMinutesFormat_parsesCorrectly() {
        val sampleLine = "frame= 5000 fps=60.0 q=-1.0 size=   45000kB time=01:15:30.25 bitrate=820.0kbits/s speed=2.5x"
        val timeSeconds = FFmpegProgressParser.parseTimeSeconds(sampleLine)

        // 1 hour (3600) + 15 min (900) + 30.25 sec = 4530.25
        val expected = (1 * 3600.0) + (15 * 60.0) + 30.25
        assertNotNull(timeSeconds)
        assertEquals(expected, timeSeconds!!, 0.001)
    }

    @Test
    fun parseTimeSeconds_nonProgressLine_returnsNull() {
        val headerLine = "Input #0, mov,mp4,m4a,3gp, from 'input.mp4':"
        assertNull(FFmpegProgressParser.parseTimeSeconds(headerLine))

        val streamLine = "  Stream #0:0(und): Video: h264 (High) (avc1 / 0x31637661), yuv420p, 1920x1080"
        assertNull(FFmpegProgressParser.parseTimeSeconds(streamLine))
    }

    @Test
    fun calculateProgressPercent_calculatesPercentageAccurately() {
        // 5 detik dari target 10 detik = 50%
        val percent = FFmpegProgressParser.calculateProgressPercent(
            currentTimeSec = 5.0,
            trimStartSec = 0.0,
            targetDurationSec = 10.0
        )
        assertEquals(50, percent)
    }

    @Test
    fun calculateProgressPercent_withStartOffset_calculatesAccurately() {
        // Pemotongan dari detik 10 s/d 20 (durasi target 10 detik)
        // Posisi log saat ini detik 15 = 5 detik diproses = 50%
        val percent = FFmpegProgressParser.calculateProgressPercent(
            currentTimeSec = 15.0,
            trimStartSec = 10.0,
            targetDurationSec = 10.0
        )
        assertEquals(50, percent)
    }

    @Test
    fun calculateProgressPercent_clampedBetween0And100() {
        val overflow = FFmpegProgressParser.calculateProgressPercent(
            currentTimeSec = 15.0,
            trimStartSec = 0.0,
            targetDurationSec = 10.0
        )
        assertEquals(100, overflow)

        val zeroDuration = FFmpegProgressParser.calculateProgressPercent(
            currentTimeSec = 5.0,
            trimStartSec = 0.0,
            targetDurationSec = 0.0
        )
        assertEquals(0, zeroDuration)
    }
}
