package com.example.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.AutoFixHigh
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.RestartAlt
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.model.PaperSizePreset
import com.example.model.PdfRenderSource
import com.example.ui.components.LabelDataEditorScreen
import com.example.ui.components.LabelPreviewStage
import com.example.ui.components.ZoomablePreviewDialog
import com.example.viewmodel.ShippingLabelUiState
import com.example.viewmodel.ShippingLabelViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShippingLabelScreen(
    viewModel: ShippingLabelViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    val sanitizedWaybill = remember(uiState.labelData.waybillNumber) {
        uiState.labelData.waybillNumber
            .replace(Regex("[^A-Za-z0-9_-]"), "_")
            .ifBlank { "Resi" }
    }
    val suggestedPdfFileName = "Resi_${sanitizedWaybill}.pdf"

    val savePdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) {
            viewModel.savePdfToUri(
                context = context,
                destinationUri = uri,
                displayFileName = suggestedPdfFileName
            )
        }
    }

    LaunchedEffect(uiState.snackbarMessage) {
        val message = uiState.snackbarMessage
        if (message != null) {
            snackbarHostState.showSnackbar(message)
            viewModel.clearSnackbarMessage()
        }
    }

    if (uiState.isEditorOpen) {
        LabelDataEditorScreen(
            data = uiState.labelData,
            onUpdateData = viewModel::updateLabelData,
            onResetSample = viewModel::resetToSampleData,
            onClose = { viewModel.setEditorOpen(false) }
        )
        return
    }

    if (uiState.isZoomDialogOpen) {
        ZoomablePreviewDialog(
            previewBitmap = uiState.previewBitmap,
            onDismiss = { viewModel.setZoomDialogOpen(false) }
        )
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.header_title),
                                style = MaterialTheme.typography.titleLarge
                            )
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Text(
                                    text = stringResource(R.string.badge_vector_ready),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = stringResource(R.string.header_subtitle),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.setEditorOpen(true) },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("top_edit_data_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.EditNote,
                            contentDescription = stringResource(R.string.cd_edit_label_data)
                        )
                    }
                    IconButton(
                        onClick = viewModel::resetToSampleData,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("top_reset_data_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.RestartAlt,
                            contentDescription = stringResource(R.string.cd_reset_label_data)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            BoxWithConstraints {
                if (maxWidth < 720.dp) {
                    BottomPrintActionBar(
                        isGenerating = uiState.isGeneratingPdf,
                        onPrintClick = { viewModel.printPdf(context) },
                        onSaveClick = { savePdfLauncher.launch(suggestedPdfFileName) },
                        onShareClick = { viewModel.sharePdf(context) }
                    )
                }
            }
        }
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val isWideScreen = maxWidth >= 720.dp

            if (isWideScreen) {
                // Canonical 2-Pane Split Layout for Tablets, Foldables & Landscape
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1.05f)
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState())
                    ) {
                        LabelPreviewStage(
                            previewBitmap = uiState.previewBitmap,
                            referenceBitmap = uiState.referenceBitmap,
                            paperPreset = uiState.paperPreset,
                            displayMode = uiState.previewDisplayMode,
                            onSelectDisplayMode = viewModel::selectPreviewDisplayMode,
                            onOpenZoom = { viewModel.setZoomDialogOpen(true) }
                        )
                    }

                    Column(
                        modifier = Modifier
                            .weight(0.95f)
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        WideActionPanel(
                            isGenerating = uiState.isGeneratingPdf,
                            onPrintClick = { viewModel.printPdf(context) },
                            onSaveClick = { savePdfLauncher.launch(suggestedPdfFileName) },
                            onShareClick = { viewModel.sharePdf(context) }
                        )
                        ConfigurationCards(
                            uiState = uiState,
                            onEditClick = { viewModel.setEditorOpen(true) },
                            onSelectPreset = viewModel::selectPaperPreset,
                            onSelectRenderSource = viewModel::selectRenderSource
                        )
                    }
                }
            } else {
                // Compact Mobile Layout
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .widthIn(max = 600.dp)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        LabelPreviewStage(
                            previewBitmap = uiState.previewBitmap,
                            referenceBitmap = uiState.referenceBitmap,
                            paperPreset = uiState.paperPreset,
                            displayMode = uiState.previewDisplayMode,
                            onSelectDisplayMode = viewModel::selectPreviewDisplayMode,
                            onOpenZoom = { viewModel.setZoomDialogOpen(true) }
                        )

                        ConfigurationCards(
                            uiState = uiState,
                            onEditClick = { viewModel.setEditorOpen(true) },
                            onSelectPreset = viewModel::selectPaperPreset,
                            onSelectRenderSource = viewModel::selectRenderSource
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ConfigurationCards(
    uiState: ShippingLabelUiState,
    onEditClick: () -> Unit,
    onSelectPreset: (PaperSizePreset) -> Unit,
    onSelectRenderSource: (PdfRenderSource) -> Unit
) {
    // Summary & Quick Edit Card
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${uiState.labelData.routingCode} • ${uiState.labelData.waybillNumber}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${uiState.labelData.recipientName} (${uiState.labelData.destinationBanner})",
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = "${uiState.labelData.shippingFeeAmount} • ${uiState.labelData.paymentMethod} • ${uiState.labelData.weight}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            FilledTonalButton(
                onClick = onEditClick,
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("edit_label_data_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.EditNote,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(stringResource(R.string.action_edit_data))
            }
        }
    }

    // Paper Size Selector Card
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = stringResource(R.string.section_paper_size),
                style = MaterialTheme.typography.titleSmall
            )

            PaperPresetOptionRow(
                title = stringResource(R.string.paper_thermal_100x200),
                subtitle = stringResource(R.string.paper_thermal_100x200_desc),
                selected = uiState.paperPreset == PaperSizePreset.THERMAL_100X200,
                onClick = { onSelectPreset(PaperSizePreset.THERMAL_100X200) },
                testTag = "preset_thermal_100x200"
            )
            PaperPresetOptionRow(
                title = stringResource(R.string.paper_thermal_78x150),
                subtitle = stringResource(R.string.paper_thermal_78x150_desc),
                selected = uiState.paperPreset == PaperSizePreset.THERMAL_78X150,
                onClick = { onSelectPreset(PaperSizePreset.THERMAL_78X150) },
                testTag = "preset_thermal_78x150"
            )
            PaperPresetOptionRow(
                title = stringResource(R.string.paper_a6),
                subtitle = stringResource(R.string.paper_a6_desc),
                selected = uiState.paperPreset == PaperSizePreset.A6_PORTRAIT,
                onClick = { onSelectPreset(PaperSizePreset.A6_PORTRAIT) },
                testTag = "preset_a6"
            )
            PaperPresetOptionRow(
                title = stringResource(R.string.paper_a4),
                subtitle = stringResource(R.string.paper_a4_desc),
                selected = uiState.paperPreset == PaperSizePreset.A4_ACTUAL_SIZE,
                onClick = { onSelectPreset(PaperSizePreset.A4_ACTUAL_SIZE) },
                testTag = "preset_a4"
            )
        }
    }

    // Render Source Selector Card
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = stringResource(R.string.section_render_mode),
                style = MaterialTheme.typography.titleSmall
            )

            RenderSourceOptionCard(
                icon = Icons.Outlined.AutoFixHigh,
                title = stringResource(R.string.render_mode_vector_title),
                subtitle = stringResource(R.string.render_mode_vector_desc),
                selected = uiState.renderSource == PdfRenderSource.VECTOR_RECONSTRUCTION,
                onClick = { onSelectRenderSource(PdfRenderSource.VECTOR_RECONSTRUCTION) },
                testTag = "render_source_vector"
            )

            if (uiState.referenceBitmap != null) {
                RenderSourceOptionCard(
                    icon = Icons.Outlined.Image,
                    title = stringResource(R.string.render_mode_image_title),
                    subtitle = stringResource(R.string.render_mode_image_desc),
                    selected = uiState.renderSource == PdfRenderSource.ORIGINAL_REFERENCE_IMAGE,
                    onClick = { onSelectRenderSource(PdfRenderSource.ORIGINAL_REFERENCE_IMAGE) },
                    testTag = "render_source_original_image"
                )
            }
        }
    }
}

@Composable
private fun PaperPresetOptionRow(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        shape = MaterialTheme.shapes.small,
        color = if (selected) {
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
        } else {
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
        },
        border = if (selected) {
            BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
        } else {
            null
        },
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = selected,
                onClick = onClick,
                modifier = Modifier.minimumInteractiveComponentSize()
            )
            Spacer(modifier = Modifier.width(6.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun RenderSourceOptionCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        shape = MaterialTheme.shapes.small,
        color = if (selected) {
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
        } else {
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
        },
        border = if (selected) {
            BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
        } else {
            null
        },
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            RadioButton(
                selected = selected,
                onClick = onClick,
                modifier = Modifier.minimumInteractiveComponentSize()
            )
        }
    }
}

@Composable
private fun BottomPrintActionBar(
    isGenerating: Boolean,
    onPrintClick: () -> Unit,
    onSaveClick: () -> Unit,
    onShareClick: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        shadowElevation = 10.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = onPrintClick,
                enabled = !isGenerating,
                modifier = Modifier
                    .weight(1.35f)
                    .height(50.dp)
                    .testTag("print_pdf_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Print,
                    contentDescription = stringResource(R.string.cd_print_pdf),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.action_print_pdf),
                    style = MaterialTheme.typography.labelLarge
                )
            }

            FilledTonalButton(
                onClick = onSaveClick,
                enabled = !isGenerating,
                contentPadding = PaddingValues(horizontal = 12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .testTag("save_pdf_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Download,
                    contentDescription = stringResource(R.string.cd_save_pdf),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = stringResource(R.string.action_save_pdf),
                    style = MaterialTheme.typography.labelLarge
                )
            }

            OutlinedButton(
                onClick = onShareClick,
                enabled = !isGenerating,
                contentPadding = PaddingValues(horizontal = 12.dp),
                modifier = Modifier
                    .height(50.dp)
                    .minimumInteractiveComponentSize()
                    .testTag("share_pdf_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Share,
                    contentDescription = stringResource(R.string.cd_share_pdf),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
private fun WideActionPanel(
    isGenerating: Boolean,
    onPrintClick: () -> Unit,
    onSaveClick: () -> Unit,
    onShareClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onPrintClick,
                enabled = !isGenerating,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("print_pdf_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Print,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(stringResource(R.string.action_print_pdf))
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FilledTonalButton(
                    onClick = onSaveClick,
                    enabled = !isGenerating,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("save_pdf_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Download,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.action_save_pdf))
                }

                OutlinedButton(
                    onClick = onShareClick,
                    enabled = !isGenerating,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("share_pdf_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Share,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.action_share_pdf))
                }
            }
        }
    }
}
