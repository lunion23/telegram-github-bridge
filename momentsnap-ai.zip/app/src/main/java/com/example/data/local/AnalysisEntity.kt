package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.*
import org.json.JSONArray
import org.json.JSONObject

@Entity(tableName = "saved_analyses")
data class SavedAnalysisEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val sourceUriOrUrl: String,
    val sourceType: String,
    val durationSeconds: Int,
    val thumbnailUrl: String,
    val summaryPointsRaw: String, // JSON array string
    val momentsRaw: String, // JSON array string
    val hooksRaw: String, // JSON array string
    val titleSuggestionsRaw: String, // JSON array string
    val socialCaptionsRaw: String, // JSON array string
    val audienceMetricsRaw: String, // JSON object string
    val seoDataRaw: String, // JSON object string
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toDomain(): VideoAnalysisResult {
        // Parse summary points
        val summaries = mutableListOf<String>()
        runCatching {
            val arr = JSONArray(summaryPointsRaw)
            for (i in 0 until arr.length()) {
                summaries.add(arr.getString(i))
            }
        }

        // Parse moments
        val momentList = mutableListOf<VideoMoment>()
        runCatching {
            val arr = JSONArray(momentsRaw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                momentList.add(
                    VideoMoment(
                        id = obj.optString("id", i.toString()),
                        startSecond = obj.optInt("startSecond", 0),
                        endSecond = obj.optInt("endSecond", 30),
                        title = obj.optString("title", ""),
                        keyQuoteOrText = obj.optString("keyQuoteOrText", ""),
                        reasonWhyViral = obj.optString("reasonWhyViral", ""),
                        viralScore = obj.optInt("viralScore", 80)
                    )
                )
            }
        }

        // Parse hooks
        val hookList = mutableListOf<VideoHook>()
        runCatching {
            val arr = JSONArray(hooksRaw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                hookList.add(
                    VideoHook(
                        id = obj.optString("id", i.toString()),
                        hookText = obj.optString("hookText", ""),
                        hookType = obj.optString("hookType", "Curiosity"),
                        deliveryTip = obj.optString("deliveryTip", "")
                    )
                )
            }
        }

        // Parse title suggestions
        val titles = mutableListOf<TitleSuggestion>()
        runCatching {
            val arr = JSONArray(titleSuggestionsRaw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                titles.add(
                    TitleSuggestion(
                        id = obj.optString("id", i.toString()),
                        titleText = obj.optString("titleText", ""),
                        category = obj.optString("category", "General"),
                        estimatedCtr = obj.optString("estimatedCtr", "8.5%")
                    )
                )
            }
        }

        // Parse social captions
        val captions = mutableListOf<SocialCaption>()
        runCatching {
            val arr = JSONArray(socialCaptionsRaw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val platformStr = obj.optString("platform", "TIKTOK")
                val platform = runCatching { SocialPlatform.valueOf(platformStr) }.getOrDefault(SocialPlatform.TIKTOK)
                val tagsArr = obj.optJSONArray("hashtags")
                val tags = mutableListOf<String>()
                if (tagsArr != null) {
                    for (j in 0 until tagsArr.length()) {
                        tags.add(tagsArr.getString(j))
                    }
                }
                captions.add(
                    SocialCaption(
                        platform = platform,
                        captionText = obj.optString("captionText", ""),
                        callToAction = obj.optString("callToAction", ""),
                        hashtags = tags
                    )
                )
            }
        }

        // Parse audience metrics
        var audience = AudienceEngagementStats(
            overallScore = 85,
            viralProbability = "Tinggi",
            bestPostingTime = "19:00 WIB",
            targetAudience = "Kreator & Penggemar Video",
            retentionPeakTime = "00:15 - 00:45",
            engagementFactors = listOf("Momen visual dinamis", "Penyampaian cepat")
        )
        runCatching {
            val obj = JSONObject(audienceMetricsRaw)
            val factorsArr = obj.optJSONArray("engagementFactors")
            val factors = mutableListOf<String>()
            if (factorsArr != null) {
                for (j in 0 until factorsArr.length()) {
                    factors.add(factorsArr.getString(j))
                }
            }
            audience = AudienceEngagementStats(
                overallScore = obj.optInt("overallScore", 85),
                viralProbability = obj.optString("viralProbability", "Tinggi"),
                bestPostingTime = obj.optString("bestPostingTime", "19:00 WIB"),
                targetAudience = obj.optString("targetAudience", "Umum"),
                retentionPeakTime = obj.optString("retentionPeakTime", "00:15"),
                engagementFactors = if (factors.isNotEmpty()) factors else audience.engagementFactors
            )
        }

        // Parse SEO
        var seo = SeoData(
            primaryKeywords = listOf("video viral", "klip menarik"),
            longTailKeywords = listOf("cara edit video cepat", "tips momen viral"),
            recommendedTags = listOf("#videoviral", "#contentcreator", "#fyp"),
            searchOptimizedDescription = ""
        )
        runCatching {
            val obj = JSONObject(seoDataRaw)
            fun parseList(key: String): List<String> {
                val list = mutableListOf<String>()
                val arr = obj.optJSONArray(key) ?: return list
                for (j in 0 until arr.length()) list.add(arr.getString(j))
                return list
            }
            seo = SeoData(
                primaryKeywords = parseList("primaryKeywords").ifEmpty { seo.primaryKeywords },
                longTailKeywords = parseList("longTailKeywords").ifEmpty { seo.longTailKeywords },
                recommendedTags = parseList("recommendedTags").ifEmpty { seo.recommendedTags },
                searchOptimizedDescription = obj.optString("searchOptimizedDescription", "")
            )
        }

        val type = runCatching { VideoSourceType.valueOf(sourceType) }.getOrDefault(VideoSourceType.LOCAL)

        return VideoAnalysisResult(
            id = id,
            title = title,
            sourceUriOrUrl = sourceUriOrUrl,
            sourceType = type,
            durationSeconds = durationSeconds,
            thumbnailUrl = thumbnailUrl,
            summaryPoints = summaries,
            moments = momentList,
            hooks = hookList,
            titleSuggestions = titles,
            socialCaptions = captions,
            audienceMetrics = audience,
            seoData = seo,
            createdAt = createdAt
        )
    }

    companion object {
        fun fromDomain(domain: VideoAnalysisResult): SavedAnalysisEntity {
            val summaryArr = JSONArray()
            domain.summaryPoints.forEach { summaryArr.put(it) }

            val momentsArr = JSONArray()
            domain.moments.forEach { m ->
                momentsArr.put(
                    JSONObject().apply {
                        put("id", m.id)
                        put("startSecond", m.startSecond)
                        put("endSecond", m.endSecond)
                        put("title", m.title)
                        put("keyQuoteOrText", m.keyQuoteOrText)
                        put("reasonWhyViral", m.reasonWhyViral)
                        put("viralScore", m.viralScore)
                    }
                )
            }

            val hooksArr = JSONArray()
            domain.hooks.forEach { h ->
                hooksArr.put(
                    JSONObject().apply {
                        put("id", h.id)
                        put("hookText", h.hookText)
                        put("hookType", h.hookType)
                        put("deliveryTip", h.deliveryTip)
                    }
                )
            }

            val titlesArr = JSONArray()
            domain.titleSuggestions.forEach { t ->
                titlesArr.put(
                    JSONObject().apply {
                        put("id", t.id)
                        put("titleText", t.titleText)
                        put("category", t.category)
                        put("estimatedCtr", t.estimatedCtr)
                    }
                )
            }

            val captionsArr = JSONArray()
            domain.socialCaptions.forEach { c ->
                captionsArr.put(
                    JSONObject().apply {
                        put("platform", c.platform.name)
                        put("captionText", c.captionText)
                        put("callToAction", c.callToAction)
                        put("hashtags", JSONArray(c.hashtags))
                    }
                )
            }

            val audienceObj = JSONObject().apply {
                put("overallScore", domain.audienceMetrics.overallScore)
                put("viralProbability", domain.audienceMetrics.viralProbability)
                put("bestPostingTime", domain.audienceMetrics.bestPostingTime)
                put("targetAudience", domain.audienceMetrics.targetAudience)
                put("retentionPeakTime", domain.audienceMetrics.retentionPeakTime)
                put("engagementFactors", JSONArray(domain.audienceMetrics.engagementFactors))
            }

            val seoObj = JSONObject().apply {
                put("primaryKeywords", JSONArray(domain.seoData.primaryKeywords))
                put("longTailKeywords", JSONArray(domain.seoData.longTailKeywords))
                put("recommendedTags", JSONArray(domain.seoData.recommendedTags))
                put("searchOptimizedDescription", domain.seoData.searchOptimizedDescription)
            }

            return SavedAnalysisEntity(
                id = domain.id,
                title = domain.title,
                sourceUriOrUrl = domain.sourceUriOrUrl,
                sourceType = domain.sourceType.name,
                durationSeconds = domain.durationSeconds,
                thumbnailUrl = domain.thumbnailUrl,
                summaryPointsRaw = summaryArr.toString(),
                momentsRaw = momentsArr.toString(),
                hooksRaw = hooksArr.toString(),
                titleSuggestionsRaw = titlesArr.toString(),
                socialCaptionsRaw = captionsArr.toString(),
                audienceMetricsRaw = audienceObj.toString(),
                seoDataRaw = seoObj.toString(),
                createdAt = domain.createdAt
            )
        }
    }
}
