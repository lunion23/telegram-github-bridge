package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.Print
import androidx.compose.material.icons.outlined.Receipt
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ExpressNavy
import com.example.ui.theme.ExpressRed
import com.example.ui.viewmodel.ReceiptViewModel
import com.example.util.PrinterStatus

enum class AppTab(val title: String) {
    FORM("Form Struk"),
    PDF_PREVIEW("Preview PDF"),
    PRINTER_BT("Printer BT"),
    HISTORY("Riwayat")
}

@Composable
fun MainAppScreen(
    viewModel: ReceiptViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by rememberSaveable { mutableIntStateOf(AppTab.FORM.ordinal) }
    val printerStatus by viewModel.printerStatus.collectAsState()
    val todayCount by viewModel.todayCount.collectAsState()

    // Handle back button: return to Form tab if on other tabs
    BackHandler(enabled = selectedTab != AppTab.FORM.ordinal) {
        selectedTab = AppTab.FORM.ordinal
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("main_navigation_bar"),
                containerColor = Color.White,
                tonalElevation = 8.dp
            ) {
                // Tab 1: Form
                NavigationBarItem(
                    selected = selectedTab == AppTab.FORM.ordinal,
                    onClick = { selectedTab = AppTab.FORM.ordinal },
                    icon = {
                        Icon(
                            imageVector = if (selectedTab == AppTab.FORM.ordinal) Icons.Filled.Receipt else Icons.Outlined.Receipt,
                            contentDescription = "Form Struk",
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    label = { Text("Form Struk", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ExpressRed,
                        selectedTextColor = ExpressRed,
                        indicatorColor = ExpressRed.copy(alpha = 0.12f)
                    ),
                    modifier = Modifier.testTag("nav_tab_form")
                )

                // Tab 2: Preview PDF
                NavigationBarItem(
                    selected = selectedTab == AppTab.PDF_PREVIEW.ordinal,
                    onClick = {
                        viewModel.preparePdfPreview()
                        selectedTab = AppTab.PDF_PREVIEW.ordinal
                    },
                    icon = {
                        Icon(
                            imageVector = if (selectedTab == AppTab.PDF_PREVIEW.ordinal) Icons.Filled.PictureAsPdf else Icons.Outlined.PictureAsPdf,
                            contentDescription = "Preview PDF",
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    label = { Text("Preview PDF", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ExpressRed,
                        selectedTextColor = ExpressRed,
                        indicatorColor = ExpressRed.copy(alpha = 0.12f)
                    ),
                    modifier = Modifier.testTag("nav_tab_pdf")
                )

                // Tab 3: Printer BT
                NavigationBarItem(
                    selected = selectedTab == AppTab.PRINTER_BT.ordinal,
                    onClick = { selectedTab = AppTab.PRINTER_BT.ordinal },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (printerStatus is PrinterStatus.Connected) {
                                    Badge(containerColor = Color(0xFF10B981))
                                }
                            }
                        ) {
                            Icon(
                                imageVector = if (selectedTab == AppTab.PRINTER_BT.ordinal) Icons.Filled.Print else Icons.Outlined.Print,
                                contentDescription = "Printer BT",
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    },
                    label = { Text("Printer BT", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ExpressNavy,
                        selectedTextColor = ExpressNavy,
                        indicatorColor = ExpressNavy.copy(alpha = 0.12f)
                    ),
                    modifier = Modifier.testTag("nav_tab_printer")
                )

                // Tab 4: Riwayat & Pemasukan
                NavigationBarItem(
                    selected = selectedTab == AppTab.HISTORY.ordinal,
                    onClick = { selectedTab = AppTab.HISTORY.ordinal },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (todayCount > 0) {
                                    Badge(containerColor = ExpressRed) {
                                        Text("$todayCount")
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = if (selectedTab == AppTab.HISTORY.ordinal) Icons.Filled.History else Icons.Outlined.History,
                                contentDescription = "Riwayat",
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    },
                    label = { Text("Riwayat", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ExpressRed,
                        selectedTextColor = ExpressRed,
                        indicatorColor = ExpressRed.copy(alpha = 0.12f)
                    ),
                    modifier = Modifier.testTag("nav_tab_history")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                AppTab.FORM.ordinal -> ReceiptFormScreen(
                    viewModel = viewModel,
                    onNavigateToPdf = { selectedTab = AppTab.PDF_PREVIEW.ordinal },
                    onNavigateToBluetooth = { selectedTab = AppTab.PRINTER_BT.ordinal }
                )
                AppTab.PDF_PREVIEW.ordinal -> PdfPreviewScreen(
                    viewModel = viewModel,
                    onBack = { selectedTab = AppTab.FORM.ordinal }
                )
                AppTab.PRINTER_BT.ordinal -> BluetoothPrinterScreen(
                    viewModel = viewModel
                )
                AppTab.HISTORY.ordinal -> HistoryScreen(
                    viewModel = viewModel,
                    onLoadReceipt = { data ->
                        viewModel.loadReceipt(data)
                        selectedTab = AppTab.FORM.ordinal
                    },
                    onNavigateToPdf = { selectedTab = AppTab.PDF_PREVIEW.ordinal },
                    onNavigateToBluetooth = { selectedTab = AppTab.PRINTER_BT.ordinal }
                )
            }
        }
    }
}
