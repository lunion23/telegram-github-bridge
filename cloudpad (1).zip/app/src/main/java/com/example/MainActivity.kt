package com.example

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.credentials.CredentialManager
import androidx.lifecycle.lifecycleScope
import com.example.auth.AuthManager
import com.example.data.model.Note
import com.example.ui.NoteViewModel
import com.example.ui.editor.NoteEditorScreen
import com.example.ui.home.NoteListScreen
import com.example.ui.theme.CloudPadTheme
import kotlinx.coroutines.launch

data class ActiveEditorSession(
    val note: Note,
    val sourceUri: Uri? = null
)

class MainActivity : ComponentActivity() {

    private val noteViewModel: NoteViewModel by viewModels()
    private val pendingIncomingSession = mutableStateOf<ActiveEditorSession?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Attempt silent auto sign-in if previously authenticated
        val credentialManager = CredentialManager.create(this)
        AuthManager.attemptAutoSignIn(
            context = this,
            credentialManager = credentialManager,
            onAuthSuccess = { noteViewModel.refreshAuth() },
            onUnauthenticated = { /* continue in guest mode */ },
            scope = lifecycleScope
        )

        handleIncomingIntent(intent)

        setContent {
            CloudPadTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    CloudPadApp(
                        viewModel = noteViewModel,
                        pendingIncomingSession = pendingIncomingSession.value,
                        onConsumeIncomingSession = { pendingIncomingSession.value = null }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        when (intent.action) {
            Intent.ACTION_VIEW, Intent.ACTION_EDIT -> {
                val uri = intent.data ?: return
                openLocalUriFromIntent(uri)
            }
            Intent.ACTION_SEND -> {
                val streamUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(Intent.EXTRA_STREAM)
                }
                if (streamUri != null) {
                    openLocalUriFromIntent(streamUri)
                } else {
                    val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
                    if (!sharedText.isNullOrBlank()) {
                        val subject = intent.getStringExtra(Intent.EXTRA_SUBJECT)
                        lifecycleScope.launch {
                            val note = noteViewModel.importSharedText(subject, sharedText)
                            pendingIncomingSession.value = ActiveEditorSession(note = note, sourceUri = null)
                        }
                    }
                }
            }
        }
    }

    private fun openLocalUriFromIntent(uri: Uri) {
        lifecycleScope.launch {
            val result = noteViewModel.importLocalFile(uri)
            result.onSuccess { opened ->
                Toast.makeText(this@MainActivity, "Membuka ${opened.fileName}", Toast.LENGTH_SHORT).show()
                pendingIncomingSession.value = ActiveEditorSession(
                    note = opened.note,
                    sourceUri = opened.uri
                )
            }.onFailure { error ->
                Toast.makeText(
                    this@MainActivity,
                    error.message ?: "Gagal membuka file lokal",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}

@Composable
fun CloudPadApp(
    viewModel: NoteViewModel,
    pendingIncomingSession: ActiveEditorSession? = null,
    onConsumeIncomingSession: () -> Unit = {}
) {
    var activeSession by remember { mutableStateOf<ActiveEditorSession?>(null) }

    LaunchedEffect(pendingIncomingSession) {
        if (pendingIncomingSession != null) {
            activeSession = pendingIncomingSession
            onConsumeIncomingSession()
        }
    }

    AnimatedContent(
        targetState = activeSession,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "screen_transition"
    ) { session ->
        if (session != null) {
            NoteEditorScreen(
                initialNote = session.note,
                sourceUri = session.sourceUri,
                onSaveNote = { note ->
                    viewModel.saveNote(note)
                },
                onDeleteNote = { id ->
                    viewModel.deleteNote(id)
                },
                onNavigateBack = {
                    activeSession = null
                }
            )
        } else {
            NoteListScreen(
                viewModel = viewModel,
                onCreateNote = {
                    activeSession = ActiveEditorSession(note = Note())
                },
                onOpenNote = { note, uri ->
                    activeSession = ActiveEditorSession(note = note, sourceUri = uri)
                }
            )
        }
    }
}
