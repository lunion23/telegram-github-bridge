package com.example.util

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import com.example.data.model.ReceiptData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.IOException
import java.io.OutputStream
import java.util.UUID

sealed class PrinterStatus {
    object Disconnected : PrinterStatus()
    object Connecting : PrinterStatus()
    data class Connected(val deviceName: String, val address: String) : PrinterStatus()
    data class Error(val message: String) : PrinterStatus()
}

class ThermalBluetoothPrinter(private val context: Context) {

    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val bluetoothAdapter: BluetoothAdapter? by lazy {
        try {
            val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? android.bluetooth.BluetoothManager
            manager?.adapter ?: BluetoothAdapter.getDefaultAdapter()
        } catch (_: Exception) {
            null
        }
    }

    private var currentSocket: BluetoothSocket? = null
    private var outputStream: OutputStream? = null

    private val _printerStatus = MutableStateFlow<PrinterStatus>(PrinterStatus.Disconnected)
    val printerStatus: StateFlow<PrinterStatus> = _printerStatus

    val isBluetoothSupported: Boolean
        get() = bluetoothAdapter != null

    val isBluetoothEnabled: Boolean
        get() = try {
            bluetoothAdapter?.isEnabled == true
        } catch (_: Exception) {
            false
        }

    @SuppressLint("MissingPermission")
    fun getPairedDevices(): List<BluetoothDevice> {
        return try {
            bluetoothAdapter?.bondedDevices?.toList() ?: emptyList()
        } catch (_: Exception) {
            emptyList()
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun connect(device: BluetoothDevice): Boolean = withContext(Dispatchers.IO) {
        _printerStatus.value = PrinterStatus.Connecting
        disconnect()
        try {
            val socket = device.createRfcommSocketToServiceRecord(sppUuid)
            socket.connect()
            currentSocket = socket
            outputStream = socket.outputStream
            val name = device.name ?: "Thermal Printer"
            _printerStatus.value = PrinterStatus.Connected(name, device.address)
            true
        } catch (e: Exception) {
            disconnect()
            _printerStatus.value = PrinterStatus.Error("Gagal menghubungkan: ${e.message}")
            false
        }
    }

    fun disconnect() {
        try {
            outputStream?.close()
        } catch (_: Exception) {}
        try {
            currentSocket?.close()
        } catch (_: Exception) {}
        outputStream = null
        currentSocket = null
        _printerStatus.value = PrinterStatus.Disconnected
    }

    suspend fun printTest(): Boolean = withContext(Dispatchers.IO) {
        val os = outputStream ?: return@withContext false
        try {
            // ESC @ (Initialize)
            os.write(byteArrayOf(0x1B, 0x40))
            // ESC a 1 (Align center)
            os.write(byteArrayOf(0x1B, 0x61, 0x01))
            // ESC E 1 (Bold on)
            os.write(byteArrayOf(0x1B, 0x45, 0x01))
            os.write("*** TEST PRINTER THERMAL ***\n".toByteArray(Charsets.ISO_8859_1))
            os.write("STRUK EXPRESS BLUETOOTH\n".toByteArray(Charsets.ISO_8859_1))
            // ESC E 0 (Bold off)
            os.write(byteArrayOf(0x1B, 0x45, 0x00))
            os.write("Koneksi Berhasil!\n".toByteArray(Charsets.ISO_8859_1))
            os.write("Siap mencetak resi pengiriman.\n".toByteArray(Charsets.ISO_8859_1))
            os.write("--------------------------------\n\n\n\n".toByteArray(Charsets.ISO_8859_1))
            os.flush()
            true
        } catch (e: Exception) {
            _printerStatus.value = PrinterStatus.Error("Gagal mencetak test: ${e.message}")
            false
        }
    }

    /**
     * Prints the shipping label / receipt as a high-contrast 1-bit raster graphic (GS v 0).
     * Supports Option 1 (Label Utama), Option 2 (Lembar Pengirim), and Option 3 (Combo 2-in-1).
     */
    suspend fun printReceiptGraphic(
        receipt: ReceiptData,
        is80mm: Boolean = false
    ): Boolean = withContext(Dispatchers.IO) {
        val os = outputStream ?: return@withContext false
        try {
            val targetWidth = if (is80mm) 576 else 384
            val heightRatio = when (receipt.selectedFormat) {
                com.example.data.model.PrintFormatMode.MAIN_LABEL -> 1.55f
                com.example.data.model.PrintFormatMode.SENDER_COPY -> 0.86f
                com.example.data.model.PrintFormatMode.COMBO_ALL -> 2.41f
            }
            val targetHeight = (targetWidth * heightRatio).toInt()

            val bitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)

            when (receipt.selectedFormat) {
                com.example.data.model.PrintFormatMode.MAIN_LABEL ->
                    PdfReceiptGenerator.drawReceiptOnCanvas(canvas, receipt, targetWidth.toFloat(), targetHeight.toFloat())
                com.example.data.model.PrintFormatMode.SENDER_COPY ->
                    PdfReceiptGenerator.drawSenderCopyOnCanvas(canvas, receipt, targetWidth.toFloat(), targetHeight.toFloat())
                com.example.data.model.PrintFormatMode.COMBO_ALL ->
                    PdfReceiptGenerator.drawComboOnCanvas(canvas, receipt, targetWidth.toFloat(), targetHeight.toFloat())
            }

            val escposRaster = convertBitmapToEscPosRaster(bitmap, targetWidth)

            // ESC @ (Initialize)
            os.write(byteArrayOf(0x1B, 0x40))
            // ESC a 1 (Center alignment)
            os.write(byteArrayOf(0x1B, 0x61, 0x01))
            // Write raster graphic
            os.write(escposRaster)
            // Feed paper
            os.write(byteArrayOf(0x1B, 0x64, 0x04))
            os.flush()
            true
        } catch (e: Exception) {
            _printerStatus.value = PrinterStatus.Error("Gagal mencetak struk: ${e.message}")
            false
        }
    }

    /**
     * Converts an Android Bitmap into ESC/POS GS v 0 raster bit-image data.
     */
    private fun convertBitmapToEscPosRaster(bitmap: Bitmap, width: Int): ByteArray {
        val height = bitmap.height
        val widthBytes = (width + 7) / 8
        val rasterData = ByteArray(widthBytes * height)

        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        for (y in 0 until height) {
            for (x in 0 until width) {
                val pixel = pixels[y * width + x]
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)
                val luminance = (0.299 * r + 0.587 * g + 0.114 * b).toInt()
                // Black pixel threshold
                if (luminance < 165) {
                    val byteIndex = y * widthBytes + (x / 8)
                    val bitOffset = 7 - (x % 8)
                    rasterData[byteIndex] = (rasterData[byteIndex].toInt() or (1 shl bitOffset)).toByte()
                }
            }
        }

        val xL = (widthBytes and 0xFF).toByte()
        val xH = ((widthBytes shr 8) and 0xFF).toByte()
        val yL = (height and 0xFF).toByte()
        val yH = ((height shr 8) and 0xFF).toByte()

        val header = byteArrayOf(0x1D, 0x76, 0x30, 0x00, xL, xH, yL, yH)
        val combined = ByteArray(header.size + rasterData.size)
        System.arraycopy(header, 0, combined, 0, header.size)
        System.arraycopy(rasterData, 0, combined, header.size, rasterData.size)
        return combined
    }
}
