package com.example

import com.example.data.model.ExtractRequest
import com.example.data.model.VideoFormatOption
import com.example.data.model.VideoInfoResponse
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testExtractRequestCreation() {
        val request = ExtractRequest(url = "https://www.tiktok.com/@test/video/123")
        assertEquals("https://www.tiktok.com/@test/video/123", request.url)
    }

    @Test
    fun testVideoFormatOptionModel() {
        val format = VideoFormatOption(
            formatId = "1080p",
            resolution = "1080p Full HD",
            extension = "mp4",
            downloadUrl = "https://cdn.example.com/video.mp4",
            filesizeFormatted = "24.5 MB",
            isAudioOnly = false
        )
        assertEquals("1080p Full HD", format.resolution)
        assertEquals("mp4", format.extension)
        assertFalse(format.isAudioOnly)
    }

    @Test
    fun testVideoInfoResponseModel() {
        val response = VideoInfoResponse(
            title = "Sample Viral Clip",
            author = "Creator123",
            thumbnail = "https://cdn.example.com/thumb.jpg",
            duration = "00:45",
            platform = "TikTok",
            webpageUrl = "https://tiktok.com/@creator/video/1",
            formats = listOf(
                VideoFormatOption(
                    formatId = "best",
                    resolution = "720p HD",
                    extension = "mp4",
                    downloadUrl = "https://cdn.example.com/video.mp4"
                )
            )
        )

        assertEquals("Sample Viral Clip", response.title)
        assertEquals("TikTok", response.platform)
        assertEquals(1, response.formats.size)
        assertNotNull(response.formats[0].downloadUrl)
    }
}
