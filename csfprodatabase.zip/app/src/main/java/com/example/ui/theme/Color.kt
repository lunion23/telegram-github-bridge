package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Fleet Management Enterprise Industrial Palette
val FleetPrimary = Color(0xFF0284C7)        // Ocean Blue / Engineering
val FleetOnPrimary = Color(0xFFFFFFFF)
val FleetPrimaryContainer = Color(0xFFE0F2FE)
val FleetOnPrimaryContainer = Color(0xFF0369A1)

val FleetSecondary = Color(0xFFD97706)      // Industrial Amber / Workshop Gold
val FleetOnSecondary = Color(0xFFFFFFFF)
val FleetSecondaryContainer = Color(0xFFFEF3C7)
val FleetOnSecondaryContainer = Color(0xFFB45309)

val FleetTertiary = Color(0xFF059669)       // Emerald Green (Success / Active)
val FleetOnTertiary = Color(0xFFFFFFFF)
val FleetTertiaryContainer = Color(0xFFD1FAE5)
val FleetOnTertiaryContainer = Color(0xFF047857)

val FleetBackground = Color(0xFFF8FAFC)     // Crisp Clean Slate
val FleetSurface = Color(0xFFFFFFFF)
val FleetSurfaceVariant = Color(0xFFF1F5F9)
val FleetOutline = Color(0xFFCBD5E1)
val FleetOutlineVariant = Color(0xFFE2E8F0)

val FleetDarkBackground = Color(0xFF0F172A)
val FleetDarkSurface = Color(0xFF1E293B)
val FleetDarkSurfaceVariant = Color(0xFF334155)
val FleetDarkPrimary = Color(0xFF38BDF8)
val FleetDarkSecondary = Color(0xFFFBBF24)

// Category Chips & Badges
val BadgePartBg = Color(0xFFE0F2FE)
val BadgePartText = Color(0xFF0369A1)
val BadgeJasaBg = Color(0xFFFEF3C7)
val BadgeJasaText = Color(0xFFB45309)
val BadgeOliBg = Color(0xFFEDE9FE)
val BadgeOliText = Color(0xFF6D28D9)
