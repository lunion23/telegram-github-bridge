package com.example.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import com.example.model.PaperSizePreset
import com.example.model.PdfRenderSource
import com.example.model.ShippingLabelData
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

/**
 * Generates native vector PDF files, high-resolution preview Bitmaps, and integrates
 * with the Android system [PrintManager] spooler ("Print" / "Save as PDF").
 */
object ShippingLabelPdfGenerator {

    private const val REFERENCE_ASSET_NAME = "reference_label.jpg"

    fun loadReferenceBitmap(context: Context): Bitmap? {
        return try {
            context.assets.open(REFERENCE_ASSET_NAME).use { stream ->
                BitmapFactory.decodeStream(stream)
            }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Renders a crisp high-DPI Bitmap for live Compose preview.
     */
    fun renderPreviewBitmap(
        data: ShippingLabelData,
        paperPreset: PaperSizePreset,
        renderSource: PdfRenderSource,
        referenceBitmap: Bitmap?,
        targetWidthPx: Int = 944
    ): Bitmap {
        val aspect = paperPreset.heightMm / paperPreset.widthMm
        val heightPx = (targetWidthPx * aspect).toInt().coerceAtLeast(100)
        val bitmap = Bitmap.createBitmap(targetWidthPx, heightPx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        ShippingLabelCanvasRenderer.renderPage(
            canvas = canvas,
            pageWidth = targetWidthPx.toFloat(),
            pageHeight = heightPx.toFloat(),
            data = data,
            paperPreset = paperPreset,
            renderSource = renderSource,
            referenceBitmap = referenceBitmap
        )
        return bitmap
    }

    /**
     * Writes a 1-page vector [PdfDocument] into [outputStream].
     */
    fun writePdfToStream(
        outputStream: OutputStream,
        data: ShippingLabelData,
        paperPreset: PaperSizePreset,
        renderSource: PdfRenderSource,
        referenceBitmap: Bitmap?
    ) {
        val document = PdfDocument()
        try {
            val pageInfo = PdfDocument.PageInfo.Builder(
                paperPreset.widthPt,
                paperPreset.heightPt,
                1
            ).create()
            val page = document.startPage(pageInfo)
            ShippingLabelCanvasRenderer.renderPage(
                canvas = page.canvas,
                pageWidth = paperPreset.widthPt.toFloat(),
                pageHeight = paperPreset.heightPt.toFloat(),
                data = data,
                paperPreset = paperPreset,
                renderSource = renderSource,
                referenceBitmap = referenceBitmap
            )
            document.finishPage(page)
            document.writeTo(outputStream)
            outputStream.flush()
        } finally {
            document.close()
        }
    }

    /**
     * Creates a shareable/openable PDF file inside `cacheDir/pdfs/` for FileProvider.
     */
    fun generateCachePdfFile(
        context: Context,
        data: ShippingLabelData,
        paperPreset: PaperSizePreset,
        renderSource: PdfRenderSource,
        referenceBitmap: Bitmap?
    ): File {
        val pdfDir = File(context.cacheDir, "pdfs")
        if (!pdfDir.exists()) {
            pdfDir.mkdirs()
        }
        val sanitizedWaybill = data.waybillNumber
            .replace(Regex("[^A-Za-z0-9_-]"), "_")
            .ifBlank { "Resi" }
        val targetFile = File(pdfDir, "Resi_${sanitizedWaybill}.pdf")
        FileOutputStream(targetFile).use { fos ->
            writePdfToStream(
                outputStream = fos,
                data = data,
                paperPreset = paperPreset,
                renderSource = renderSource,
                referenceBitmap = referenceBitmap
            )
        }
        return targetFile
    }

    /**
     * Launches the Android system Print Spooler (supports physical printers, thermal Wi-Fi/USB,
     * and Android's built-in "Save as PDF").
     */
    fun launchSystemPrint(
        context: Context,
        jobName: String,
        data: ShippingLabelData,
        paperPreset: PaperSizePreset,
        renderSource: PdfRenderSource,
        referenceBitmap: Bitmap?
    ) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager

        val mediaSize = when (paperPreset) {
            PaperSizePreset.THERMAL_100X200 -> PrintAttributes.MediaSize(
                "THERMAL_100X200",
                "Thermal 100 x 200 mm",
                (100f / 25.4f * 1000f).toInt(),
                (200f / 25.4f * 1000f).toInt()
            )
            PaperSizePreset.THERMAL_78X150 -> PrintAttributes.MediaSize(
                "THERMAL_78X150",
                "Thermal 78 x 150 mm",
                (78f / 25.4f * 1000f).toInt(),
                (150f / 25.4f * 1000f).toInt()
            )
            PaperSizePreset.A6_PORTRAIT -> PrintAttributes.MediaSize.ISO_A6.asPortrait()
            PaperSizePreset.A4_ACTUAL_SIZE -> PrintAttributes.MediaSize.ISO_A4.asPortrait()
        }

        val attributes = PrintAttributes.Builder()
            .setMediaSize(mediaSize)
            .setColorMode(PrintAttributes.COLOR_MODE_MONOCHROME)
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .build()

        val adapter = ShippingLabelPrintAdapter(
            documentName = "$jobName.pdf",
            data = data,
            paperPreset = paperPreset,
            renderSource = renderSource,
            referenceBitmap = referenceBitmap
        )

        printManager.print(jobName, adapter, attributes)
    }
}

/**
 * Custom [PrintDocumentAdapter] rendering crisp vector graphics directly to whatever page
 * size the user selects in the Android Print Preview UI.
 */
private class ShippingLabelPrintAdapter(
    private val documentName: String,
    private val data: ShippingLabelData,
    private val paperPreset: PaperSizePreset,
    private val renderSource: PdfRenderSource,
    private val referenceBitmap: Bitmap?
) : PrintDocumentAdapter() {

    private var currentAttributes: PrintAttributes? = null

    override fun onLayout(
        oldAttributes: PrintAttributes?,
        newAttributes: PrintAttributes,
        cancellationSignal: CancellationSignal?,
        callback: LayoutResultCallback,
        extras: Bundle?
    ) {
        if (cancellationSignal?.isCanceled == true) {
            callback.onLayoutCancelled()
            return
        }
        currentAttributes = newAttributes
        val info = PrintDocumentInfo.Builder(documentName)
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
            .setPageCount(1)
            .build()
        callback.onLayoutFinished(info, oldAttributes != newAttributes)
    }

    override fun onWrite(
        pages: Array<out PageRange>?,
        destination: ParcelFileDescriptor,
        cancellationSignal: CancellationSignal?,
        callback: WriteResultCallback
    ) {
        if (cancellationSignal?.isCanceled == true) {
            callback.onWriteCancelled()
            return
        }

        val mediaSize = currentAttributes?.mediaSize
        val pageWidthPt = if (mediaSize != null) {
            ((mediaSize.widthMils / 1000f) * 72f).toInt().coerceAtLeast(100)
        } else {
            paperPreset.widthPt
        }
        val pageHeightPt = if (mediaSize != null) {
            ((mediaSize.heightMils / 1000f) * 72f).toInt().coerceAtLeast(100)
        } else {
            paperPreset.heightPt
        }

        val effectivePreset = if (
            mediaSize?.id == PrintAttributes.MediaSize.ISO_A4.id &&
            paperPreset == PaperSizePreset.A4_ACTUAL_SIZE
        ) {
            PaperSizePreset.A4_ACTUAL_SIZE
        } else {
            // Fit proportionally onto whichever paper size the user chose in system print preview
            PaperSizePreset.THERMAL_100X200
        }

        val pdfDocument = PdfDocument()
        try {
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidthPt, pageHeightPt, 1).create()
            val page = pdfDocument.startPage(pageInfo)
            ShippingLabelCanvasRenderer.renderPage(
                canvas = page.canvas,
                pageWidth = pageWidthPt.toFloat(),
                pageHeight = pageHeightPt.toFloat(),
                data = data,
                paperPreset = effectivePreset,
                renderSource = renderSource,
                referenceBitmap = referenceBitmap
            )
            pdfDocument.finishPage(page)

            FileOutputStream(destination.fileDescriptor).use { out ->
                pdfDocument.writeTo(out)
                out.flush()
            }
            callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
        } catch (e: Exception) {
            callback.onWriteFailed(e.localizedMessage ?: "PDF write error")
        } finally {
            pdfDocument.close()
        }
    }
}
