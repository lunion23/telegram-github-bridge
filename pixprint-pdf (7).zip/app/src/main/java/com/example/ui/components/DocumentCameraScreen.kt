package com.example.ui.components

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.RotateRight
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Contrast
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.FlashAuto
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.outlined.AutoFixHigh
import androidx.compose.material.icons.outlined.Cameraswitch
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.graphics.createBitmap
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.R
import com.example.data.local.CapturedDocumentStorage
import com.example.model.PdfRenderSource
import com.example.pdf.CameraLabelExtractor
import com.example.pdf.ExtractedCameraLabel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun DocumentCameraScreen(
    onPhotoConfirmed: (Bitmap, ExtractedCameraLabel?, PdfRenderSource) -> Unit,
    onCaptureError: (String) -> Unit,
    onClose: () -> Unit
) {
    BackHandler(onBack = onClose)

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    var rawCapturedBitmap by remember { mutableStateOf<Bitmap?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    // Zero-permission Android Photo Picker so users can also import label/receipt photos directly
    val pickVisualMediaLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch {
                val decoded = CapturedDocumentStorage.decodeUriBitmap(context, uri)
                if (decoded != null) {
                    rawCapturedBitmap = decoded
                } else {
                    onCaptureError("Gagal memuat gambar yang dipilih")
                }
            }
        }
    }

    val launchGalleryPicker: () -> Unit = {
        runCatching {
            pickVisualMediaLauncher.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
            )
        }.onFailure { err ->
            onCaptureError(err.localizedMessage ?: "Gagal membuka pemilih gambar")
        }
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            runCatching { permissionLauncher.launch(Manifest.permission.CAMERA) }
        }
    }

    if (rawCapturedBitmap != null) {
        CapturedDocumentReviewView(
            rawBitmap = rawCapturedBitmap!!,
            onRetake = { rawCapturedBitmap = null },
            onConfirm = onPhotoConfirmed,
            onClose = onClose
        )
    } else if (!hasCameraPermission) {
        CameraPermissionRationaleView(
            onRequestPermission = {
                runCatching { permissionLauncher.launch(Manifest.permission.CAMERA) }
            },
            onPickFromGallery = launchGalleryPicker,
            onClose = onClose
        )
    } else {
        LiveCameraCaptureView(
            context = context,
            onBitmapCaptured = { captured -> rawCapturedBitmap = captured },
            onPickFromGallery = launchGalleryPicker,
            onCaptureError = onCaptureError,
            onClose = onClose
        )
    }
}

@Composable
private fun CameraPermissionRationaleView(
    onRequestPermission: () -> Unit,
    onPickFromGallery: () -> Unit,
    onClose: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(20.dp)
        ) {
            IconButton(
                onClick = onClose,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .minimumInteractiveComponentSize()
                    .testTag("camera_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = stringResource(R.string.cd_back)
                )
            }

            Card(
                modifier = Modifier
                    .align(Alignment.Center)
                    .widthIn(max = 420.dp)
                    .fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(64.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Outlined.PhotoCamera,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }

                    Text(
                        text = stringResource(R.string.camera_permission_title),
                        style = MaterialTheme.typography.titleLarge,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = stringResource(R.string.camera_permission_desc),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Button(
                        onClick = onRequestPermission,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("camera_permission_request_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CameraAlt,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.action_grant_camera_permission))
                    }

                    OutlinedButton(
                        onClick = onPickFromGallery,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("camera_rationale_gallery_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.PhotoLibrary,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.action_pick_from_gallery))
                    }
                }
            }
        }
    }
}

@Composable
private fun LiveCameraCaptureView(
    context: Context,
    onBitmapCaptured: (Bitmap) -> Unit,
    onPickFromGallery: () -> Unit,
    onCaptureError: (String) -> Unit,
    onClose: () -> Unit
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val coroutineScope = rememberCoroutineScope()

    val previewView = remember {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    var lensFacing by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var flashMode by remember { mutableIntStateOf(ImageCapture.FLASH_MODE_OFF) }
    var canSwitchCamera by remember { mutableStateOf(false) }
    var isCameraUnavailable by remember { mutableStateOf(false) }
    var isTakingPhoto by remember { mutableStateOf(false) }
    var cameraProviderRef by remember { mutableStateOf<ProcessCameraProvider?>(null) }

    val imageCapture = remember {
        ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .build()
    }

    LaunchedEffect(flashMode) {
        imageCapture.flashMode = flashMode
    }

    DisposableEffect(lifecycleOwner, lensFacing) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        val mainExecutor = ContextCompat.getMainExecutor(context)

        val listener = Runnable {
            try {
                val provider = cameraProviderFuture.get()
                cameraProviderRef = provider

                val hasBack = runCatching {
                    provider.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA)
                }.getOrDefault(false)
                val hasFront = runCatching {
                    provider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)
                }.getOrDefault(false)

                canSwitchCamera = hasBack && hasFront

                val resolvedSelector = when {
                    lensFacing == CameraSelector.LENS_FACING_BACK && hasBack ->
                        CameraSelector.DEFAULT_BACK_CAMERA
                    lensFacing == CameraSelector.LENS_FACING_FRONT && hasFront ->
                        CameraSelector.DEFAULT_FRONT_CAMERA
                    hasBack -> CameraSelector.DEFAULT_BACK_CAMERA
                    hasFront -> CameraSelector.DEFAULT_FRONT_CAMERA
                    else -> null
                }

                if (resolvedSelector == null) {
                    isCameraUnavailable = true
                } else {
                    isCameraUnavailable = false
                    val previewUseCase = Preview.Builder().build().also {
                        it.surfaceProvider = previewView.surfaceProvider
                    }
                    imageCapture.flashMode = flashMode
                    provider.unbindAll()
                    provider.bindToLifecycle(
                        lifecycleOwner,
                        resolvedSelector,
                        previewUseCase,
                        imageCapture
                    )
                }
            } catch (_: Exception) {
                isCameraUnavailable = true
            }
        }

        cameraProviderFuture.addListener(listener, mainExecutor)

        onDispose {
            runCatching { cameraProviderRef?.unbindAll() }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF090D16))
    ) {
        if (isCameraUnavailable) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stringResource(R.string.camera_unavailable_message),
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            AndroidView(
                factory = { previewView },
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("camerax_preview_view")
            )

            // Document Framing Corner Guide Overlay
            androidx.compose.foundation.Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 28.dp, vertical = 110.dp)
            ) {
                val stroke = 3.5.dp.toPx()
                val cornerLen = 28.dp.toPx()
                val guideColor = Color.White.copy(alpha = 0.9f)
                val w = size.width
                val h = size.height

                // Dim border frame outline
                drawRect(
                    color = Color.White.copy(alpha = 0.25f),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.dp.toPx())
                )

                // Top-left corner
                drawLine(guideColor, Offset(0f, 0f), Offset(cornerLen, 0f), stroke, StrokeCap.Round)
                drawLine(guideColor, Offset(0f, 0f), Offset(0f, cornerLen), stroke, StrokeCap.Round)
                // Top-right corner
                drawLine(guideColor, Offset(w, 0f), Offset(w - cornerLen, 0f), stroke, StrokeCap.Round)
                drawLine(guideColor, Offset(w, 0f), Offset(w, cornerLen), stroke, StrokeCap.Round)
                // Bottom-left corner
                drawLine(guideColor, Offset(0f, h), Offset(cornerLen, h), stroke, StrokeCap.Round)
                drawLine(guideColor, Offset(0f, h), Offset(0f, h - cornerLen), stroke, StrokeCap.Round)
                // Bottom-right corner
                drawLine(guideColor, Offset(w, h), Offset(w - cornerLen, h), stroke, StrokeCap.Round)
                drawLine(guideColor, Offset(w, h), Offset(w, h - cornerLen), stroke, StrokeCap.Round)
            }
        }

        // Top Camera Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 12.dp, vertical = 8.dp)
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onClose,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("camera_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = stringResource(R.string.cd_back),
                    tint = Color.White
                )
            }

            Text(
                text = stringResource(R.string.camera_screen_title),
                style = MaterialTheme.typography.titleMedium,
                color = Color.White
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = {
                        flashMode = when (flashMode) {
                            ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
                            ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                            else -> ImageCapture.FLASH_MODE_OFF
                        }
                    },
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("camera_flash_button")
                ) {
                    val flashIcon = when (flashMode) {
                        ImageCapture.FLASH_MODE_AUTO -> Icons.Filled.FlashAuto
                        ImageCapture.FLASH_MODE_ON -> Icons.Filled.FlashOn
                        else -> Icons.Filled.FlashOff
                    }
                    Icon(
                        imageVector = flashIcon,
                        contentDescription = stringResource(R.string.cd_toggle_flash),
                        tint = Color.White
                    )
                }

                if (canSwitchCamera) {
                    IconButton(
                        onClick = {
                            lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
                                CameraSelector.LENS_FACING_FRONT
                            } else {
                                CameraSelector.LENS_FACING_BACK
                            }
                        },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("camera_switch_lens_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Cameraswitch,
                            contentDescription = stringResource(R.string.cd_switch_camera),
                            tint = Color.White
                        )
                    }
                }
            }
        }

        // Bottom Capture Controls + Gallery Picker
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(50),
                color = Color.Black.copy(alpha = 0.62f)
            ) {
                Text(
                    text = stringResource(R.string.camera_guide_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Zero-permission Gallery Picker Button
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color.White.copy(alpha = 0.16f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.35f)),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .clip(RoundedCornerShape(50))
                        .clickable(enabled = !isTakingPhoto, onClick = onPickFromGallery)
                        .testTag("camera_pick_gallery_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.PhotoLibrary,
                            contentDescription = stringResource(R.string.cd_pick_from_gallery),
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = stringResource(R.string.action_pick_from_gallery),
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White
                        )
                    }
                }

                // Shutter Button
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .border(4.dp, Color.White, CircleShape)
                        .clickable(enabled = !isTakingPhoto && !isCameraUnavailable) {
                            isTakingPhoto = true
                            val mainExecutor = ContextCompat.getMainExecutor(context)
                            imageCapture.takePicture(
                                mainExecutor,
                                object : ImageCapture.OnImageCapturedCallback() {
                                    override fun onCaptureSuccess(image: ImageProxy) {
                                        coroutineScope.launch {
                                            val bitmapResult = runCatching {
                                                withContext(Dispatchers.Default) {
                                                    try {
                                                        val raw = image.toBitmap()
                                                        rotateBitmapIfNeeded(
                                                            raw,
                                                            image.imageInfo.rotationDegrees
                                                        )
                                                    } finally {
                                                        image.close()
                                                    }
                                                }
                                            }
                                            isTakingPhoto = false
                                            bitmapResult
                                                .onSuccess { bmp -> onBitmapCaptured(bmp) }
                                                .onFailure { err ->
                                                    onCaptureError(err.localizedMessage ?: "Error")
                                                }
                                        }
                                    }

                                    override fun onError(exception: ImageCaptureException) {
                                        isTakingPhoto = false
                                        onCaptureError(exception.localizedMessage ?: "Error")
                                    }
                                }
                            )
                        }
                        .semantics(mergeDescendants = true) {}
                        .testTag("camera_capture_button")
                ) {
                    if (isTakingPhoto) {
                        CircularProgressIndicator(
                            color = Color.White,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(34.dp)
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(58.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CameraAlt,
                                contentDescription = stringResource(R.string.action_capture_photo),
                                tint = Color.White,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }
                }

                // Balancing spacer to keep shutter centered visually
                Spacer(modifier = Modifier.width(96.dp))
            }
        }
    }
}

@Composable
private fun CapturedDocumentReviewView(
    rawBitmap: Bitmap,
    onRetake: () -> Unit,
    onConfirm: (Bitmap, ExtractedCameraLabel?, PdfRenderSource) -> Unit,
    onClose: () -> Unit
) {
    var extraRotationDegrees by remember(rawBitmap) { mutableIntStateOf(0) }
    var highContrastBw by remember(rawBitmap) { mutableStateOf(false) }
    var processedBitmap by remember(rawBitmap) { mutableStateOf(rawBitmap) }
    var isProcessingImage by remember(rawBitmap) { mutableStateOf(false) }
    var isExtractingOcr by remember(rawBitmap) { mutableStateOf(true) }
    var extractedResult by remember(rawBitmap) { mutableStateOf<ExtractedCameraLabel?>(null) }
    var selectedRenderSource by remember(rawBitmap) {
        mutableStateOf(PdfRenderSource.CAPTURED_DOCUMENT)
    }

    LaunchedEffect(rawBitmap, extraRotationDegrees, highContrastBw) {
        isProcessingImage = true
        val transformed = withContext(Dispatchers.Default) {
            val rotated = rotateBitmapIfNeeded(rawBitmap, extraRotationDegrees)
            if (highContrastBw) {
                applyHighContrastDocumentFilter(rotated)
            } else {
                rotated
            }
        }
        processedBitmap = transformed
        isProcessingImage = false

        isExtractingOcr = true
        val extraction = CameraLabelExtractor.extractFromBitmap(transformed)
        extractedResult = extraction
        isExtractingOcr = false
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0B0F19)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            // Top Review Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("camera_review_close_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.cd_back),
                        tint = Color.White
                    )
                }

                Text(
                    text = stringResource(R.string.camera_screen_title),
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White
                )

                IconButton(
                    onClick = { extraRotationDegrees = (extraRotationDegrees + 90) % 360 },
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("camera_rotate_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Outlined.RotateRight,
                        contentDescription = stringResource(R.string.action_rotate_90),
                        tint = Color.White
                    )
                }
            }

            // Captured Document Image Preview
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    bitmap = processedBitmap.asImageBitmap(),
                    contentDescription = stringResource(R.string.cd_captured_preview),
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(8.dp))
                )

                if (isProcessingImage) {
                    CircularProgressIndicator(color = Color.White)
                }
            }

            // OCR Preview, Render Mode & Save/Confirm Controls
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Live OCR & Barcode Extraction Summary Card
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("camera_ocr_status_card"),
                        shape = MaterialTheme.shapes.medium,
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (isExtractingOcr) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.5.dp
                                )
                                Text(
                                    text = stringResource(R.string.camera_ocr_scanning),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Filled.DocumentScanner,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(22.dp)
                                )
                                val currentExtract = extractedResult
                                Column(modifier = Modifier.weight(1f)) {
                                    if (currentExtract != null && (
                                            currentExtract.detectedBarcode != null ||
                                                currentExtract.rawRecognizedText.isNotBlank()
                                            )
                                    ) {
                                        Text(
                                            text = stringResource(R.string.camera_ocr_detected_title),
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = "${currentExtract.labelData.waybillNumber} • ${currentExtract.labelData.recipientName}",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        if (currentExtract.labelData.recipientAddress.isNotBlank()) {
                                            Text(
                                                text = currentExtract.labelData.recipientAddress,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    } else {
                                        Text(
                                            text = stringResource(R.string.camera_ocr_fallback_title),
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer
                                        )
                                        Text(
                                            text = stringResource(R.string.camera_ocr_fallback_desc),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Filter & Output Mode Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilterChip(
                            selected = selectedRenderSource == PdfRenderSource.CAPTURED_DOCUMENT,
                            onClick = { selectedRenderSource = PdfRenderSource.CAPTURED_DOCUMENT },
                            label = {
                                Text(
                                    text = stringResource(R.string.camera_apply_mode_photo),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Outlined.PhotoCamera,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("camera_mode_photo_chip")
                        )

                        FilterChip(
                            selected = selectedRenderSource == PdfRenderSource.VECTOR_RECONSTRUCTION,
                            onClick = { selectedRenderSource = PdfRenderSource.VECTOR_RECONSTRUCTION },
                            label = {
                                Text(
                                    text = stringResource(R.string.camera_apply_mode_vector),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Outlined.AutoFixHigh,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("camera_mode_vector_chip")
                        )
                    }

                    FilterChip(
                        selected = highContrastBw,
                        onClick = { highContrastBw = !highContrastBw },
                        label = {
                            Text(
                                text = stringResource(R.string.filter_high_contrast_bw),
                                style = MaterialTheme.typography.labelSmall
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.Contrast,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("camera_bw_filter_chip")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = onRetake,
                            contentPadding = PaddingValues(horizontal = 12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("camera_retake_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Refresh,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(stringResource(R.string.action_retake_photo))
                        }

                        Button(
                            onClick = {
                                onConfirm(
                                    processedBitmap,
                                    extractedResult,
                                    selectedRenderSource
                                )
                            },
                            enabled = !isProcessingImage && !isExtractingOcr,
                            contentPadding = PaddingValues(horizontal = 12.dp),
                            modifier = Modifier
                                .weight(1.35f)
                                .height(50.dp)
                                .testTag("camera_confirm_use_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Check,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(stringResource(R.string.action_save_and_use_pdf))
                        }
                    }
                }
            }
        }
    }
}

internal fun rotateBitmapIfNeeded(source: Bitmap, rotationDegrees: Int): Bitmap {
    val normalized = ((rotationDegrees % 360) + 360) % 360
    if (normalized == 0) return source
    val matrix = Matrix().apply { postRotate(normalized.toFloat()) }
    return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
}

internal fun applyHighContrastDocumentFilter(source: Bitmap): Bitmap {
    val output = createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(output)
    // Desaturate to grayscale + boost contrast for crisp document/thermal PDF readability
    val grayscale = ColorMatrix().apply { setSaturation(0f) }
    val contrast = 1.45f
    val translate = (-0.5f * contrast + 0.5f) * 255f
    val contrastMatrix = ColorMatrix(
        floatArrayOf(
            contrast, 0f, 0f, 0f, translate,
            0f, contrast, 0f, 0f, translate,
            0f, 0f, contrast, 0f, translate,
            0f, 0f, 0f, 1f, 0f
        )
    )
    grayscale.postConcat(contrastMatrix)
    val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
        colorFilter = ColorMatrixColorFilter(grayscale)
    }
    canvas.drawBitmap(source, 0f, 0f, paint)
    return output
}
