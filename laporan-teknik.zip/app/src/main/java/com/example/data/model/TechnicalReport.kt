package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "technical_reports")
data class TechnicalReport(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    // 1. Header Dokumen
    val title: String = "LAPORAN TEKNIK",
    val companyName: String = "Hiba Group",
    val reportNumber: String = "",
    val workshop: String = "",
    val reportDate: String = "",

    // 2. Informasi Unit/Alat
    val manufacturer: String = "",
    val unitType: String = "",
    val model: String = "",
    val unitCode: String = "",
    val toolName: String = "",
    val damageDate: String = "",
    val mileageKmHm: String = "",
    val component: String = "",

    // 3. Status Garansi
    val warrantyStatus: WarrantyStatus = WarrantyStatus.AFTER_WARRANTY,

    // 4. Detail Kerusakan, Lokasi & Analisa (Khusus Desain 2 & Riwayat)
    val damageDetail: String = "",
    val location: String = "",
    val storingStatus: String = "Storing",
    val analysisNotes: String = "",
    val conclusionNotes: String = "",
    val workshopHistory: String = "",
    val tireHistory: String = "",
    val lastReplacement: String = "",
    val lastReplacementWo: String = "",
    val lastWeeklyCheck: String = "",
    val lastWeeklyCheckWo: String = "",
    val attachments: String = "Foto Kerusakan terlampir",
    val damagePhotoUri: String = "", // Path or Uri to damage photo

    // 5. Penyebab Kerusakan (Checkbox & Penjelasan)
    val causeInstallation: Boolean = false,
    val causeInstallationNotes: String = "",
    val causeQuality: Boolean = false,
    val causeQualityNotes: String = "",
    val causeOperational: Boolean = false,
    val causeOperationalNotes: String = "",
    val causeTimeExpired: Boolean = false,
    val causeTimeExpiredNotes: String = "",
    val causeOthers: Boolean = false,
    val causeOthersNotes: String = "",

    // 6. Cara Mengatasi Kerusakan
    val solutionReplacePart: Boolean = false,
    val solutionReplacePartNotes: String = "",
    val solutionReinstallAdjust: Boolean = false,
    val solutionReinstallAdjustNotes: String = "",
    val solutionModification: Boolean = false,
    val solutionModificationNotes: String = "",

    // 7. Usulan & Pending (Khusus Desain 2)
    val pendingReason: String = "",
    val reporterProposal: String = "",

    // 8. Tabel Parts yang Harus Diganti
    val partsList: List<PartItem> = emptyList(),

    // 9. Bagian Penandatangan
    val knownBy1: String = "",
    val knownBy2: String = "SUHERMAN",
    val approvedByName: String = "",
    val approvedByTitle: String = "",
    val reportedByName: String = "",
    val reportedByTitle: String = "",
    val signDate: String = "",

    // Template aktif: 1 = Desain 1 (Standar Dealer), 2 = Desain 2 (Hiba Group)
    val activeTemplate: Int = 1,

    // Metadata
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
