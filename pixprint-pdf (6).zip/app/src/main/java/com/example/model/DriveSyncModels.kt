package com.example.model

enum class DriveSyncMode {
    TWO_WAY_MERGE,
    UPLOAD_ONLY,
    RESTORE_ONLY;

    companion object {
        fun fromStoredName(raw: String?): DriveSyncMode {
            return entries.firstOrNull { it.name == raw } ?: TWO_WAY_MERGE
        }
    }
}

data class DriveSyncPreferences(
    val isDriveConnected: Boolean = false,
    val autoSyncHistory: Boolean = true,
    val autoUploadPdf: Boolean = false,
    val syncMode: DriveSyncMode = DriveSyncMode.TWO_WAY_MERGE,
    val driveFolderName: String = DEFAULT_DRIVE_FOLDER_NAME,
    val cachedFolderId: String = "",
    val cachedSyncFileId: String = "",
    val lastSyncTimeMillis: Long = 0L,
    val lastSyncMessage: String = "",
    val lastSyncSuccess: Boolean = true,
    val deletedTombstones: Map<String, Long> = emptyMap()
) {
    val sanitizedFolderName: String
        get() = sanitizeDriveFolderName(driveFolderName)

    companion object {
        const val DEFAULT_DRIVE_FOLDER_NAME = "Cetak Resi PDF"
        const val SYNC_JSON_FILE_NAME = "riwayat_resi_sync.json"

        fun sanitizeDriveFolderName(raw: String): String {
            val cleaned = raw
                .replace(Regex("[\\r\\n\\t/\\\\]"), " ")
                .replace(Regex("\\s+"), " ")
                .trim()
                .take(80)
            return cleaned.ifBlank { DEFAULT_DRIVE_FOLDER_NAME }
        }
    }
}

data class DriveSyncPayload(
    val schemaVersion: Int = 1,
    val exportedAtMillis: Long = System.currentTimeMillis(),
    val items: List<LabelHistoryItem> = emptyList(),
    val deletedTombstones: Map<String, Long> = emptyMap()
)

data class DriveSyncExecutionResult(
    val uploadedItemCount: Int,
    val restoredItemCount: Int,
    val deletedLocalCount: Int,
    val uploadedPdfCount: Int,
    val folderName: String,
    val syncedAtMillis: Long
)
