package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ImportMode

/**
 * Flexible Import Mode Selection Dialog:
 * Allows user to choose between Append (add to existing) or Replace All (overwrite database).
 */
@Composable
fun ImportModeDialog(
    fileName: String,
    isDatabaseFile: Boolean,
    initialMode: ImportMode = ImportMode.UPDATE_EXISTING,
    onDismiss: () -> Unit,
    onConfirm: (ImportMode) -> Unit
) {
    var selectedMode by remember(initialMode) {
        mutableStateOf(initialMode)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isDatabaseFile) Icons.Default.Storage else Icons.Default.PlaylistAdd,
                        contentDescription = "Metode Simpan",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Metode Simpan Import",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    Text(
                        text = if (isDatabaseFile) "Berkas Database SQLite (.db)" else "Berkas Spreadsheet CSV / Excel",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Info Box File
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "File:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = fileName,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Pilih bagaimana data akan disimpan ke dalam aplikasi:",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(10.dp))

                // OPSI 1: UPDATE & MERGE (Perbarui Data Sama)
                ModeOptionCard(
                    title = "Perbarui Data Sama (Update & Merge)",
                    badge = "Rekomendasi Cerdas",
                    badgeColor = Color(0xFF0D9488),
                    badgeBgColor = Color(0xFFCCFBF1),
                    subtitle = "Memperbarui data yang sama (nomor WO/item) dengan data baru, menambahkan data baru, tanpa menghapus data lama lainnya.",
                    icon = Icons.Default.Sync,
                    isSelected = selectedMode == ImportMode.UPDATE_EXISTING,
                    onClick = { selectedMode = ImportMode.UPDATE_EXISTING },
                    testTag = "import_mode_update_option"
                )

                Spacer(modifier = Modifier.height(10.dp))

                // OPSI 2: APPEND
                ModeOptionCard(
                    title = "Append (Tambahkan Saja)",
                    badge = "Penambahan Saja",
                    badgeColor = Color(0xFF2E7D32),
                    badgeBgColor = Color(0xFFE8F5E9),
                    subtitle = "Data dari file akan ditambahkan sebagai baris baru tanpa memperbarui data yang sudah ada.",
                    icon = Icons.Default.PlaylistAdd,
                    isSelected = selectedMode == ImportMode.APPEND,
                    onClick = { selectedMode = ImportMode.APPEND },
                    testTag = "import_mode_append_option"
                )

                Spacer(modifier = Modifier.height(10.dp))

                // OPSI 3: REPLACE ALL
                ModeOptionCard(
                    title = "Replace All (Ganti Seluruh Database)",
                    badge = "Hapus Bersih & Ganti",
                    badgeColor = Color(0xFFC62828),
                    badgeBgColor = Color(0xFFFFEBEE),
                    subtitle = "Seluruh data lama di database akan dikosongkan dan digantikan sepenuhnya oleh data file ini.",
                    icon = Icons.Default.Sync,
                    isSelected = selectedMode == ImportMode.REPLACE_ALL,
                    onClick = { selectedMode = ImportMode.REPLACE_ALL },
                    testTag = "import_mode_replace_option"
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(selectedMode) },
                modifier = Modifier.testTag("confirm_import_mode_button")
            ) {
                Text("Mulai Import")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}

@Composable
private fun ModeOptionCard(
    title: String,
    badge: String,
    badgeColor: Color,
    badgeBgColor: Color,
    subtitle: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected)
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
            else
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
        ),
        border = BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.Top
        ) {
            RadioButton(
                selected = isSelected,
                onClick = onClick,
                modifier = Modifier.size(24.dp)
            )

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = title,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = badgeBgColor
                ) {
                    Text(
                        text = badge,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = badgeColor,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 14.sp
                )
            }
        }
    }
}
