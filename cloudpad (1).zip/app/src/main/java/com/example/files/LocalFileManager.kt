package com.example.files

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.data.model.Note
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.Locale

data class OpenedLocalFile(
    val note: Note,
    val fileName: String,
    val uri: Uri
)

object LocalFileManager {

    private const val MAX_FILE_BYTES = 900_000 // Keep safely under Firestore 1MB document limit

    suspend fun readNoteFromUri(context: Context, uri: Uri): Result<OpenedLocalFile> =
        withContext(Dispatchers.IO) {
            try {
                val resolver = context.contentResolver
                val rawFileName = resolveFileName(context, uri)
                val (title, extension) = splitFileName(rawFileName)

                val inputStream = resolver.openInputStream(uri)
                    ?: return@withContext Result.failure(
                        IllegalStateException("Tidak dapat membuka aliran data file.")
                    )

                val bytes = inputStream.use { stream ->
                    val buffer = ByteArrayOutputStream()
                    val chunk = ByteArray(8192)
                    var totalRead = 0
                    while (true) {
                        val read = stream.read(chunk)
                        if (read == -1) break
                        totalRead += read
                        if (totalRead > MAX_FILE_BYTES) {
                            return@withContext Result.failure(
                                IllegalArgumentException("Ukuran file terlalu besar (maksimal 900 KB).")
                            )
                        }
                        buffer.write(chunk, 0, read)
                    }
                    buffer.toByteArray()
                }

                // Basic binary file detection: check for NUL bytes in initial slice
                val sampleSize = minOf(bytes.size, 4096)
                for (i in 0 until sampleSize) {
                    if (bytes[i].toInt() == 0) {
                        return@withContext Result.failure(
                            IllegalArgumentException("File biner tidak didukung. Pilih file teks atau kode.")
                        )
                    }
                }

                val textContent = bytes.toString(Charsets.UTF_8)
                val note = Note(
                    title = title,
                    content = textContent,
                    tags = listOf("lokal", extension),
                    fileExtension = extension
                )

                Result.success(
                    OpenedLocalFile(
                        note = note,
                        fileName = rawFileName,
                        uri = uri
                    )
                )
            } catch (e: SecurityException) {
                Result.failure(IllegalStateException("Izin akses file ditolak atau kadaluarsa.", e))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun writeNoteToUri(context: Context, uri: Uri, content: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val outputStream = context.contentResolver.openOutputStream(uri, "wt")
                    ?: context.contentResolver.openOutputStream(uri)
                    ?: return@withContext Result.failure(
                        IllegalStateException("File ini bersifat hanya-baca dan tidak dapat ditimpa langsung.")
                    )

                outputStream.use { stream ->
                    stream.write(content.toByteArray(Charsets.UTF_8))
                    stream.flush()
                }
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    fun resolveFileName(context: Context, uri: Uri): String {
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (nameIndex >= 0) {
                            val name = cursor.getString(nameIndex)
                            if (!name.isNullOrBlank()) return name
                        }
                    }
                }
        }
        return uri.lastPathSegment?.substringAfterLast('/')?.ifBlank { "catatan_lokal.txt" }
            ?: "catatan_lokal.txt"
    }

    fun splitFileName(fileName: String): Pair<String, String> {
        val cleanName = fileName.trim()
        val lastDot = cleanName.lastIndexOf('.')
        return if (lastDot > 0 && lastDot < cleanName.length - 1) {
            val title = cleanName.substring(0, lastDot)
            val ext = cleanName.substring(lastDot + 1)
                .lowercase(Locale.ROOT)
                .replace("[^a-z0-9]".toRegex(), "")
                .ifBlank { "txt" }
            title to ext
        } else {
            cleanName.ifBlank { "Catatan Lokal" } to "txt"
        }
    }
}
