package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val StudioCyan = Color(0xFF00E5FF)
val StudioCyanGlow = Color(0x3300E5FF)
val StudioViolet = Color(0xFF8B5CF6)
val StudioGold = Color(0xFFF59E0B)
val StudioEmerald = Color(0xFF10B981)
val StudioRose = Color(0xFFF43F5E)

val DarkObsidian = Color(0xFF0D1117)
val DarkSurface = Color(0xFF161B22)
val DarkSurfaceVariant = Color(0xFF21262D)
val DarkBorder = Color(0xFF30363D)

val TextPrimary = Color(0xFFF0F6FC)
val TextSecondary = Color(0xFF8B949E)
val TextTertiary = Color(0xFF6E7681)
