package com.example.data.model

data class FilterCriteria(
    val searchQuery: String = "",
    val searchColumn2Index: Int = 2,
    val searchQuery2: String = "",
    val columnFilters: Map<Int, String> = emptyMap(),
    val statusFilter: String? = null,
    val categoryFilter: String? = null,
    val sortColumnIndex: Int = 0,
    val isSortAscending: Boolean = true
) {
    val isActive: Boolean
        get() = searchQuery.isNotEmpty() ||
                searchQuery2.isNotEmpty() ||
                columnFilters.isNotEmpty() ||
                !statusFilter.isNullOrEmpty() ||
                !categoryFilter.isNullOrEmpty()

    val activeCount: Int
        get() {
            var count = 0
            if (searchQuery.isNotEmpty()) count++
            if (searchQuery2.isNotEmpty()) count++
            count += columnFilters.size
            if (!statusFilter.isNullOrEmpty()) count++
            if (!categoryFilter.isNullOrEmpty()) count++
            return count
        }
}
