# Social Video Downloader (Android App & FastAPI Backend)

A complete full-stack solution to extract and download high-definition videos and audio from TikTok, Instagram, YouTube, X (Twitter), and Facebook. It pairs a modern Jetpack Compose Material 3 Android frontend (with DownloadManager & Retrofit) with a high-performance Python FastAPI + yt-dlp backend microservice.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural decisions have been aligned based on your preferences:

- **Confirmed Decision 1 (Android UI Architecture)**: The live Android application will be built using modern Jetpack Compose with Material 3 styling (rich media card preview, format chips, and download progress), along with complete reference source code for the classic XML layout (`activity_main.xml` and ViewBinding) for Android Studio developers.
- **Confirmed Decision 2 (Download & Extraction Capabilities)**: The FastAPI backend will analyze incoming links and return rich metadata (thumbnail, title, author, duration, platform badge) along with multiple download options (best video MP4 with audio, 1080p/720p/480p, and audio extraction MP3).
- **Confirmed Decision 3 (Server Connectivity)**: The Android app will include an easy in-app Server Settings dialog (defaulting to `http://10.0.2.2:8000` for the Android Studio emulator, or your computer's local Wi-Fi IP `http://192.168.x.x:8000` for physical devices) with health-check testing.

---

## 1. Overview & Core Concept

- **What It Does**: Users copy a link from TikTok, Instagram Reels, YouTube, Facebook, or Twitter, paste it into the Android app (or tap a quick "Paste from Clipboard" button), and the app queries the local or remote FastAPI backend. The backend uses `yt-dlp` to extract direct, un-watermarked media streams. Users can preview the video thumbnail and title, select their desired format/resolution, and start downloading directly to their device's public `Download/` or gallery storage via Android's native `DownloadManager`.
- **Target Audience / Persona**: Content creators, students, and mobile users wanting to save social clips, educational videos, and music offline without invasive advertisements or watermarks.
- **Key Value**: Reliable, fast extraction powered by `yt-dlp` decoupled into a modular Python backend, giving Android clients direct download speeds without browser redirects or bloatware.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Input & Paste**: The user opens the app. If a social link is already on the clipboard, a floating prompt or 1-tap "Paste" button appears.
2. **Analysis & Loading**: The user taps "Inspect Link". A smooth loading indicator displays while the backend extracts formats and stream URLs.
3. **Media Card Preview & Format Selection**: The card expands showing the video thumbnail, title, platform icon (TikTok / Instagram / YouTube / etc.), and resolution chips (e.g., `1080p HD`, `720p`, `480p`, `Audio MP3`).
4. **Download Execution**: The user selects a format and taps "Download Video". Android's native `DownloadManager` handles the background transfer with a system notification.
5. **Server Setup & Connection Health**: An accessible settings icon in the top app bar opens a sheet allowing users to test their FastAPI backend connection and switch between Emulator (`10.0.2.2:8000`), Local Wi-Fi, or custom cloud domains.

### Visual Identity & Theme

- **Aesthetic Direction**: Sleek, modern utility with dark-mode aesthetic, dynamic gradient accents, and tactile Material 3 cards.
- **Color Palette**:
  - Primary: Deep Indigo / Violet (`#6366F1`)
  - Secondary / Accent: Electric Cyan (`#06B6D4`)
  - Surface & Background: Midnight Dark (`#0F172A`) and Card Slate (`#1E293B`)
  - Status Accents: Success Green (`#10B981`) and Warning Amber (`#F59E0B`)
- **Typography**: Clean modern sans-serif typography with strong visual hierarchy for video titles, platform badges, and file sizes.
- **Interactive Feedback**: Haptic feedback on tap, ripple effects on format pills, smooth animated transitions (`AnimatedVisibility`) when video info loads, and snackbars for download confirmations.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Direct Streams vs. Proxy Download**:
  - *Chosen Approach*: The FastAPI backend extracts direct CDN download URLs using `yt-dlp` and passes them to Android's `DownloadManager`. For platforms that restrict direct IP streaming (e.g., some token-bound streams), the backend also provides a fallback stream endpoint `/download/stream`.
  - *Why*: Direct stream URLs allow Android's OS to download directly at maximum network speed and resume downloads without putting heavy bandwidth load on the local Python server.
- **Decision 2: Android Native DownloadManager**:
  - *Chosen Approach*: Delegating file downloads to `android.app.DownloadManager`.
  - *Why*: Runs in a system background service, automatically handles network interruptions, provides standard system download notifications, and automatically registers media in the Android MediaStore.
- **Decision 3: Server Address Portability**:
  - *Chosen Approach*: Providing a persistent Settings preference (via local state / SharedPreferences) allowing dynamic backend URL configuration.
  - *Why*: Allows seamless switching between Android Studio's AVD emulator (`10.0.2.2:8000`) and physical devices on the same Wi-Fi network (`192.168.x.x:8000`).

---

## 4. Technical Architecture & Data Strategy

### System Architecture Diagram

```
┌──────────────────────────────────────────────────────────────┐
│                    Android Mobile Client                     │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐  │
│  │                     User Interface                     │  │
│  │   • URL Input Field & Clipboard Paste Button           │  │
│  │   • Video Card Preview (Coil Image Loader)             │  │
│  │   • Format & Resolution Selector (Chips)               │  │
│  │   • Backend Server Config & Health Check Dialog        │  │
│  └──────────────────────────┬─────────────────────────────┘  │
│                             │ State Flow / Events            │
│  ┌──────────────────────────▼─────────────────────────────┐  │
│  │              DownloaderViewModel (MVVM)                │  │
│  └──────────────┬───────────────────────────┬─────────────┘  │
│                 │ Retrofit REST Call        │ Start Download │
│                 ▼                           ▼                │
│       ┌───────────────────┐       ┌───────────────────┐      │
│       │  ApiClient Service│       │  DownloadManager  │      │
│       └─────────┬─────────┘       └─────────┬─────────┘      │
└─────────────────┼───────────────────────────┼────────────────┘
                  │ HTTP POST /extract        │ Direct Media GET
                  ▼                           │
┌──────────────────────────────────┐          │
│      Python FastAPI Backend      │          │
│                                  │          │
│  ┌────────────────────────────┐  │          │
│  │      POST /api/extract     │  │          │
│  │   Input: { "url": "..." }  │  │          │
│  └──────────────┬─────────────┘  │          │
│                 │ yt_dlp.YoutubeDL()        │
│  ┌──────────────▼─────────────┐  │          │
│  │  Extract Info & Formats    │  │          │
│  │  (Title, Thumb, MP4/MP3)   │  │          │
│  └──────────────┬─────────────┘  │          │
│                 │ Return JSON    │          │
│                 ▼                │          │
│     { title, formats, ... }      │          │
└──────────────────────────────────┘          │
                                              ▼
                             ┌─────────────────────────────────┐
                             │ Social Platform CDN / Stream    │
                             │ (TikTok / IG / YT / X CDN)      │
                             └─────────────────────────────────┘
```

### Data Models

```kotlin
// Android Client Models
data class VideoExtractRequest(
    val url: String
)

data class VideoFormatOption(
    val formatId: String,
    val resolution: String,
    val extension: String,
    val downloadUrl: String,
    val fileSizeFormatted: String?,
    val isAudioOnly: Boolean = false
)

data class VideoInfoResponse(
    val title: String,
    val author: String?,
    val thumbnail: String?,
    val duration: String?,
    val platform: String?,
    val formats: List<VideoFormatOption>
)
```

### Planned Implementation Steps

1. **Android App Updates (`app/build.gradle.kts` & `AndroidManifest.xml`)**:
   - Add `INTERNET` and `ACCESS_NETWORK_STATE` permissions.
   - Configure cleartext HTTP traffic flag (`android:usesCleartextTraffic="true"`) so the app can communicate with local development servers (`http://10.0.2.2:8000` or `http://192.168.x.x:8000`).
   - Enable `coil-compose` for thumbnail loading.
2. **Android UI & Networking Implementation**:
   - Create `VideoDownloadService` with Retrofit interface.
   - Implement `DownloaderViewModel` with reactive UI states (Idle, Loading, Success, Error).
   - Build Material 3 Jetpack Compose screen with URL input, clipboard action, server setting dialog, video metadata preview, and format selector.
   - Implement `AndroidDownloader` utility leveraging `DownloadManager` with notification handling and MIME-type assignment.
   - Provide classic XML layout files (`activity_main.xml`) and companion documentation.
3. **Complete Backend Files & Documentation**:
   - Provide complete Python backend code (`backend/main.py`) using FastAPI and `yt-dlp`.
   - Provide `backend/requirements.txt` with exact tested package versions.
   - Provide a step-by-step execution guide for local testing (venv, pip, uvicorn), emulator testing, and physical device setup.
