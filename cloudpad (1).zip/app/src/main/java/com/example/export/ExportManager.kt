package com.example.export

import android.content.Context
import android.content.Intent
import com.example.data.model.Note
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ExportManager {

    val PRESET_EXTENSIONS = listOf("txt", "json", "html", "js", "py", "md")

    fun getMimeType(extension: String): String {
        return when (extension.lowercase(Locale.ROOT)) {
            "txt" -> "text/plain"
            "json" -> "application/json"
            "html", "htm" -> "text/html"
            "js", "javascript" -> "application/javascript"
            "py", "python" -> "text/x-python"
            "md", "markdown" -> "text/markdown"
            "css" -> "text/css"
            "kt", "kts" -> "text/x-kotlin"
            "java" -> "text/x-java-source"
            "sh", "bash" -> "application/x-sh"
            "xml" -> "text/xml"
            "yaml", "yml" -> "text/yaml"
            "csv" -> "text/csv"
            else -> "text/plain"
        }
    }

    fun getDefaultFileName(note: Note, extension: String): String {
        val sanitizedTitle = if (note.title.isNotBlank()) {
            note.title.trim().replace("[^a-zA-Z0-9_-]".toRegex(), "_").take(40)
        } else {
            "note_${note.id.take(8)}"
        }
        val cleanExt = extension.removePrefix(".").ifBlank { "txt" }
        return "$sanitizedTitle.$cleanExt"
    }

    fun generateExportContent(note: Note, extension: String): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val dateStr = dateFormat.format(Date(note.updatedAt))

        return when (extension.lowercase(Locale.ROOT)) {
            "json" -> {
                val tagsJson = note.tags.joinToString(", ") { "\"${it.replace("\"", "\\\"")}\"" }
                val escapedTitle = note.title.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n")
                val escapedContent = note.content.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r")
                """
                {
                  "id": "${note.id}",
                  "title": "$escapedTitle",
                  "content": "$escapedContent",
                  "tags": [$tagsJson],
                  "isPinned": ${note.isPinned},
                  "createdAt": ${note.createdAt},
                  "updatedAt": ${note.updatedAt},
                  "updatedAtFormatted": "$dateStr"
                }
                """.trimIndent()
            }
            "html" -> {
                val escapedContent = note.content
                    .replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                """
                <!DOCTYPE html>
                <html lang="id">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>${note.title.ifBlank { "Catatan CloudPad" }}</title>
                    <style>
                        body {
                            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
                            line-height: 1.6;
                            color: #1e293b;
                            background-color: #f8fafc;
                            margin: 0;
                            padding: 2rem;
                        }
                        .container {
                            max-width: 800px;
                            margin: 0 auto;
                            background: #ffffff;
                            padding: 2.5rem;
                            border-radius: 12px;
                            box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
                        }
                        h1 {
                            margin-top: 0;
                            color: #0f172a;
                            border-bottom: 2px solid #00adb5;
                            padding-bottom: 0.5rem;
                        }
                        .meta {
                            font-size: 0.875rem;
                            color: #64748b;
                            margin-bottom: 1.5rem;
                        }
                        .tags {
                            display: flex;
                            gap: 0.5rem;
                            margin-bottom: 1.5rem;
                        }
                        .tag {
                            background: #e0f2fe;
                            color: #0369a1;
                            padding: 0.2rem 0.6rem;
                            border-radius: 9999px;
                            font-size: 0.75rem;
                            font-weight: 500;
                        }
                        pre {
                            background: #0f172a;
                            color: #f8fafc;
                            padding: 1rem;
                            border-radius: 8px;
                            overflow-x: auto;
                            font-family: 'JetBrains Mono', Consolas, Monaco, monospace;
                            font-size: 0.9rem;
                            white-space: pre-wrap;
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <h1>${note.title.ifBlank { "Tanpa Judul" }}</h1>
                        <div class="meta">Terakhir diperbarui: $dateStr</div>
                        ${
                            if (note.tags.isNotEmpty()) {
                                "<div class=\"tags\">" + note.tags.joinToString("") { "<span class=\"tag\">#$it</span>" } + "</div>"
                            } else ""
                        }
                        <pre><code>$escapedContent</code></pre>
                    </div>
                </body>
                </html>
                """.trimIndent()
            }
            "js" -> {
                val tagsHeader = if (note.tags.isNotEmpty()) " * Tags: ${note.tags.joinToString(", ")}\n" else ""
                """
                /**
                 * CloudPad Note
                 * Title: ${note.title}
                 * Date: $dateStr
                $tagsHeader */

                ${note.content}
                """.trimIndent()
            }
            "py" -> {
                val tagsHeader = if (note.tags.isNotEmpty()) "Tags: ${note.tags.joinToString(", ")}\n" else ""
                val pyDoc = "\"\"\""
                "$pyDoc\nCloudPad Note\nTitle: ${note.title}\nDate: $dateStr\n$tagsHeader$pyDoc\n\n${note.content}"
            }
            else -> {
                // txt, md, custom
                val header = buildString {
                    if (note.title.isNotBlank()) {
                        append(note.title)
                        append("\n")
                        append("=".repeat(note.title.length))
                        append("\n\n")
                    }
                    if (note.tags.isNotEmpty()) {
                        append("Tags: ").append(note.tags.joinToString(", ")).append("\n\n")
                    }
                }
                header + note.content
            }
        }
    }

    fun createShareIntent(context: Context, note: Note, extension: String): Intent {
        val content = generateExportContent(note, extension)
        val fileName = getDefaultFileName(note, extension)
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, fileName)
            putExtra(Intent.EXTRA_TEXT, content)
        }
        return Intent.createChooser(sendIntent, "Bagikan $fileName")
    }
}
