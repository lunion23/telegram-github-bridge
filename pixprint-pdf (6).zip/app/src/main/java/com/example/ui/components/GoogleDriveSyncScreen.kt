package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.outlined.CloudDownload
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.CloudSync
import androidx.compose.material.icons.outlined.CloudUpload
import androidx.compose.material.icons.outlined.LinkOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.DriveSyncMode
import com.example.model.DriveSyncPreferences
import com.example.model.LabelHistoryItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoogleDriveSyncScreen(
    drivePrefs: DriveSyncPreferences,
    historyItems: List<LabelHistoryItem>,
    isSyncing: Boolean,
    onConnectClick: () -> Unit,
    onSyncNowClick: () -> Unit,
    onUploadAllPdfsClick: () -> Unit,
    onSelectSyncMode: (DriveSyncMode) -> Unit,
    onToggleAutoSync: (Boolean) -> Unit,
    onToggleAutoUploadPdf: (Boolean) -> Unit,
    onSaveFolderName: (String) -> Unit,
    onDisconnectClick: () -> Unit,
    onClose: () -> Unit
) {
    BackHandler(onBack = onClose)

    var folderInput by rememberSaveable(drivePrefs.driveFolderName) {
        mutableStateOf(drivePrefs.driveFolderName)
    }
    var showDisconnectDialog by remember { mutableStateOf(false) }

    val totalCount = historyItems.size
    val syncedCount = remember(historyItems) { historyItems.count { it.isSyncedToDrive } }
    val pdfBackedUpCount = remember(historyItems) {
        historyItems.count { it.drivePdfFileId.isNotBlank() }
    }
    val formattedLastSync = remember(drivePrefs.lastSyncTimeMillis) {
        if (drivePrefs.lastSyncTimeMillis > 0L) {
            formatDriveSyncTimestamp(drivePrefs.lastSyncTimeMillis)
        } else {
            null
        }
    }

    if (showDisconnectDialog) {
        AlertDialog(
            onDismissRequest = { showDisconnectDialog = false },
            title = { Text(stringResource(R.string.dialog_disconnect_drive_title)) },
            text = { Text(stringResource(R.string.dialog_disconnect_drive_message)) },
            confirmButton = {
                Button(
                    onClick = {
                        showDisconnectDialog = false
                        onDisconnectClick()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    ),
                    modifier = Modifier.testTag("confirm_disconnect_drive_button")
                ) {
                    Text(stringResource(R.string.action_disconnect_drive))
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showDisconnectDialog = false },
                    modifier = Modifier.testTag("cancel_disconnect_drive_button")
                ) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = stringResource(R.string.drive_sync_screen_title),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = stringResource(R.string.drive_sync_screen_subtitle),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("drive_sync_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 680.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1. Hero Connection & Sync Action Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("drive_connection_card"),
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(
                        containerColor = if (drivePrefs.isDriveConnected) {
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.42f)
                        } else {
                            MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f)
                        }
                    ),
                    border = BorderStroke(
                        1.dp,
                        if (drivePrefs.isDriveConnected) {
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
                        } else {
                            MaterialTheme.colorScheme.secondary.copy(alpha = 0.35f)
                        }
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (isSyncing) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(26.dp),
                                    strokeWidth = 2.8.dp
                                )
                            } else {
                                Icon(
                                    imageVector = if (drivePrefs.isDriveConnected) {
                                        Icons.Filled.CloudDone
                                    } else {
                                        Icons.Outlined.CloudOff
                                    },
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(28.dp)
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (drivePrefs.isDriveConnected) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.surface
                                    }
                                ) {
                                    Text(
                                        text = when {
                                            isSyncing -> stringResource(R.string.drive_badge_syncing)
                                            drivePrefs.isDriveConnected -> stringResource(R.string.drive_badge_connected)
                                            else -> stringResource(R.string.drive_badge_local_mode)
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (drivePrefs.isDriveConnected) {
                                            MaterialTheme.colorScheme.onPrimary
                                        } else {
                                            MaterialTheme.colorScheme.onSurface
                                        },
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (drivePrefs.isDriveConnected) {
                                        stringResource(R.string.drive_hero_connected_title)
                                    } else {
                                        stringResource(R.string.drive_hero_disconnected_title)
                                    },
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Text(
                            text = if (drivePrefs.isDriveConnected) {
                                stringResource(
                                    R.string.drive_stats_summary,
                                    totalCount,
                                    syncedCount,
                                    pdfBackedUpCount
                                )
                            } else {
                                stringResource(R.string.drive_hero_disconnected_desc)
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        if (drivePrefs.isDriveConnected || drivePrefs.lastSyncMessage.isNotBlank()) {
                            val statusText = when {
                                drivePrefs.lastSyncMessage.isNotBlank() -> drivePrefs.lastSyncMessage
                                formattedLastSync != null -> stringResource(
                                    R.string.drive_last_sync_time,
                                    formattedLastSync
                                )
                                else -> stringResource(R.string.drive_last_sync_never)
                            }
                            Text(
                                text = statusText,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (drivePrefs.lastSyncSuccess) {
                                    MaterialTheme.colorScheme.primary
                                } else {
                                    MaterialTheme.colorScheme.error
                                },
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        if (!drivePrefs.isDriveConnected) {
                            Button(
                                onClick = onConnectClick,
                                enabled = !isSyncing,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("connect_drive_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.CloudUpload,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(stringResource(R.string.action_connect_drive))
                            }
                        } else {
                            Button(
                                onClick = onSyncNowClick,
                                enabled = !isSyncing,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("sync_now_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Sync,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(stringResource(R.string.action_sync_now))
                            }

                            if (totalCount > 0) {
                                FilledTonalButton(
                                    onClick = onUploadAllPdfsClick,
                                    enabled = !isSyncing,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("upload_all_pdfs_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.PictureAsPdf,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(stringResource(R.string.action_upload_all_pdfs))
                                }
                            }
                        }
                    }
                }

                // 2. Sync Mode Selection Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.drive_section_sync_mode),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )

                        DriveSyncModeOptionCard(
                            icon = Icons.Outlined.CloudSync,
                            title = stringResource(R.string.drive_mode_two_way_title),
                            subtitle = stringResource(R.string.drive_mode_two_way_desc),
                            selected = drivePrefs.syncMode == DriveSyncMode.TWO_WAY_MERGE,
                            onClick = { onSelectSyncMode(DriveSyncMode.TWO_WAY_MERGE) },
                            testTag = "sync_mode_two_way"
                        )

                        DriveSyncModeOptionCard(
                            icon = Icons.Outlined.CloudUpload,
                            title = stringResource(R.string.drive_mode_upload_title),
                            subtitle = stringResource(R.string.drive_mode_upload_desc),
                            selected = drivePrefs.syncMode == DriveSyncMode.UPLOAD_ONLY,
                            onClick = { onSelectSyncMode(DriveSyncMode.UPLOAD_ONLY) },
                            testTag = "sync_mode_upload_only"
                        )

                        DriveSyncModeOptionCard(
                            icon = Icons.Outlined.CloudDownload,
                            title = stringResource(R.string.drive_mode_restore_title),
                            subtitle = stringResource(R.string.drive_mode_restore_desc),
                            selected = drivePrefs.syncMode == DriveSyncMode.RESTORE_ONLY,
                            onClick = { onSelectSyncMode(DriveSyncMode.RESTORE_ONLY) },
                            testTag = "sync_mode_restore_only"
                        )
                    }
                }

                // 3. Automation & PDF Backup Toggles Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.drive_section_automation),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.drive_auto_sync_title),
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = stringResource(R.string.drive_auto_sync_desc),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = drivePrefs.autoSyncHistory,
                                onCheckedChange = onToggleAutoSync,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("auto_sync_switch")
                            )
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.drive_auto_pdf_title),
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = stringResource(R.string.drive_auto_pdf_desc),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = drivePrefs.autoUploadPdf,
                                onCheckedChange = onToggleAutoUploadPdf,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("auto_upload_pdf_switch")
                            )
                        }
                    }
                }

                // 4. Custom Google Drive Folder Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.drive_section_folder),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )

                        OutlinedTextField(
                            value = folderInput,
                            onValueChange = { folderInput = it },
                            singleLine = true,
                            label = { Text(stringResource(R.string.drive_folder_label)) },
                            placeholder = { Text(stringResource(R.string.drive_folder_hint)) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Filled.Folder,
                                    contentDescription = null
                                )
                            },
                            supportingText = {
                                Text(stringResource(R.string.drive_folder_helper))
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("drive_folder_input")
                        )

                        val presetDefault = stringResource(R.string.drive_folder_preset_default)
                        val presetArchive = stringResource(R.string.drive_folder_preset_archive)
                        val presetDaily = stringResource(R.string.drive_folder_preset_daily)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(presetDefault, presetArchive, presetDaily).forEachIndexed { idx, preset ->
                                AssistChip(
                                    onClick = {
                                        folderInput = preset
                                        onSaveFolderName(preset)
                                    },
                                    label = { Text(preset) },
                                    modifier = Modifier.testTag("drive_folder_preset_$idx")
                                )
                            }
                        }

                        FilledTonalButton(
                            onClick = { onSaveFolderName(folderInput) },
                            modifier = Modifier
                                .align(Alignment.End)
                                .minimumInteractiveComponentSize()
                                .testTag("save_drive_folder_button")
                        ) {
                            Text(stringResource(R.string.action_save_folder))
                        }
                    }
                }

                // 5. Disconnect & Return to Local Mode Card
                if (drivePrefs.isDriveConnected) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = MaterialTheme.shapes.medium,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.35f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.drive_section_disconnect),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = stringResource(R.string.drive_disconnect_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedButton(
                                onClick = { showDisconnectDialog = true },
                                enabled = !isSyncing,
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.error
                                ),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.6f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("disconnect_drive_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.LinkOff,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(stringResource(R.string.action_disconnect_drive))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun DriveSyncModeOptionCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        shape = MaterialTheme.shapes.small,
        color = if (selected) {
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
        } else {
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
        },
        border = if (selected) {
            BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
        } else {
            null
        },
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                }
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            RadioButton(
                selected = selected,
                onClick = onClick,
                modifier = Modifier.minimumInteractiveComponentSize()
            )
        }
    }
}
