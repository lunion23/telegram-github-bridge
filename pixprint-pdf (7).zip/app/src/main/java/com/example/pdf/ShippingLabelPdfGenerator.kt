package com.example.pdf

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.graphics.createBitmap
import com.example.model.PaperSizePreset
import com.example.model.PdfRenderSource
import com.example.model.ShippingLabelData
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Generates native vector PDF files, camera-captured document PDFs, high-resolution preview Bitmaps,
 * and integrates with the Android system [PrintManager] spooler ("Print" / "Save as PDF").
 */
object ShippingLabelPdfGenerator {

    private const val REFERENCE_ASSET_NAME = "reference_label.jpg"
    private val printScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun Context.findActivity(): Activity? {
        var ctx: Context = this
        while (ctx is ContextWrapper) {
            if (ctx is Activity) return ctx
            ctx = ctx.baseContext
        }
        return null
    }

    fun loadReferenceBitmap(context: Context): Bitmap? {
        return try {
            context.assets.open(REFERENCE_ASSET_NAME).use { stream ->
                BitmapFactory.decodeStream(stream)
            }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Renders a crisp high-DPI Bitmap for live Compose preview.
     */
    fun renderPreviewBitmap(
        data: ShippingLabelData,
        paperPreset: PaperSizePreset,
        renderSource: PdfRenderSource,
        referenceBitmap: Bitmap?,
        capturedBitmap: Bitmap? = null,
        targetWidthPx: Int = 944
    ): Bitmap {
        val safeWidth = targetWidthPx.coerceAtLeast(100)
        val aspect = paperPreset.heightMm / paperPreset.widthMm
        val heightPx = (safeWidth * aspect).toInt().coerceAtLeast(100)
        val bitmap = createBitmap(safeWidth, heightPx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        ShippingLabelCanvasRenderer.renderPage(
            canvas = canvas,
            pageWidth = safeWidth.toFloat(),
            pageHeight = heightPx.toFloat(),
            data = data,
            paperPreset = paperPreset,
            renderSource = renderSource,
            referenceBitmap = referenceBitmap,
            capturedBitmap = capturedBitmap
        )
        return bitmap
    }

    /**
     * Writes a 1-page [PdfDocument] into [outputStream].
     */
    fun writePdfToStream(
        outputStream: OutputStream,
        data: ShippingLabelData,
        paperPreset: PaperSizePreset,
        renderSource: PdfRenderSource,
        referenceBitmap: Bitmap?,
        capturedBitmap: Bitmap? = null
    ) {
        val document = PdfDocument()
        try {
            val pageInfo = PdfDocument.PageInfo.Builder(
                paperPreset.widthPt,
                paperPreset.heightPt,
                1
            ).create()
            val page = document.startPage(pageInfo)
            ShippingLabelCanvasRenderer.renderPage(
                canvas = page.canvas,
                pageWidth = paperPreset.widthPt.toFloat(),
                pageHeight = paperPreset.heightPt.toFloat(),
                data = data,
                paperPreset = paperPreset,
                renderSource = renderSource,
                referenceBitmap = referenceBitmap,
                capturedBitmap = capturedBitmap
            )
            document.finishPage(page)
            document.writeTo(outputStream)
            outputStream.flush()
        } finally {
            document.close()
        }
    }

    /**
     * Creates a shareable PDF file inside `cacheDir/pdfs/` for FileProvider.
     */
    fun generateCachePdfFile(
        context: Context,
        data: ShippingLabelData,
        paperPreset: PaperSizePreset,
        renderSource: PdfRenderSource,
        referenceBitmap: Bitmap?,
        capturedBitmap: Bitmap? = null
    ): File {
        val pdfDir = File(context.cacheDir, "pdfs")
        if (!pdfDir.exists()) {
            pdfDir.mkdirs()
        }
        val sanitizedWaybill = data.waybillNumber
            .replace(Regex("[^A-Za-z0-9_-]"), "_")
            .take(48)
            .ifBlank { "Resi" }
        val baseName = if (renderSource == PdfRenderSource.CAPTURED_DOCUMENT) {
            "Dokumen_$sanitizedWaybill"
        } else {
            "Resi_$sanitizedWaybill"
        }
        val targetFile = File(pdfDir, "${baseName}.pdf")
        FileOutputStream(targetFile).use { fos ->
            writePdfToStream(
                outputStream = fos,
                data = data,
                paperPreset = paperPreset,
                renderSource = renderSource,
                referenceBitmap = referenceBitmap,
                capturedBitmap = capturedBitmap
            )
        }
        return targetFile
    }

    /**
     * Launches the Android system Print Spooler using a guaranteed Activity context.
     */
    fun launchSystemPrint(
        context: Context,
        jobName: String,
        data: ShippingLabelData,
        paperPreset: PaperSizePreset,
        renderSource: PdfRenderSource,
        referenceBitmap: Bitmap?,
        capturedBitmap: Bitmap? = null
    ) {
        val activity = context.findActivity()
            ?: throw IllegalStateException("Activity context required for PrintManager")
        val printManager = activity.getSystemService(Context.PRINT_SERVICE) as PrintManager

        val mediaSize = when (paperPreset) {
            PaperSizePreset.THERMAL_100X200 -> PrintAttributes.MediaSize(
                "THERMAL_100X200",
                "Thermal 100 x 200 mm",
                (100f / 25.4f * 1000f).toInt(),
                (200f / 25.4f * 1000f).toInt()
            )
            PaperSizePreset.THERMAL_78X150 -> PrintAttributes.MediaSize(
                "THERMAL_78X150",
                "Thermal 78 x 150 mm",
                (78f / 25.4f * 1000f).toInt(),
                (150f / 25.4f * 1000f).toInt()
            )
            PaperSizePreset.A6_PORTRAIT -> PrintAttributes.MediaSize.ISO_A6.asPortrait()
            PaperSizePreset.A4_ACTUAL_SIZE -> PrintAttributes.MediaSize.ISO_A4.asPortrait()
        }

        val colorMode = if (renderSource == PdfRenderSource.CAPTURED_DOCUMENT) {
            PrintAttributes.COLOR_MODE_COLOR
        } else {
            PrintAttributes.COLOR_MODE_MONOCHROME
        }

        val attributes = PrintAttributes.Builder()
            .setMediaSize(mediaSize)
            .setColorMode(colorMode)
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .build()

        val adapter = ShippingLabelPrintAdapter(
            documentName = "$jobName.pdf",
            data = data,
            paperPreset = paperPreset,
            renderSource = renderSource,
            referenceBitmap = referenceBitmap,
            capturedBitmap = capturedBitmap,
            ioScope = printScope
        )

        printManager.print(jobName, adapter, attributes)
    }
}

private class ShippingLabelPrintAdapter(
    private val documentName: String,
    private val data: ShippingLabelData,
    private val paperPreset: PaperSizePreset,
    private val renderSource: PdfRenderSource,
    private val referenceBitmap: Bitmap?,
    private val capturedBitmap: Bitmap?,
    private val ioScope: CoroutineScope
) : PrintDocumentAdapter() {

    @Volatile
    private var currentAttributes: PrintAttributes? = null

    override fun onLayout(
        oldAttributes: PrintAttributes?,
        newAttributes: PrintAttributes,
        cancellationSignal: CancellationSignal?,
        callback: LayoutResultCallback,
        extras: Bundle?
    ) {
        if (cancellationSignal?.isCanceled == true) {
            callback.onLayoutCancelled()
            return
        }
        currentAttributes = newAttributes
        val info = PrintDocumentInfo.Builder(documentName)
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
            .setPageCount(1)
            .build()
        callback.onLayoutFinished(info, oldAttributes != newAttributes)
    }

    override fun onWrite(
        pages: Array<out PageRange>?,
        destination: ParcelFileDescriptor,
        cancellationSignal: CancellationSignal?,
        callback: WriteResultCallback
    ) {
        val attributesSnapshot = currentAttributes
        val job = ioScope.launch {
            ParcelFileDescriptor.AutoCloseOutputStream(destination).use { out ->
                if (cancellationSignal?.isCanceled == true) {
                    callback.onWriteCancelled()
                    return@launch
                }

                val mediaSize = attributesSnapshot?.mediaSize
                val pageWidthPt = if (mediaSize != null) {
                    ((mediaSize.widthMils / 1000f) * 72f).toInt().coerceAtLeast(100)
                } else {
                    paperPreset.widthPt
                }
                val pageHeightPt = if (mediaSize != null) {
                    ((mediaSize.heightMils / 1000f) * 72f).toInt().coerceAtLeast(100)
                } else {
                    paperPreset.heightPt
                }

                val isSpoolerA4 = mediaSize != null && (
                    mediaSize.id == PrintAttributes.MediaSize.ISO_A4.id ||
                        (mediaSize.widthMils in 8000..8500 && mediaSize.heightMils in 11400..11900)
                    )
                val effectivePreset = when {
                    isSpoolerA4 -> PaperSizePreset.A4_ACTUAL_SIZE
                    mediaSize != null && paperPreset == PaperSizePreset.A4_ACTUAL_SIZE ->
                        PaperSizePreset.THERMAL_100X200
                    else -> paperPreset
                }

                val pdfDocument = PdfDocument()
                try {
                    val pageInfo = PdfDocument.PageInfo.Builder(pageWidthPt, pageHeightPt, 1).create()
                    val page = pdfDocument.startPage(pageInfo)
                    ShippingLabelCanvasRenderer.renderPage(
                        canvas = page.canvas,
                        pageWidth = pageWidthPt.toFloat(),
                        pageHeight = pageHeightPt.toFloat(),
                        data = data,
                        paperPreset = effectivePreset,
                        renderSource = renderSource,
                        referenceBitmap = referenceBitmap,
                        capturedBitmap = capturedBitmap
                    )
                    pdfDocument.finishPage(page)

                    if (cancellationSignal?.isCanceled == true) {
                        callback.onWriteCancelled()
                        return@launch
                    }

                    pdfDocument.writeTo(out)
                    out.flush()
                    callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    if (cancellationSignal?.isCanceled == true) {
                        callback.onWriteCancelled()
                    } else {
                        callback.onWriteFailed(e.localizedMessage ?: "PDF write error")
                    }
                } finally {
                    pdfDocument.close()
                }
            }
        }

        cancellationSignal?.setOnCancelListener {
            job.cancel()
        }
    }
}
