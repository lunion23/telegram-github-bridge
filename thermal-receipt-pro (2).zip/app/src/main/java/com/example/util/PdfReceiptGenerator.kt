package com.example.util

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.content.FileProvider
import com.example.data.model.PrintFormatMode
import com.example.data.model.ReceiptData
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

object PdfReceiptGenerator {

    const val PAGE_WIDTH = 560
    const val OPTION1_HEIGHT = 532
    const val OPTION2_HEIGHT = 330
    const val OPTION3_HEIGHT = 852
    const val OPTION4_HEIGHT = 320
    const val OPTION5_HEIGHT = 560

    /**
     * Generates a PDF file atomically from receipt data based on selected format.
     */
    fun generatePdfFile(context: Context, receipt: ReceiptData): File {
        val (pdfWidth, pdfHeight) = when (receipt.selectedFormat) {
            PrintFormatMode.MAIN_LABEL -> Pair(PAGE_WIDTH, OPTION1_HEIGHT)
            PrintFormatMode.SENDER_COPY -> Pair(PAGE_WIDTH, OPTION2_HEIGHT)
            PrintFormatMode.COMBO_ALL -> Pair(PAGE_WIDTH, OPTION3_HEIGHT)
            PrintFormatMode.SENDER_CLEAN -> Pair(PAGE_WIDTH, OPTION4_HEIGHT)
            PrintFormatMode.LABEL_ALT -> Pair(PAGE_WIDTH, OPTION5_HEIGHT)
        }

        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pdfWidth, pdfHeight, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        when (receipt.selectedFormat) {
            PrintFormatMode.MAIN_LABEL -> drawReceiptOnCanvas(canvas, receipt, pdfWidth.toFloat(), pdfHeight.toFloat())
            PrintFormatMode.SENDER_COPY -> drawSenderCopyOnCanvas(canvas, receipt, pdfWidth.toFloat(), pdfHeight.toFloat())
            PrintFormatMode.COMBO_ALL -> drawComboOnCanvas(canvas, receipt, pdfWidth.toFloat(), pdfHeight.toFloat())
            PrintFormatMode.SENDER_CLEAN -> drawSenderCleanOnCanvas(canvas, receipt, pdfWidth.toFloat(), pdfHeight.toFloat())
            PrintFormatMode.LABEL_ALT -> drawLabelAltOnCanvas(canvas, receipt, pdfWidth.toFloat(), pdfHeight.toFloat())
        }

        pdfDocument.finishPage(page)

        val outputDir = File(context.cacheDir, "receipt_pdfs").apply { mkdirs() }
        val sanitizedResi = receipt.resiCode.replace("[^a-zA-Z0-9]".toRegex(), "_")
        val outputFile = File(outputDir, "Struk_${receipt.selectedFormat.name}_${sanitizedResi}.pdf")

        // Atomic write via temp file to avoid concurrent read of partially written file
        val tempFile = File.createTempFile("tmp_receipt_", ".pdf", outputDir)
        FileOutputStream(tempFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        if (outputFile.exists()) {
            outputFile.delete()
        }
        if (!tempFile.renameTo(outputFile)) {
            tempFile.copyTo(outputFile, overwrite = true)
            tempFile.delete()
        }

        return outputFile
    }

    /**
     * Renders a PDF file into a high-resolution preview Bitmap using PdfRenderer safely.
     */
    fun renderPdfToBitmap(pdfFile: File): Bitmap? {
        if (!pdfFile.exists() || pdfFile.length() <= 0) return null
        return try {
            ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY).use { fileDescriptor ->
                val renderer = PdfRenderer(fileDescriptor)
                try {
                    if (renderer.pageCount == 0) return null
                    val page = renderer.openPage(0)
                    try {
                        val scale = 2.0f
                        val bitmap = Bitmap.createBitmap(
                            (page.width * scale).toInt(),
                            (page.height * scale).toInt(),
                            Bitmap.Config.ARGB_8888
                        )
                        bitmap.eraseColor(Color.WHITE)
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        bitmap
                    } finally {
                        page.close()
                    }
                } finally {
                    renderer.close()
                }
            }
        } catch (e: Throwable) {
            e.printStackTrace()
            null
        }
    }

    fun findActivity(context: Context): Activity? {
        var ctx = context
        while (ctx is ContextWrapper) {
            if (ctx is Activity) return ctx
            ctx = ctx.baseContext
        }
        return null
    }

    fun printPdf(context: Context, pdfFile: File, jobName: String = "Cetak Struk"): Boolean {
        return try {
            val activity = findActivity(context) ?: return false
            val printManager = activity.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return false
            val printAdapter = object : PrintDocumentAdapter() {
                override fun onLayout(
                    oldAttributes: PrintAttributes?,
                    newAttributes: PrintAttributes?,
                    cancellationSignal: CancellationSignal?,
                    callback: LayoutResultCallback?,
                    extras: Bundle?
                ) {
                    if (cancellationSignal?.isCanceled == true) {
                        callback?.onLayoutCancelled()
                        return
                    }
                    val info = PrintDocumentInfo.Builder("$jobName.pdf")
                        .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .setPageCount(1)
                        .build()
                    callback?.onLayoutFinished(info, true)
                }

                override fun onWrite(
                    pages: Array<out PageRange>?,
                    destination: ParcelFileDescriptor?,
                    cancellationSignal: CancellationSignal?,
                    callback: WriteResultCallback?
                ) {
                    var input: FileInputStream? = null
                    var output: FileOutputStream? = null
                    try {
                        input = FileInputStream(pdfFile)
                        output = FileOutputStream(destination?.fileDescriptor)
                        val buf = ByteArray(1024)
                        var bytesRead: Int
                        while (input.read(buf).also { bytesRead = it } > 0) {
                            if (cancellationSignal?.isCanceled == true) {
                                callback?.onWriteCancelled()
                                return
                            }
                            output.write(buf, 0, bytesRead)
                        }
                        callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                    } catch (e: Exception) {
                        callback?.onWriteFailed(e.message)
                    } finally {
                        try { input?.close() } catch (_: IOException) {}
                        try { output?.close() } catch (_: IOException) {}
                    }
                }
            }

            val attributes = PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A6)
                .setResolution(PrintAttributes.Resolution("thermal", "Thermal", 300, 300))
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .build()

            printManager.print(jobName, printAdapter, attributes)
            true
        } catch (e: Throwable) {
            e.printStackTrace()
            false
        }
    }

    fun sharePdf(context: Context, pdfFile: File) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.provider",
                pdfFile
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Struk Resi ${pdfFile.name}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, "Bagikan Struk PDF")
            if (context !is Activity) {
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * OPSI 1: Exact PDF layout matching IMG-20261021-WA0070_232e08d2.jpg
     * Canvas dimensions: 560 x 532.
     */
    fun drawReceiptOnCanvas(
        canvas: Canvas,
        receipt: ReceiptData,
        width: Float,
        height: Float
    ) {
        val bgPaint = Paint().apply { color = Color.WHITE; style = Paint.Style.FILL }
        canvas.drawRect(0f, 0f, width, height, bgPaint)

        val borderPaint = Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 2.5f; isAntiAlias = true }
        val thinLinePaint = Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 1.5f; isAntiAlias = true }

        val leftBorder = 34f
        val rightBorder = width - 34f
        val topBorder = 16f
        val bottomBorder = height - 16f

        // Outer Bounding Box
        canvas.drawRect(leftBorder, topBorder, rightBorder, bottomBorder, borderPaint)

        // Side Vertical Resi Text (2 on left, 2 on right as in reference image)
        drawVerticalSideResi(canvas, receipt.resiCode, leftBorder, rightBorder, topBorder, bottomBorder, listOf(0.28f, 0.78f))

        // Draw inner elements of Option 1
        drawReceiptInner(canvas, receipt, leftBorder, rightBorder, topBorder, bottomBorder, thinLinePaint)
    }

    private fun drawReceiptInner(
        canvas: Canvas,
        receipt: ReceiptData,
        leftBorder: Float,
        rightBorder: Float,
        topBorder: Float,
        bottomBorder: Float,
        thinLinePaint: Paint
    ) {
        val fillBlackPaint = Paint().apply { color = Color.BLACK; style = Paint.Style.FILL; isAntiAlias = true }
        val textPaint = Paint().apply { color = Color.BLACK; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL) }
        val boldTextPaint = Paint().apply { color = Color.BLACK; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }
        val whiteBoldPaint = Paint().apply { color = Color.WHITE; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }

        // 1. Top Routing Code & Badges [NP] [EZ]
        val badgeW = 42f
        val badgeH = 24f
        val badge2Left = rightBorder - badgeW - 6f
        val badge1Left = badge2Left - badgeW - 6f
        val badgeTop = topBorder + 7f

        canvas.drawRect(badge1Left, badgeTop, badge1Left + badgeW, badgeTop + badgeH, fillBlackPaint)
        canvas.drawRect(badge2Left, badgeTop, badge2Left + badgeW, badgeTop + badgeH, fillBlackPaint)

        whiteBoldPaint.textSize = 14f
        whiteBoldPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.badge1, badge1Left + (badgeW / 2), badgeTop + 17f, whiteBoldPaint)
        canvas.drawText(receipt.badge2, badge2Left + (badgeW / 2), badgeTop + 17f, whiteBoldPaint)

        boldTextPaint.textSize = 27f
        boldTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText(receipt.routingCode, leftBorder + 8f, badgeTop + 22f, boldTextPaint)

        val headerBottomY = topBorder + 40f
        canvas.drawLine(leftBorder, headerBottomY, rightBorder, headerBottomY, thinLinePaint)

        // 2. Barcode Section
        val barcodeBitmap = BarcodeGenerator.generateBarcode128(receipt.resiCode, width = 640, height = 110)
        val barcodeRect = RectF(leftBorder + 26f, headerBottomY + 6f, rightBorder - 26f, headerBottomY + 74f)
        if (barcodeBitmap != null) {
            canvas.drawBitmap(barcodeBitmap, null, barcodeRect, null)
        }

        val resiTextY = headerBottomY + 90f
        boldTextPaint.textSize = 13.5f
        boldTextPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.resiCode, (leftBorder + rightBorder) / 2f, resiTextY, boldTextPaint)

        // 3. Drop Point Banner
        val bannerTop = headerBottomY + 98f
        val bannerHeight = 28f
        canvas.drawRect(leftBorder, bannerTop, rightBorder, bannerTop + bannerHeight, fillBlackPaint)
        whiteBoldPaint.textSize = 13.5f
        whiteBoldPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.dropPoint.uppercase(), (leftBorder + rightBorder) / 2f, bannerTop + 19f, whiteBoldPaint)

        // 4. Recipient Section (Penerima)
        val recipientTop = bannerTop + bannerHeight
        var currentY = recipientTop + 15f
        boldTextPaint.textSize = 11.5f
        boldTextPaint.textAlign = Paint.Align.LEFT
        val recipPhone = receipt.getDisplayRecipientPhone()
        val rPhoneW = boldTextPaint.measureText(recipPhone)
        val maxRecipW = (rightBorder - leftBorder - 20f) - rPhoneW
        drawTextBounded(canvas, "Penerima: ${receipt.recipientName}", leftBorder + 8f, currentY, maxRecipW, boldTextPaint)
        boldTextPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(recipPhone, rightBorder - 8f, currentY, boldTextPaint)

        currentY += 4f
        textPaint.textSize = 9.2f
        textPaint.textAlign = Paint.Align.LEFT
        drawMultilineText(
            canvas,
            receipt.recipientAddress.uppercase(),
            leftBorder + 8f,
            currentY + 10f,
            rightBorder - leftBorder - 16f,
            textPaint,
            12.5f,
            3
        )

        val recipientBottomY = recipientTop + 68f
        canvas.drawLine(leftBorder, recipientBottomY, rightBorder, recipientBottomY, thinLinePaint)

        // 5. Sender Section (Pengirim)
        val senderTop = recipientBottomY
        currentY = senderTop + 15f
        boldTextPaint.textAlign = Paint.Align.LEFT
        val senderPhone = receipt.getDisplaySenderPhone()
        val sPhoneW = boldTextPaint.measureText(senderPhone)
        val maxSenderW = (rightBorder - leftBorder - 20f) - sPhoneW
        drawTextBounded(canvas, "Pengirim: ${receipt.senderName}", leftBorder + 8f, currentY, maxSenderW, boldTextPaint)
        boldTextPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(senderPhone, rightBorder - 8f, currentY, boldTextPaint)

        currentY += 4f
        currentY = drawMultilineText(
            canvas,
            receipt.senderAddress,
            leftBorder + 8f,
            currentY + 10f,
            rightBorder - leftBorder - 16f,
            textPaint,
            12.5f,
            3
        )

        val senderBottomY = senderTop + 68f
        canvas.drawLine(leftBorder, senderBottomY, rightBorder, senderBottomY, thinLinePaint)

        // 6. Details Table
        val tableTop = senderBottomY
        val col1Width = 114f
        val col2Width = 78f
        val col3Width = 98f

        val row1Height = 42f
        val row2Height = 23f
        val row3Height = 23f
        val tableHeight = row1Height + row2Height + row3Height

        canvas.drawLine(leftBorder, tableTop + row1Height, rightBorder, tableTop + row1Height, thinLinePaint)
        canvas.drawLine(leftBorder, tableTop + row1Height + row2Height, rightBorder, tableTop + row1Height + row2Height, thinLinePaint)
        canvas.drawLine(leftBorder, tableTop + tableHeight, rightBorder, tableTop + tableHeight, thinLinePaint)

        val col1Right = leftBorder + col1Width
        val col2Right = col1Right + col2Width
        val col3Right = col2Right + col3Width

        canvas.drawLine(col1Right, tableTop, col1Right, tableTop + row1Height + row2Height, thinLinePaint)
        canvas.drawLine(col2Right, tableTop, col2Right, tableTop + row1Height, thinLinePaint)
        canvas.drawLine(col3Right, tableTop, col3Right, tableTop + row1Height + row2Height, thinLinePaint)

        // Col 1: Header BIAYAPENGIRIMAN, fee, note
        canvas.drawRect(leftBorder, tableTop, col1Right, tableTop + 14f, fillBlackPaint)
        whiteBoldPaint.textSize = 8f
        whiteBoldPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("BIAYAPENGIRIMAN", leftBorder + (col1Width / 2f), tableTop + 10.5f, whiteBoldPaint)

        boldTextPaint.textSize = 13.5f
        boldTextPaint.textAlign = Paint.Align.CENTER
        val tightFee = receipt.getFormattedFee().replace("IDR ", "IDR")
        canvas.drawText(tightFee, leftBorder + (col1Width / 2f), tableTop + 27.5f, boldTextPaint)

        textPaint.textSize = 7.5f
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("Sudah Termasuk PPH", leftBorder + (col1Width / 2f), tableTop + 37f, textPaint)

        // Col 2: Tunai
        boldTextPaint.textSize = 12f
        canvas.drawText(receipt.paymentType, col1Right + (col2Width / 2f), tableTop + 26f, boldTextPaint)

        // Col 3: Weight
        boldTextPaint.textSize = 11.5f
        canvas.drawText("• ${receipt.weightKg}", col2Right + (col3Width / 2f), tableTop + 26f, boldTextPaint)

        // Col 4: Print Date
        textPaint.textSize = 10f
        canvas.drawText("Cetak ${receipt.printDate}", col3Right + ((rightBorder - col3Right) / 2f), tableTop + 26f, textPaint)

        // Row 2: Order No & Exp
        textPaint.textSize = 9.5f
        textPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Order No. ${receipt.orderNo}", col1Right + 6f, tableTop + row1Height + 15.5f, textPaint)
        canvas.drawText("Exp: ${receipt.expNote}", col3Right + 6f, tableTop + row1Height + 15.5f, textPaint)

        // Row 3: Notes
        textPaint.textSize = 10f
        drawTextBounded(canvas, "Notes: ${receipt.notes}", leftBorder + 8f, tableTop + row1Height + row2Height + 15.5f, rightBorder - leftBorder - 16f, textPaint)

        // 7. Footer Section
        val footerTop = tableTop + tableHeight
        val qrSize = 94f
        val qrLeft = rightBorder - qrSize - 4f
        val qrBitmap = BarcodeGenerator.generateQrCode(receipt.resiCode, size = 200)
        if (qrBitmap != null) {
            canvas.drawBitmap(qrBitmap, null, RectF(qrLeft, footerTop + 6f, qrLeft + qrSize, footerTop + 6f + qrSize), null)
        }

        textPaint.textSize = 8.5f
        textPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Syarat dan ketentuan pengiriman dilihat pada website", leftBorder + 8f, footerTop + 16f, textPaint)

        val lines = receipt.footerCompany.split("\n")
        var footerY = footerTop + 30f
        for (line in lines) {
            canvas.drawText(line.trim(), leftBorder + 8f, footerY, textPaint)
            footerY += 14f
        }
    }

    /**
     * OPSI 2: Lembar Pengirim dengan border margin vertikal (matching IMG-20261021-WA0053_cf311a20.jpg)
     * Canvas dimensions: 560 x 330.
     */
    fun drawSenderCopyOnCanvas(
        canvas: Canvas,
        receipt: ReceiptData,
        width: Float,
        height: Float
    ) {
        val bgPaint = Paint().apply { color = Color.WHITE; style = Paint.Style.FILL }
        canvas.drawRect(0f, 0f, width, height, bgPaint)

        val borderPaint = Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 2.5f; isAntiAlias = true }
        val thinLinePaint = Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 1.5f; isAntiAlias = true }

        val leftBorder = 34f
        val rightBorder = width - 34f
        val topBorder = 16f
        val bottomBorder = height - 16f

        canvas.drawRect(leftBorder, topBorder, rightBorder, bottomBorder, borderPaint)

        // Side Vertical Resi Text (1 repeat centered on each side)
        drawVerticalSideResi(canvas, receipt.resiCode, leftBorder, rightBorder, topBorder, bottomBorder, listOf(0.5f))

        // Draw inner elements of Option 2
        drawSenderCopyInner(canvas, receipt, leftBorder, rightBorder, topBorder, bottomBorder, thinLinePaint)
    }

    private fun drawSenderCopyInner(
        canvas: Canvas,
        receipt: ReceiptData,
        leftBorder: Float,
        rightBorder: Float,
        topBorder: Float,
        bottomBorder: Float,
        thinLinePaint: Paint
    ) {
        val fillBlackPaint = Paint().apply { color = Color.BLACK; style = Paint.Style.FILL; isAntiAlias = true }
        val textPaint = Paint().apply { color = Color.BLACK; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL) }
        val boldTextPaint = Paint().apply { color = Color.BLACK; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }
        val whiteBoldPaint = Paint().apply { color = Color.WHITE; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }

        // 1. Top Barcode
        val barcodeBitmap = BarcodeGenerator.generateBarcode128(receipt.resiCode, width = 600, height = 75)
        val barcodeRect = RectF(leftBorder + 30f, topBorder + 6f, rightBorder - 30f, topBorder + 40f)
        if (barcodeBitmap != null) {
            canvas.drawBitmap(barcodeBitmap, null, barcodeRect, null)
        }

        val resiTextY = topBorder + 52f
        boldTextPaint.textSize = 12f
        boldTextPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.resiCode, (leftBorder + rightBorder) / 2f, resiTextY, boldTextPaint)

        val barcodeBottomY = topBorder + 56f
        canvas.drawLine(leftBorder, barcodeBottomY, rightBorder, barcodeBottomY, thinLinePaint)

        // 2. Sender & Recipient Section
        var currentY = barcodeBottomY + 16f
        boldTextPaint.textSize = 11f
        boldTextPaint.textAlign = Paint.Align.LEFT
        val senderPhone = receipt.getDisplaySenderPhone()
        val sPhoneW = boldTextPaint.measureText(senderPhone)
        val maxSenderW = (rightBorder - leftBorder - 20f) - sPhoneW
        drawTextBounded(canvas, "Pengirim: ${receipt.senderName}", leftBorder + 8f, currentY, maxSenderW, boldTextPaint)
        boldTextPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(senderPhone, rightBorder - 8f, currentY, boldTextPaint)

        currentY += 16f
        boldTextPaint.textAlign = Paint.Align.LEFT
        val recipPhone = receipt.getDisplayRecipientPhone()
        val rPhoneW = boldTextPaint.measureText(recipPhone)
        val maxRecipW = (rightBorder - leftBorder - 20f) - rPhoneW
        drawTextBounded(canvas, "Penerima : ${receipt.recipientName}", leftBorder + 8f, currentY, maxRecipW, boldTextPaint)
        boldTextPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(recipPhone, rightBorder - 8f, currentY, boldTextPaint)

        currentY += 4f
        textPaint.textSize = 9.5f
        textPaint.textAlign = Paint.Align.LEFT
        drawMultilineText(
            canvas,
            receipt.recipientAddress,
            leftBorder + 8f,
            currentY + 11f,
            rightBorder - leftBorder - 16f,
            textPaint,
            13.5f,
            2
        )

        val addressBottomY = barcodeBottomY + 76f
        canvas.drawLine(leftBorder, addressBottomY, rightBorder, addressBottomY, thinLinePaint)

        // 3. Split Details Table (from addressBottomY to bottomBorder)
        val splitTop = addressBottomY
        val splitDividerX = leftBorder + 151f

        canvas.drawLine(splitDividerX, splitTop, splitDividerX, bottomBorder, thinLinePaint)

        // Left Column: Total Biaya + Lembar Pengirim badge
        val leftColCenter = (leftBorder + splitDividerX) / 2f
        boldTextPaint.textSize = 13.5f
        boldTextPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("TOTAL BIAYA", leftColCenter, splitTop + 24f, boldTextPaint)

        boldTextPaint.textSize = 16.5f
        canvas.drawText(receipt.getFormattedFee(), leftColCenter, splitTop + 48f, boldTextPaint)

        textPaint.textSize = 8.5f
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("Sudah Termasuk PPN", leftColCenter, splitTop + 63f, textPaint)

        val badgeHeight = 30f
        canvas.drawRect(leftBorder, bottomBorder - badgeHeight, splitDividerX, bottomBorder, fillBlackPaint)
        whiteBoldPaint.textSize = 12f
        whiteBoldPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("Lembar Pengirim", leftColCenter, bottomBorder - 10f, whiteBoldPaint)

        // Right Column: Rows with exact lines
        val rRow1H = 32f
        val rRow2H = 30f
        val rRow3H = 30f

        // Row 1: Qty & Barang
        canvas.drawLine(splitDividerX, splitTop + rRow1H, rightBorder, splitTop + rRow1H, thinLinePaint)
        val rSubColW = 92f
        canvas.drawLine(splitDividerX + rSubColW, splitTop, splitDividerX + rSubColW, splitTop + rRow1H, thinLinePaint)

        boldTextPaint.textSize = 10.5f
        boldTextPaint.textAlign = Paint.Align.LEFT
        drawTextBounded(canvas, "Qty ${receipt.itemQty}", splitDividerX + 8f, splitTop + 21f, rSubColW - 14f, boldTextPaint)
        val maxBarangW = rightBorder - (splitDividerX + rSubColW + 16f)
        drawTextBounded(canvas, "BARANG ${receipt.itemName}", splitDividerX + rSubColW + 8f, splitTop + 21f, maxBarangW, boldTextPaint)

        // Row 2: Notes
        canvas.drawLine(splitDividerX, splitTop + rRow1H + rRow2H, rightBorder, splitTop + rRow1H + rRow2H, thinLinePaint)
        textPaint.textSize = 10f
        val maxNotesW = rightBorder - splitDividerX - 16f
        drawTextBounded(canvas, "Notes: ${receipt.notes}", splitDividerX + 8f, splitTop + rRow1H + 20f, maxNotesW, textPaint)

        // Row 3: Cetak & Exp
        canvas.drawLine(splitDividerX, splitTop + rRow1H + rRow2H + rRow3H, rightBorder, splitTop + rRow1H + rRow2H + rRow3H, thinLinePaint)
        val rSubExpW = (rightBorder - splitDividerX) / 2f
        canvas.drawLine(splitDividerX + rSubExpW, splitTop + rRow1H + rRow2H, splitDividerX + rSubExpW, splitTop + rRow1H + rRow2H + rRow3H, thinLinePaint)

        textPaint.textSize = 9.8f
        drawTextBounded(canvas, "Cetak ${receipt.printDate}", splitDividerX + 8f, splitTop + rRow1H + rRow2H + 20f, rSubExpW - 14f, textPaint)
        drawTextBounded(canvas, "Exp ${receipt.expDate}", splitDividerX + rSubExpW + 8f, splitTop + rRow1H + rRow2H + 20f, rSubExpW - 14f, textPaint)

        // Row 4: Legal - clamped and sized so it never pierces the right border
        var legalY = splitTop + rRow1H + rRow2H + rRow3H + 14f
        textPaint.textSize = 6.8f
        val maxLegalW = rightBorder - splitDividerX - 14f
        drawTextBounded(canvas, "Syarat dan ketentuan pengiriman dilihat pada website www.jet.co.id", splitDividerX + 8f, legalY, maxLegalW, textPaint)
        legalY += 12.5f
        drawTextBounded(canvas, "PT GLOBAL JET EXPRESS, 0735 697 740 041 000", splitDividerX + 8f, legalY, maxLegalW, textPaint)
        legalY += 12.5f
        drawTextBounded(canvas, "LANDMARK PLUIT TOWER BLOK B1, LANTAI 8, 9A, PENJARINGAN", splitDividerX + 8f, legalY, maxLegalW, textPaint)
    }

    /**
     * OPSI 3: Combo 2-in-1 (Exact layout matching Tak_berjudul23__1__7e0e24ca.jpg)
     * Canvas dimensions: 560 x 852.
     * Top is Option 1, bottom is Option 2, seamlessly connected in one sheet with NO text overlaps!
     */
    fun drawComboOnCanvas(
        canvas: Canvas,
        receipt: ReceiptData,
        width: Float,
        height: Float
    ) {
        val bgPaint = Paint().apply { color = Color.WHITE; style = Paint.Style.FILL }
        canvas.drawRect(0f, 0f, width, height, bgPaint)

        val borderPaint = Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 2.5f; isAntiAlias = true }
        val thinLinePaint = Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 1.5f; isAntiAlias = true }

        val leftBorder = 34f
        val rightBorder = width - 34f
        val topBorder = 16f
        val bottomBorder = height - 16f

        // Single continuous outer rectangle for the entire combo sheet
        canvas.drawRect(leftBorder, topBorder, rightBorder, bottomBorder, borderPaint)

        // Side Vertical Resi Text: 5 repeats evenly spaced down the entire sheet
        drawVerticalSideResi(canvas, receipt.resiCode, leftBorder, rightBorder, topBorder, bottomBorder, listOf(0.16f, 0.36f, 0.55f, 0.72f, 0.90f))

        // Top Section: Option 1
        val option1Bottom = 516f
        drawReceiptInner(canvas, receipt, leftBorder, rightBorder, topBorder, option1Bottom, thinLinePaint)

        // Perforation Separator Line
        val separatorY = 522f
        val sepPaint = Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 2f }
        canvas.drawLine(leftBorder, separatorY, rightBorder, separatorY, sepPaint)

        // Bottom Section: Option 2 (Lembar Pengirim)
        drawSenderCopyInner(canvas, receipt, leftBorder, rightBorder, separatorY, bottomBorder, thinLinePaint)
    }

    /**
     * OPSI 4: Lembar Pengirim Polos / Bersih (Persis Tak_berjudul24_a827c196.jpg)
     * Tidak ada teks resi vertikal samping, border tepi penuh, teks rapi & proporsional.
     * Canvas dimensions: 560 x 320.
     */
    fun drawSenderCleanOnCanvas(
        canvas: Canvas,
        receipt: ReceiptData,
        width: Float,
        height: Float
    ) {
        val bgPaint = Paint().apply { color = Color.WHITE; style = Paint.Style.FILL }
        canvas.drawRect(0f, 0f, width, height, bgPaint)

        val borderPaint = Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 2.2f; isAntiAlias = true }
        val thinLinePaint = Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 1.3f; isAntiAlias = true }
        val fillBlackPaint = Paint().apply { color = Color.BLACK; style = Paint.Style.FILL; isAntiAlias = true }
        val textPaint = Paint().apply { color = Color.BLACK; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL) }
        val boldTextPaint = Paint().apply { color = Color.BLACK; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }
        val whiteBoldPaint = Paint().apply { color = Color.WHITE; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }

        val leftBorder = 12f
        val rightBorder = width - 12f
        val topBorder = 10f
        val bottomBorder = height - 10f

        // Outer Bounding Box (tanpa margin samping)
        canvas.drawRect(leftBorder, topBorder, rightBorder, bottomBorder, borderPaint)

        // 1. Barcode Atas
        val barcodeBitmap = BarcodeGenerator.generateBarcode128(receipt.resiCode, width = 640, height = 75)
        val barcodeRect = RectF(leftBorder + 38f, topBorder + 8f, rightBorder - 38f, topBorder + 44f)
        if (barcodeBitmap != null) {
            canvas.drawBitmap(barcodeBitmap, null, barcodeRect, null)
        }

        boldTextPaint.textSize = 12.5f
        boldTextPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.resiCode, (leftBorder + rightBorder) / 2f, topBorder + 58f, boldTextPaint)

        val barcodeBottomY = topBorder + 64f
        canvas.drawLine(leftBorder, barcodeBottomY, rightBorder, barcodeBottomY, thinLinePaint)

        // 2. Pengirim & Penerima
        var currentY = barcodeBottomY + 17f
        boldTextPaint.textSize = 12f
        boldTextPaint.textAlign = Paint.Align.LEFT
        val senderPhone = receipt.getDisplaySenderPhone()
        val sPhoneW = boldTextPaint.measureText(senderPhone)
        val maxSenderW = (rightBorder - leftBorder - 24f) - sPhoneW
        drawTextBounded(canvas, "Pengirim: ${receipt.senderName}", leftBorder + 10f, currentY, maxSenderW, boldTextPaint)
        boldTextPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(senderPhone, rightBorder - 10f, currentY, boldTextPaint)

        currentY += 17f
        boldTextPaint.textAlign = Paint.Align.LEFT
        val recipPhone = receipt.getDisplayRecipientPhone()
        val rPhoneW = boldTextPaint.measureText(recipPhone)
        val maxRecipW = (rightBorder - leftBorder - 24f) - rPhoneW
        drawTextBounded(canvas, "Penerima : ${receipt.recipientName}", leftBorder + 10f, currentY, maxRecipW, boldTextPaint)
        boldTextPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(recipPhone, rightBorder - 10f, currentY, boldTextPaint)

        currentY += 4f
        textPaint.textSize = 9.8f
        textPaint.textAlign = Paint.Align.LEFT
        drawMultilineText(
            canvas,
            receipt.recipientAddress,
            leftBorder + 10f,
            currentY + 11f,
            rightBorder - leftBorder - 20f,
            textPaint,
            13.5f,
            2
        )

        val addressBottomY = barcodeBottomY + 78f
        canvas.drawLine(leftBorder, addressBottomY, rightBorder, addressBottomY, thinLinePaint)

        // 3. Split Table: Kiri (TOTAL BIAYA) & Kanan (Detail)
        val splitTop = addressBottomY
        val splitDividerX = leftBorder + 178f

        canvas.drawLine(splitDividerX, splitTop, splitDividerX, bottomBorder, thinLinePaint)

        // Kolom Kiri
        val leftColCenter = (leftBorder + splitDividerX) / 2f
        boldTextPaint.textSize = 14f
        boldTextPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("TOTAL BIAYA", leftColCenter, splitTop + 24f, boldTextPaint)

        boldTextPaint.textSize = 17f
        canvas.drawText(receipt.getFormattedFee(), leftColCenter, splitTop + 49f, boldTextPaint)

        textPaint.textSize = 9f
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("Sudah Termasuk PPN", leftColCenter, splitTop + 65f, textPaint)

        val badgeHeight = 32f
        canvas.drawRect(leftBorder, bottomBorder - badgeHeight, splitDividerX, bottomBorder, fillBlackPaint)
        whiteBoldPaint.textSize = 13f
        whiteBoldPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("Lembar Pengirim", leftColCenter, bottomBorder - 11f, whiteBoldPaint)

        // Kolom Kanan
        val rRow1H = 31f
        val rRow2H = 29f
        val rRow3H = 29f

        // Row 1: Qty & Barang
        canvas.drawLine(splitDividerX, splitTop + rRow1H, rightBorder, splitTop + rRow1H, thinLinePaint)
        val rSubColW = 106f
        canvas.drawLine(splitDividerX + rSubColW, splitTop, splitDividerX + rSubColW, splitTop + rRow1H, thinLinePaint)

        boldTextPaint.textSize = 11f
        boldTextPaint.textAlign = Paint.Align.LEFT
        drawTextBounded(canvas, "Qty: ${receipt.itemQty}", splitDividerX + 10f, splitTop + 21f, rSubColW - 16f, boldTextPaint)
        val maxBarangW = rightBorder - (splitDividerX + rSubColW + 16f)
        drawTextBounded(canvas, "BARANG ${receipt.itemName}", splitDividerX + rSubColW + 10f, splitTop + 21f, maxBarangW, boldTextPaint)

        // Row 2: Notes
        canvas.drawLine(splitDividerX, splitTop + rRow1H + rRow2H, rightBorder, splitTop + rRow1H + rRow2H, thinLinePaint)
        textPaint.textSize = 10.5f
        val maxNotesW = rightBorder - splitDividerX - 16f
        drawTextBounded(canvas, "Notes: ${receipt.notes}", splitDividerX + 10f, splitTop + rRow1H + 20f, maxNotesW, textPaint)

        // Row 3: Cetak & Exp
        canvas.drawLine(splitDividerX, splitTop + rRow1H + rRow2H + rRow3H, rightBorder, splitTop + rRow1H + rRow2H + rRow3H, thinLinePaint)
        val rSubExpW = (rightBorder - splitDividerX) / 2f
        canvas.drawLine(splitDividerX + rSubExpW, splitTop + rRow1H + rRow2H, splitDividerX + rSubExpW, splitTop + rRow1H + rRow2H + rRow3H, thinLinePaint)

        textPaint.textSize = 10f
        drawTextBounded(canvas, "Cetak: ${receipt.printDate}", splitDividerX + 10f, splitTop + rRow1H + rRow2H + 20f, rSubExpW - 16f, textPaint)
        drawTextBounded(canvas, "Exp: ${receipt.expDate}", splitDividerX + rSubExpW + 10f, splitTop + rRow1H + rRow2H + 20f, rSubExpW - 16f, textPaint)

        // Row 4: Legal - clamped and sized so it never pierces the right border
        var legalY = splitTop + rRow1H + rRow2H + rRow3H + 14f
        textPaint.textSize = 6.8f
        val maxLegalW = rightBorder - splitDividerX - 16f
        drawTextBounded(canvas, "Syarat dan ketentuan pengiriman dilihat pada website www.jet.co.id", splitDividerX + 10f, legalY, maxLegalW, textPaint)
        legalY += 12.5f
        drawTextBounded(canvas, "PT GLOBAL JET EXPRESS, 0735 697 740 041 000", splitDividerX + 10f, legalY, maxLegalW, textPaint)
        legalY += 12.5f
        drawTextBounded(canvas, "LANDMARK PLUIT TOWER BLOK B1, LANTAI 8, 9A, PENJARINGAN", splitDividerX + 10f, legalY, maxLegalW, textPaint)
    }

    /**
     * OPSI 5: Label Paket Alternatif (Persis Tak_berjudul25_5432ae4c.jpg)
     * Badges NP & EZ di bagian atas, 4x teks resi vertikal samping, teks legal Jakarta Utara 14450.
     * Canvas dimensions: 560 x 560.
     */
    fun drawLabelAltOnCanvas(
        canvas: Canvas,
        receipt: ReceiptData,
        width: Float,
        height: Float
    ) {
        val bgPaint = Paint().apply { color = Color.WHITE; style = Paint.Style.FILL }
        canvas.drawRect(0f, 0f, width, height, bgPaint)

        val borderPaint = Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 2.5f; isAntiAlias = true }
        val thinLinePaint = Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 1.5f; isAntiAlias = true }
        val fillBlackPaint = Paint().apply { color = Color.BLACK; style = Paint.Style.FILL; isAntiAlias = true }
        val textPaint = Paint().apply { color = Color.BLACK; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL) }
        val boldTextPaint = Paint().apply { color = Color.BLACK; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }
        val whiteBoldPaint = Paint().apply { color = Color.WHITE; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }

        val leftBorder = 34f
        val rightBorder = width - 34f
        val topBorder = 42f
        val bottomBorder = height - 16f

        // Badges [NP] & [EZ] di atas card utama (sesuai gambar 2)
        val badgeW = 54f
        val badgeH = 28f
        val badge2Left = rightBorder - badgeW - 12f
        val badge1Left = badge2Left - badgeW - 14f
        val badgeTop = 8f

        canvas.drawRect(badge1Left, badgeTop, badge1Left + badgeW, badgeTop + badgeH, fillBlackPaint)
        canvas.drawRect(badge2Left, badgeTop, badge2Left + badgeW, badgeTop + badgeH, fillBlackPaint)

        whiteBoldPaint.textSize = 17f
        whiteBoldPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("NP", badge1Left + (badgeW / 2), badgeTop + 20f, whiteBoldPaint)
        canvas.drawText("EZ", badge2Left + (badgeW / 2), badgeTop + 20f, whiteBoldPaint)

        // Outer Bounding Box
        canvas.drawRect(leftBorder, topBorder, rightBorder, bottomBorder, borderPaint)

        // Side Vertical Resi Text: 4 repeats on left and right
        drawVerticalSideResi(canvas, receipt.resiCode, leftBorder, rightBorder, topBorder, bottomBorder, listOf(0.14f, 0.38f, 0.62f, 0.86f))

        // 1. Header Code (350-4BDO88-16A)
        boldTextPaint.textSize = 31f
        boldTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText(receipt.routingCode, leftBorder + 10f, topBorder + 34f, boldTextPaint)

        val headerBottomY = topBorder + 44f
        canvas.drawLine(leftBorder, headerBottomY, rightBorder, headerBottomY, thinLinePaint)

        // 2. Barcode
        val barcodeBitmap = BarcodeGenerator.generateBarcode128(receipt.resiCode, width = 640, height = 110)
        val barcodeRect = RectF(leftBorder + 24f, headerBottomY + 6f, rightBorder - 24f, headerBottomY + 68f)
        if (barcodeBitmap != null) {
            canvas.drawBitmap(barcodeBitmap, null, barcodeRect, null)
        }

        val resiTextY = headerBottomY + 84f
        boldTextPaint.textSize = 13.5f
        boldTextPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.resiCode, (leftBorder + rightBorder) / 2f, resiTextY, boldTextPaint)

        // 3. Drop Point Banner
        val bannerTop = headerBottomY + 92f
        val bannerHeight = 28f
        canvas.drawRect(leftBorder, bannerTop, rightBorder, bannerTop + bannerHeight, fillBlackPaint)
        whiteBoldPaint.textSize = 14f
        whiteBoldPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.dropPoint.uppercase(), (leftBorder + rightBorder) / 2f, bannerTop + 19.5f, whiteBoldPaint)

        // 4. Recipient Section (Penerima)
        val recipientTop = bannerTop + bannerHeight
        var currentY = recipientTop + 16f
        boldTextPaint.textSize = 12f
        boldTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Penerima: ${receipt.recipientName}", leftBorder + 8f, currentY, boldTextPaint)
        boldTextPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(receipt.getDisplayRecipientPhone(), rightBorder - 8f, currentY, boldTextPaint)

        currentY += 4f
        textPaint.textSize = 9.5f
        textPaint.textAlign = Paint.Align.LEFT
        currentY = drawMultilineText(
            canvas,
            receipt.recipientAddress.uppercase(),
            leftBorder + 8f,
            currentY + 11f,
            rightBorder - leftBorder - 16f,
            textPaint,
            13f,
            3
        )

        val recipientBottomY = recipientTop + 72f
        canvas.drawLine(leftBorder, recipientBottomY, rightBorder, recipientBottomY, thinLinePaint)

        // 5. Sender Section (Pengirim)
        val senderTop = recipientBottomY
        currentY = senderTop + 16f
        boldTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Pengirim: ${receipt.senderName}", leftBorder + 8f, currentY, boldTextPaint)
        boldTextPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(receipt.getDisplaySenderPhone(), rightBorder - 8f, currentY, boldTextPaint)

        currentY += 4f
        currentY = drawMultilineText(
            canvas,
            receipt.senderAddress,
            leftBorder + 8f,
            currentY + 11f,
            rightBorder - leftBorder - 16f,
            textPaint,
            13f,
            3
        )

        val senderBottomY = senderTop + 72f
        canvas.drawLine(leftBorder, senderBottomY, rightBorder, senderBottomY, thinLinePaint)

        // 6. Details Table
        val tableTop = senderBottomY
        val col1Width = 114f
        val col2Width = 80f
        val col3Width = 98f

        val row1Height = 42f
        val row2Height = 23f
        val row3Height = 23f
        val tableHeight = row1Height + row2Height + row3Height

        canvas.drawLine(leftBorder, tableTop + row1Height, rightBorder, tableTop + row1Height, thinLinePaint)
        canvas.drawLine(leftBorder, tableTop + row1Height + row2Height, rightBorder, tableTop + row1Height + row2Height, thinLinePaint)
        canvas.drawLine(leftBorder, tableTop + tableHeight, rightBorder, tableTop + tableHeight, thinLinePaint)

        val col1Right = leftBorder + col1Width
        val col2Right = col1Right + col2Width
        val col3Right = col2Right + col3Width

        canvas.drawLine(col1Right, tableTop, col1Right, tableTop + row1Height + row2Height, thinLinePaint)
        canvas.drawLine(col2Right, tableTop, col2Right, tableTop + row1Height, thinLinePaint)
        canvas.drawLine(col3Right, tableTop, col3Right, tableTop + row1Height + row2Height, thinLinePaint)

        // Col 1: Header BIAYA / MAYAFFIF-IMHAH
        canvas.drawRect(leftBorder, tableTop, col1Right, tableTop + 14f, fillBlackPaint)
        whiteBoldPaint.textSize = 7.8f
        whiteBoldPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("MAYAFFIF-IMHAH", leftBorder + (col1Width / 2f), tableTop + 10.5f, whiteBoldPaint)

        boldTextPaint.textSize = 13.5f
        boldTextPaint.textAlign = Paint.Align.CENTER
        val tightFee = receipt.getFormattedFee()
        canvas.drawText(tightFee, leftBorder + (col1Width / 2f), tableTop + 27.5f, boldTextPaint)

        textPaint.textSize = 7.5f
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("Sudah Termasuk PPN", leftBorder + (col1Width / 2f), tableTop + 37f, textPaint)

        // Col 2: Tunai
        boldTextPaint.textSize = 12f
        canvas.drawText(receipt.paymentType, col1Right + (col2Width / 2f), tableTop + 26f, boldTextPaint)

        // Col 3: Weight (without bullet)
        boldTextPaint.textSize = 12f
        canvas.drawText(receipt.weightKg.replace("•", "").trim(), col2Right + (col3Width / 2f), tableTop + 26f, boldTextPaint)

        // Col 4: Print Date
        textPaint.textSize = 10f
        canvas.drawText("Cetak ${receipt.printDate}", col3Right + ((rightBorder - col3Right) / 2f), tableTop + 26f, textPaint)

        // Row 2: Order No & Exp
        textPaint.textSize = 9.5f
        textPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Order No. ${receipt.orderNo}", col1Right + 6f, tableTop + row1Height + 15.5f, textPaint)
        canvas.drawText("Exp : ${receipt.expNote}", col3Right + 6f, tableTop + row1Height + 15.5f, textPaint)

        // Row 3: Notes
        textPaint.textSize = 10f
        canvas.drawText("Notes: ${receipt.notes}", leftBorder + 8f, tableTop + row1Height + row2Height + 15.5f, textPaint)

        // 7. Footer Section
        val footerTop = tableTop + tableHeight
        val qrSize = 100f
        val qrLeft = rightBorder - qrSize - 4f
        val qrBitmap = BarcodeGenerator.generateQrCode(receipt.resiCode, size = 220)
        if (qrBitmap != null) {
            canvas.drawBitmap(qrBitmap, null, RectF(qrLeft, footerTop + 6f, qrLeft + qrSize, footerTop + 6f + qrSize), null)
        }

        textPaint.textSize = 8.5f
        textPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Syarat dan ketentuan pengiriman dilihat pada website:", leftBorder + 8f, footerTop + 16f, textPaint)
        canvas.drawText("www.jet.co.id   JET EXPRESS, 021-3000-0111", leftBorder + 8f, footerTop + 30f, textPaint)
        canvas.drawText("LANDMARK PLUIT TOWER BLOK BI, LANTAI 8, 9A,", leftBorder + 8f, footerTop + 44f, textPaint)
        canvas.drawText("10A, JL. PLUIT SELATAN RAYA, PENJARINGAN,", leftBorder + 8f, footerTop + 58f, textPaint)
        canvas.drawText("JAKARTA UTARA, 14450", leftBorder + 8f, footerTop + 72f, textPaint)
    }

    private fun drawVerticalSideResi(
        canvas: Canvas,
        resiCode: String,
        leftBorder: Float,
        rightBorder: Float,
        topBorder: Float,
        bottomBorder: Float,
        relativePositions: List<Float>
    ) {
        val sidePaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 9f
            isAntiAlias = true
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }

        val totalHeight = bottomBorder - topBorder
        for (rel in relativePositions) {
            val yPos = topBorder + (rel * totalHeight)

            // Left Margin (rotated -90 degrees)
            canvas.save()
            canvas.rotate(-90f, 18f, yPos)
            canvas.drawText(resiCode, 18f, yPos, sidePaint)
            canvas.restore()

            // Right Margin (rotated 90 degrees)
            canvas.save()
            canvas.rotate(90f, rightBorder + 16f, yPos)
            canvas.drawText(resiCode, rightBorder + 16f, yPos, sidePaint)
            canvas.restore()
        }
    }

    private fun drawTextBounded(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        maxWidth: Float,
        paint: Paint
    ) {
        if (maxWidth <= 0f || text.isEmpty()) return
        val measured = paint.measureText(text)
        if (measured <= maxWidth) {
            canvas.drawText(text, x, y, paint)
            return
        }
        val ellipsis = "..."
        val ellipsisWidth = paint.measureText(ellipsis)
        val availableWidth = maxWidth - ellipsisWidth
        if (availableWidth <= 0f) return

        val count = paint.breakText(text, true, availableWidth, null)
        val truncated = text.take(count).trimEnd() + ellipsis
        canvas.drawText(truncated, x, y, paint)
    }

    private fun drawMultilineText(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        maxWidth: Float,
        paint: Paint,
        lineSpacing: Float,
        maxLines: Int
    ): Float {
        if (text.isEmpty() || maxLines <= 0 || maxWidth <= 0f) return y
        val words = text.split("\\s+".toRegex()).filter { it.isNotEmpty() }
        var currentY = y
        var lineIndex = 0
        var wordIndex = 0

        while (wordIndex < words.size && lineIndex < maxLines) {
            val isLastLine = (lineIndex == maxLines - 1)
            var lineText = words[wordIndex]
            wordIndex++

            if (paint.measureText(lineText) > maxWidth) {
                val count = paint.breakText(lineText, true, maxWidth, null)
                lineText = lineText.take(count)
            }

            while (wordIndex < words.size) {
                val nextWord = words[wordIndex]
                val candidate = "$lineText $nextWord"
                if (paint.measureText(candidate) <= maxWidth) {
                    lineText = candidate
                    wordIndex++
                } else {
                    break
                }
            }

            if (isLastLine && wordIndex < words.size) {
                val ellipsis = "..."
                val ellipsisW = paint.measureText(ellipsis)
                val avail = maxWidth - ellipsisW
                if (avail > 0f) {
                    val count = paint.breakText(lineText, true, avail, null)
                    lineText = lineText.take(count).trimEnd() + ellipsis
                }
            }

            canvas.drawText(lineText, x, currentY, paint)
            currentY += lineSpacing
            lineIndex++
        }

        return currentY
    }
}
