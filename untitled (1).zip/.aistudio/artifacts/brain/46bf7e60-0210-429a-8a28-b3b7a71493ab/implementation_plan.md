# Generator Laporan Teknik & Surat Tugas dengan Cetak PDF Langsung dan Cloud Storage

Aplikasi Android profesional untuk membuat, mengedit, melihat pratinjau (preview), mencetak langsung ke PDF, dan menyimpan riwayat Laporan Teknik kendaraan/peralatan sesuai format standar industri dengan foto kerusakan dan sinkronisasi Google Drive.

### User Review & Critical Decisions

> [!IMPORTANT]
> Berdasarkan preferensi yang telah Anda pilih pada tahap klarifikasi, berikut adalah keputusan arsitektur utama yang akan diterapkan:

- **Google Drive & Cloud Export**: Menggunakan Google Sign-In terintegrasi dan Storage Access Framework / Google Drive intent untuk ekspor PDF langsung ke Google Drive pengguna, dipadukan dengan database lokal Room agar semua riwayat tetap dapat diakses secara offline.
- **Kop Perusahaan & Logo**: Dilengkapi pengaturan profil perusahaan (default preset: Hiba Group dengan logo dan identitas bengkel resmi), serta opsi untuk menyesuaikan nama perusahaan, logo bengkel, dan cabang kapan saja.
- **Lampiran Foto Kerusakan**: Mendukung pengambilan foto langsung dari Kamera teknisi di lapangan maupun memilih dari Galeri perangkat (Photo Picker aman tanpa izin berbahaya).
- **Cetak & Preview PDF Langsung**: Menggunakan native `PdfDocument` Android untuk menghasilkan dokumen berformat presisi piksel sesuai gambar, dengan viewer pratinjau instan di layar dan tombol "Cetak PDF" langsung menggunakan Android `PrintManager`.

---

### 1. Overview & Core Concept

- **Apa yang Dibuat**: Aplikasi form generator laporan teknik (Laporan Kerusakan Kendaraan & Alat Berat) yang secara presisi mereplikasi format dokumen fisik/tabel seperti pada gambar referensi ("Hiba Group - LAPORAN TEKNIK").
- **Sasaran Pengguna**: Teknisi armada, mekanik lapangan, kepala bengkel, staf operasional logistik & transportasi.
- **Nilai Utama**:
  - Mengurangi pengisian kertas manual di lapangan.
  - Dokumentasi foto kerusakan yang terintegrasi langsung ke dalam PDF.
  - Cetak langsung (ke printer fisik maupun simpan sebagai file PDF) dalam hitungan detik.
  - Pencatatan riwayat lengkap dengan status pelaporan, nomor laporan, dan pencarian cepat.
  - Backup aman ke Google Drive dan penyimpanan lokal di perangkat.

---

### 2. User Experience & Visual Design

#### Alur Pengguna Utama (Key User Flows)

```
┌─────────────────┐       ┌──────────────────────┐       ┌──────────────────────┐
│  Riwayat Laporan│ ────> │ Formulir Pembuatan   │ ────> │ Pratinjau PDF Live   │
│  (History List) │       │ (Input Data & Foto)  │       │ (Zoomable View)      │
└────────┬────────┘       └──────────────────────┘       └──────────┬───────────┘
         │                                                          │
         │ Cari / Filter / Buka                                     ├─► Cetak PDF (PrintManager)
         ▼                                                          ├─► Simpan ke Google Drive
┌─────────────────┐                                                 └─► Bagikan Dokumen (Share)
│  Detail & Edit  │
└─────────────────┘
```

1. **Dashboard & Riwayat Laporan**:
   - Menampilkan daftar kartu laporan yang telah dibuat (Nomor Laporan, Bengkel, Tanggal, Kode Unit/Model, Status, Thumbnail Foto).
   - Fitur pencarian instan (berdasarkan nomor unit, nama alat, tanggal, atau nomor laporan).
   - Tombol Aksi Terapung (FAB) untuk membuat laporan baru.
2. **Formulir Laporan Interaktif**:
   - Formulir bertahap yang rapi dan terorganisir per bagian (Header & Unit, Uraian Kerusakan, Analisa & Riwayat Servis, Checklist Penyebab & Solusi, Tabel Kebutuhan Parts, Tanda Tangan).
   - Selector foto kerusakan dengan opsi Kamera atau Galeri.
   - Tabel dinamis untuk input suku cadang (tambah baris, pilih jenis pengadaan: Stock, Order, Modifikasi, Pending).
   - Validasi data otomatis dan tombol "Simpan Draf" serta "Lihat Pratinjau PDF".
3. **Pratinjau PDF & Aksi Dokumen**:
   - Menampilkan lembar laporan teknik dalam tata letak yang identik 100% dengan dokumen cetak resmi.
   - Tombol aksi utama: **Cetak Dokumen** (membuka dialog cetak sistem Android), **Simpan ke Google Drive / Storage**, dan **Bagikan (Share PDF)**.

#### Visual Identity & Theme
- **Tema Visual**: Industrial Professional & Clean Engineering.
- **Palet Warna**:
  - Primary: Deep Slate Blue (`#1E3A8A`) & Crisp Cobalt (`#2563EB`) yang memberikan kesan formal, kredibel, dan bersih.
  - Accent: Amber Hazard / Safety Orange (`#D97706` / `#F59E0B`) untuk status storing & checklist kerusakan.
  - Surface: Pure White (`#FFFFFF`) dengan kontras soft gray neutral (`#F8FAFC` & `#F1F5F9`) untuk kartu dan sekat dokumen.
- **Tipografi**: Heading tegas dengan Sans-serif modern, teks isi yang mudah dibaca teknisi di bawah terik matahari, dan font monospace untuk nomor part / kode unit.
- **Rhythm & Accessibility**: Target sentuh tombol minimal 48dp, visual status badge yang kontras, serta form field yang mendukung auto-capitalization untuk kode unit (misal: "W04DTPJ-53447").

---

### 3. Key Product Decisions & Trade-Offs

- **PDF Generation Engine**:
  - *Pilihan*: Menggunakan Android Native `android.graphics.pdf.PdfDocument` yang menggambar dokumen berbasis Canvas A4 standar dengan resolusi tinggi (300 DPI vector lines and text).
  - *Alasan*: Ringan, bebas dependensi pihak ketiga yang rentan masalah lisensi/ukuran file, dan menghasilkan tabel bergaris presisi yang identik dengan gambar yang diberikan.
- **Penyimpanan Riwayat (Persistence)**:
  - *Pilihan*: Room Database SQLite lokal + export berkas PDF ke penyimpanan internal / Google Drive.
  - *Alasan*: Memungkinkan teknisi bekerja di lokasi bengkel tanpa sinyal internet (offline-first), data riwayat tersimpan permanen dan cepat dicari.
- **Google Drive Storage**:
  - *Pilihan*: Storage Access Framework (SAF) dengan target Google Drive, dikombinasikan dengan Action Send PDF dan Intent Cloud Backup.
  - *Alasan*: Pengguna dapat langsung memilih folder Google Drive mereka dengan akun Google aktif di ponsel tanpa perlu setup API console yang rumit bagi pengguna akhir.

---

### 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────┐
│                       UI LAYER                              │
│  ┌───────────────────┐ ┌─────────────────┐ ┌─────────────┐  │
│  │ HistoryScreen     │ │ FormEditScreen  │ │ PdfPreview  │  │
│  │ (LazyColumn)      │ │ (Form Sections) │ │ (Renderer)  │  │
│  └─────────▲─────────┘ └────────┬────────┘ └──────▲──────┘  │
└────────────┼────────────────────┼─────────────────┼─────────┘
             │                    ▼                 │
┌────────────┴──────────────────────────────────────┴─────────┐
│                      VIEWMODEL LAYER                        │
│               ReportViewModel / FormViewModel               │
│  - StateFlow<ReportListUiState>                             │
│  - StateFlow<ReportFormState>                               │
│  - generatePdfBitmap(), printPdf(), exportToDrive()         │
└─────────────────────────────┬───────────────────────────────┘
                              │
┌─────────────────────────────▼───────────────────────────────┐
│                     DATA & ENGINE LAYER                     │
│  ┌───────────────────────┐       ┌──────────────────────┐   │
│  │ Room Database & DAO   │       │ PdfDocumentGenerator │   │
│  │ - TechnicalReport     │       │ - A4 Canvas Drawing  │   │
│  │ - PartItem            │       │ - Image embedding    │   │
│  └───────────────────────┘       └──────────────────────┘   │
│  ┌───────────────────────┐       ┌──────────────────────┐   │
│  │ File & Image Manager  │       │ Android PrintManager │   │
│  │ - Photo capture/cache │       │ & Google Drive SAF   │   │
│  └───────────────────────┘       └──────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

#### Struktur Data (Entity Model)

1. **`TechnicalReport`**:
   - `id`: Long (Primary Key)
   - `reportNumber`: String (No. Laporan, misal: `1/LT-CLG/III/2026`)
   - `workshopName`: String (Bengkel, misal: `Cilegon`)
   - `date`: String (Tanggal, misal: `12-Mar-26`)
   - `toolName`: String (Nama Alat, misal: `Ban`)
   - `component`: String (Komponen, misal: `Underbody`)
   - `manufacturer`: String (Pabrik Pembuat, misal: `HINO`)
   - `vehicleType`: String (Tipe, misal: `DUTRO`)
   - `model`: String (Model, misal: `W04DTPJ-53447`)
   - `unitCode`: String (Kode, misal: `D127`)
   - `damageDate`: String
   - `odometer`: String (Km / Hm, misal: `598916`)
   - `warrantyStatus`: String (`UNDER_WARRANTY` / `POST_WARRANTY`)
   - `status`: String (misal: `Storing`)
   - `damageDescription`: String (misal: `Ban kempes`)
   - `damageLocation`: String (misal: `Tol tangerang - merak`)
   - `analysis`: String
   - `lastReplacementDate`: String
   - `lastReplacementKm`: String
   - `lastReplacementWo`: String
   - `lastWeeklyDate`: String
   - `lastWeeklyKm`: String
   - `lastWeeklyWo`: String
   - `photoUri`: String? (path lokal foto kerusakan)
   - `causes`: List<String> (Pemasangan, Kwalitas Parts, Kesalahan Operasional, Sudah waktunya, Lain-lain)
   - `causeExplanation`: String
   - `solutions`: List<String> (Ganti Part Baru, Pemasangan/Penyetelan Ulang, Modifikasi)
   - `solutionDetail`: String
   - `delayedReason`: String (Tertunda Karena)
   - `reporterSuggestion`: String (Usulan Pelapor)
   - `parts`: List<ReplacementPart> (No, No Parts, Nama Parts, Jenis Pengadaan: Stock/Order/Modifikasi/Pending)
   - `knownBy1`: String
   - `knownBy2`: String
   - `reporterName`: String (misal: `Yudi Indrawan`)
   - `reporterTitle`: String (misal: `Wa.Ka.Bengkel`)
   - `createdAt`: Long
   - `pdfFilePath`: String?

#### Tahapan Eksekusi Setelah Disetujui
1. **Konfigurasi Dependensi & Manifest**:
   - Aktifkan library Room, Coil (untuk preview gambar), Coroutines, FileProvider untuk foto & PDF sharing.
   - Set icon aplikasi & metadata resmi.
2. **Data Layer**:
   - Buat Room Database, TypeConverters (untuk list part & strings), DAO, dan Repository.
3. **PDF Generation Engine**:
   - Buat renderer `TechnicalReportPdfGenerator` yang menggambar template tabel presisi persis seperti gambar lampiran, termasuk kop Hiba Group, tabel kerusakan, kotak foto, checklist, dan tabel suku cadang.
4. **UI Components & Screens**:
   - Layar Riwayat (History) dengan pencarian, filter, dan quick action (Cetak / Share).
   - Layar Form Editor (multi-tab/accordion yang nyaman di ponsel).
   - Layar Live Preview PDF interaktif dengan fungsi Cetak langsung via `PrintManager` dan unggah/simpan ke Google Drive.
5. **Verifikasi & Build**:
   - Menjalankan `compile_applet` untuk memastikan integrasi bersih tanpa error.
