package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.database.AppDatabase
import com.example.model.ReplacementPart
import com.example.model.TechnicalReport
import com.example.pdf.TechnicalReportPdfGenerator
import com.example.repository.ReportRepository
import com.example.util.DocumentPrintAndShareHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

sealed interface ScreenDestination {
    object History : ScreenDestination
    data class EditForm(val reportId: Long? = null) : ScreenDestination
    data class PdfPreview(val reportId: Long) : ScreenDestination
}

class ReportViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ReportRepository
    private val pdfGenerator = TechnicalReportPdfGenerator(application)

    init {
        val db = AppDatabase.getDatabase(application)
        repository = ReportRepository(db.technicalReportDao())
        viewModelScope.launch {
            repository.seedSampleReportIfEmpty()
        }
    }

    // Navigation State
    private val _currentScreen = MutableStateFlow<ScreenDestination>(ScreenDestination.History)
    val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

    // Search query & filter
    val searchQuery = MutableStateFlow("")
    val filterStatus = MutableStateFlow("Semua") // Semua, Storing, Rutin

    val reportsList: StateFlow<List<TechnicalReport>> = combine(
        repository.allReports,
        searchQuery,
        filterStatus
    ) { reports, query, filter ->
        reports.filter { report ->
            val matchesQuery = query.isEmpty() ||
                    report.reportNumber.contains(query, ignoreCase = true) ||
                    report.unitCode.contains(query, ignoreCase = true) ||
                    report.workshop.contains(query, ignoreCase = true) ||
                    report.toolName.contains(query, ignoreCase = true) ||
                    report.status.contains(query, ignoreCase = true)

            val matchesFilter = when (filter) {
                "Storing" -> report.status.equals("Storing", ignoreCase = true)
                "Rutin" -> !report.status.equals("Storing", ignoreCase = true)
                else -> true
            }

            matchesQuery && matchesFilter
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Current Active Editing Report
    private val _activeReport = MutableStateFlow(createNewBlankReport())
    val activeReport: StateFlow<TechnicalReport> = _activeReport.asStateFlow()

    // Preview PDF State
    private val _previewBitmap = MutableStateFlow<Bitmap?>(null)
    val previewBitmap: StateFlow<Bitmap?> = _previewBitmap.asStateFlow()

    private val _previewPdfFile = MutableStateFlow<File?>(null)
    val previewPdfFile: StateFlow<File?> = _previewPdfFile.asStateFlow()

    private val _isGeneratingPdf = MutableStateFlow(false)
    val isGeneratingPdf: StateFlow<Boolean> = _isGeneratingPdf.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    fun clearToast() {
        _toastMessage.value = null
    }

    fun navigateToHistory() {
        _currentScreen.value = ScreenDestination.History
    }

    fun navigateToNewReport() {
        _activeReport.value = createNewBlankReport()
        _currentScreen.value = ScreenDestination.EditForm(null)
    }

    fun navigateToEditReport(reportId: Long) {
        viewModelScope.launch {
            val report = repository.getReportByIdSync(reportId)
            if (report != null) {
                _activeReport.value = report
                _currentScreen.value = ScreenDestination.EditForm(reportId)
            }
        }
    }

    fun navigateToPreview(report: TechnicalReport? = null) {
        viewModelScope.launch {
            val target = report ?: _activeReport.value
            _activeReport.value = target
            _isGeneratingPdf.value = true
            _currentScreen.value = ScreenDestination.PdfPreview(target.id)

            withContext(Dispatchers.IO) {
                try {
                    val pdfFile = pdfGenerator.generatePdf(target)
                    val bitmap = pdfGenerator.renderPdfToBitmap(pdfFile)
                    _previewPdfFile.value = pdfFile
                    _previewBitmap.value = bitmap
                } catch (e: Exception) {
                    e.printStackTrace()
                    _toastMessage.value = "Gagal memproses pratinjau PDF: ${e.localizedMessage}"
                } finally {
                    _isGeneratingPdf.value = false
                }
            }
        }
    }

    fun updateActiveReport(updated: TechnicalReport) {
        _activeReport.value = updated
    }

    fun saveActiveReport(andPreview: Boolean = false) {
        viewModelScope.launch {
            val current = _activeReport.value
            // generate pdf file and store path
            val pdfFile = withContext(Dispatchers.IO) {
                pdfGenerator.generatePdf(current)
            }
            val toSave = current.copy(pdfPath = pdfFile.absolutePath)
            val savedId = repository.insertOrUpdate(toSave)
            val finalReport = toSave.copy(id = if (current.id == 0L) savedId else current.id)
            _activeReport.value = finalReport
            _toastMessage.value = "Laporan berhasil disimpan!"

            if (andPreview) {
                navigateToPreview(finalReport)
            } else {
                _currentScreen.value = ScreenDestination.History
            }
        }
    }

    fun duplicateReport(report: TechnicalReport) {
        viewModelScope.launch {
            val newNumber = report.reportNumber + "-SALINAN"
            val duplicated = report.copy(
                id = 0,
                reportNumber = newNumber,
                createdAt = System.currentTimeMillis()
            )
            repository.insertOrUpdate(duplicated)
            _toastMessage.value = "Laporan disalin!"
        }
    }

    fun deleteReport(report: TechnicalReport) {
        viewModelScope.launch {
            repository.delete(report)
            _toastMessage.value = "Laporan berhasil dihapus"
        }
    }

    fun printReport(context: Context, report: TechnicalReport? = null) {
        viewModelScope.launch {
            val target = report ?: _activeReport.value
            val file = withContext(Dispatchers.IO) {
                if (target.id == _activeReport.value.id && _previewPdfFile.value != null) {
                    _previewPdfFile.value!!
                } else {
                    pdfGenerator.generatePdf(target)
                }
            }
            DocumentPrintAndShareHelper.printDocument(
                context,
                file,
                "Laporan_${target.reportNumber}"
            )
        }
    }

    fun shareReport(context: Context, report: TechnicalReport? = null) {
        viewModelScope.launch {
            val target = report ?: _activeReport.value
            val file = withContext(Dispatchers.IO) {
                if (target.id == _activeReport.value.id && _previewPdfFile.value != null) {
                    _previewPdfFile.value!!
                } else {
                    pdfGenerator.generatePdf(target)
                }
            }
            DocumentPrintAndShareHelper.sharePdf(
                context,
                file,
                "Laporan Teknik - ${target.reportNumber}"
            )
        }
    }

    fun exportReportToDrive(context: Context, report: TechnicalReport? = null) {
        viewModelScope.launch {
            val target = report ?: _activeReport.value
            val file = withContext(Dispatchers.IO) {
                if (target.id == _activeReport.value.id && _previewPdfFile.value != null) {
                    _previewPdfFile.value!!
                } else {
                    pdfGenerator.generatePdf(target)
                }
            }
            DocumentPrintAndShareHelper.saveToGoogleDrive(context, file)
            _toastMessage.value = "Membuka Google Drive untuk ekspor dokumen..."
        }
    }

    // Photo selection handling: Copies content URI to local internal storage
    fun onPhotoSelected(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val context = getApplication<Application>()
                val imagesDir = File(context.filesDir, "images")
                if (!imagesDir.exists()) imagesDir.mkdirs()

                val destFile = File(imagesDir, "photo_${System.currentTimeMillis()}.jpg")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(destFile).use { output ->
                        input.copyTo(output)
                    }
                }
                _activeReport.value = _activeReport.value.copy(photoPath = destFile.absolutePath)
                _toastMessage.value = "Foto kerusakan berhasil dilampirkan"
            } catch (e: Exception) {
                _toastMessage.value = "Gagal memuat foto: ${e.localizedMessage}"
            }
        }
    }

    // Parts list manipulation
    fun addPartItem(part: ReplacementPart) {
        val list = _activeReport.value.parts.toMutableList()
        list.add(part)
        _activeReport.value = _activeReport.value.copy(parts = list)
    }

    fun removePartItem(index: Int) {
        val list = _activeReport.value.parts.toMutableList()
        if (index in list.indices) {
            list.removeAt(index)
            _activeReport.value = _activeReport.value.copy(parts = list)
        }
    }

    fun updatePartItem(index: Int, part: ReplacementPart) {
        val list = _activeReport.value.parts.toMutableList()
        if (index in list.indices) {
            list[index] = part
            _activeReport.value = _activeReport.value.copy(parts = list)
        }
    }

    // Create fresh template prefilled with today's date & sample numbering
    private fun createNewBlankReport(): TechnicalReport {
        val today = java.text.SimpleDateFormat("dd-MMM-yy", java.util.Locale.ENGLISH).format(java.util.Date())
        val randomNum = (100..999).random()
        return TechnicalReport(
            id = 0,
            companyName = "Hiba Group",
            reportTitle = "LAPORAN TEKNIK",
            reportNumber = "$randomNum/LT-CLG/III/2026",
            workshop = "Cilegon",
            date = today,
            toolName = "Ban",
            component = "Underbody",
            manufacturer = "HINO",
            vehicleType = "DUTRO",
            model = "W04DTPJ-53447",
            unitCode = "D127",
            damageDate = today,
            odometer = "598916",
            warrantyStatus = "SETELAH_GARANSI",
            status = "Storing",
            damageDescription = "",
            damageLocation = "",
            analysis = "",
            lastReplacement = "",
            lastReplacementWo = "",
            lastWeekly = "",
            lastWeeklyWo = "",
            photoPath = "sample_damage.jpg",
            causePemasangan = false,
            causeKwalitasParts = false,
            causeKesalahanOperasional = false,
            causeSudahWaktunya = true,
            causeLainLain = false,
            causeExplanation = "",
            solutionGantiPartBaru = false,
            solutionPemasanganUlang = true,
            solutionModifikasi = false,
            solutionActionText = "",
            delayedReason = "-",
            reporterSuggestion = "",
            parts = listOf(
                ReplacementPart(partNumber = "42611-EW010", partName = "Velg Roda 7.50-16", procurementType = "Stock"),
                ReplacementPart(partNumber = "BAN-BRIDGE-1000", partName = "Ban Luar 10.00 R20", procurementType = "Order")
            ),
            knownBy1 = "Kepala Operasional",
            knownBy2 = "Manager Teknik",
            reporterName = "Yudi Indrawan",
            reporterTitle = "Wa.Ka.Bengkel"
        )
    }
}
