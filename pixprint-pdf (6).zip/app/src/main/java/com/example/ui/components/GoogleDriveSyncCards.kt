package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.DriveSyncPreferences
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DriveSyncSummaryCard(
    drivePrefs: DriveSyncPreferences,
    isSyncing: Boolean,
    onConnectClick: () -> Unit,
    onSyncNowClick: () -> Unit,
    onOpenSettingsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val formattedLastSync = remember(drivePrefs.lastSyncTimeMillis) {
        if (drivePrefs.lastSyncTimeMillis > 0L) {
            formatDriveSyncTimestamp(drivePrefs.lastSyncTimeMillis)
        } else {
            null
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("drive_sync_summary_card"),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(
            containerColor = if (drivePrefs.isDriveConnected) {
                MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.36f)
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            }
        ),
        border = BorderStroke(
            width = 1.dp,
            color = if (drivePrefs.isDriveConnected) {
                MaterialTheme.colorScheme.tertiary.copy(alpha = 0.4f)
            } else {
                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (isSyncing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.5.dp
                    )
                } else {
                    Icon(
                        imageVector = if (drivePrefs.isDriveConnected) {
                            Icons.Filled.CloudDone
                        } else {
                            Icons.Outlined.CloudOff
                        },
                        contentDescription = null,
                        tint = if (drivePrefs.isDriveConnected) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.drive_card_title),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = when {
                                isSyncing -> MaterialTheme.colorScheme.secondaryContainer
                                drivePrefs.isDriveConnected -> MaterialTheme.colorScheme.primaryContainer
                                else -> MaterialTheme.colorScheme.surface
                            }
                        ) {
                            Text(
                                text = when {
                                    isSyncing -> stringResource(R.string.drive_badge_syncing)
                                    drivePrefs.isDriveConnected -> stringResource(R.string.drive_badge_connected)
                                    else -> stringResource(R.string.drive_badge_local_mode)
                                },
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = when {
                                    isSyncing -> MaterialTheme.colorScheme.onSecondaryContainer
                                    drivePrefs.isDriveConnected -> MaterialTheme.colorScheme.onPrimaryContainer
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                },
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    if (drivePrefs.isDriveConnected) {
                        Text(
                            text = stringResource(
                                R.string.drive_card_desc_connected_folder,
                                drivePrefs.sanitizedFolderName
                            ),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = if (formattedLastSync != null) {
                                stringResource(R.string.drive_last_sync_time, formattedLastSync)
                            } else {
                                stringResource(R.string.drive_last_sync_never)
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = if (drivePrefs.lastSyncSuccess) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.error
                            }
                        )
                    } else {
                        Text(
                            text = stringResource(R.string.drive_card_desc_disconnected),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (drivePrefs.isDriveConnected) {
                    Button(
                        onClick = onSyncNowClick,
                        enabled = !isSyncing,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("quick_sync_now_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Sync,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(stringResource(R.string.action_sync_now))
                    }
                } else {
                    Button(
                        onClick = onConnectClick,
                        enabled = !isSyncing,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("quick_connect_drive_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CloudUpload,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.action_connect_drive),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                FilledTonalButton(
                    onClick = onOpenSettingsClick,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("open_drive_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Settings,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.action_drive_settings))
                }
            }
        }
    }
}

@Composable
fun DriveHistorySyncBanner(
    drivePrefs: DriveSyncPreferences,
    isSyncing: Boolean,
    onConnectOrSyncClick: () -> Unit,
    onOpenSettingsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val syncStatusLabel = remember(
        drivePrefs.lastSyncTimeMillis,
        drivePrefs.lastSyncMessage,
        isSyncing
    ) {
        when {
            isSyncing -> "Menyinkronkan..."
            drivePrefs.lastSyncTimeMillis > 0L -> formatDriveSyncTimestamp(drivePrefs.lastSyncTimeMillis)
            else -> "Siap sinkron"
        }
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (drivePrefs.isDriveConnected) {
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.42f)
        } else {
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
        },
        border = BorderStroke(
            width = 1.dp,
            color = if (drivePrefs.isDriveConnected) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
            } else {
                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
            }
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("history_drive_banner")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (isSyncing) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp
                )
            } else {
                Icon(
                    imageVector = if (drivePrefs.isDriveConnected) {
                        Icons.Filled.CloudDone
                    } else {
                        Icons.Outlined.CloudOff
                    },
                    contentDescription = null,
                    tint = if (drivePrefs.isDriveConnected) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    modifier = Modifier.size(20.dp)
                )
            }

            Text(
                text = if (drivePrefs.isDriveConnected) {
                    stringResource(
                        R.string.history_drive_banner_connected,
                        drivePrefs.sanitizedFolderName,
                        syncStatusLabel
                    )
                } else {
                    stringResource(R.string.history_drive_banner_disconnected)
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )

            FilledTonalButton(
                onClick = onConnectOrSyncClick,
                enabled = !isSyncing,
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag(
                        if (drivePrefs.isDriveConnected) {
                            "history_sync_now_button"
                        } else {
                            "history_connect_drive_button"
                        }
                    )
            ) {
                Text(
                    text = if (drivePrefs.isDriveConnected) {
                        stringResource(R.string.action_sync_now)
                    } else {
                        stringResource(R.string.action_connect_drive)
                    },
                    style = MaterialTheme.typography.labelMedium
                )
            }

            IconButton(
                onClick = onOpenSettingsClick,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("history_open_drive_settings_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.Settings,
                    contentDescription = stringResource(R.string.cd_open_drive_sync)
                )
            }
        }
    }
}

internal fun formatDriveSyncTimestamp(epochMillis: Long): String {
    val formatter = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.forLanguageTag("id-ID"))
    return formatter.format(Date(epochMillis))
}
