const { initializeTestEnvironment, assertFails, assertSucceeds } = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

const PROJECT_ID = "demo-no-project";
const DATABASE_ID = "ai-studio-android-cloudpad-5dbdac28-ee48-4309-8e1c-f11b2abcb6d9";

let testEnv;

before(async () => {
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      host: "127.0.0.1",
      port: 8085,
      rules: fs.readFileSync("firestore.rules", "utf8"),
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("unauthenticated user cannot read or write notes", async () => {
  const unauthedDb = testEnv.unauthenticatedContext().firestore({ databaseId: DATABASE_ID });
  await assertFails(unauthedDb.doc("users/user_1/notes/note_1").get());
  await assertFails(
    unauthedDb.doc("users/user_1/notes/note_1").set({
      userId: "user_1",
      title: "Title",
      content: "Content",
      tags: [],
      isPinned: false,
      fileExtension: "txt",
      createdAt: new Date(),
      updatedAt: new Date(),
    })
  );
});

test("authenticated user can create and read their own notes", async () => {
  const user1Db = testEnv.authenticatedContext("user_1").firestore({ databaseId: DATABASE_ID });
  await assertSucceeds(
    user1Db.doc("users/user_1/notes/note_1").set({
      userId: "user_1",
      title: "My Note",
      content: "Hello world",
      tags: ["work", "code"],
      isPinned: false,
      fileExtension: "txt",
      createdAt: new Date(),
      updatedAt: new Date(),
    })
  );
  await assertSucceeds(user1Db.doc("users/user_1/notes/note_1").get());
});

test("user cannot read or write another user's notes", async () => {
  const user1Db = testEnv.authenticatedContext("user_1").firestore({ databaseId: DATABASE_ID });
  const user2Db = testEnv.authenticatedContext("user_2").firestore({ databaseId: DATABASE_ID });

  await assertSucceeds(
    user1Db.doc("users/user_1/notes/note_1").set({
      userId: "user_1",
      title: "User 1 Note",
      content: "Secret",
      tags: [],
      isPinned: false,
      fileExtension: "txt",
      createdAt: new Date(),
      updatedAt: new Date(),
    })
  );

  await assertFails(user2Db.doc("users/user_1/notes/note_1").get());
  await assertFails(
    user2Db.doc("users/user_1/notes/note_2").set({
      userId: "user_1",
      title: "Imposter",
      content: "Hack",
      tags: [],
      isPinned: false,
      fileExtension: "txt",
      createdAt: new Date(),
      updatedAt: new Date(),
    })
  );
});

test("authenticated user can update their existing note preserving createdAt", async () => {
  const user1Db = testEnv.authenticatedContext("user_1").firestore({ databaseId: DATABASE_ID });
  const createdDate = new Date();
  await assertSucceeds(
    user1Db.doc("users/user_1/notes/note_1").set({
      userId: "user_1",
      title: "Initial Title",
      content: "Initial Content",
      tags: ["init"],
      isPinned: false,
      fileExtension: "txt",
      createdAt: createdDate,
      updatedAt: createdDate,
    })
  );

  await assertSucceeds(
    user1Db.doc("users/user_1/notes/note_1").update({
      title: "Updated Title",
      content: "Updated Content",
      tags: ["updated"],
      isPinned: true,
      fileExtension: "py",
      updatedAt: new Date(),
    })
  );
});
