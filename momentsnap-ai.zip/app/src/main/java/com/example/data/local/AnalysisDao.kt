package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AnalysisDao {

    @Query("SELECT * FROM saved_analyses ORDER BY createdAt DESC")
    fun getAllAnalyses(): Flow<List<SavedAnalysisEntity>>

    @Query("SELECT * FROM saved_analyses WHERE id = :id LIMIT 1")
    suspend fun getAnalysisById(id: String): SavedAnalysisEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnalysis(entity: SavedAnalysisEntity)

    @Query("DELETE FROM saved_analyses WHERE id = :id")
    suspend fun deleteAnalysisById(id: String)

    @Query("DELETE FROM saved_analyses")
    suspend fun clearAll()
}
