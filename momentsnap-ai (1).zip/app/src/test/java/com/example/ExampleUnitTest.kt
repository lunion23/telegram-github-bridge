package com.example

import com.example.data.analyzer.VideoAnalyzerEngine
import com.example.data.model.VideoMoment
import com.example.data.model.VideoSourceType
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleUnitTest {

    @Test
    fun testYouTubeVideoIdExtraction() {
        val standardUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
        val extracted1 = VideoAnalyzerEngine.extractYouTubeVideoId(standardUrl)
        assertEquals("dQw4w9WgXcQ", extracted1)

        val shortUrl = "https://youtu.be/dQw4w9WgXcQ"
        val extracted2 = VideoAnalyzerEngine.extractYouTubeVideoId(shortUrl)
        assertEquals("dQw4w9WgXcQ", extracted2)

        val shortsUrl = "https://youtube.com/shorts/dQw4w9WgXcQ"
        val extracted3 = VideoAnalyzerEngine.extractYouTubeVideoId(shortsUrl)
        assertEquals("dQw4w9WgXcQ", extracted3)
    }

    @Test
    fun testVideoMomentFormatTime() {
        assertEquals("00:00", VideoMoment.formatTime(0))
        assertEquals("00:35", VideoMoment.formatTime(35))
        assertEquals("01:15", VideoMoment.formatTime(75))
        assertEquals("10:05", VideoMoment.formatTime(605))
    }

    @Test
    fun testVideoAnalyzerEngineGeneratesCompleteData() {
        val result = VideoAnalyzerEngine.analyzeVideo(
            titleInput = "Test Podcast Kreator",
            source = "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
            sourceType = VideoSourceType.YOUTUBE,
            customDurationSec = 300,
            userNotes = "podcast tips algoritma"
        )

        assertNotNull(result)
        assertTrue(result.moments.isNotEmpty())
        assertTrue(result.hooks.isNotEmpty())
        assertTrue(result.titleSuggestions.isNotEmpty())
        assertTrue(result.socialCaptions.isNotEmpty())
        assertTrue(result.summaryPoints.isNotEmpty())
        assertTrue(result.audienceMetrics.overallScore > 0)
        assertTrue(result.seoData.primaryKeywords.isNotEmpty())
    }

    @Test
    fun testGeminiStructuredPromptGeneration() {
        val prompt = com.example.data.repository.GeminiVideoAiRepository.buildVideoAnalysisPrompt(
            videoTitle = "Review AI Smartphone",
            videoSource = "https://youtube.com/watch?v=12345678901",
            durationSeconds = 240,
            transcriptOrNotes = "Review kamera dan benchmark"
        )

        assertNotNull(prompt)
        assertTrue(prompt.contains("Review AI Smartphone"))
        assertTrue(prompt.contains("moments"))
        assertTrue(prompt.contains("hooks"))
        assertTrue(prompt.contains("socialCaptions"))
        assertTrue(prompt.contains("audienceMetrics"))
        assertTrue(prompt.contains("seoData"))
    }

    @Test
    fun testGeminiResponseParsing() {
        val repo = com.example.data.repository.GeminiVideoAiRepository()
        val mockJson = """
        {
          "summaryPoints": ["Poin ringkasan pertama", "Poin ringkasan kedua"],
          "moments": [
            {
              "startSecond": 10,
              "endSecond": 35,
              "title": "Momen Shocking AI",
              "keyQuoteOrText": "Fitur ini luar biasa",
              "reasonWhyViral": "Visual demonstrasi dramatis",
              "viralScore": 96
            }
          ],
          "hooks": [
            {
              "hookText": "Jangan beli ini sebelum tahu...",
              "hookType": "FOMO",
              "deliveryTip": "Ekspresi serius"
            }
          ],
          "titleSuggestions": [
            {
              "titleText": "AI Ini Mengubah Segalanya!",
              "category": "High CTR",
              "estimatedCtr": "12.0% CTR"
            }
          ],
          "socialCaptions": [
            {
              "platform": "TIKTOK",
              "captionText": "Wajib tonton sampai akhir!",
              "callToAction": "Komen pendapatmu!",
              "hashtags": ["#fyp", "#tech"]
            }
          ],
          "audienceMetrics": {
            "overallScore": 94,
            "viralProbability": "Sangat Tinggi",
            "bestPostingTime": "19:00 WIB",
            "targetAudience": "Tech Enthusiast",
            "retentionPeakTime": "Detik 10-35",
            "engagementFactors": ["Hook kuat"]
          },
          "seoData": {
            "primaryKeywords": ["gadget ai", "review"],
            "longTailKeywords": ["smartphone ai terbaik 2026"],
            "recommendedTags": ["#gadget", "#tech"],
            "searchOptimizedDescription": "Review smartphone AI terlengkap"
          }
        }
        """.trimIndent()

        val parsed = repo.parseGeminiResponse(
            jsonString = mockJson,
            title = "Review AI Smartphone",
            source = "https://youtube.com/watch?v=123",
            sourceType = VideoSourceType.YOUTUBE,
            durationSeconds = 180,
            thumbnailUrl = "https://img.youtube.com/vi/123/hqdefault.jpg"
        )

        assertNotNull(parsed)
        assertEquals(1, parsed.moments.size)
        assertEquals(10, parsed.moments[0].startSecond)
        assertEquals(35, parsed.moments[0].endSecond)
        assertEquals(96, parsed.moments[0].viralScore)
        assertEquals(1, parsed.hooks.size)
        assertEquals("FOMO", parsed.hooks[0].hookType)
        assertEquals(94, parsed.audienceMetrics.overallScore)
        assertEquals("gadget ai", parsed.seoData.primaryKeywords[0])
    }
}
