package com.example.data.repository

import com.example.data.local.ReportDao
import com.example.data.model.TechnicalReport
import kotlinx.coroutines.flow.Flow

class ReportRepository(private val reportDao: ReportDao) {
    val allReports: Flow<List<TechnicalReport>> = reportDao.getAllReports()

    fun searchReports(query: String): Flow<List<TechnicalReport>> {
        return if (query.isBlank()) {
            reportDao.getAllReports()
        } else {
            reportDao.searchReports(query.trim())
        }
    }

    suspend fun getReportById(id: Long): TechnicalReport? = reportDao.getReportById(id)

    suspend fun saveReport(report: TechnicalReport): Long {
        return if (report.id == 0L) {
            reportDao.insertReport(report.copy(createdAt = System.currentTimeMillis(), updatedAt = System.currentTimeMillis()))
        } else {
            reportDao.updateReport(report.copy(updatedAt = System.currentTimeMillis()))
            report.id
        }
    }

    suspend fun deleteReport(report: TechnicalReport) = reportDao.deleteReport(report)

    suspend fun deleteReportById(id: Long) = reportDao.deleteReportById(id)
}
