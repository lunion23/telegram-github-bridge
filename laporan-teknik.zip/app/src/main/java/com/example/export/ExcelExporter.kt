package com.example.export

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.example.data.model.TechnicalReport
import com.example.data.model.WarrantyStatus
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets

object ExcelExporter {

    fun generateExcel(context: Context, report: TechnicalReport, templateOption: Int = report.activeTemplate): File {
        val outputDir = File(context.cacheDir, "reports")
        if (!outputDir.exists()) outputDir.mkdirs()

        val prefix = if (templateOption == 2) "Laporan_Teknik_HibaGroup" else "Laporan_Teknik_Standar"
        val cleanReportNo = report.reportNumber.replace("/", "_").replace(" ", "_").ifBlank { "report_${System.currentTimeMillis()}" }
        val excelFile = File(outputDir, "${prefix}_${cleanReportNo}.xls")

        val htmlContent = if (templateOption == 2) buildExcelHtmlHibaGroup(report) else buildExcelHtmlStandard(report)

        val writer = OutputStreamWriter(FileOutputStream(excelFile), StandardCharsets.UTF_8)
        writer.write(htmlContent)
        writer.flush()
        writer.close()

        return excelFile
    }

    private fun buildExcelHtmlHibaGroup(report: TechnicalReport): String {
        val sb = StringBuilder()
        sb.append("<html xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:x=\"urn:schemas-microsoft-com:office:excel\" xmlns=\"http://www.w3.org/TR/REC-html40\">\n")
        sb.append("<head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n")
        sb.append("<!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>Laporan Teknik Hiba Group</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->\n")
        sb.append("<style>\n")
        sb.append("  body { font-family: Calibri, Arial, sans-serif; font-size: 10pt; }\n")
        sb.append("  table { border-collapse: collapse; width: 100%; }\n")
        sb.append("  th, td { border: 1px solid #000000; padding: 5px 6px; text-align: left; vertical-align: top; }\n")
        sb.append("  .header-title { font-size: 15pt; font-weight: bold; text-decoration: underline; }\n")
        sb.append("  .sec-header { background-color: #E2E8F0; font-weight: bold; }\n")
        sb.append("  .center { text-align: center; }\n")
        sb.append("</style>\n</head>\n<body>\n")

        sb.append("<table>\n")
        // Header
        sb.append("  <tr>\n")
        sb.append("    <td colspan=\"4\" style=\"border-bottom: 2px solid #000;\"><b>${escapeHtml(report.companyName.ifBlank { "Hiba Group" })}</b> &nbsp;&nbsp;&nbsp; <span class=\"header-title\">${escapeHtml(report.title.ifBlank { "LAPORAN TEKNIK" })}</span></td>\n")
        sb.append("    <td colspan=\"3\">\n")
        sb.append("      <b>No.Laporan:</b> ${escapeHtml(report.reportNumber.ifBlank { "1/LT-CLG/III/2026" })}<br/>\n")
        sb.append("      <b>Bengkel:</b> ${escapeHtml(report.workshop.ifBlank { "Cilegon" })}<br/>\n")
        sb.append("      <b>Tanggal:</b> ${escapeHtml(report.reportDate.ifBlank { "12-Mar-26" })}\n")
        sb.append("    </td>\n")
        sb.append("  </tr>\n")

        // Informasi Unit
        sb.append("  <tr>\n")
        sb.append("    <td><b>Pabrik Pembuat</b></td><td>${escapeHtml(report.manufacturer)}</td>\n")
        sb.append("    <td><b>Tipe</b></td><td colspan=\"4\">${escapeHtml(report.unitType)}</td>\n")
        sb.append("  </tr>\n")
        sb.append("  <tr>\n")
        sb.append("    <td><b>Model</b></td><td>${escapeHtml(report.model)}</td>\n")
        sb.append("    <td><b>Kode</b></td><td>${escapeHtml(report.unitCode)}</td>\n")
        sb.append("    <td><b>Nama Alat</b></td><td colspan=\"2\">${escapeHtml(report.toolName)}</td>\n")
        sb.append("  </tr>\n")
        sb.append("  <tr>\n")
        sb.append("    <td><b>Tanggal Rusak</b></td><td>${escapeHtml(report.damageDate)}</td>\n")
        sb.append("    <td><b>Km / Hm</b></td><td>${escapeHtml(report.mileageKmHm)}</td>\n")
        sb.append("    <td><b>Komponen</b></td><td colspan=\"2\">${escapeHtml(report.component)}</td>\n")
        sb.append("  </tr>\n")

        // Uraian Kerusakan & Foto
        val gIn = if (report.warrantyStatus == WarrantyStatus.IN_WARRANTY) "[✓]" else "[ ]"
        val gOut = if (report.warrantyStatus == WarrantyStatus.AFTER_WARRANTY) "[✓]" else "[ ]"
        sb.append("  <tr>\n")
        sb.append("    <td colspan=\"4\" class=\"sec-header\"><b>Uraian Kerusakan:</b> $gIn Masa Garansi &nbsp;&nbsp; $gOut Setelah Masa Garansi</td>\n")
        sb.append("    <td colspan=\"3\" class=\"sec-header\"><b>Foto Kerusakan:</b></td>\n")
        sb.append("  </tr>\n")
        sb.append("  <tr>\n")
        sb.append("    <td colspan=\"4\">\n")
        sb.append("      <b>Tanggal:</b> ${escapeHtml(report.reportDate)} &nbsp;&nbsp;&nbsp;&nbsp; <b>Status:</b> ${escapeHtml(report.storingStatus.ifBlank { "Storing" })}<br/>\n")
        sb.append("      <b>Kerusakan:</b> ${escapeHtml(report.damageDetail)} &nbsp;&nbsp;&nbsp;&nbsp; <b>Lokasi:</b> ${escapeHtml(report.location)}<br/><br/>\n")
        sb.append("      <b>Analisa:</b><br/>${escapeHtml(report.analysisNotes.ifBlank { "Setelah di lakukan storing oleh team cikupa di temukan ban depan kiri kempes" })}<br/><br/>\n")
        sb.append("      <b>Kesimpulan:</b> ${escapeHtml(report.conclusionNotes)}<br/><br/>\n")
        sb.append("      <b>Penggantian terakhir:</b> ${escapeHtml(report.lastReplacement.ifBlank { "9-5-2022 (km.415513)" })}<br/>\n")
        sb.append("      <b>No. Work Order:</b> ${escapeHtml(report.lastReplacementWo.ifBlank { "KLD1-WO-2205-00381" })}<br/>\n")
        sb.append("      <b>Weekly terakhir:</b> ${escapeHtml(report.lastWeeklyCheck.ifBlank { "5-3-2026 (km.598234)" })}<br/>\n")
        sb.append("      <b>No. Work Order:</b> ${escapeHtml(report.lastWeeklyCheckWo.ifBlank { "CLG1-WO-2603-00225" })}\n")
        sb.append("    </td>\n")
        sb.append("    <td colspan=\"3\" style=\"text-align:center; vertical-align:middle; background-color:#F8FAFC;\">\n")
        sb.append("      [Foto Kerusakan Terlampir di Dokumen PDF/Lampiran]<br/>\n")
        sb.append("      <b>${escapeHtml(report.damageDetail)}</b>\n")
        sb.append("    </td>\n")
        sb.append("  </tr>\n")

        // Penyebab Kerusakan
        val c1 = if (report.causeInstallation) "√" else ""
        val c2 = if (report.causeQuality) "√" else ""
        val c3 = if (report.causeOperational) "√" else ""
        val c4 = if (report.causeTimeExpired) "√" else ""
        val c5 = if (report.causeOthers) "√" else ""

        sb.append("  <tr><td colspan=\"4\" class=\"sec-header\"><b>Penyebab Kerusakan : √ = YA &nbsp;&nbsp; X = TIDAK</b></td><td colspan=\"3\" class=\"sec-header\"><b>jika YA, tolong jelaskan!</b></td></tr>\n")
        sb.append("  <tr><td colspan=\"3\">1. Pemasangan</td><td class=\"center\">$c1</td><td colspan=\"3\">${escapeHtml(report.causeInstallationNotes)}</td></tr>\n")
        sb.append("  <tr><td colspan=\"3\">2. Kwalitas Parts</td><td class=\"center\">$c2</td><td colspan=\"3\">${escapeHtml(report.causeQualityNotes)}</td></tr>\n")
        sb.append("  <tr><td colspan=\"3\">3. Kesalahan Operasional</td><td class=\"center\">$c3</td><td colspan=\"3\">${escapeHtml(report.causeOperationalNotes)}</td></tr>\n")
        sb.append("  <tr><td colspan=\"3\">4. Sudah waktunya</td><td class=\"center\">$c4</td><td colspan=\"3\">${escapeHtml(report.causeTimeExpiredNotes)}</td></tr>\n")
        sb.append("  <tr><td colspan=\"3\">5. Lain-lain</td><td class=\"center\">$c5</td><td colspan=\"3\">${escapeHtml(report.causeOthersNotes)}</td></tr>\n")

        // Cara Mengatasi Kerusakan
        val s1 = if (report.solutionReplacePart) "√" else ""
        val s2 = if (report.solutionReinstallAdjust) "√" else ""
        val s3 = if (report.solutionModification) "√" else ""

        sb.append("  <tr><td colspan=\"7\" class=\"sec-header\" style=\"text-align:center;\"><b>Cara mengatasi kerusakan :</b></td></tr>\n")
        sb.append("  <tr><td colspan=\"3\">1. Ganti Part Baru</td><td class=\"center\">$s1</td><td colspan=\"3\" rowspan=\"3\" style=\"text-align:center; vertical-align:middle; font-weight:bold;\">${escapeHtml(report.solutionReinstallAdjustNotes.ifBlank { "Ganti ban stip" })}</td></tr>\n")
        sb.append("  <tr><td colspan=\"3\">2. Pemasangan atau Penyetelan Ulang</td><td class=\"center\">$s2</td></tr>\n")
        sb.append("  <tr><td colspan=\"3\">3. Modifikasi</td><td class=\"center\">$s3</td></tr>\n")

        // Tertunda & Usulan
        sb.append("  <tr><td colspan=\"3\" class=\"sec-header\" style=\"text-align:center;\"><b>Tertunda Karena</b></td><td colspan=\"4\" class=\"sec-header\" style=\"text-align:center;\"><b>Usulan Pelapor</b></td></tr>\n")
        sb.append("  <tr><td colspan=\"3\">${escapeHtml(report.pendingReason)}</td><td colspan=\"4\" style=\"font-weight:bold;\">${escapeHtml(report.reporterProposal.ifBlank { "Segera akan di lakukan program pengecekan atau penggantian terkait part tersebut terhadap RK8J supaya tidak terjadi kejadian serupa" })}</td></tr>\n")

        // Parts yang harus diganti (Stock | Order | Modifikasi | Pending)
        sb.append("  <tr><td colspan=\"7\" class=\"sec-header\"><b>Parts yang harus diganti :</b></td></tr>\n")
        sb.append("  <tr>\n")
        sb.append("    <th style=\"width:5%; text-align:center;\">No</th>\n")
        sb.append("    <th style=\"width:20%;\">No Parts</th>\n")
        sb.append("    <th style=\"width:35%;\">Nama Parts</th>\n")
        sb.append("    <th style=\"width:10%; text-align:center;\">Stock</th>\n")
        sb.append("    <th style=\"width:10%; text-align:center;\">Order</th>\n")
        sb.append("    <th style=\"width:10%; text-align:center;\">Modifikasi</th>\n")
        sb.append("    <th style=\"width:10%; text-align:center;\">Pending</th>\n")
        sb.append("  </tr>\n")

        for (i in 0 until 5) {
            val part = if (i < report.partsList.size) report.partsList[i] else null
            val isStock = if (part?.procurementType.equals("Stock", true)) "√" else ""
            val isOrder = if (part?.procurementType.equals("Order", true)) "√" else ""
            val isModif = if (part?.procurementType.equals("Modifikasi", true)) "√" else ""
            val isPending = if (part?.procurementType.equals("Pending", true)) "√" else ""

            sb.append("  <tr>\n")
            sb.append("    <td class=\"center\">${i + 1}</td>\n")
            sb.append("    <td>${escapeHtml(part?.partNumber ?: "")}</td>\n")
            sb.append("    <td>${escapeHtml(part?.partName ?: "")}</td>\n")
            sb.append("    <td class=\"center\">$isStock</td>\n")
            sb.append("    <td class=\"center\">$isOrder</td>\n")
            sb.append("    <td class=\"center\">$isModif</td>\n")
            sb.append("    <td class=\"center\">$isPending</td>\n")
            sb.append("  </tr>\n")
        }

        // Signatures
        sb.append("  <tr>\n")
        sb.append("    <td colspan=\"3\" class=\"sec-header\" style=\"text-align:center;\"><b>Mengetahui,</b></td>\n")
        sb.append("    <td colspan=\"4\" class=\"sec-header\" style=\"text-align:center;\"><b>Dilaporkan Oleh:</b></td>\n")
        sb.append("  </tr>\n")
        sb.append("  <tr>\n")
        sb.append("    <td colspan=\"3\" style=\"height:70px; vertical-align:bottom; text-align:center;\">(...............................) &nbsp;&nbsp; (...............................)</td>\n")
        sb.append("    <td colspan=\"4\">\n")
        sb.append("      <b>Nama:</b> ${escapeHtml(report.reportedByName.ifBlank { "Yudi Indrawan" })}<br/>\n")
        sb.append("      <b>Jabatan:</b> ${escapeHtml(report.reportedByTitle.ifBlank { "Wa.Ka.Bengkel" })}<br/><br/>\n")
        sb.append("      <table style=\"border:none; width:100%;\">\n")
        sb.append("        <tr><td style=\"border:none; text-align:center;\"><b>${escapeHtml(report.knownBy2.ifBlank { "SUHERMAN" })}</b></td><td style=\"border:none; text-align:center;\"><b>${escapeHtml(report.reportedByName.ifBlank { "YUDI INDRAWAN" })}</b></td></tr>\n")
        sb.append("      </table>\n")
        sb.append("    </td>\n")
        sb.append("  </tr>\n")

        sb.append("</table>\n</body>\n</html>")
        return sb.toString()
    }

    private fun buildExcelHtmlStandard(report: TechnicalReport): String {
        val sb = StringBuilder()
        sb.append("<html xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:x=\"urn:schemas-microsoft-com:office:excel\" xmlns=\"http://www.w3.org/TR/REC-html40\">\n")
        sb.append("<head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n")
        sb.append("<!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>Laporan Teknik</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->\n")
        sb.append("<style>\n")
        sb.append("  body { font-family: Calibri, Arial, sans-serif; font-size: 11pt; }\n")
        sb.append("  table { border-collapse: collapse; width: 100%; }\n")
        sb.append("  th, td { border: 1px solid #94A3B8; padding: 6px 8px; text-align: left; vertical-align: top; }\n")
        sb.append("  .title { font-size: 16pt; font-weight: bold; text-align: center; background-color: #1E3A8A; color: #FFFFFF; height: 35px; }\n")
        sb.append("  .section-hdr { background-color: #E2E8F0; font-weight: bold; color: #0F172A; font-size: 11pt; }\n")
        sb.append("  .meta-label { font-weight: bold; background-color: #F8FAFC; width: 18%; }\n")
        sb.append("  .th-part { background-color: #CBD5E1; font-weight: bold; text-align: center; }\n")
        sb.append("  .center { text-align: center; }\n")
        sb.append("  .sign-box { height: 70px; vertical-align: bottom; font-weight: bold; text-decoration: underline; }\n")
        sb.append("</style>\n</head>\n<body>\n")

        sb.append("<table>\n")
        sb.append("  <tr><th colspan=\"5\" class=\"title\">LAPORAN TEKNIK</th></tr>\n")
        sb.append("  <tr>\n")
        sb.append("    <td class=\"meta-label\">No. Laporan</td><td>${escapeHtml(report.reportNumber)}</td>\n")
        sb.append("    <td class=\"meta-label\">Bengkel</td><td>${escapeHtml(report.workshop)}</td>\n")
        sb.append("    <td><b>Tanggal:</b> ${escapeHtml(report.reportDate)}</td>\n")
        sb.append("  </tr>\n")
        sb.append("  <tr><td colspan=\"5\" style=\"border:none; height:8px;\"></td></tr>\n")

        sb.append("  <tr><th colspan=\"5\" class=\"section-hdr\">1. INFORMASI UNIT / ALAT</th></tr>\n")
        sb.append("  <tr>\n")
        sb.append("    <td class=\"meta-label\">Pabrik Pembuat</td><td>${escapeHtml(report.manufacturer)}</td>\n")
        sb.append("    <td class=\"meta-label\">Nama Alat</td><td colspan=\"2\">${escapeHtml(report.toolName)}</td>\n")
        sb.append("  </tr>\n")
        sb.append("  <tr>\n")
        sb.append("    <td class=\"meta-label\">Tipe</td><td>${escapeHtml(report.unitType)}</td>\n")
        sb.append("    <td class=\"meta-label\">Tanggal Rusak</td><td colspan=\"2\">${escapeHtml(report.damageDate)}</td>\n")
        sb.append("  </tr>\n")
        sb.append("  <tr>\n")
        sb.append("    <td class=\"meta-label\">Model</td><td>${escapeHtml(report.model)}</td>\n")
        sb.append("    <td class=\"meta-label\">KM / HM</td><td colspan=\"2\">${escapeHtml(report.mileageKmHm)}</td>\n")
        sb.append("  </tr>\n")
        sb.append("  <tr>\n")
        sb.append("    <td class=\"meta-label\">Kode Unit</td><td>${escapeHtml(report.unitCode)}</td>\n")
        sb.append("    <td class=\"meta-label\">Komponen</td><td colspan=\"2\">${escapeHtml(report.component)}</td>\n")
        sb.append("  </tr>\n")
        sb.append("  <tr><td colspan=\"5\" style=\"border:none; height:8px;\"></td></tr>\n")

        sb.append("  <tr><th colspan=\"5\" class=\"section-hdr\">2. STATUS GARANSI</th></tr>\n")
        val gIn = if (report.warrantyStatus == WarrantyStatus.IN_WARRANTY) "[ ✓ ]" else "[   ]"
        val gOut = if (report.warrantyStatus == WarrantyStatus.AFTER_WARRANTY) "[ ✓ ]" else "[   ]"
        sb.append("  <tr><td colspan=\"5\">$gIn Masa Garansi &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $gOut Setelah Masa Garansi</td></tr>\n")
        sb.append("  <tr><td colspan=\"5\" style=\"border:none; height:8px;\"></td></tr>\n")

        sb.append("  <tr><th colspan=\"5\" class=\"section-hdr\">3. DETAIL KERUSAKAN & LOKASI</th></tr>\n")
        sb.append("  <tr><td class=\"meta-label\">Kerusakan</td><td colspan=\"4\">${escapeHtml(report.damageDetail)}</td></tr>\n")
        sb.append("  <tr><td class=\"meta-label\">Lokasi</td><td colspan=\"4\">${escapeHtml(report.location)}</td></tr>\n")
        sb.append("  <tr><td class=\"meta-label\">History Bengkel</td><td colspan=\"4\">${escapeHtml(report.workshopHistory)}</td></tr>\n")
        sb.append("  <tr><td class=\"meta-label\">History Ban / Part</td><td colspan=\"4\">${escapeHtml(report.tireHistory)}</td></tr>\n")
        sb.append("  <tr><td class=\"meta-label\">Lampiran</td><td colspan=\"4\">${escapeHtml(report.attachments)}</td></tr>\n")
        sb.append("  <tr><td colspan=\"5\" style=\"border:none; height:8px;\"></td></tr>\n")

        sb.append("  <tr><th colspan=\"5\" class=\"section-hdr\">4. PENYEBAB KERUSAKAN</th></tr>\n")
        val c1 = if (report.causeInstallation) "[ ✓ ]" else "[   ]"
        val c2 = if (report.causeQuality) "[ ✓ ]" else "[   ]"
        val c3 = if (report.causeOperational) "[ ✓ ]" else "[   ]"
        val c4 = if (report.causeTimeExpired) "[ ✓ ]" else "[   ]"
        val c5 = if (report.causeOthers) "[ ✓ ]" else "[   ]"

        sb.append("  <tr><td class=\"meta-label\">$c1 1. Pemasangan</td><td colspan=\"4\">${escapeHtml(report.causeInstallationNotes)}</td></tr>\n")
        sb.append("  <tr><td class=\"meta-label\">$c2 2. Kualitas</td><td colspan=\"4\">${escapeHtml(report.causeQualityNotes)}</td></tr>\n")
        sb.append("  <tr><td class=\"meta-label\">$c3 3. Kesalahan Operasional</td><td colspan=\"4\">${escapeHtml(report.causeOperationalNotes)}</td></tr>\n")
        sb.append("  <tr><td class=\"meta-label\">$c4 4. Sudah Waktunya</td><td colspan=\"4\">${escapeHtml(report.causeTimeExpiredNotes)}</td></tr>\n")
        sb.append("  <tr><td class=\"meta-label\">$c5 5. Lain-lain</td><td colspan=\"4\">${escapeHtml(report.causeOthersNotes)}</td></tr>\n")
        sb.append("  <tr><td colspan=\"5\" style=\"border:none; height:8px;\"></td></tr>\n")

        sb.append("  <tr><th colspan=\"5\" class=\"section-hdr\">5. CARA MENGATASI KERUSAKAN</th></tr>\n")
        val s1 = if (report.solutionReplacePart) "[ ✓ ]" else "[   ]"
        val s2 = if (report.solutionReinstallAdjust) "[ ✓ ]" else "[   ]"
        val s3 = if (report.solutionModification) "[ ✓ ]" else "[   ]"

        sb.append("  <tr><td class=\"meta-label\">$s1 1. Ganti Part Baru</td><td colspan=\"4\">${escapeHtml(report.solutionReplacePartNotes)}</td></tr>\n")
        sb.append("  <tr><td class=\"meta-label\">$s2 2. Penyetelan Ulang</td><td colspan=\"4\">${escapeHtml(report.solutionReinstallAdjustNotes)}</td></tr>\n")
        sb.append("  <tr><td class=\"meta-label\">$s3 3. Modifikasi</td><td colspan=\"4\">${escapeHtml(report.solutionModificationNotes)}</td></tr>\n")
        sb.append("  <tr><td colspan=\"5\" style=\"border:none; height:8px;\"></td></tr>\n")

        sb.append("  <tr><th colspan=\"5\" class=\"section-hdr\">6. TABEL PARTS YANG HARUS DIGANTI</th></tr>\n")
        sb.append("  <tr>\n")
        sb.append("    <th class=\"th-part\" style=\"width:5%;\">NO</th>\n")
        sb.append("    <th class=\"th-part\" style=\"width:25%;\">No.Part</th>\n")
        sb.append("    <th class=\"th-part\" style=\"width:30%;\">Nama Parts</th>\n")
        sb.append("    <th class=\"th-part\" style=\"width:20%;\">Jenis Pengadaan Part</th>\n")
        sb.append("    <th class=\"th-part\" style=\"width:20%;\">Keterangan</th>\n")
        sb.append("  </tr>\n")

        if (report.partsList.isEmpty()) {
            sb.append("  <tr><td class=\"center\">1</td><td>-</td><td>Tidak ada penggantian part</td><td class=\"center\">Stock</td><td>-</td></tr>\n")
        } else {
            report.partsList.forEachIndexed { idx, part ->
                sb.append("  <tr>\n")
                sb.append("    <td class=\"center\">${idx + 1}</td>\n")
                sb.append("    <td>${escapeHtml(part.partNumber)}</td>\n")
                sb.append("    <td>${escapeHtml(part.partName)}</td>\n")
                sb.append("    <td class=\"center\">${escapeHtml(part.procurementType)}</td>\n")
                sb.append("    <td>${escapeHtml(part.notes)}</td>\n")
                sb.append("  </tr>\n")
            }
        }
        sb.append("  <tr><td colspan=\"5\" style=\"border:none; height:12px;\"></td></tr>\n")

        sb.append("  <tr>\n")
        sb.append("    <th colspan=\"2\" class=\"section-hdr\" style=\"text-align:center;\">Disetujui Oleh:</th>\n")
        sb.append("    <td style=\"border:none;\"></td>\n")
        sb.append("    <th colspan=\"2\" class=\"section-hdr\" style=\"text-align:center;\">Dilaporkan Oleh:</th>\n")
        sb.append("  </tr>\n")
        sb.append("  <tr>\n")
        sb.append("    <td colspan=\"2\" style=\"text-align:center; height:18px;\"><b>${escapeHtml(report.approvedByTitle.ifBlank { "WA.KA. Bengkel" })}</b></td>\n")
        sb.append("    <td style=\"border:none;\"></td>\n")
        sb.append("    <td colspan=\"2\" style=\"text-align:center; height:18px;\"><b>${escapeHtml(report.reportedByTitle.ifBlank { "Mekanik / Foreman" })}</b></td>\n")
        sb.append("  </tr>\n")
        sb.append("  <tr>\n")
        sb.append("    <td colspan=\"2\" class=\"sign-box\" style=\"text-align:center;\">${escapeHtml(report.approvedByName.ifBlank { "Yudi Indrawan" })}</td>\n")
        sb.append("    <td style=\"border:none;\"></td>\n")
        sb.append("    <td colspan=\"2\" class=\"sign-box\" style=\"text-align:center;\">${escapeHtml(report.reportedByName.ifBlank { "Ahmad Supriyadi" })}</td>\n")
        sb.append("  </tr>\n")
        sb.append("  <tr>\n")
        sb.append("    <td colspan=\"2\" style=\"text-align:center; font-size:9pt; color:#64748B;\">Tanggal: ${escapeHtml(report.signDate.ifBlank { report.reportDate })}</td>\n")
        sb.append("    <td style=\"border:none;\"></td>\n")
        sb.append("    <td colspan=\"2\" style=\"text-align:center; font-size:9pt; color:#64748B;\">Tanggal: ${escapeHtml(report.signDate.ifBlank { report.reportDate })}</td>\n")
        sb.append("  </tr>\n")

        sb.append("</table>\n</body>\n</html>")
        return sb.toString()
    }

    private fun escapeHtml(text: String): String {
        return text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&#39;")
    }

    fun shareExcel(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/vnd.ms-excel"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Laporan Teknik (Excel) - ${file.name}")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(shareIntent, "Bagikan Dokumen Excel (.xls)")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    fun openExcel(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val viewIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.ms-excel")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooser = Intent.createChooser(viewIntent, "Buka Dokumen Excel")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }
}
