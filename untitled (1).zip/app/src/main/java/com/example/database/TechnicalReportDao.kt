package com.example.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.model.TechnicalReport
import kotlinx.coroutines.flow.Flow

@Dao
interface TechnicalReportDao {
    @Query("SELECT * FROM technical_reports ORDER BY createdAt DESC")
    fun getAllReports(): Flow<List<TechnicalReport>>

    @Query("SELECT * FROM technical_reports WHERE id = :id LIMIT 1")
    fun getReportById(id: Long): Flow<TechnicalReport?>

    @Query("SELECT * FROM technical_reports WHERE id = :id LIMIT 1")
    suspend fun getReportByIdSync(id: Long): TechnicalReport?

    @Query("SELECT * FROM technical_reports WHERE reportNumber LIKE '%' || :query || '%' OR unitCode LIKE '%' || :query || '%' OR workshop LIKE '%' || :query || '%' OR toolName LIKE '%' || :query || '%' ORDER BY createdAt DESC")
    fun searchReports(query: String): Flow<List<TechnicalReport>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: TechnicalReport): Long

    @Update
    suspend fun updateReport(report: TechnicalReport)

    @Delete
    suspend fun deleteReport(report: TechnicalReport)

    @Query("DELETE FROM technical_reports WHERE id = :id")
    suspend fun deleteReportById(id: Long)
}
