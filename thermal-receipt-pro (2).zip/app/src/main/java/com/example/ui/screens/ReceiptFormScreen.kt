package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PrintFormatMode
import com.example.ui.components.DynamicReceiptView
import com.example.ui.components.ShippingLabelView
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.ExpressNavy
import com.example.ui.theme.ExpressRed
import com.example.ui.viewmodel.ReceiptViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReceiptFormScreen(
    viewModel: ReceiptViewModel,
    onNavigateToPdf: () -> Unit,
    onNavigateToBluetooth: () -> Unit,
    modifier: Modifier = Modifier
) {
    val receipt by viewModel.currentReceipt.collectAsState()
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    var showLivePreview by remember { mutableStateOf(true) }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Presets
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Generator Resi & Struk",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Barcode otomatis sync dengan nomor resi",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }

                    OutlinedButton(
                        onClick = { showLivePreview = !showLivePreview },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("toggle_preview_button")
                    ) {
                        Icon(
                            imageVector = if (showLivePreview) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (showLivePreview) "Tutup Struk" else "Lihat Struk", fontSize = 12.sp)
                    }
                }
            }

            // Print Format Selector (Opsi 1, Opsi 2, Opsi 3)
            item {
                ElevatedCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "Format Tampilan & Cetak:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            PrintFormatMode.entries.forEach { mode ->
                                FilterChip(
                                    selected = receipt.selectedFormat == mode,
                                    onClick = { viewModel.setPrintFormat(mode) },
                                    label = {
                                        Text(
                                            text = mode.displayName,
                                            fontSize = 11.5.sp,
                                            fontWeight = if (receipt.selectedFormat == mode) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Quick Preset Chips
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Pilih Template Cepat:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = receipt.selectedFormat == PrintFormatMode.MAIN_LABEL,
                            onClick = { viewModel.applyPreset("RETROSPORT") },
                            label = { Text("Opsi 1 (J&T)") },
                            leadingIcon = {
                                Icon(Icons.Default.BookmarkBorder, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        )
                        FilterChip(
                            selected = receipt.selectedFormat == PrintFormatMode.SENDER_CLEAN,
                            onClick = { viewModel.applyPreset("LAPIP_MALANG") },
                            label = { Text("Opsi 4 (Lapip)") }
                        )
                        FilterChip(
                            selected = receipt.selectedFormat == PrintFormatMode.LABEL_ALT,
                            onClick = { viewModel.applyPreset("RETRO_ALT") },
                            label = { Text("Opsi 5 (Label Alt)") }
                        )
                        FilterChip(
                            selected = receipt.badge1 == "COD",
                            onClick = { viewModel.applyPreset("COD_FASHION") },
                            label = { Text("Fashion COD") }
                        )
                        FilterChip(
                            selected = receipt.badge2 == "DOC",
                            onClick = { viewModel.applyPreset("DOC_KILAT") },
                            label = { Text("Dokumen Kilat") }
                        )
                    }
                }
            }

            // Live Preview Card (Mirrors the reference image)
            item {
                AnimatedVisibility(visible = showLivePreview) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Preview Struk Fisik (1:1)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = ExpressRed
                            )
                            Text(
                                text = "Otomatis Mengikuti Form",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }

                        DynamicReceiptView(receipt = receipt)
                    }
                }
            }

            // Action Buttons Bar
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Aksi Cepat Transaksi",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    viewModel.preparePdfPreview()
                                    onNavigateToPdf()
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("preview_pdf_btn"),
                                colors = ButtonDefaults.buttonColors(containerColor = ExpressRed)
                            ) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Preview PDF", fontSize = 13.sp)
                            }

                            Button(
                                onClick = {
                                    onNavigateToBluetooth()
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("bluetooth_print_btn"),
                                colors = ButtonDefaults.buttonColors(containerColor = ExpressNavy)
                            ) {
                                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Thermal BT", fontSize = 13.sp)
                            }
                        }

                        Button(
                            onClick = {
                                viewModel.saveCurrentReceiptToDatabase { id ->
                                    scope.launch {
                                        snackbarHostState.showSnackbar("Transaksi tersimpan di Riwayat! (ID: $id)")
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("save_history_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = AccentGreen)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Simpan ke Riwayat & Pemasukan", fontSize = 13.sp)
                        }
                    }
                }
            }

            // 1. Resi & Barcode Form Section
            item {
                SectionCard(title = "1. Nomor Resi & Kode Barcode (Otomatis)") {
                    OutlinedTextField(
                        value = receipt.resiCode,
                        onValueChange = { viewModel.updateResiCode(it) },
                        label = { Text("Nomor Resi (Barcode & QR Code)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_resi_code"),
                        singleLine = true,
                        trailingIcon = {
                            IconButton(onClick = { viewModel.generateNewResi() }) {
                                Icon(
                                    imageVector = Icons.Default.Autorenew,
                                    contentDescription = "Acak Resi Baru",
                                    tint = ExpressRed
                                )
                            }
                        },
                        supportingText = {
                            Text("Barcode 1D & QR Code langsung disesuaikan dengan nilai ini.")
                        }
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = receipt.routingCode,
                        onValueChange = { viewModel.updateReceipt { r -> r.copy(routingCode = it) } },
                        label = { Text("Kode Routing Tujuan (Besar)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = receipt.badge1,
                            onValueChange = { viewModel.updateReceipt { r -> r.copy(badge1 = it) } },
                            label = { Text("Badge 1 (cth: NP, COD)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = receipt.badge2,
                            onValueChange = { viewModel.updateReceipt { r -> r.copy(badge2 = it) } },
                            label = { Text("Badge 2 (cth: EZ, ECO)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = receipt.dropPoint,
                        onValueChange = { viewModel.updateReceipt { r -> r.copy(dropPoint = it) } },
                        label = { Text("Nama Drop Point / Kantor Cabang") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }

            // 2. Penerima (Recipient) Form Section
            item {
                SectionCard(title = "2. Data Penerima (Consignee)") {
                    OutlinedTextField(
                        value = receipt.recipientName,
                        onValueChange = { viewModel.updateReceipt { r -> r.copy(recipientName = it) } },
                        label = { Text("Nama Penerima") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_recipient_name"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = receipt.recipientPhone,
                        onValueChange = { viewModel.updateReceipt { r -> r.copy(recipientPhone = it) } },
                        label = { Text("Nomor HP Penerima") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = receipt.recipientAddress,
                        onValueChange = { viewModel.updateReceipt { r -> r.copy(recipientAddress = it) } },
                        label = { Text("Alamat Lengkap Penerima") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        maxLines = 5
                    )
                }
            }

            // 3. Pengirim (Sender) Form Section
            item {
                SectionCard(title = "3. Data Pengirim (Shipper)") {
                    OutlinedTextField(
                        value = receipt.senderName,
                        onValueChange = { viewModel.updateReceipt { r -> r.copy(senderName = it) } },
                        label = { Text("Nama Pengirim / Olshop") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_sender_name"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = receipt.senderPhone,
                        onValueChange = { viewModel.updateReceipt { r -> r.copy(senderPhone = it) } },
                        label = { Text("Nomor HP Pengirim") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = receipt.senderAddress,
                        onValueChange = { viewModel.updateReceipt { r -> r.copy(senderAddress = it) } },
                        label = { Text("Alamat Lengkap Pengirim") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        maxLines = 4
                    )
                }
            }

            // 4. Tarif & Detail Pengiriman
            item {
                SectionCard(title = "4. Biaya & Detail Paket") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = receipt.shippingFee.toString(),
                            onValueChange = {
                                val fee = it.filter { ch -> ch.isDigit() }.toLongOrNull() ?: 0L
                                viewModel.updateReceipt { r -> r.copy(shippingFee = fee) }
                            },
                            label = { Text("Ongkir (IDR)") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_shipping_fee"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = receipt.paymentType,
                            onValueChange = { viewModel.updateReceipt { r -> r.copy(paymentType = it) } },
                            label = { Text("Tipe Bayar (cth: TUNAI)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = receipt.weightKg,
                            onValueChange = { viewModel.updateReceipt { r -> r.copy(weightKg = it) } },
                            label = { Text("Berat (cth: 1.00 KG)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = receipt.printDate,
                            onValueChange = { viewModel.updateReceipt { r -> r.copy(printDate = it) } },
                            label = { Text("Tgl Cetak") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = receipt.orderNo,
                        onValueChange = { viewModel.updateReceipt { r -> r.copy(orderNo = it) } },
                        label = { Text("Order No / Nomor Pesanan") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        trailingIcon = {
                            IconButton(onClick = { viewModel.generateNewOrderNo() }) {
                                Icon(Icons.Default.Refresh, contentDescription = "Acak Order No")
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = receipt.notes,
                        onValueChange = { viewModel.updateReceipt { r -> r.copy(notes = it) } },
                        label = { Text("Notes / Catatan Kurir") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Fields for Lembar Pengirim (Image 1 & 2)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = receipt.itemName,
                            onValueChange = { viewModel.updateReceipt { r -> r.copy(itemName = it) } },
                            label = { Text("Nama Barang") },
                            modifier = Modifier.weight(1.4f),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = receipt.itemQty,
                            onValueChange = { viewModel.updateReceipt { r -> r.copy(itemQty = it) } },
                            label = { Text("Qty (PCS)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = receipt.expDate,
                        onValueChange = { viewModel.updateReceipt { r -> r.copy(expDate = it) } },
                        label = { Text("Tgl Expire (Lembar Pengirim)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Sensor / Masking No HP (cth: *******3149)",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Switch(
                            checked = receipt.maskPhone,
                            onCheckedChange = { viewModel.updateReceipt { r -> r.copy(maskPhone = it) } }
                        )
                    }
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 80.dp)
        )
    }
}

@Composable
private fun SectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 10.dp)
            )
            content()
        }
    }
}
