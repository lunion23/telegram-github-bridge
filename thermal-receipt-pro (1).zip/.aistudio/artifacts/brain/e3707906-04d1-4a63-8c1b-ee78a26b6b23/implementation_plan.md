# Rencana Implementasi: 3 Opsi Format Cetak Struk & Label Pengiriman

Menambahkan 2 opsi format cetak baru ke dalam aplikasi:
1. **Opsi 1: Label Pengiriman Utama** (Format struk paket reguler yang sudah ada)
2. **Opsi 2: Lembar Pengirim** (Sesuai Gambar 1 - bukti kirim khusus pengirim dengan barcode, nama barang, qty, total biaya, dan badge hitam "Lembar Pengirim")
3. **Opsi 3: Kombinasi Lengkap 2-in-1** (Sesuai Gambar 2 - menggabungkan Label Utama di bagian atas dan Lembar Pengirim di bagian bawah dalam satu lembar cetak berkesinambungan)

---

## 1. Perubahan Data & Model (`ReceiptData.kt`, `ReceiptEntity.kt`)
- Menambahkan enum `PrintFormatMode`:
  - `MAIN_LABEL` (Opsi 1: Label Paket Utama)
  - `SENDER_COPY` (Opsi 2: Lembar Pengirim)
  - `COMBO_ALL` (Opsi 3: Label Utama + Lembar Pengirim 2-in-1)
- Menambahkan field baru pada `ReceiptData`:
  - `itemName: String = "Pakaian"`
  - `itemQty: String = "1 PCS"`
  - `expDate: String = "25-10-2026"`
  - `selectedFormat: PrintFormatMode = PrintFormatMode.MAIN_LABEL`
- Memperbarui `ReceiptEntity` (Room Database) dengan migrasi fallback yang aman agar riwayat transaksi menyimpan format dan detail barang yang dicetak.

---

## 2. Pembuatan Komponen UI Struk Baru (`ShippingLabelView.kt`)
- **`SenderCopyLabelView` (Gambar 1)**:
  - Barcode 1D Code 128 dengan nomor resi terpusat di bawah barcode.
  - Baris Pengirim (nama & masked HP) dan Penerima (nama & masked HP).
  - Alamat lengkap penerima.
  - Tabel 2 kolom:
    - Kiri: `TOTAL BIAYA`, nominal tebal (cth: `IDR 200,000`), `Sudah Termasuk PPN`, dan badge hitam pekat bertuliskan `Lembar Pengirim`.
    - Kanan: `Qty 1 PCS`, `BARANG [Nama Barang]`, `Notes`, `Cetak [Tanggal]`, `Exp [Tanggal Expire]`.
    - Bawah: Info legalitas PT GLOBAL JET EXPRESS dan alamat kantor.
- **`ComboLabelView` (Gambar 2)**:
  - Menyusun `ShippingLabelView` (Label Utama) di sisi atas.
  - Garis pemisah perforasi / potong.
  - Menyusun `SenderCopyLabelView` di sisi bawah dengan teks resi vertikal yang memanjang di kedua sisi samping secara proporsional.
- **`DynamicReceiptView`**:
  - Komponen wrapper pintar yang menampilkan Opsi 1, Opsi 2, atau Opsi 3 sesuai opsi yang dipilih pengguna.

---

## 3. Integrasi Generator PDF & Bluetooth Thermal (`util/`)
- **`PdfReceiptGenerator.kt`**:
  - `drawSenderCopyOnCanvas`: Menggambar tata letak Lembar Pengirim pada Canvas PDF.
  - `drawComboOnCanvas`: Menggambar format gabungan 2-in-1 pada Canvas PDF dengan rasio tinggi dinamis.
  - Pembuatan file PDF otomatis menyesuaikan mode: lembar tunggal atau panjang combo.
- **`ThermalBluetoothPrinter.kt`**:
  - Rasterizer grafis monochrome 1-bit (`GS v 0`) menyesuaikan tinggi cetakan untuk mencetak Opsi 1, Opsi 2, atau Opsi 3 ke printer thermal Bluetooth (58mm dan 80mm).
- **Stabilisasi Build `.env`**:
  - Menyesuaikan konfigurasi Secrets Gradle Plugin di `app/build.gradle.kts` agar build tidak gagal jika file `.env` tidak ada atau dihapus oleh pengguna.

---

## 4. Antarmuka Pengguna (UI & Form)
- **`ReceiptFormScreen.kt`**:
  - Menambahkan selector 3 opsi format cetak (Pill/Chips: `1. Label Utama`, `2. Lembar Pengirim`, `3. Lengkap (2-in-1)`).
  - Menambahkan field input baru: `Nama Barang` (cth: Pakaian, Sepatu, Dokumen), `Jumlah Qty` (cth: 1 PCS), dan `Tanggal Expire`.
  - Live Preview langsung merender format sesuai opsi yang dipilih.
- **`PdfPreviewScreen.kt`**:
  - Menambahkan selector cepat 3 opsi cetak di toolbar preview sehingga pengguna dapat beralih melihat dan langsung mencetak format apa pun secara instan.
- **`BluetoothPrinterScreen.kt`**:
  - Menampilkan badge format yang sedang aktif sebelum tombol "Cetak Resi Sekarang" ditekan.

---

## 5. Rencana Verifikasi
- Menjalankan `compile_applet` untuk memastikan kompilasi Gradle bebas error.
- Menjalankan pengujian unit `gradle :app:testDebugUnitTest`.
- Memvalidasi tampilan dan fungsi Opsi 1, Opsi 2, dan Opsi 3 di Form, Preview PDF, dan Printer Thermal Bluetooth.
