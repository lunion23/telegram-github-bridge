package com.example.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ffmpeg.TrimTimeRange
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.LightTextMuted
import com.example.ui.theme.LightTextPrimary
import com.example.ui.theme.LightTextSecondary
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioViolet
import com.example.ui.theme.SuccessGreen
import com.example.util.MediaUtils
import java.io.File

/**
 * Layar utama pemotong video dengan integrasi biner FFmpeg internal, opsi Termux,
 * serta fitur Multi-Text Time Command Batch Trimming.
 */
@Composable
fun VideoTrimScreen(
    viewModel: VideoTrimViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // File yang sedang aktif dipilih untuk preview di video player
    var previewTargetFile by remember { mutableStateOf<File?>(null) }

    // Update target preview jika ada single trim selesai
    LaunchedEffect(uiState.trimmedOutputFile) {
        if (uiState.trimmedOutputFile != null) {
            previewTargetFile = uiState.trimmedOutputFile
        }
    }

    // Launcher untuk memilih video dari penyimpanan lokal / galeri (zero permissions Photo Picker)
    val pickVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            previewTargetFile = null
            viewModel.onVideoSelected(uri)
        }
    }

    var showLogsDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(WindowInsets.statusBars.asPaddingValues())
    ) {
        // App Header Bar
        TopHeaderBar(
            isBinaryReady = uiState.isBinaryReady,
            onShowLogs = { showLogsDialog = true },
            onReloadSample = {
                previewTargetFile = null
                viewModel.loadSampleVideo()
            }
        )

        // Segmented Control: Pilihan Mode Mesin Pemotongan (Biner Internal vs Termux)
        EngineModeSegmentedControl(
            currentMode = uiState.engineMode,
            onModeSelect = { viewModel.setEngineMode(it) },
            isTermuxInstalled = uiState.isTermuxInstalled
        )

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Video Player Preview Box
            item {
                VideoPreviewCard(
                    videoFile = uiState.localVideoFile,
                    trimmedFile = previewTargetFile ?: uiState.trimmedOutputFile,
                    trimStartSec = uiState.trimStartSeconds,
                    trimEndSec = uiState.trimEndSeconds
                )
            }

            // 2. Video Info & Selection Actions
            item {
                VideoSelectionBar(
                    selectedTitle = uiState.selectedVideo?.title ?: "Belum ada video",
                    durationText = uiState.selectedVideo?.formattedDuration ?: "00:00",
                    onPickFromGallery = {
                        pickVideoLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                        )
                    },
                    onUseSample = {
                        previewTargetFile = null
                        viewModel.loadSampleVideo()
                    },
                    isTrimming = uiState.isTrimming || uiState.isBatchTrimming
                )
            }

            // 3. Fast Stream Copy Toggle
            if (uiState.selectedVideo != null) {
                item {
                    StreamCopyOptionCard(
                        useFastCopy = uiState.useFastStreamCopy,
                        isTrimming = uiState.isTrimming || uiState.isBatchTrimming,
                        onToggle = { viewModel.toggleStreamCopy(it) }
                    )
                }

                // 4. FITUR BARU: Multi-Text Time Command Batch Trimming
                item {
                    BatchTextTrimCard(
                        textCommand = uiState.batchTextCommand,
                        onTextChanged = { viewModel.onBatchTextChanged(it) },
                        parsedRanges = uiState.batchParsedRanges,
                        isBatchTrimming = uiState.isBatchTrimming,
                        isSingleTrimming = uiState.isTrimming,
                        batchCurrentIndex = uiState.batchCurrentIndex,
                        batchTotalCount = uiState.batchTotalCount,
                        batchOverallPercent = uiState.batchOverallPercent,
                        batchItemPercent = uiState.batchItemPercent,
                        onStartBatchTrim = { viewModel.startBatchTrim() },
                        onCancelBatchTrim = { viewModel.cancelBatchTrim() },
                        hasSelectedVideo = uiState.localVideoFile != null
                    )
                }

                // 5. Hasil Batch Trimming (Daftar File Keluaran)
                if (uiState.batchTrimmedFiles.isNotEmpty()) {
                    item {
                        BatchTrimResultsCard(
                            files = uiState.batchTrimmedFiles,
                            onPlaySegment = { previewTargetFile = it },
                            onShareSegment = { shareVideoFile(context, it) }
                        )
                    }
                }

                // 6. Pemotongan Tunggal: Visual Range Slider
                item {
                    TrimRangeControlsCard(
                        totalDurationSec = uiState.selectedVideo?.durationSeconds ?: 15.0,
                        startSec = uiState.trimStartSeconds,
                        endSec = uiState.trimEndSeconds,
                        isTrimming = uiState.isTrimming || uiState.isBatchTrimming,
                        onRangeChange = { start, end -> viewModel.updateTrimRange(start, end) }
                    )
                }
            }

            // 7. Execution Card tergantung Mode yang dipilih
            if (uiState.engineMode == EngineMode.TERMUX) {
                item {
                    TermuxExecutionCard(
                        isInstalled = uiState.isTermuxInstalled,
                        command = uiState.generatedTermuxCommand,
                        onExecuteIntent = { viewModel.executeTermuxCommand(runInBackground = false) },
                        onCopyCommand = { viewModel.copyTermuxCommand() },
                        onLaunchTermux = { viewModel.launchTermux() },
                        onOpenDownload = { viewModel.openTermuxDownload() }
                    )
                }
            } else {
                // Card Real-time Progress Bar & Percentage (Mode Biner Internal - Single Trim)
                item {
                    RealtimeProgressCard(
                        isTrimming = uiState.isTrimming,
                        progressPercent = uiState.progressPercent,
                        currentTimeSec = uiState.currentTimeSeconds,
                        targetDurationSec = uiState.targetDurationSeconds,
                        statusText = uiState.statusMessage,
                        onStartTrim = {
                            previewTargetFile = null
                            viewModel.startTrim()
                        },
                        onCancelTrim = { viewModel.cancelTrim() },
                        hasSelectedVideo = uiState.localVideoFile != null && !uiState.isBatchTrimming
                    )
                }
            }

            // Feedback Message Banner untuk Termux (jika ada)
            if (uiState.termuxFeedbackMessage != null) {
                item {
                    TermuxFeedbackBanner(
                        message = uiState.termuxFeedbackMessage!!,
                        onDismiss = { viewModel.dismissTermuxFeedback() }
                    )
                }
            }

            // 8. Success Result Card (Single Trim)
            if (uiState.trimmedOutputFile != null && !uiState.isBatchTrimming) {
                item {
                    TrimSuccessResultCard(
                        outputFile = uiState.trimmedOutputFile!!,
                        elapsedTimeMs = uiState.trimElapsedTimeMs,
                        onShare = { shareVideoFile(context, uiState.trimmedOutputFile!!) }
                    )
                }
            }

            // 9. Error Banner jika ada kegagalan
            if (uiState.errorMessage != null) {
                item {
                    ErrorNotificationCard(
                        errorMessage = uiState.errorMessage!!,
                        onDismiss = { viewModel.clearError() }
                    )
                }
            }

            // Bottom Spacing for safe area
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Spacer(modifier = Modifier.padding(WindowInsets.navigationBars.asPaddingValues()))
            }
        }
    }

    // Modal Sheet untuk Log Diagnostik FFmpeg
    if (showLogsDialog) {
        FfmpegLogsBottomSheet(
            logs = uiState.recentLogs,
            binaryPath = uiState.binaryPath,
            onClose = { showLogsDialog = false }
        )
    }
}

/**
 * Top Bar Header dengan judul aplikasi dan indikator status biner.
 */
@Composable
private fun TopHeaderBar(
    isBinaryReady: Boolean,
    onShowLogs: () -> Unit,
    onReloadSample: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCut,
                    contentDescription = "Logo",
                    tint = StudioCyan,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "FFmpeg Video Trimmer",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = LightTextPrimary
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(if (isBinaryReady) SuccessGreen else Color(0xFFFFB300))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isBinaryReady) "Biner FFmpeg Aktif" else "Mode Kompatibilitas",
                        style = MaterialTheme.typography.labelSmall,
                        color = LightTextSecondary
                    )
                }
            }
        }

        Row {
            IconButton(
                onClick = onReloadSample,
                modifier = Modifier.testTag("reload_sample_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Muat Ulang Sampel",
                    tint = LightTextSecondary
                )
            }
            IconButton(
                onClick = onShowLogs,
                modifier = Modifier.testTag("open_logs_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Terminal,
                    contentDescription = "Lihat Log FFmpeg",
                    tint = StudioCyan
                )
            }
        }
    }
}

/**
 * Kontrol tersegmentasi untuk memilih antara mode Biner Internal vs Opsi Termux.
 */
@Composable
private fun EngineModeSegmentedControl(
    currentMode: EngineMode,
    onModeSelect: (EngineMode) -> Unit,
    isTermuxInstalled: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(DarkSurfaceVariant)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        val isEmbedded = currentMode == EngineMode.EMBEDDED
        Box(
            modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(9.dp))
                .background(if (isEmbedded) StudioViolet else Color.Transparent)
                .clickable { onModeSelect(EngineMode.EMBEDDED) }
                .padding(vertical = 8.dp)
                .testTag("mode_embedded_tab"),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.ContentCut,
                    contentDescription = null,
                    tint = if (isEmbedded) Color.White else LightTextSecondary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Biner Internal",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = if (isEmbedded) FontWeight.Bold else FontWeight.Normal,
                    color = if (isEmbedded) Color.White else LightTextSecondary
                )
            }
        }

        val isTermux = currentMode == EngineMode.TERMUX
        Box(
            modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(9.dp))
                .background(if (isTermux) StudioCyan else Color.Transparent)
                .clickable { onModeSelect(EngineMode.TERMUX) }
                .padding(vertical = 8.dp)
                .testTag("mode_termux_tab"),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Terminal,
                    contentDescription = null,
                    tint = if (isTermux) Color.Black else LightTextSecondary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Opsi Termux",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = if (isTermux) FontWeight.Bold else FontWeight.Normal,
                    color = if (isTermux) Color.Black else LightTextSecondary
                )
                if (isTermuxInstalled) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(if (isTermux) Color.Black else SuccessGreen)
                    )
                }
            }
        }
    }
}

/**
 * Player video preview yang dapat memutar video sumber maupun hasil potongan.
 */
@Composable
private fun VideoPreviewCard(
    videoFile: File?,
    trimmedFile: File?,
    trimStartSec: Double,
    trimEndSec: Double
) {
    val activeFile = trimmedFile ?: videoFile
    var isPlaying by remember { mutableStateOf(false) }
    var videoViewRef by remember { mutableStateOf<VideoView?>(null) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, DarkBorder, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                if (activeFile != null && activeFile.exists()) {
                    AndroidView(
                        factory = { ctx ->
                            VideoView(ctx).apply {
                                setVideoPath(activeFile.absolutePath)
                                setOnPreparedListener { mp ->
                                    mp.isLooping = true
                                    seekTo((trimStartSec * 1000).toInt())
                                }
                                setOnErrorListener { _, _, _ -> true }
                                videoViewRef = this
                            }
                        },
                        update = { view ->
                            view.setVideoPath(activeFile.absolutePath)
                            view.seekTo((trimStartSec * 1000).toInt())
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    if (!isPlaying) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.65f))
                                .clickable {
                                    videoViewRef?.let { vv ->
                                        vv.seekTo((trimStartSec * 1000).toInt())
                                        vv.start()
                                        isPlaying = true
                                    }
                                }
                                .testTag("preview_play_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Putar Preview",
                                tint = StudioCyan,
                                modifier = Modifier.size(34.dp)
                            )
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clickable {
                                    videoViewRef?.pause()
                                    isPlaying = false
                                }
                        )
                    }
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Movie,
                            contentDescription = null,
                            tint = LightTextMuted,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Pilih video untuk mulai memotong",
                            style = MaterialTheme.typography.bodyMedium,
                            color = LightTextSecondary
                        )
                    }
                }

                if (trimmedFile != null) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(10.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(SuccessGreen.copy(alpha = 0.9f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "Pratinjau Hasil Potongan",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.Black,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = activeFile?.name ?: "Tidak ada file aktif",
                    style = MaterialTheme.typography.bodySmall,
                    color = LightTextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                if (activeFile != null) {
                    Text(
                        text = "${activeFile.length() / 1024} KB",
                        style = MaterialTheme.typography.labelSmall,
                        color = StudioCyan,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

/**
 * Bar pemilih video dari galeri lokal atau video sampel bawaan.
 */
@Composable
private fun VideoSelectionBar(
    selectedTitle: String,
    durationText: String,
    onPickFromGallery: () -> Unit,
    onUseSample: () -> Unit,
    isTrimming: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Button(
            onClick = onPickFromGallery,
            enabled = !isTrimming,
            modifier = Modifier
                .weight(1f)
                .height(48.dp)
                .testTag("select_video_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = DarkSurfaceVariant,
                contentColor = LightTextPrimary
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Pilih Galeri", maxLines = 1)
        }

        OutlinedButton(
            onClick = onUseSample,
            enabled = !isTrimming,
            modifier = Modifier
                .height(48.dp)
                .testTag("sample_video_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = StudioCyan)
        ) {
            Icon(Icons.Default.Movie, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Sampel")
        }
    }
}

// =============================================================================
// KOMPONEN BARU: MULTI-TEXT TIME COMMAND BATCH TRIMMING
// =============================================================================

/**
 * Card fitur Multi-Text Time Command Batch Trimming.
 * Menyediakan OutlinedTextField multi-baris untuk mengetikkan beberapa rentang pemotongan sekaligus
 * dan tombol eksekusi batch berurutan (maksimal 5 video teratas).
 */
@Composable
private fun BatchTextTrimCard(
    textCommand: String,
    onTextChanged: (String) -> Unit,
    parsedRanges: List<TrimTimeRange>,
    isBatchTrimming: Boolean,
    isSingleTrimming: Boolean,
    batchCurrentIndex: Int,
    batchTotalCount: Int,
    batchOverallPercent: Int,
    batchItemPercent: Int,
    onStartBatchTrim: () -> Unit,
    onCancelBatchTrim: () -> Unit,
    hasSelectedVideo: Boolean
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isBatchTrimming) StudioCyan else DarkBorder,
                RoundedCornerShape(16.dp)
            )
            .animateContentSize(),
        colors = CardDefaults.cardColors(
            containerColor = if (isBatchTrimming) DarkSurfaceVariant else DarkSurface
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Batch Card
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Layers,
                        contentDescription = null,
                        tint = StudioCyan,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Multi-Text Command Batch Trim",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = LightTextPrimary
                        )
                        Text(
                            text = "Potong beberapa rentang sekaligus",
                            style = MaterialTheme.typography.labelSmall,
                            color = LightTextSecondary
                        )
                    }
                }

                // Badge batas maksimal 5 video teratas
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(StudioCyan.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "Maks. 5 Teratas",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = StudioCyan
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Petunjuk Format
            Text(
                text = "Ketik rentang waktu per baris (contoh: 00:00-00:10 atau detik 5-15):",
                style = MaterialTheme.typography.labelSmall,
                color = LightTextSecondary
            )

            Spacer(modifier = Modifier.height(6.dp))

            // OutlinedTextField Multi-Baris
            OutlinedTextField(
                value = textCommand,
                onValueChange = onTextChanged,
                enabled = !isBatchTrimming && !isSingleTrimming,
                placeholder = {
                    Text(
                        text = "00:00-00:05\n00:05-00:10\n10-15",
                        color = LightTextMuted,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("batch_time_commands_input"),
                minLines = 3,
                maxLines = 6,
                textStyle = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    color = LightTextPrimary,
                    fontSize = 13.sp,
                    lineHeight = 20.sp
                ),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = StudioCyan,
                    unfocusedBorderColor = DarkBorder,
                    focusedContainerColor = Color(0xFF0C0E14),
                    unfocusedContainerColor = Color(0xFF0C0E14)
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Tombol Preset Cepat
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PresetChip(
                    text = "Preset 3 Segmen",
                    onClick = { onTextChanged("00:00-00:04\n00:04-00:08\n8-12") },
                    enabled = !isBatchTrimming
                )
                PresetChip(
                    text = "Preset Detik (5-10)",
                    onClick = { onTextChanged("0-5\n5-10\n10-15") },
                    enabled = !isBatchTrimming
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Pratinjau Rentang Waktu yang Terdeteksi
            if (parsedRanges.isNotEmpty()) {
                Text(
                    text = "Dikenali (${parsedRanges.size} rentang):",
                    style = MaterialTheme.typography.labelSmall,
                    color = LightTextSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkSurfaceVariant.copy(alpha = 0.6f))
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    parsedRanges.forEachIndexed { index, range ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Segmen #${index + 1}: ${range.formattedDisplay}",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = StudioCyan
                            )
                            Text(
                                text = "Durasi: ${MediaUtils.formatSeconds(range.durationSeconds, true)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = LightTextSecondary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Status Saat Batch Sedang Berjalan vs Tombol Eksekusi
            if (isBatchTrimming) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = StudioCyan,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Memotong Segmen $batchCurrentIndex dari $batchTotalCount...",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = LightTextPrimary
                            )
                        }

                        Text(
                            text = "$batchOverallPercent%",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = StudioCyan,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.testTag("batch_overall_percent_text")
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Progres Keseluruhan Batch
                    Text(
                        text = "Progres Keseluruhan:",
                        style = MaterialTheme.typography.labelSmall,
                        color = LightTextSecondary,
                        modifier = Modifier.align(Alignment.Start)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { batchOverallPercent / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .testTag("batch_overall_progress_bar"),
                        color = StudioCyan,
                        trackColor = DarkBorder
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Progres Item Saat Ini
                    Text(
                        text = "Progres Segmen #$batchCurrentIndex: $batchItemPercent%",
                        style = MaterialTheme.typography.labelSmall,
                        color = LightTextMuted,
                        modifier = Modifier.align(Alignment.Start)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { batchItemPercent / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(5.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = StudioViolet,
                        trackColor = DarkBorder
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedButton(
                        onClick = onCancelBatchTrim,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("cancel_batch_trim_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF5252))
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Batalkan Batch Trimming")
                    }
                }
            } else {
                // Tombol Eksekusi Batch Khusus
                Button(
                    onClick = onStartBatchTrim,
                    enabled = hasSelectedVideo && parsedRanges.isNotEmpty() && !isSingleTrimming,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("start_batch_trim_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StudioCyan,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Layers,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "JALANKAN BATCH TRIM (${parsedRanges.size} SEGMEN)",
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }
    }
}

/**
 * Chip pembantu untuk mengisi preset teks cepat.
 */
@Composable
private fun PresetChip(
    text: String,
    onClick: () -> Unit,
    enabled: Boolean
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(DarkSurfaceVariant)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = if (enabled) StudioCyan else LightTextMuted,
            fontWeight = FontWeight.Medium
        )
    }
}

/**
 * Card yang menampilkan daftar file video hasil Batch Trimming.
 */
@Composable
private fun BatchTrimResultsCard(
    files: List<File>,
    onPlaySegment: (File) -> Unit,
    onShareSegment: (File) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SuccessGreen.copy(alpha = 0.4f), RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = SuccessGreen.copy(alpha = 0.08f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = SuccessGreen,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Daftar Hasil Batch Trim (${files.size} Video Selesai)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = SuccessGreen
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            files.firstOrNull()?.parentFile?.let { dir ->
                Text(
                    text = "Direktori: ${dir.absolutePath}",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = LightTextSecondary,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
            }

            val context = LocalContext.current
            val coroutineScope = rememberCoroutineScope()

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                files.forEachIndexed { index, file ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(DarkSurface)
                            .border(1.dp, DarkBorder, RoundedCornerShape(10.dp))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Segmen #${index + 1}: ${file.name}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = LightTextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${file.length() / 1024} KB • ${file.name}",
                                style = MaterialTheme.typography.labelSmall,
                                color = StudioCyan
                            )
                        }

                        Row {
                            IconButton(
                                onClick = { onPlaySegment(file) },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Putar Segmen",
                                    tint = StudioCyan
                                )
                            }
                            IconButton(
                                onClick = {
                                    coroutineScope.launch {
                                        val res = MediaUtils.saveVideoToPublicGallery(context, file)
                                        if (res.isSuccess) {
                                            Toast.makeText(context, "${file.name} disimpan ke Galeri HP (Movies/VideoTrimmer)", Toast.LENGTH_SHORT).show()
                                        } else {
                                            Toast.makeText(context, "Gagal: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Download,
                                    contentDescription = "Simpan ke Galeri",
                                    tint = StudioCyan
                                )
                            }
                            IconButton(
                                onClick = { onShareSegment(file) },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = "Bagikan Segmen",
                                    tint = SuccessGreen
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Kontrol visual pemilihan rentang waktu awal dan akhir potongan (dual-thumb slider).
 */
@Composable
private fun TrimRangeControlsCard(
    totalDurationSec: Double,
    startSec: Double,
    endSec: Double,
    isTrimming: Boolean,
    onRangeChange: (start: Double, end: Double) -> Unit
) {
    val durationTarget = (endSec - startSec).coerceAtLeast(0.0)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, DarkBorder, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Pemotongan Tunggal (Visual Slider)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = LightTextPrimary
                )
                Text(
                    text = "Durasi: ${MediaUtils.formatSeconds(durationTarget, true)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = StudioCyan,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            RangeSlider(
                value = startSec.toFloat()..endSec.toFloat(),
                onValueChange = { range ->
                    onRangeChange(range.start.toDouble(), range.endInclusive.toDouble())
                },
                valueRange = 0f..totalDurationSec.toFloat().coerceAtLeast(1f),
                enabled = !isTrimming,
                colors = SliderDefaults.colors(
                    thumbColor = StudioCyan,
                    activeTrackColor = StudioCyan,
                    inactiveTrackColor = DarkBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("trim_range_slider")
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TimecodeBadge(
                    label = "Awal (Start)",
                    timeText = MediaUtils.formatSeconds(startSec, true),
                    onStepBack = { onRangeChange((startSec - 0.5).coerceAtLeast(0.0), endSec) },
                    onStepForward = { onRangeChange((startSec + 0.5).coerceAtMost(endSec - 0.2), endSec) },
                    enabled = !isTrimming
                )

                TimecodeBadge(
                    label = "Akhir (End)",
                    timeText = MediaUtils.formatSeconds(endSec, true),
                    onStepBack = { onRangeChange(startSec, (endSec - 0.5).coerceAtLeast(startSec + 0.2)) },
                    onStepForward = { onRangeChange(startSec, (endSec + 0.5).coerceAtMost(totalDurationSec)) },
                    enabled = !isTrimming
                )
            }
        }
    }
}

/**
 * Badge pembacaan waktu dengan tombol penyesuaian presisi ±0.5 detik.
 */
@Composable
private fun TimecodeBadge(
    label: String,
    timeText: String,
    onStepBack: () -> Unit,
    onStepForward: () -> Unit,
    enabled: Boolean
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = LightTextSecondary)
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(DarkSurfaceVariant)
                .padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
            Text(
                text = "-",
                modifier = Modifier
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .clickable(enabled = enabled, onClick = onStepBack),
                color = StudioCyan,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = timeText,
                style = MaterialTheme.typography.bodyMedium,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = LightTextPrimary,
                modifier = Modifier.padding(horizontal = 6.dp)
            )
            Text(
                text = "+",
                modifier = Modifier
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .clickable(enabled = enabled, onClick = onStepForward),
                color = StudioCyan,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/**
 * Switch pilihan Stream Copy (-c copy) vs Re-encode.
 */
@Composable
private fun StreamCopyOptionCard(
    useFastCopy: Boolean,
    isTrimming: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, DarkBorder, RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Mode Fast Stream Copy (-c copy)",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = LightTextPrimary
                )
                Text(
                    text = if (useFastCopy) "Pemrosesan secepat kilat tanpa re-encoding (kualitas 100% utuh)"
                    else "Re-encode penuh (frame-accurate H.264/AAC)",
                    style = MaterialTheme.typography.labelSmall,
                    color = LightTextSecondary
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Switch(
                checked = useFastCopy,
                onCheckedChange = onToggle,
                enabled = !isTrimming,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = StudioCyan,
                    checkedTrackColor = StudioCyan.copy(alpha = 0.35f)
                ),
                modifier = Modifier.testTag("toggle_stream_copy")
            )
        }
    }
}

/**
 * Card Opsi Termux: Menampilkan status instalasi Termux, perintah FFmpeg yang siap dieksekusi,
 * dan tombol eksekusi via RUN_COMMAND / salin ke clipboard / buka Termux.
 */
@Composable
private fun TermuxExecutionCard(
    isInstalled: Boolean,
    command: String,
    onExecuteIntent: () -> Unit,
    onCopyCommand: () -> Unit,
    onLaunchTermux: () -> Unit,
    onOpenDownload: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, StudioCyan.copy(alpha = 0.4f), RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = null,
                        tint = StudioCyan,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Integrasi Termux CLI",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = LightTextPrimary
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            if (isInstalled) SuccessGreen.copy(alpha = 0.2f)
                            else Color(0xFFFFB300).copy(alpha = 0.2f)
                        )
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (isInstalled) "Termux Terdeteksi" else "Belum Terpasang",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isInstalled) SuccessGreen else Color(0xFFFFB300)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Perintah FFmpeg yang Dihasilkan:",
                style = MaterialTheme.typography.labelSmall,
                color = LightTextSecondary
            )
            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0C0E14))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Text(
                    text = command.ifEmpty { "Pilih video untuk membuat perintah..." },
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    color = StudioCyan,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onCopyCommand,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("copy_termux_command_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = StudioCyan)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Salin", maxLines = 1)
                }

                if (isInstalled) {
                    OutlinedButton(
                        onClick = onLaunchTermux,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("open_termux_app_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = LightTextPrimary)
                    ) {
                        Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Buka Termux", maxLines = 1)
                    }
                } else {
                    OutlinedButton(
                        onClick = onOpenDownload,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("download_termux_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFFB300))
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Unduh F-Droid", maxLines = 1)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = onExecuteIntent,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("execute_termux_intent_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = StudioCyan,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Jalankan via Termux RUN_COMMAND",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkSurfaceVariant.copy(alpha = 0.5f))
                    .padding(8.dp),
                verticalAlignment = Alignment.Top
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = LightTextMuted,
                    modifier = Modifier.size(16.dp).padding(top = 2.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Catatan: Untuk eksekusi langsung via Intent, tambahkan baris 'allow-external-apps = true' di file ~/.termux/termux.properties.",
                    style = MaterialTheme.typography.labelSmall,
                    color = LightTextMuted,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        }
    }
}

/**
 * Banner notifikasi feedback Termux.
 */
@Composable
private fun TermuxFeedbackBanner(
    message: String,
    onDismiss: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, StudioCyan.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = StudioCyan.copy(alpha = 0.12f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = StudioCyan,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodySmall,
                color = LightTextPrimary,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Tutup", tint = LightTextSecondary, modifier = Modifier.size(16.dp))
            }
        }
    }
}

/**
 * Card utama yang menampilkan tombol trigger, ProgressBar, dan persentase TextView real-time (Single Trim).
 */
@Composable
private fun RealtimeProgressCard(
    isTrimming: Boolean,
    progressPercent: Int,
    currentTimeSec: Double,
    targetDurationSec: Double,
    statusText: String,
    onStartTrim: () -> Unit,
    onCancelTrim: () -> Unit,
    hasSelectedVideo: Boolean
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isTrimming) StudioCyan.copy(alpha = 0.5f) else DarkBorder,
                RoundedCornerShape(16.dp)
            )
            .animateContentSize(),
        colors = CardDefaults.cardColors(
            containerColor = if (isTrimming) DarkSurfaceVariant else DarkSurface
        )
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (isTrimming) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = StudioCyan,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Memotong dengan FFmpeg...",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = LightTextPrimary
                        )
                    }

                    Text(
                        text = "$progressPercent%",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = StudioCyan,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.testTag("progress_percent_text")
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                LinearProgressIndicator(
                    progress = { progressPercent / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .testTag("realtime_progress_bar"),
                    color = StudioCyan,
                    trackColor = DarkBorder
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Posisi: ${MediaUtils.formatSeconds(currentTimeSec, true)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = LightTextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Target: ${MediaUtils.formatSeconds(targetDurationSec, true)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = LightTextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedButton(
                    onClick = onCancelTrim,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("cancel_trim_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF5252))
                ) {
                    Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Batalkan Proses")
                }
            } else {
                Button(
                    onClick = onStartTrim,
                    enabled = hasSelectedVideo,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("start_trim_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StudioViolet,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.ContentCut, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "POTONG VIDEO SEKARANG (Slider Tunggal)",
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = statusText,
                    style = MaterialTheme.typography.labelSmall,
                    color = LightTextSecondary,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

/**
 * Card pemberitahuan hasil pemotongan tunggal berhasil.
 */
@Composable
private fun TrimSuccessResultCard(
    outputFile: File,
    elapsedTimeMs: Long,
    onShare: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SuccessGreen.copy(alpha = 0.4f), RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = SuccessGreen.copy(alpha = 0.1f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = SuccessGreen,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Video Berhasil Dipotong!",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = SuccessGreen
                    )
                    Text(
                        text = "Selesai dalam ${(elapsedTimeMs / 1000.0)} detik • Ukuran: ${outputFile.length() / 1024} KB",
                        style = MaterialTheme.typography.labelSmall,
                        color = LightTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Info Path Lokasi Penyimpanan Internal
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0C0E14))
                    .padding(10.dp)
            ) {
                Text(
                    text = "Lokasi Penyimpanan:",
                    style = MaterialTheme.typography.labelSmall,
                    color = LightTextSecondary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = outputFile.absolutePath,
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = StudioCyan
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            val context = LocalContext.current
            val coroutineScope = rememberCoroutineScope()
            var isSavedToGallery by remember { mutableStateOf(false) }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        coroutineScope.launch {
                            val res = MediaUtils.saveVideoToPublicGallery(context, outputFile)
                            if (res.isSuccess) {
                                isSavedToGallery = true
                                Toast.makeText(context, "Tersimpan di Galeri (folder Movies/VideoTrimmer)", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, "Gagal: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("save_to_gallery_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (isSavedToGallery) SuccessGreen else StudioCyan
                    )
                ) {
                    Icon(
                        imageVector = if (isSavedToGallery) Icons.Default.CheckCircle else Icons.Default.Download,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isSavedToGallery) "Tersimpan" else "Ke Galeri", maxLines = 1)
                }

                Button(
                    onClick = onShare,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("share_trimmed_video_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Bagikan", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
        }
    }
}

/**
 * Card banner notifikasi error.
 */
@Composable
private fun ErrorNotificationCard(
    errorMessage: String,
    onDismiss: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFFF5252).copy(alpha = 0.4f), RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFF5252).copy(alpha = 0.12f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Error,
                contentDescription = null,
                tint = Color(0xFFFF5252),
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = errorMessage,
                style = MaterialTheme.typography.bodySmall,
                color = LightTextPrimary,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onDismiss) {
                Icon(Icons.Default.Close, contentDescription = "Tutup", tint = LightTextSecondary)
            }
        }
    }
}

/**
 * Dialog / Bottom Sheet yang menampilkan baris output stdout / stderr FFmpeg secara real-time.
 */
@Composable
private fun FfmpegLogsBottomSheet(
    logs: List<String>,
    binaryPath: String,
    onClose: () -> Unit
) {
    val listState = rememberLazyListState()

    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.size - 1)
        }
    }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f)),
        color = DarkBackground
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Terminal, contentDescription = null, tint = StudioCyan)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Terminal Output FFmpeg",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = LightTextPrimary
                    )
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Tutup", tint = LightTextSecondary)
                }
            }

            Text(
                text = "Lokasi Biner: $binaryPath",
                style = MaterialTheme.typography.labelSmall,
                fontFamily = FontFamily.Monospace,
                color = LightTextMuted
            )

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = DarkBorder)
            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF0A0C10))
                    .padding(10.dp)
            ) {
                if (logs.isEmpty()) {
                    item {
                        Text(
                            text = "Belum ada output log dari proses FFmpeg.",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            color = LightTextMuted
                        )
                    }
                } else {
                    items(logs) { line ->
                        val isProgressLine = line.contains("time=")
                        val isErrorLine = line.contains("error", ignoreCase = true)

                        Text(
                            text = line,
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = when {
                                isProgressLine -> StudioCyan
                                isErrorLine -> Color(0xFFFF5252)
                                else -> LightTextSecondary
                            },
                            modifier = Modifier.padding(vertical = 1.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Helper untuk membagikan file video ke aplikasi lain (WhatsApp, Telegram, dll).
 */
private fun shareVideoFile(context: Context, file: File) {
    try {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Bagikan Video"))
    } catch (e: Exception) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file))
        }
        context.startActivity(Intent.createChooser(intent, "Bagikan Video"))
    }
}
