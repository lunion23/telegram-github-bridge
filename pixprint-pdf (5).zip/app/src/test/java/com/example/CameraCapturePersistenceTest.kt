package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.CapturedDocumentStorage
import com.example.data.repository.LabelHistoryRepository
import com.example.model.PdfRenderSource
import com.example.pdf.BarcodeVectorHelper
import com.example.pdf.CameraLabelExtractor
import com.example.viewmodel.ShippingLabelViewModel
import java.io.File
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.shadows.ShadowLooper

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class CameraCapturePersistenceTest {

    private lateinit var context: Context
    private lateinit var database: AppDatabase
    private lateinit var repository: LabelHistoryRepository

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = LabelHistoryRepository(database.labelHistoryDao())
    }

    @After
    fun tearDown() {
        database.close()
    }

    private suspend fun awaitMainAndBackgroundTasks(
        maxIterations: Int = 40,
        condition: suspend () -> Boolean = { false }
    ) {
        for (i in 0 until maxIterations) {
            ShadowLooper.idleMainLooper()
            if (condition()) break
            delay(25)
            ShadowLooper.idleMainLooper()
        }
    }

    @Test
    fun `parseFromTextAndBarcode extracts courier label fields and never reuses old sample data`() {
        val sampleOcr = """
            EZ | COD
            205-JKT09-02
            No. Resi: JP9988776655
            Kota Tujuan: SURABAYA TIMUR
            Penerima: Siti Rahmawati 081299887766
            Jl. Raya Darmo Permai No. 88, Kec. Sukomanunggal, Surabaya
            Pengirim: Toko Berkah Jaya 085711223344
            BANDUNG, Coblong
            IDR 28,500
            COD
            1.25 KG
            02-11-2026
            Order: ORD-20261102-991
            Qty: 2 PCS
            Barang: Perlengkapan Elektronik Rumah
            Catatan: Jangan dibanting
        """.trimIndent()

        val extracted = CameraLabelExtractor.parseFromTextAndBarcode(
            rawText = sampleOcr,
            detectedBarcode = "JP9988776655",
            timestampMillis = 1762070400000L
        )
        val data = extracted.labelData

        assertEquals("JP9988776655", data.waybillNumber)
        assertEquals("205-JKT09-02", data.routingCode)
        assertEquals("Siti Rahmawati", data.recipientName)
        assertEquals("081299887766", data.recipientPhone)
        assertTrue(data.recipientAddress.contains("Darmo Permai"))
        assertEquals("Toko Berkah Jaya", data.senderName)
        assertEquals("IDR 28,500", data.shippingFeeAmount)
        assertEquals("COD", data.paymentMethod)
        assertEquals("1.25 KG", data.weight)
        assertEquals("2 PCS", data.quantityText)

        // Guarantee zero leakage from static sample data
        assertNotEquals("Muhamad Arif", data.recipientName)
        assertNotEquals("JD0600216038", data.waybillNumber)
        assertNotEquals("PT MCDERMOTT", data.destinationBanner)
        assertNotEquals("Adinda", data.senderName)
    }

    @Test
    fun `parseFromTextAndBarcode with blank OCR creates clean camera document without old data`() {
        val extracted = CameraLabelExtractor.parseFromTextAndBarcode(
            rawText = "",
            detectedBarcode = null,
            timestampMillis = 1762070400000L
        )
        val data = extracted.labelData

        assertTrue(data.waybillNumber.startsWith("SCAN-"))
        assertTrue(data.recipientName.startsWith("Dokumen Kamera"))
        assertEquals("", data.routingCode)
        assertEquals("", data.destinationBanner)
        assertEquals("", data.senderName)
        assertEquals("", data.shippingFeeAmount)
        assertFalse(data.recipientName.contains("Muhamad Arif"))
        assertFalse(data.waybillNumber.contains("JD0600216038"))
    }

    @Test
    fun `decodeBarcodeFromBitmap decodes Code 128 barcode at top of tall shipping label bitmap`() {
        val bmp = Bitmap.createBitmap(500, 900, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.WHITE)
        BarcodeVectorHelper.drawCode128(
            canvas = canvas,
            content = "JD8877665544",
            left = 40f,
            top = 60f,
            right = 460f,
            bottom = 180f
        )

        val decoded = CameraLabelExtractor.decodeBarcodeFromBitmap(bmp)
        assertEquals("JD8877665544", decoded)
    }

    @Test
    fun `onDocumentCaptured replaces old data, saves photo to disk, persists to Room history, and reloads`() = runBlocking {
        val capturedBmp = Bitmap.createBitmap(500, 800, Bitmap.Config.ARGB_8888).also { bmp ->
            val canvas = Canvas(bmp)
            canvas.drawColor(Color.WHITE)
            BarcodeVectorHelper.drawCode128(
                canvas = canvas,
                content = "JX5544332211",
                left = 30f,
                top = 50f,
                right = 470f,
                bottom = 170f
            )
        }

        val viewModel = ShippingLabelViewModel(
            repository = repository,
            cameraLabelExtractor = { bmp ->
                val barcode = CameraLabelExtractor.decodeBarcodeFromBitmap(bmp)
                CameraLabelExtractor.parseFromTextAndBarcode(
                    rawText = "Penerima: Rina Kusuma 081355667788\nJl. Merdeka No. 12 Bandung\nPengirim: Gudang Utama\nIDR 19,000\nTUNAI\n0.8 KG",
                    detectedBarcode = barcode
                )
            }
        )
        ShadowLooper.idleMainLooper()

        // Initially defaults to reference sample
        assertEquals("Muhamad Arif", viewModel.uiState.value.labelData.recipientName)

        // Capture document via camera
        viewModel.onDocumentCaptured(context = context, bitmap = capturedBmp)

        // Pump Robolectric main looper while async IO + Room save completes
        awaitMainAndBackgroundTasks {
            !viewModel.uiState.value.isSavingHistory && viewModel.uiState.value.activeHistoryItem != null
        }

        val stateAfterCapture = viewModel.uiState.value
        assertEquals("JX5544332211", stateAfterCapture.labelData.waybillNumber)
        assertEquals("Rina Kusuma", stateAfterCapture.labelData.recipientName)
        assertEquals("IDR 19,000", stateAfterCapture.labelData.shippingFeeAmount)
        assertEquals(PdfRenderSource.CAPTURED_DOCUMENT, stateAfterCapture.renderSource)
        assertNotNull("Active history item must be set after camera capture", stateAfterCapture.activeHistoryItem)
        assertTrue("Captured image path must be stored", stateAfterCapture.capturedImagePath.isNotBlank())
        assertTrue("Captured JPEG file must exist on disk", File(stateAfterCapture.capturedImagePath).exists())

        // Verify Room repository contains the saved camera record
        val allSaved = repository.getAllHistory()
        assertEquals(1, allSaved.size)
        val savedRecord = allSaved.first()
        assertEquals("JX5544332211", savedRecord.waybillNumber)
        assertEquals("Rina Kusuma", savedRecord.recipientName)
        assertEquals(PdfRenderSource.CAPTURED_DOCUMENT.name, savedRecord.renderSourceName)
        assertEquals(stateAfterCapture.capturedImagePath, savedRecord.capturedImagePath)

        // Edit recipient name and close editor -> verify auto-persisted to Room
        viewModel.setEditorOpen(true)
        viewModel.updateLabelData { it.copy(recipientName = "Rina Kusuma Wijaya") }
        viewModel.setEditorOpen(false)
        awaitMainAndBackgroundTasks {
            repository.getAllHistory().firstOrNull()?.recipientName == "Rina Kusuma Wijaya"
        }

        val updatedRecord = repository.getHistoryItem(savedRecord.id)
        assertNotNull(updatedRecord)
        assertEquals("Rina Kusuma Wijaya", updatedRecord!!.recipientName)
        assertEquals(stateAfterCapture.capturedImagePath, updatedRecord.capturedImagePath)

        // Reset to sample data -> verify state resets, then reload camera item from history!
        viewModel.resetToSampleData(context)
        ShadowLooper.idleMainLooper()
        assertEquals("Muhamad Arif", viewModel.uiState.value.labelData.recipientName)

        viewModel.loadHistoryItem(context, updatedRecord)
        awaitMainAndBackgroundTasks {
            viewModel.uiState.value.capturedDocumentBitmap != null &&
                viewModel.uiState.value.labelData.waybillNumber == "JX5544332211"
        }

        val reloadedState = viewModel.uiState.value
        assertEquals("JX5544332211", reloadedState.labelData.waybillNumber)
        assertEquals("Rina Kusuma Wijaya", reloadedState.labelData.recipientName)
        assertEquals(PdfRenderSource.CAPTURED_DOCUMENT, reloadedState.renderSource)
        assertNotNull("Captured camera bitmap must reload from disk", reloadedState.capturedDocumentBitmap)

        // Clean up stored test file
        CapturedDocumentStorage.deleteCapturedFileBlocking(updatedRecord.capturedImagePath)
    }
}
