package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Accents
val CyanPrimaryLight = Color(0xFF007E8A)
val CyanOnPrimaryLight = Color(0xFFFFFFFF)
val CyanPrimaryContainerLight = Color(0xFFBCEEF5)
val CyanOnPrimaryContainerLight = Color(0xFF002024)

val CyanPrimaryDark = Color(0xFF4DD0E1)
val CyanOnPrimaryDark = Color(0xFF00363D)
val CyanPrimaryContainerDark = Color(0xFF004F58)
val CyanOnPrimaryContainerDark = Color(0xFFBCEEF5)

// Secondary & Tertiary
val TealSecondaryLight = Color(0xFF4A6267)
val TealSecondaryDark = Color(0xFFB1CBD0)
val AmberTertiaryLight = Color(0xFF8B5000)
val AmberTertiaryDark = Color(0xFFFFB870)

// Surfaces & Backgrounds
val SurfaceLight = Color(0xFFF7FAFC)
val SurfaceContainerLight = Color(0xFFFFFFFF)
val SurfaceContainerHighLight = Color(0xFFEEF2F6)
val OnSurfaceLight = Color(0xFF191C1E)
val OutlineLight = Color(0xFF70787D)

val SurfaceDark = Color(0xFF0E1624)
val SurfaceContainerDark = Color(0xFF152238)
val SurfaceContainerHighDark = Color(0xFF1E2D47)
val OnSurfaceDark = Color(0xFFE1E3E5)
val OutlineDark = Color(0xFF8A9297)

// Code Syntax Tokens
val CodeKeyword = Color(0xFFC678DD)
val CodeString = Color(0xFF98C379)
val CodeComment = Color(0xFF5C6370)
val CodeFunction = Color(0xFF61AFEF)
val CodeNumber = Color(0xFFD19A66)
val CodeBackground = Color(0xFF1A2332)
