package com.example.ui.components

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.DataObject
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.LibraryAdd
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SheetState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.export.BulkExportFormat
import com.example.export.BulkImportResult
import com.example.export.BulkTransferManager
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupRestoreBottomSheet(
    totalNoteCount: Int,
    sheetState: SheetState,
    onExportAllToUri: suspend (Uri, BulkExportFormat) -> Result<Int>,
    onImportBackupFromUri: suspend (Uri) -> Result<BulkImportResult>,
    onImportMultipleFiles: suspend (List<Uri>) -> Result<BulkImportResult>,
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isProcessing by remember { mutableStateOf(false) }

    val exportJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(BulkTransferManager.getMimeType(BulkExportFormat.JSON_BACKUP))
    ) { uri: Uri? ->
        if (uri != null) {
            isProcessing = true
            scope.launch {
                val res = onExportAllToUri(uri, BulkExportFormat.JSON_BACKUP)
                isProcessing = false
                res.onSuccess { count ->
                    Toast.makeText(context, "Berhasil mengekspor $count catatan ke JSON", Toast.LENGTH_LONG).show()
                    onDismissRequest()
                }.onFailure { err ->
                    Toast.makeText(context, err.message ?: "Gagal mengekspor backup JSON", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    val exportZipLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(BulkTransferManager.getMimeType(BulkExportFormat.ZIP_ARCHIVE))
    ) { uri: Uri? ->
        if (uri != null) {
            isProcessing = true
            scope.launch {
                val res = onExportAllToUri(uri, BulkExportFormat.ZIP_ARCHIVE)
                isProcessing = false
                res.onSuccess { count ->
                    Toast.makeText(context, "Berhasil mengekspor $count catatan ke ZIP", Toast.LENGTH_LONG).show()
                    onDismissRequest()
                }.onFailure { err ->
                    Toast.makeText(context, err.message ?: "Gagal mengekspor arsip ZIP", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    val importBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            isProcessing = true
            scope.launch {
                val res = onImportBackupFromUri(uri)
                isProcessing = false
                res.onSuccess { imported ->
                    val extra = if (imported.skippedCount > 0) " (${imported.skippedCount} dilewati)" else ""
                    Toast.makeText(
                        context,
                        "Berhasil mengimpor ${imported.notes.size} catatan$extra",
                        Toast.LENGTH_LONG
                    ).show()
                    onDismissRequest()
                }.onFailure { err ->
                    Toast.makeText(context, err.message ?: "Gagal mengimpor catatan", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    val importMultipleFilesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            isProcessing = true
            scope.launch {
                val res = onImportMultipleFiles(uris)
                isProcessing = false
                res.onSuccess { imported ->
                    val extra = if (imported.skippedCount > 0) " (${imported.skippedCount} dilewati)" else ""
                    Toast.makeText(
                        context,
                        "Berhasil mengimpor ${imported.notes.size} catatan$extra",
                        Toast.LENGTH_LONG
                    ).show()
                    onDismissRequest()
                }.onFailure { err ->
                    Toast.makeText(context, err.message ?: "Gagal mengimpor file", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    ModalBottomSheet(
        onDismissRequest = { if (!isProcessing) onDismissRequest() },
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 32.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = stringResource(R.string.bulk_transfer_title),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = "$totalNoteCount catatan",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Text(
                text = "Cadangkan seluruh catatan Anda ke penyimpanan perangkat atau pulihkan catatan dari file lokal.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp, bottom = 16.dp)
            )

            if (isProcessing) {
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                )
            }

            // Export Section
            Text(
                text = "Ekspor Seluruh Catatan",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    exportJsonLauncher.launch(
                        BulkTransferManager.getDefaultExportFileName(BulkExportFormat.JSON_BACKUP)
                    )
                },
                enabled = !isProcessing && totalNoteCount > 0,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_export_all_json")
            ) {
                Icon(Icons.Default.DataObject, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(stringResource(R.string.export_all_json))
            }

            Spacer(modifier = Modifier.height(8.dp))

            FilledTonalButton(
                onClick = {
                    exportZipLauncher.launch(
                        BulkTransferManager.getDefaultExportFileName(BulkExportFormat.ZIP_ARCHIVE)
                    )
                },
                enabled = !isProcessing && totalNoteCount > 0,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_export_all_zip")
            ) {
                Icon(Icons.Default.FolderZip, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(stringResource(R.string.export_all_zip))
            }

            Text(
                text = "JSON menyimpan metadata lengkap; ZIP menyimpan file individual (.txt, .py, .js, .md) beserta metadata.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp)
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 18.dp))

            // Import Section
            Text(
                text = "Impor Catatan dari Lokal",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedButton(
                onClick = {
                    importBackupLauncher.launch(
                        arrayOf("application/json", "application/zip", "application/x-zip-compressed", "*/*")
                    )
                },
                enabled = !isProcessing,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_import_backup_file")
            ) {
                Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(stringResource(R.string.import_backup_file))
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedButton(
                onClick = {
                    importMultipleFilesLauncher.launch(arrayOf("*/*"))
                },
                enabled = !isProcessing,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_import_multiple_files")
            ) {
                Icon(Icons.Default.LibraryAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(stringResource(R.string.import_multiple_files))
            }

            Text(
                text = "Semua catatan yang diimpor otomatis tersimpan di perangkat dan disinkronkan ke cloud saat login.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}
