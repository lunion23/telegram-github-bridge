package com.example.data

import android.content.Context
import com.example.R
import com.example.model.PaperSizePreset
import com.example.model.ShippingLabelData
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

/**
 * Repository managing persistent user-created shipping label records in Firestore
 * (`/users/{userId}/shipping_labels/{labelId}`).
 *
 * Strictly initializes with the provisioned named database ID (`R.string.firestore_database_id`)
 * and delegates authentication to Google Sign-In in the UI layer.
 */
class ShippingLabelRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        auth = Firebase.auth
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Pengguna harus masuk dengan Google terlebih dahulu.")
    }

    private fun userLabelsCollection(userId: String) =
        db.collection("users").document(userId).collection("shipping_labels")

    /**
     * Real-time stream of saved shipping labels for [userId], aligned with `allow list` rules
     * via `.whereEqualTo("userId", userId)`.
     */
    fun observeLabels(userId: String): Flow<List<SavedLabelRecord>> {
        val path = "users/$userId/shipping_labels"
        return userLabelsCollection(userId)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    SavedLabelRecord::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedWith(
                    compareByDescending<SavedLabelRecord> { it.pinned }
                        .thenByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
                )
            }
            .catch { error ->
                if (error is Exception) {
                    handleFirestoreError(error, OperationType.LIST, path)
                }
                throw error
            }
    }

    /**
     * One-shot query of saved shipping labels for the currently authenticated user.
     */
    suspend fun getUserLabels(): Result<List<SavedLabelRecord>> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val path = "users/$uid/shipping_labels"
        return try {
            val snapshot = userLabelsCollection(uid)
                .whereEqualTo("userId", uid)
                .get()
                .await()
            val items = snapshot.toObjects(
                SavedLabelRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ).sortedWith(
                compareByDescending<SavedLabelRecord> { it.pinned }
                    .thenByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            )
            Result.success(items)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            Result.failure(e)
        }
    }

    /**
     * Fetches a single shipping label document under `/users/{ownerUserId}/shipping_labels/{labelId}`.
     */
    suspend fun getLabelById(ownerUserId: String, labelId: String): Result<SavedLabelRecord?> {
        val docRef = userLabelsCollection(ownerUserId).document(labelId)
        return try {
            val snapshot = docRef.get().await()
            val item = snapshot.toObject(
                SavedLabelRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )
            Result.success(item)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            Result.failure(e)
        }
    }

    /**
     * Saves a new shipping label document and returns its generated Firestore document ID.
     */
    suspend fun createLabel(
        data: ShippingLabelData,
        paperPreset: PaperSizePreset,
        customTitle: String = "",
        pinned: Boolean = false
    ): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val collectionRef = userLabelsCollection(uid)
        val docRef = collectionRef.document()
        val payload = SavedLabelRecord.fromShippingLabelData(
            data = data,
            paperPreset = paperPreset,
            customTitle = customTitle,
            pinned = pinned
        ).sanitizedForRules(uid).copy(
            createdAt = null,
            updatedAt = null
        )

        return try {
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    /**
     * Updates an existing shipping label document while preserving immutable `userId` and `createdAt`.
     */
    suspend fun updateLabel(record: SavedLabelRecord): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        if (record.id.isBlank()) {
            return Result.failure(IllegalArgumentException("ID dokumen resi tidak boleh kosong."))
        }
        val existingCreatedAt = record.createdAt
            ?: return Result.failure(IllegalArgumentException("createdAt resi tidak boleh kosong saat pembaruan."))

        val docRef = userLabelsCollection(uid).document(record.id)
        val updatedPayload = record.sanitizedForRules(uid).copy(
            createdAt = existingCreatedAt,
            updatedAt = null
        )
        return try {
            docRef.set(updatedPayload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    /**
     * Toggles the `pinned` favorite flag on an existing shipping label.
     */
    suspend fun setLabelPinned(labelId: String, pinned: Boolean): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        if (labelId.isBlank()) {
            return Result.failure(IllegalArgumentException("ID dokumen resi tidak valid."))
        }
        val docRef = userLabelsCollection(uid).document(labelId)
        return try {
            docRef.update(
                mapOf(
                    "pinned" to pinned,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    /**
     * Deletes a saved shipping label document owned by the current user.
     */
    suspend fun deleteLabel(labelId: String): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        if (labelId.isBlank()) {
            return Result.failure(IllegalArgumentException("ID dokumen resi tidak valid."))
        }
        val docRef = userLabelsCollection(uid).document(labelId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }
}
