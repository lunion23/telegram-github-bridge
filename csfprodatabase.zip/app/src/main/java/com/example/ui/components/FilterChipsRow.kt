package com.example.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterAltOff
import androidx.compose.material.icons.filled.ManageSearch
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.InputChip
import androidx.compose.material3.InputChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FilterCriteria

/**
 * Filter & Sort Bar for Work Orders - Ultra-sleek & locked single-line height (34dp).
 * Ketinggian tetap stabil dan TIDAK melar/memanjang saat filter aktif:
 * - Setiap chip dibatasi maxLines = 1 dengan TextOverflow.Ellipsis
 * - Ketinggian baris terkunci pada 34dp
 */
@Composable
fun FilterChipsRow(
    filterCriteria: FilterCriteria,
    onToggleDateSort: () -> Unit,
    onOpenDualSearch: () -> Unit,
    onClearDualSearch: () -> Unit,
    onClearFilters: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(34.dp)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 1.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // 1. Date Sort Chip
        FilterChip(
            selected = filterCriteria.sortDateAscending,
            onClick = onToggleDateSort,
            label = {
                Text(
                    text = if (filterCriteria.sortDateAscending) "Tgl: Terlama (A-Z)" else "Tgl: Terbaru (Z-A)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = if (filterCriteria.sortDateAscending) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                    contentDescription = "Urut Tanggal",
                    modifier = Modifier.size(13.dp)
                )
            },
            colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
            ),
            modifier = Modifier
                .height(28.dp)
                .testTag("sort_date_chip")
        )

        // 2. Dual Keyword Search Active Chip or Quick Launcher Chip
        if (filterCriteria.isDualSearchActive) {
            val kw1Text = if (filterCriteria.dualKeyword1.isNotBlank()) {
                "\"${filterCriteria.dualKeyword1}\" (${filterCriteria.dualColumn1.shortName})"
            } else ""
            val kw2Text = if (filterCriteria.dualKeyword2.isNotBlank()) {
                "\"${filterCriteria.dualKeyword2}\" (${filterCriteria.dualColumn2.shortName})"
            } else ""
            val labelText = listOf(kw1Text, kw2Text).filter { it.isNotBlank() }.joinToString(" + ")

            InputChip(
                selected = true,
                onClick = onOpenDualSearch,
                label = {
                    Text(
                        text = "🔍 $labelText",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                trailingIcon = {
                    IconButton(
                        onClick = onClearDualSearch,
                        modifier = Modifier.size(16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Hapus Pencarian 2 Kata Kunci",
                            modifier = Modifier.size(11.dp)
                        )
                    }
                },
                colors = InputChipDefaults.inputChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                modifier = Modifier
                    .height(28.dp)
                    .widthIn(max = 240.dp)
                    .testTag("active_dual_search_chip")
            )
        } else {
            SuggestionChip(
                onClick = onOpenDualSearch,
                label = {
                    Text(
                        text = "🔍 Cari 2 Kata Kunci (Beda Kolom)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                icon = {
                    Icon(
                        imageVector = Icons.Default.ManageSearch,
                        contentDescription = "Pencarian 2 Kolom",
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                },
                modifier = Modifier
                    .height(28.dp)
                    .testTag("launch_dual_search_chip")
            )
        }

        // 3. Reset Filter Chip if any active
        if (filterCriteria.isActive) {
            InputChip(
                selected = false,
                onClick = onClearFilters,
                label = {
                    Text(
                        text = "Reset Filter",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.FilterAltOff,
                        contentDescription = "Reset Filter",
                        modifier = Modifier.size(12.dp),
                        tint = MaterialTheme.colorScheme.error
                    )
                },
                colors = InputChipDefaults.inputChipColors(
                    labelColor = MaterialTheme.colorScheme.error
                ),
                modifier = Modifier
                    .height(28.dp)
                    .testTag("reset_filters_chip")
            )
        }
    }
}
