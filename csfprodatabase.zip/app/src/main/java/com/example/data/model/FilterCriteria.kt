package com.example.data.model

data class FilterCriteria(
    val searchQuery: String = "",
    // Simultaneous 2-Keyword Search across different columns
    val dualKeyword1: String = "",
    val dualColumn1: SearchTargetColumn = SearchTargetColumn.ALL,
    val dualKeyword2: String = "",
    val dualColumn2: SearchTargetColumn = SearchTargetColumn.ALL,
    // Other criteria
    val selectedTypes: Set<String> = emptySet(),
    val selectedProductClasses: Set<String> = emptySet(),
    val startDateMillis: Long? = null,
    val endDateMillis: Long? = null,
    val specificMobil: String = "",
    val specificChassis: String = "",
    val specificKeluhan: String = "",
    val sortDateAscending: Boolean = false
) {
    /**
     * True if either of the 2 dual-keywords is active.
     */
    val isDualSearchActive: Boolean
        get() = dualKeyword1.isNotBlank() || dualKeyword2.isNotBlank()

    val isActive: Boolean
        get() = searchQuery.isNotBlank() ||
                isDualSearchActive ||
                selectedTypes.isNotEmpty() ||
                selectedProductClasses.isNotEmpty() ||
                startDateMillis != null ||
                endDateMillis != null ||
                specificMobil.isNotBlank() ||
                specificChassis.isNotBlank() ||
                specificKeluhan.isNotBlank()
}
