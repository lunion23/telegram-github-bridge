package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.ColumnVisibilityState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PreferencesManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("fleet_wo_prefs", Context.MODE_PRIVATE)

    private val _columnVisibilityState = MutableStateFlow(
        ColumnVisibilityState.fromSerialized(prefs.getString(KEY_VISIBLE_COLUMNS, null))
    )
    val columnVisibilityState: StateFlow<ColumnVisibilityState> = _columnVisibilityState.asStateFlow()

    fun saveColumnVisibility(state: ColumnVisibilityState) {
        prefs.edit().putString(KEY_VISIBLE_COLUMNS, state.serializedString()).apply()
        _columnVisibilityState.value = state
    }

    companion object {
        private const val KEY_VISIBLE_COLUMNS = "key_visible_columns_v1"
    }
}
