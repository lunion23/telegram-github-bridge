package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

object HistoryActionType {
    const val SAVED = "DISIMPAN"
    const val PRINTED = "DICETAK_PDF"
    const val DOWNLOADED = "UNDUH_PDF"
    const val SHARED = "BAGIKAN_PDF"

    val allowedValues = setOf(SAVED, PRINTED, DOWNLOADED, SHARED)
}

@Entity(tableName = "label_history")
data class LabelHistoryItem(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val badgeLeft: String = "NP",
    val badgeRight: String = "EZ",
    val routingCode: String = "",
    val waybillNumber: String = "JD0600216038",
    val destinationBanner: String = "",
    val recipientName: String = "-",
    val recipientPhone: String = "",
    val recipientAddress: String = "",
    val senderName: String = "",
    val senderPhone: String = "",
    val senderArea: String = "",
    val shippingFeeLabel: String = "BIAYA PENGIRIMAN",
    val shippingFeeAmount: String = "",
    val taxIncludedText: String = "Sudah Termasuk PPN",
    val paymentMethod: String = "",
    val weight: String = "",
    val printDate: String = "",
    val orderNumber: String = "",
    val expCode: String = "",
    val quantityText: String = "",
    val itemCategory: String = "",
    val notes: String = "",
    val companyNameAndTax: String = "PT GLOBAL JET EXPRESS, 0735697740041000",
    val companyAddressLine1: String = "LANDMARK PLUIT TOWER BLCK B1, LANTAI 8, 9A,",
    val companyAddressLine2: String = "10A JL. PLUIT SELATAN RAYA, PENJARINGAN",
    val websiteUrl: String = "www.jet.co.id",
    val stubBadgeText: String = "Lembar Pengirim",
    val paperPreset: String = PaperSizePreset.THERMAL_100X200.name,
    val actionLabel: String = HistoryActionType.SAVED,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val updatedAtMillis: Long = System.currentTimeMillis(),
    val drivePdfFileId: String = "",
    val lastSyncedAtMillis: Long = 0L
) {
    val isSyncedToDrive: Boolean
        get() = lastSyncedAtMillis > 0L && lastSyncedAtMillis >= updatedAtMillis
}

fun LabelHistoryItem.toShippingLabelData(): ShippingLabelData {
    return ShippingLabelData(
        badgeLeft = badgeLeft,
        badgeRight = badgeRight,
        routingCode = routingCode,
        waybillNumber = waybillNumber,
        destinationBanner = destinationBanner,
        recipientName = recipientName,
        recipientPhone = recipientPhone,
        recipientAddress = recipientAddress,
        senderName = senderName,
        senderPhone = senderPhone,
        senderArea = senderArea,
        shippingFeeLabel = shippingFeeLabel,
        shippingFeeAmount = shippingFeeAmount,
        taxIncludedText = taxIncludedText,
        paymentMethod = paymentMethod,
        weight = weight,
        printDate = printDate,
        orderNumber = orderNumber,
        expCode = expCode,
        quantityText = quantityText,
        itemCategory = itemCategory,
        notes = notes,
        companyNameAndTax = companyNameAndTax,
        companyAddressLine1 = companyAddressLine1,
        companyAddressLine2 = companyAddressLine2,
        websiteUrl = websiteUrl,
        stubBadgeText = stubBadgeText
    )
}

fun LabelHistoryItem.resolvedPaperPreset(): PaperSizePreset {
    return PaperSizePreset.entries.firstOrNull { it.name == paperPreset }
        ?: PaperSizePreset.THERMAL_100X200
}

fun ShippingLabelData.toHistoryItem(
    paperPreset: PaperSizePreset,
    actionLabel: String = HistoryActionType.SAVED,
    id: String = UUID.randomUUID().toString(),
    createdAtMillis: Long = System.currentTimeMillis(),
    updatedAtMillis: Long = System.currentTimeMillis(),
    drivePdfFileId: String = "",
    lastSyncedAtMillis: Long = 0L
): LabelHistoryItem {
    val normalizedAction = if (actionLabel in HistoryActionType.allowedValues) {
        actionLabel
    } else {
        HistoryActionType.SAVED
    }
    val resolvedId = id.ifBlank { UUID.randomUUID().toString() }
    return LabelHistoryItem(
        id = resolvedId,
        badgeLeft = badgeLeft.trim().take(16),
        badgeRight = badgeRight.trim().take(16),
        routingCode = routingCode.trim().take(64),
        waybillNumber = waybillNumber.trim().ifBlank { "JD0600216038" }.take(80),
        destinationBanner = destinationBanner.trim().take(120),
        recipientName = recipientName.trim().ifBlank { "-" }.take(120),
        recipientPhone = recipientPhone.trim().take(40),
        recipientAddress = recipientAddress.trim().take(500),
        senderName = senderName.trim().take(120),
        senderPhone = senderPhone.trim().take(40),
        senderArea = senderArea.trim().take(200),
        shippingFeeLabel = shippingFeeLabel.trim().take(64),
        shippingFeeAmount = shippingFeeAmount.trim().take(64),
        taxIncludedText = taxIncludedText.trim().take(64),
        paymentMethod = paymentMethod.trim().take(64),
        weight = weight.trim().take(40),
        printDate = printDate.trim().take(40),
        orderNumber = orderNumber.trim().take(80),
        expCode = expCode.trim().take(40),
        quantityText = quantityText.trim().take(40),
        itemCategory = itemCategory.trim().take(160),
        notes = notes.trim().take(500),
        companyNameAndTax = companyNameAndTax.trim().take(160),
        companyAddressLine1 = companyAddressLine1.trim().take(200),
        companyAddressLine2 = companyAddressLine2.trim().take(200),
        websiteUrl = websiteUrl.trim().take(120),
        stubBadgeText = stubBadgeText.trim().take(64),
        paperPreset = paperPreset.name,
        actionLabel = normalizedAction,
        createdAtMillis = createdAtMillis,
        updatedAtMillis = updatedAtMillis,
        drivePdfFileId = drivePdfFileId.trim(),
        lastSyncedAtMillis = lastSyncedAtMillis
    )
}
