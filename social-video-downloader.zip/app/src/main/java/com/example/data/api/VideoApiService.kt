package com.example.data.api

import com.example.data.model.ExtractRequest
import com.example.data.model.HealthResponse
import com.example.data.model.VideoInfoResponse
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface VideoApiService {

    @POST("api/extract")
    suspend fun extractVideo(
        @Body request: ExtractRequest
    ): VideoInfoResponse

    @GET("api/health")
    suspend fun checkHealth(): HealthResponse
}
