package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes WHERE (userId = :userId OR userId = '') ORDER BY isPinned DESC, updatedAt DESC")
    fun observeNotesForUser(userId: String): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes WHERE userId = '' ORDER BY isPinned DESC, updatedAt DESC")
    fun observeGuestNotes(): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes WHERE id = :id LIMIT 1")
    suspend fun getNoteById(id: String): NoteEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertNote(note: NoteEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertNotes(notes: List<NoteEntity>)

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteNoteById(id: String)

    @Query("SELECT * FROM notes WHERE (userId = :userId OR userId = '') AND isSynced = 0")
    suspend fun getUnsyncedNotes(userId: String): List<NoteEntity>

    @Query("UPDATE notes SET userId = :newUserId, isSynced = 0 WHERE userId = ''")
    suspend fun migrateGuestNotesToUser(newUserId: String)
}
