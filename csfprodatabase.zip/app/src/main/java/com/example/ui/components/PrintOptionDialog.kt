package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.ViewColumn
import androidx.compose.material.icons.filled.Feed
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class PrintLayoutOption {
    COMPACT_ORDER_KERJA,       // Opsi 1: Format fisik SPJ 2 Kolom (Keluhan & Catatan Perbaikan baris baru '-')
    FULL_DETAIL_REPORT,        // Opsi 2: Laporan A4 komprehensif dengan tabel terpisah full
    THREE_COLUMN_ORDER_KERJA   // Opsi 3: Format fisik SPJ 3 Kolom LX-300 (Keluhan, Perbaikan & Part)
}

@Composable
fun PrintOptionDialog(
    woName: String,
    onDismiss: () -> Unit,
    onPreview: (PrintLayoutOption) -> Unit,
    onConfirmPrint: (PrintLayoutOption) -> Unit
) {
    var selectedOption by remember { mutableStateOf(PrintLayoutOption.COMPACT_ORDER_KERJA) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 4.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Print,
                            contentDescription = "Cetak PDF",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Cetak Dokumen PDF",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Work Order: $woName",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Text(
                    text = "Pilih tata letak dokumen PDF yang ingin Anda cetak atau bagikan:",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                // OPSI 1: Cetak Ringkas (Sesuai foto)
                PrintOptionCard(
                    title = "Cetak Ringkas (Order Kerja 2 Kolom)",
                    badge = "Format Fisik SPJ",
                    description = "Tata letak lembar kerja fisik SPJ 2 kolom (Keluhan & Catatan Perbaikan). Catatan dipisahkan per baris baru secara otomatis bila terdapat tanda '-' agar tidak terpotong.",
                    icon = Icons.Default.Feed,
                    badgeColor = Color(0xFF1E88E5),
                    badgeBgColor = Color(0xFFE3F2FD),
                    isSelected = selectedOption == PrintLayoutOption.COMPACT_ORDER_KERJA,
                    onSelect = { selectedOption = PrintLayoutOption.COMPACT_ORDER_KERJA },
                    testTag = "option_compact_print"
                )

                Spacer(modifier = Modifier.height(10.dp))

                // OPSI 2: Cetak Full Detail
                PrintOptionCard(
                    title = "Cetak Full Detail (Seluruh Data Kartu WO)",
                    badge = "Laporan Lengkap A4",
                    description = "Memuat seluruh rincian kartu WO secara lengkap: tabel suku cadang, tipe pekerjaan/jasa, kuantitas, jam kerja, rincian biaya per item, dan total pengeluaran bengkel.",
                    icon = Icons.Default.Description,
                    badgeColor = Color(0xFF43A047),
                    badgeBgColor = Color(0xFFE8F5E9),
                    isSelected = selectedOption == PrintLayoutOption.FULL_DETAIL_REPORT,
                    onSelect = { selectedOption = PrintLayoutOption.FULL_DETAIL_REPORT },
                    testTag = "option_full_print"
                )

                Spacer(modifier = Modifier.height(10.dp))

                // OPSI 3: Cetak Ringkas 3 Kolom (LX-300 + Part)
                PrintOptionCard(
                    title = "Cetak Ringkas 3 Kolom (Keluhan, Perbaikan & Part)",
                    badge = "Format SPJ LX-300",
                    description = "Format SPJ continuous form printer LX-300 dengan 3 kolom: Keluhan di sisi kiri, Catatan Perbaikan di tengah (baris baru per tanda '-'), dan Suku Cadang/Produk di sisi kanan.",
                    icon = Icons.Default.ViewColumn,
                    badgeColor = Color(0xFFE65100),
                    badgeBgColor = Color(0xFFFFF3E0),
                    isSelected = selectedOption == PrintLayoutOption.THREE_COLUMN_ORDER_KERJA,
                    onSelect = { selectedOption = PrintLayoutOption.THREE_COLUMN_ORDER_KERJA },
                    testTag = "option_three_column_print"
                )
            }
        },
        confirmButton = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                FilledTonalButton(
                    onClick = { onPreview(selectedOption) },
                    modifier = Modifier.testTag("preview_print_option_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Visibility,
                        contentDescription = "Pratinjau",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Pratinjau", fontWeight = FontWeight.SemiBold)
                }

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = { onConfirmPrint(selectedOption) },
                    modifier = Modifier.testTag("confirm_print_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Print,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = when (selectedOption) {
                            PrintLayoutOption.COMPACT_ORDER_KERJA -> "Cetak Opsi 1"
                            PrintLayoutOption.FULL_DETAIL_REPORT -> "Cetak Opsi 2"
                            PrintLayoutOption.THREE_COLUMN_ORDER_KERJA -> "Cetak Opsi 3"
                        },
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_print_button")
            ) {
                Text("Batal")
            }
        },
        shape = RoundedCornerShape(20.dp)
    )
}

@Composable
private fun PrintOptionCard(
    title: String,
    badge: String,
    description: String,
    icon: ImageVector,
    badgeColor: Color,
    badgeBgColor: Color,
    isSelected: Boolean,
    onSelect: () -> Unit,
    testTag: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onSelect() }
            .testTag(testTag),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
            }
        ),
        border = BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                RadioButton(
                    selected = isSelected,
                    onClick = onSelect,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 30.dp),
                horizontalArrangement = Arrangement.Start
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(badgeBgColor)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = badge,
                        color = badgeColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = description,
                fontSize = 11.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 16.sp,
                modifier = Modifier.padding(start = 30.dp)
            )
        }
    }
}
