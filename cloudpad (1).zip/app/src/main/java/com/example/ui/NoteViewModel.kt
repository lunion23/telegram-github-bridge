package com.example.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Note
import com.example.data.repository.NoteRepository
import com.example.data.repository.SyncStatus
import com.example.files.LocalFileManager
import com.example.files.OpenedLocalFile
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class NoteViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = NoteRepository(application.applicationContext)
    private val prefs = application.getSharedPreferences("cloudpad_prefs", Context.MODE_PRIVATE)

    private val _currentUser = MutableStateFlow<FirebaseUser?>(Firebase.auth.currentUser)
    val currentUser: StateFlow<FirebaseUser?> = _currentUser.asStateFlow()

    val syncStatus: StateFlow<SyncStatus> = repository.syncStatus

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedTag = MutableStateFlow<String?>(null)
    val selectedTag: StateFlow<String?> = _selectedTag.asStateFlow()

    init {
        Firebase.auth.addAuthStateListener { auth ->
            _currentUser.value = auth.currentUser
        }
        seedWelcomeNoteOnce()
    }

    private fun seedWelcomeNoteOnce() {
        val alreadySeeded = prefs.getBoolean("welcome_note_seeded", false)
        if (alreadySeeded) return
        prefs.edit().putBoolean("welcome_note_seeded", true).apply()

        viewModelScope.launch {
            repository.saveNote(
                Note(
                    title = "Selamat Datang di CloudPad!",
                    content = """
# Selamat Datang di CloudPad!

CloudPad adalah aplikasi notepad & editor catatan kode dengan sinkronisasi cloud real-time.

## Fitur Utama:
- **Sinkronisasi Otomatis:** Catatan Anda disimpan aman dan disinkronkan langsung ke cloud saat masuk dengan Google.
- **Mode Tamu (Offline):** Catatan tetap tersimpan di perangkat lokal tanpa perlu login.
- **Buka File Lokal:** Tekan ikon folder di atas untuk membuka file `.txt`, `.json`, `.html`, `.js`, `.py`, `.md`, atau file teks lainnya dari perangkat Anda.
- **Format Ekspor Fleksibel:** Ekspor ke `.txt`, `.json`, `.html`, `.js`, `.py`, atau ekstensi kustom.

### Contoh Kode JavaScript:
```javascript
function greetUser(name) {
    console.log("Halo, " + name + "! Selamat mencatat di CloudPad.");
    return true;
}
greetUser("Pengguna");
```

### Contoh Kode Python:
```python
def hitung_kata(teks):
    kata = teks.split()
    return len(kata)

print("Jumlah kata:", hitung_kata("CloudPad sangat cepat!"))
```

Tekan tombol **Ekspor** untuk menyimpan file ke memori perangkat atau membagikannya!
                    """.trimIndent(),
                    tags = listOf("panduan", "cloudpad"),
                    fileExtension = "md",
                    isPinned = true
                )
            )
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    private val rawNotesFlow = _currentUser.flatMapLatest { user ->
        repository.observeNotes(user?.uid)
    }

    val notes: StateFlow<List<Note>> = combine(
        rawNotesFlow,
        _searchQuery,
        _selectedTag
    ) { allNotes, query, tag ->
        allNotes.filter { note ->
            val matchesQuery = query.isBlank() ||
                    note.title.contains(query, ignoreCase = true) ||
                    note.content.contains(query, ignoreCase = true) ||
                    note.tags.any { it.contains(query, ignoreCase = true) }

            val matchesTag = tag == null || note.tags.contains(tag)

            matchesQuery && matchesTag
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = emptyList()
    )

    val allTags: StateFlow<List<String>> = rawNotesFlow.combine(_currentUser) { notes, _ ->
        notes.flatMap { it.tags }.distinct().sorted()
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = emptyList()
    )

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedTag(tag: String?) {
        _selectedTag.value = if (_selectedTag.value == tag) null else tag
    }

    fun saveNote(note: Note) {
        viewModelScope.launch {
            repository.saveNote(note)
        }
    }

    fun deleteNote(id: String) {
        viewModelScope.launch {
            repository.deleteNote(id)
        }
    }

    fun togglePin(id: String) {
        viewModelScope.launch {
            repository.togglePin(id)
        }
    }

    suspend fun importLocalFile(uri: Uri): Result<OpenedLocalFile> {
        val result = LocalFileManager.readNoteFromUri(getApplication(), uri)
        result.onSuccess { opened ->
            repository.saveNote(opened.note)
        }
        return result
    }

    suspend fun importSharedText(title: String?, text: String): Note {
        val note = Note(
            title = title?.take(120)?.ifBlank { "Teks Dibagikan" } ?: "Teks Dibagikan",
            content = text,
            tags = listOf("impor"),
            fileExtension = "txt"
        )
        repository.saveNote(note)
        return note
    }

    fun refreshAuth() {
        _currentUser.value = Firebase.auth.currentUser
    }
}
