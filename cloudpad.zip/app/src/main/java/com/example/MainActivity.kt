package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.credentials.CredentialManager
import androidx.lifecycle.lifecycleScope
import com.example.auth.AuthManager
import com.example.data.model.Note
import com.example.ui.NoteViewModel
import com.example.ui.editor.NoteEditorScreen
import com.example.ui.home.NoteListScreen
import com.example.ui.theme.CloudPadTheme

class MainActivity : ComponentActivity() {

    private val noteViewModel: NoteViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Attempt silent auto sign-in if previously authenticated
        val credentialManager = CredentialManager.create(this)
        AuthManager.attemptAutoSignIn(
            context = this,
            credentialManager = credentialManager,
            onAuthSuccess = { noteViewModel.refreshAuth() },
            onUnauthenticated = { /* continue in guest mode */ },
            scope = lifecycleScope
        )

        setContent {
            CloudPadTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    CloudPadApp(viewModel = noteViewModel)
                }
            }
        }
    }
}

@Composable
fun CloudPadApp(viewModel: NoteViewModel) {
    val notes by viewModel.notes.collectAsState()
    var currentEditingNote by remember { mutableStateOf<Note?>(null) }

    // First run seed note if empty
    LaunchedEffect(notes) {
        if (notes.isEmpty() && viewModel.searchQuery.value.isEmpty() && viewModel.selectedTag.value == null) {
            // Seed welcome tutorial note
            viewModel.saveNote(
                Note(
                    title = "Selamat Datang di CloudPad! 🚀",
                    content = """
# Selamat Datang di CloudPad!

CloudPad adalah aplikasi notepad & editor catatan kode dengan sinkronisasi cloud real-time.

## Fitur Utama:
- 🔄 **Sinkronisasi Otomatis:** Catatan Anda disimpan aman dan disinkronkan langsung ke cloud saat masuk dengan Google.
- 📱 **Mode Tamu (Offline):** Catatan tetap tersimpan di perangkat lokal tanpa perlu login.
- 💻 **Format Ekspor Fleksibel:** Ekspor ke .txt, .json, .html, .js, .py, atau ekstensi kustom.
- 🎨 **Editor Syntax & Markdown:** Penyorotan sintaks kode dan pintasan format.

### Contoh Kode JavaScript:
```javascript
function greetUser(name) {
    console.log("Halo, " + name + "! Selamat mencatat di CloudPad.");
    return true;
}
greetUser("Pengguna");
```

### Contoh Kode Python:
```python
def hitung_kata(teks):
    kata = teks.split()
    return len(kata)

print("Jumlah kata:", hitung_kata("CloudPad sangat cepat!"))
```

Tekan tombol **Ekspor** di atas untuk menyimpan file ke memori perangkat atau membagikannya!
                    """.trimIndent(),
                    tags = listOf("panduan", "cloudpad"),
                    fileExtension = "md",
                    isPinned = true
                )
            )
        }
    }

    AnimatedContent(
        targetState = currentEditingNote,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "screen_transition"
    ) { currentNote ->
        if (currentNote != null) {
            NoteEditorScreen(
                initialNote = currentNote,
                onSaveNote = { note ->
                    viewModel.saveNote(note)
                },
                onDeleteNote = { id ->
                    viewModel.deleteNote(id)
                },
                onNavigateBack = {
                    currentEditingNote = null
                }
            )
        } else {
            NoteListScreen(
                viewModel = viewModel,
                onCreateNote = {
                    currentEditingNote = Note()
                },
                onOpenNote = { note ->
                    currentEditingNote = note
                }
            )
        }
    }
}
