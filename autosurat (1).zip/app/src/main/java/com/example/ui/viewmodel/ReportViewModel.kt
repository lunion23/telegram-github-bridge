package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.PartItem
import com.example.data.model.TechnicalReport
import com.example.data.repository.ReportRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class ScreenState {
    object List : ScreenState()
    data class Edit(val reportId: Long?) : ScreenState()
    data class Preview(val report: TechnicalReport) : ScreenState()
}

class ReportViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ReportRepository

    val reportsList: StateFlow<List<TechnicalReport>>

    private val _currentReport = MutableStateFlow(TechnicalReport())
    val currentReport: StateFlow<TechnicalReport> = _currentReport.asStateFlow()

    private val _currentParts = MutableStateFlow(PartItem.defaultList())
    val currentParts: StateFlow<List<PartItem>> = _currentParts.asStateFlow()

    private val _screenState = MutableStateFlow<ScreenState>(ScreenState.List)
    val screenState: StateFlow<ScreenState> = _screenState.asStateFlow()

    init {
        val db = AppDatabase.getInstance(application)
        repository = ReportRepository(db.reportDao())
        reportsList = repository.allReports.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        // Seed with sample initial report only once if database is completely empty
        viewModelScope.launch {
            if (repository.getReportCount() == 0) {
                seedDefaultReport()
            }
        }
    }

    private suspend fun seedDefaultReport() {
        val sampleParts = listOf(
            PartItem(1, "42611-EW010", "Velg Ban 16x6.00GS", "Stock"),
            PartItem(2, "42431-36070", "Tromol Rem Belakang", "Order"),
            PartItem(3, "", "", ""),
            PartItem(4, "", "", ""),
            PartItem(5, "", "", "")
        )

        val defaultReport = TechnicalReport(
            companyName = "Hiba Group",
            noLaporan = "1/LT-CLG/III/2026",
            bengkel = "Cilegon",
            tanggalLaporan = "12-Mar-26",
            pabrikPembuat = "HINO",
            model = "W04DTPJ-53447",
            tipe = "DUTRO",
            kode = "D127",
            tanggalRusak = "12-Mar-26",
            kmHm = "598916",
            namaAlat = "Ban",
            komponen = "Underbody",
            isMasaGaransi = false,
            tanggalKejadian = "12 Maret 2026",
            statusArmada = "Storing",
            kerusakan = "Ban kempes",
            lokasi = "Tol tangerang - merak",
            analisa = "Setelah di lakukan storing oleh team cikupa di temukan ban depan kiri kempes",
            kesimpulanPenggantianTerakhir = "9-5-2022 (km.415513)",
            noWoPenggantianTerakhir = "KLD1-WO-2205-00381",
            weeklyTerakhir = "5-3-2026 (km.598234)",
            noWoWeeklyTerakhir = "CLG1-WO-2603-00225",
            penyebabSudahWaktunya = true,
            caraPenyetelanUlang = true,
            caraDeskripsi = "Ganti ban stip",
            usulanPelapor = "Segera akan di lakukan program pengecekan atau penggantian terkait part tersebut terhadap RK8J supaya tidak terjadi kejadian serupa",
            partsJson = ReportRepository.partsToJson(sampleParts),
            pelaporNama = "Yudi Indrawan",
            pelaporJabatan = "Wa.Ka.Bengkel"
        )
        repository.saveReport(defaultReport)
    }

    fun navigateToList() {
        _screenState.value = ScreenState.List
    }

    fun startNewReport() {
        val newRep = TechnicalReport(
            id = 0,
            noLaporan = "${(1..99).random()}/LT-CLG/III/2026",
            tanggalLaporan = "20-Oct-26",
            tanggalRusak = "20-Oct-26",
            tanggalKejadian = "20 Oktober 2026"
        )
        _currentReport.value = newRep
        _currentParts.value = PartItem.defaultList()
        _screenState.value = ScreenState.Edit(null)
    }

    fun editReport(report: TechnicalReport) {
        _currentReport.value = report
        _currentParts.value = ReportRepository.jsonToParts(report.partsJson)
        _screenState.value = ScreenState.Edit(report.id)
    }

    fun previewReport(report: TechnicalReport) {
        _currentReport.value = report
        _screenState.value = ScreenState.Preview(report)
    }

    fun updateCurrentReport(transform: (TechnicalReport) -> TechnicalReport) {
        _currentReport.value = transform(_currentReport.value)
    }

    fun updatePartItem(index: Int, transform: (PartItem) -> PartItem) {
        val list = _currentParts.value.toMutableList()
        if (index in list.indices) {
            list[index] = transform(list[index])
            _currentParts.value = list
            _currentReport.value = _currentReport.value.copy(
                partsJson = ReportRepository.partsToJson(list)
            )
        }
    }

    fun setCompanyLogo(uriString: String) {
        val context = getApplication<Application>()
        val persistentPath = com.example.util.FileUtil.saveUriToInternalStorage(context, uriString, "company_logos")
        _currentReport.value = _currentReport.value.copy(companyLogoUri = persistentPath)
    }

    fun addPhotos(newUris: List<String>) {
        val context = getApplication<Application>()
        val current = _currentReport.value.getPhotoList().toMutableList()
        newUris.forEach { uri ->
            if (current.size < 4) {
                val persistentPath = com.example.util.FileUtil.saveUriToInternalStorage(context, uri, "damage_photos")
                if (!current.contains(persistentPath)) {
                    current.add(persistentPath)
                }
            }
        }
        _currentReport.value = _currentReport.value.copy(
            fotoKerusakanPaths = current.joinToString("|||")
        )
    }

    fun removePhoto(index: Int) {
        val current = _currentReport.value.getPhotoList().toMutableList()
        if (index in current.indices) {
            current.removeAt(index)
            _currentReport.value = _currentReport.value.copy(
                fotoKerusakanPaths = current.joinToString("|||")
            )
        }
    }

    fun clearAllPhotos() {
        _currentReport.value = _currentReport.value.copy(fotoKerusakanPaths = "")
    }

    fun saveDraft(onSaved: (() -> Unit)? = null) {
        viewModelScope.launch {
            val reportToSave = _currentReport.value.copy(
                partsJson = ReportRepository.partsToJson(_currentParts.value),
                updatedAt = System.currentTimeMillis()
            )
            val newId = repository.saveReport(reportToSave)
            _currentReport.value = reportToSave.copy(id = newId)
            onSaved?.invoke()
        }
    }

    fun duplicateReport(report: TechnicalReport) {
        viewModelScope.launch {
            repository.duplicateReport(report)
        }
    }

    fun deleteReport(report: TechnicalReport) {
        viewModelScope.launch {
            repository.deleteReport(report)
        }
    }
}
