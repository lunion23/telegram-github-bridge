package com.example.data.model

/**
 * Flexible Storage Method for Importing Data (CSV, Excel, or SQLite .db).
 * - APPEND: Adds imported records to the current database without deleting existing data.
 * - REPLACE_ALL: Clears existing database records and replaces with imported records.
 */
enum class ImportMode(
    val title: String,
    val subtitle: String
) {
    APPEND(
        title = "Append (Tambahkan Data)",
        subtitle = "Tambahkan ke data yang sudah ada tanpa menghapus data sebelumnya."
    ),
    REPLACE_ALL(
        title = "Replace All (Ganti Database)",
        subtitle = "Kosongkan seluruh database lama dan ganti bersih dengan data file ini."
    )
}
