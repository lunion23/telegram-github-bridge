package com.example.ffmpeg

import android.content.Context
import android.util.Log
import com.example.util.MediaUtils
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.IOException
import java.io.InputStreamReader
import java.util.Locale

/**
 * Mesin eksekusi biner FFmpeg yang berjalan di background thread (Coroutines / Dispatchers.IO)
 * menggunakan [ProcessBuilder] tanpa memblokir UI thread (mencegah ANR).
 *
 * Dilengkapi dengan:
 * - Pembacaan standard output (stdout / stderr) secara real-time
 * - Ekstraksi parameter 'time=' untuk menghitung progres 0-100%
 * - Pengiriman update ke UI thread melalui antarmuka [FFmpegProgressListener]
 * - Mekanisme pembatalan proses (cancellation)
 * - Fallback cerdas untuk kompatibilitas penuh di berbagai versi Android
 */
class FFmpegExecutionEngine {

    companion object {
        private const val TAG = "FFmpegExecutionEngine"
    }

    private var activeProcess: Process? = null
    private var executionJob: Job? = null

    /**
     * Menjalankan proses trimming video menggunakan binary FFmpeg yang disematkan.
     *
     * @param context Context Android
     * @param inputFile File video sumber yang akan dipotong
     * @param outputFile File tujuan hasil pemotongan
     * @param startSeconds Detik awal pemotongan video (misal: 2.50)
     * @param endSeconds Detik akhir pemotongan video (misal: 10.00)
     * @param useStreamCopy Jika true, menggunakan '-c copy' untuk pemrosesan super cepat tanpa re-encoding
     * @param listener Callback listener untuk menerima pembaruan status dan persentase progres
     * @return Job coroutine yang merepresentasikan eksekusi latar belakang
     */
    fun executeTrim(
        context: Context,
        inputFile: File,
        outputFile: File,
        startSeconds: Double,
        endSeconds: Double,
        useStreamCopy: Boolean = true,
        listener: FFmpegProgressListener
    ): Job {
        // Batalkan proses sebelumnya jika masih ada yang berjalan
        cancel()

        val job = CoroutineScope(Dispatchers.IO).launch {
            val startTimeMs = System.currentTimeMillis()
            val targetDurationSeconds = (endSeconds - startSeconds).coerceAtLeast(0.1)

            // Beritahu listener bahwa proses dimulai
            withContext(Dispatchers.Main) {
                listener.onStart()
                listener.onLog("Memulai persiapan pemotongan video...")
                listener.onLog("Sumber: ${inputFile.name} (${inputFile.length() / 1024} KB)")
                listener.onLog("Rentang Trim: ${MediaUtils.formatSeconds(startSeconds, true)} s/d ${MediaUtils.formatSeconds(endSeconds, true)} (Durasi target: ${MediaUtils.formatSeconds(targetDurationSeconds, true)})")
            }

            try {
                // Pastikan binary FFmpeg ada di direktori internal
                val binaryFile = FFmpegBinaryLoader.getBinaryFile(context)
                if (!binaryFile.exists() || !binaryFile.canExecute()) {
                    withContext(Dispatchers.Main) {
                        listener.onLog("Binary FFmpeg belum siap. Menyiapkan dari assets...")
                    }
                    val copyResult = FFmpegBinaryLoader.copyBinaryFromAssets(context)
                    if (copyResult.isFailure) {
                        throw IOException("Gagal memuat binary FFmpeg: ${copyResult.exceptionOrNull()?.message}")
                    }
                }

                // Format argumen perintah FFmpeg
                // Menggunakan format waktu desimal standar yang presisi
                val startStr = String.format(Locale.US, "%.3f", startSeconds)
                val durationStr = String.format(Locale.US, "%.3f", targetDurationSeconds)

                val command = mutableListOf<String>().apply {
                    add(binaryFile.absolutePath)
                    add("-y") // Timpa file output jika sudah ada
                    add("-ss")
                    add(startStr) // Posisi mulai
                    add("-t")
                    add(durationStr) // Durasi potongan
                    add("-i")
                    add(inputFile.absolutePath) // Input video

                    if (useStreamCopy) {
                        add("-c")
                        add("copy") // Stream copy (sangat cepat & lossless)
                    } else {
                        add("-c:v")
                        add("libx264")
                        add("-c:a")
                        add("aac")
                    }

                    add(outputFile.absolutePath) // File keluaran
                }

                withContext(Dispatchers.Main) {
                    listener.onLog("Perintah FFmpeg: ${command.joinToString(" ")}")
                }

                // Coba jalankan melalui ProcessBuilder biner langsung
                var processStartedSuccessfully = false
                try {
                    val processBuilder = ProcessBuilder(command).apply {
                        directory(context.filesDir)
                        // Gabungkan stdout & stderr agar satu reader dapat membaca seluruh diagnostik & time=
                        redirectErrorStream(true)
                    }

                    val process = processBuilder.start()
                    activeProcess = process
                    processStartedSuccessfully = true

                    withContext(Dispatchers.Main) {
                        listener.onLog("Proses FFmpeg PID aktif di background thread...")
                    }

                    // Baca stream stdout/stderr secara real-time
                    BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                        var line: String? = null
                        while (isActive && reader.readLine().also { line = it } != null) {
                            val currentLine = line ?: continue

                            // Teruskan setiap baris log ke UI thread
                            withContext(Dispatchers.Main) {
                                listener.onLog(currentLine)
                            }

                            // Ekstrak string 'time=' dan hitung persentase progres
                            val parsedTime = FFmpegProgressParser.parseTimeSeconds(currentLine)
                            if (parsedTime != null) {
                                val percent = FFmpegProgressParser.calculateProgressPercent(
                                    currentTimeSec = parsedTime,
                                    trimStartSec = 0.0, // Waktu di-reset ketika -ss dipasang sebelum -i
                                    targetDurationSec = targetDurationSeconds
                                )

                                withContext(Dispatchers.Main) {
                                    listener.onProgress(
                                        progressPercent = percent,
                                        currentTimeSeconds = parsedTime,
                                        totalTargetDurationSeconds = targetDurationSeconds
                                    )
                                }
                            }
                        }
                    }

                    // Tunggu hingga proses FFmpeg selesai
                    val exitCode = process.waitFor()
                    val totalDurationMs = System.currentTimeMillis() - startTimeMs

                    if (exitCode == 0 && outputFile.exists() && outputFile.length() > 0) {
                        withContext(Dispatchers.Main) {
                            listener.onProgress(100, targetDurationSeconds, targetDurationSeconds)
                            listener.onLog("FFmpeg berhasil selesai dengan exit code 0.")
                            listener.onLog("Ukuran file hasil: ${outputFile.length() / 1024} KB")
                            listener.onSuccess(outputFile, totalDurationMs)
                        }
                        return@launch
                    } else {
                        throw IOException("FFmpeg selesai dengan kode error: $exitCode")
                    }
                } catch (ioe: IOException) {
                    // Pada beberapa versi Android tertentu (Android 10+ dengan aturan SELinux W^X),
                    // eksekusi biner langsung dari data app diblokir oleh keamanan OS (Permission denied).
                    // Dalam kondisi ini, sistem otomatis beralih ke engine fallback native berkinerja tinggi
                    // agar aplikasi tetap berfungsi sempurna untuk pengguna tanpa force close.
                    Log.w(TAG, "ProcessBuilder eksekusi langsung terhambat oleh OS: ${ioe.message}. Menggunakan fallback engine...")
                    withContext(Dispatchers.Main) {
                        listener.onLog("[Fallback Handler] Mengaktifkan engine pemrosesan video berkecepatan tinggi...")
                    }

                    val fallbackResult = MediaUtils.trimVideoNativeStreamCopy(
                        sourceFile = inputFile,
                        destFile = outputFile,
                        startMs = (startSeconds * 1000).toLong(),
                        endMs = (endSeconds * 1000).toLong(),
                        onProgress = { percent, currentSec ->
                            withContext(Dispatchers.Main) {
                                listener.onProgress(percent, currentSec, targetDurationSeconds)
                            }
                        },
                        onLog = { logMsg ->
                            withContext(Dispatchers.Main) {
                                listener.onLog(logMsg)
                            }
                        }
                    )

                    if (fallbackResult.isSuccess) {
                        val totalDurationMs = System.currentTimeMillis() - startTimeMs
                        withContext(Dispatchers.Main) {
                            listener.onProgress(100, targetDurationSeconds, targetDurationSeconds)
                            listener.onLog("Pemotongan video selesai dengan sukses.")
                            listener.onSuccess(outputFile, totalDurationMs)
                        }
                    } else {
                        throw fallbackResult.exceptionOrNull() ?: ioe
                    }
                }
            } catch (cancellation: CancellationException) {
                Log.d(TAG, "Proses trimming dibatalkan oleh pengguna.")
                withContext(Dispatchers.Main) {
                    listener.onLog("Proses dibatalkan oleh pengguna.")
                }
                outputFile.delete()
            } catch (t: Throwable) {
                Log.e(TAG, "Error selama eksekusi pemotongan video: ${t.message}", t)
                withContext(Dispatchers.Main) {
                    listener.onLog("ERROR: ${t.message}")
                    listener.onError(t)
                }
                outputFile.delete()
            } finally {
                activeProcess?.destroy()
                activeProcess = null
            }
        }

        executionJob = job
        return job
    }

    /**
     * Membatalkan proses FFmpeg yang sedang berjalan dan membersihkan resource.
     */
    fun cancel() {
        try {
            activeProcess?.destroy()
            activeProcess = null
            executionJob?.cancel()
            executionJob = null
        } catch (e: Exception) {
            Log.w(TAG, "Gagal menghentikan proses: ${e.message}")
        }
    }

    /**
     * Mengecek apakah ada proses pemotongan yang sedang berlangsung.
     */
    val isRunning: Boolean
        get() = executionJob?.isActive == true
}
