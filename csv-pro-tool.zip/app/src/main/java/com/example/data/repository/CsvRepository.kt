package com.example.data.repository

import android.content.Context
import android.net.Uri
import androidx.room.withTransaction
import com.example.data.database.AppDatabase
import com.example.data.database.CsvDao
import com.example.data.exporter.CsvExporter
import com.example.data.exporter.ExcelExporter
import com.example.data.exporter.PdfExporter
import com.example.data.model.ColumnConfigEntity
import com.example.data.model.ConsolidatedCardItem
import com.example.data.model.CsvRowEntity
import com.example.data.model.FilterCriteria
import com.example.data.model.SampleDataGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.OutputStream

class CsvRepository(private val context: Context) {

    private val db = AppDatabase.getDatabase(context)
    private val dao: CsvDao = db.csvDao()

    val columnConfigs: Flow<List<ColumnConfigEntity>> = dao.getAllColumnConfigs()

    suspend fun getRowCount(): Int = withContext(Dispatchers.IO) {
        try {
            dao.getRowCountDirect()
        } catch (e: Exception) {
            0
        }
    }

    suspend fun getDistinctStatuses(): List<String> = withContext(Dispatchers.IO) {
        try {
            dao.getDistinctStatusesDirect()
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getDistinctCategories(): List<String> = withContext(Dispatchers.IO) {
        try {
            dao.getDistinctCategoriesDirect()
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun initializeDefaultsIfNeeded() = withContext(Dispatchers.IO) {
        val existingConfigs = dao.getAllColumnConfigsDirect()
        if (existingConfigs.isEmpty()) {
            dao.insertColumnConfigs(ColumnConfigEntity.defaultConfigs())
        }
    }

    suspend fun loadSampleData(isReplaceAll: Boolean = true) = withContext(Dispatchers.IO) {
        db.withTransaction {
            if (isReplaceAll) {
                dao.clearAllRows()
            }
            val sample = SampleDataGenerator.generate10ColumnDataset()
            dao.insertAll(sample)
        }
    }

    // High performance paged fetch (100 rows per page - Zero OOM risk)
    suspend fun getPagedFilteredRows(
        filter: FilterCriteria,
        page: Int = 0,
        pageSize: Int = 100
    ): Pair<List<CsvRowEntity>, Int> = withContext(Dispatchers.IO) {
        val query = filter.searchQuery.trim()
        val totalCount = dao.getFilteredRowCount(query, filter.statusFilter, filter.categoryFilter)

        val offset = page * pageSize
        val rows = dao.getPagedFilteredRows(
            query = query,
            status = filter.statusFilter,
            category = filter.categoryFilter,
            limit = pageSize,
            offset = offset
        )

        var result = rows

        // In-memory filter for column 2 search if provided
        if (filter.searchQuery2.isNotBlank()) {
            val q2 = filter.searchQuery2.trim()
            val colIdx = filter.searchColumn2Index
            result = result.filter { row ->
                row.getCell(colIdx).contains(q2, ignoreCase = true)
            }
        }

        // Apply sorting
        result = if (filter.isSortAscending) {
            result.sortedBy { it.getCell(filter.sortColumnIndex).lowercase() }
        } else {
            result.sortedByDescending { it.getCell(filter.sortColumnIndex).lowercase() }
        }

        Pair(result, totalCount)
    }

    // Safe indexed fetch for consolidated groups without memory explosion
    suspend fun getPagedConsolidatedGroups(
        filter: FilterCriteria,
        page: Int = 0,
        pageSize: Int = 50
    ): List<ConsolidatedCardItem> = withContext(Dispatchers.IO) {
        val query = filter.searchQuery.trim()
        val offset = page * pageSize

        val distinctIds = dao.getDistinctRecordIdsPaged(
            query = query,
            status = filter.statusFilter,
            category = filter.categoryFilter,
            limit = pageSize,
            offset = offset
        )

        val items = mutableListOf<ConsolidatedCardItem>()
        for (recId in distinctIds) {
            val summary = dao.getGroupSummaryForRecordId(recId)
            if (summary != null) {
                items.add(
                    ConsolidatedCardItem(
                        recordId = summary.recordId.ifEmpty { "TANPA-ID" },
                        primaryDate = summary.primaryDate ?: "-",
                        customerOrEntity = summary.customerOrEntity ?: "-",
                        category = summary.category ?: "-",
                        totalItemsCount = summary.itemCount,
                        status = summary.status ?: "Selesai",
                        rows = emptyList(),
                        isRowsLoaded = false
                    )
                )
            }
        }

        // Apply column 2 search filtering if active
        if (filter.searchQuery2.isNotBlank()) {
            val q2 = filter.searchQuery2.trim()
            items.filter { it.recordId.contains(q2, ignoreCase = true) || it.customerOrEntity.contains(q2, ignoreCase = true) }
        } else {
            items
        }
    }

    suspend fun getChildRowsForCard(recordId: String): List<CsvRowEntity> = withContext(Dispatchers.IO) {
        dao.getRowsByRecordId(recordId, limit = 100)
    }

    // Dynamic Column Addition & Deletion
    suspend fun addNewColumn(headerName: String): ColumnConfigEntity = withContext(Dispatchers.IO) {
        val currentConfigs = dao.getAllColumnConfigsDirect()
        val nextColIndex = (currentConfigs.maxOfOrNull { it.colIndex } ?: -1) + 1
        val nextDisplayOrder = (currentConfigs.maxOfOrNull { it.displayOrder } ?: -1) + 1

        val newConfig = ColumnConfigEntity(
            colIndex = nextColIndex,
            headerName = headerName.trim().ifEmpty { "Kolom ${nextColIndex + 1}" },
            isVisible = true,
            displayOrder = nextDisplayOrder
        )
        dao.insertColumnConfig(newConfig)
        newConfig
    }

    suspend fun deleteColumn(colIndex: Int) = withContext(Dispatchers.IO) {
        dao.deleteColumnConfigByIndex(colIndex)
    }

    suspend fun insertRow(row: CsvRowEntity) = withContext(Dispatchers.IO) {
        dao.insertRow(row)
    }

    suspend fun updateRow(row: CsvRowEntity) = withContext(Dispatchers.IO) {
        dao.updateRow(row)
    }

    suspend fun deleteRow(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteRowById(id)
    }

    suspend fun deleteGroup(recordId: String) = withContext(Dispatchers.IO) {
        dao.deleteByRecordId(recordId)
    }

    suspend fun clearAll() = withContext(Dispatchers.IO) {
        dao.clearAllRows()
    }

    suspend fun updateColumnConfig(config: ColumnConfigEntity) = withContext(Dispatchers.IO) {
        dao.updateColumnConfig(config)
    }

    suspend fun updateColumnConfigs(configs: List<ColumnConfigEntity>) = withContext(Dispatchers.IO) {
        dao.insertColumnConfigs(configs)
    }

    // Flexible Import: Append vs Replace All with chunked batch transactions
    // Ultra-optimized for large files (hundreds of thousands or millions of lines)
    suspend fun importCsvFromUri(
        uri: Uri,
        isReplaceAll: Boolean,
        onProgress: (imported: Int) -> Unit = {}
    ): Int = withContext(Dispatchers.IO) {
        val contentResolver = context.contentResolver
        val inputStream = contentResolver.openInputStream(uri) ?: return@withContext 0

        if (isReplaceAll) {
            dao.clearAllRows()
        }

        val reader = BufferedReader(InputStreamReader(inputStream), 65536)
        val batch = mutableListOf<CsvRowEntity>()
        var totalImported = 0
        var firstLine = true
        var detectedHeaders = listOf<String>()

        reader.useLines { lines ->
            for (line in lines) {
                if (line.isBlank()) continue
                val values = parseCsvLine(line)

                if (firstLine) {
                    firstLine = false
                    if (isHeaderLine(values)) {
                        detectedHeaders = values
                        // If replace all or empty, align columns
                        if (isReplaceAll || dao.getAllColumnConfigsDirect().isEmpty()) {
                            val newConfigs = detectedHeaders.mapIndexed { idx, name ->
                                ColumnConfigEntity(
                                    colIndex = idx,
                                    headerName = name.ifBlank { "Kolom ${idx + 1}" },
                                    isVisible = true,
                                    displayOrder = idx
                                )
                            }
                            dao.insertColumnConfigs(newConfigs)
                        }
                        continue
                    }
                }

                val entity = CsvRowEntity.fromList(values)
                batch.add(entity)

                if (batch.size >= 2000) {
                    db.withTransaction {
                        dao.insertAll(batch)
                    }
                    totalImported += batch.size
                    onProgress(totalImported)
                    batch.clear()
                }
            }
        }

        if (batch.isNotEmpty()) {
            db.withTransaction {
                dao.insertAll(batch)
            }
            totalImported += batch.size
            onProgress(totalImported)
            batch.clear()
        }

        totalImported
    }

    suspend fun backupDatabaseToUri(uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val dbFile = context.getDatabasePath(AppDatabase.DATABASE_NAME)
            if (!dbFile.exists()) return@withContext false

            val outputStream: OutputStream? = context.contentResolver.openOutputStream(uri)
            outputStream?.use { out ->
                FileInputStream(dbFile).use { input ->
                    input.copyTo(out)
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun restoreDatabaseFromUri(uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val dbFile = context.getDatabasePath(AppDatabase.DATABASE_NAME)
            val parent = dbFile.parentFile
            if (parent != null && !parent.exists()) {
                parent.mkdirs()
            }

            db.close()

            val inputStream = context.contentResolver.openInputStream(uri) ?: return@withContext false
            FileOutputStream(dbFile).use { output ->
                inputStream.use { input ->
                    input.copyTo(output)
                }
            }

            File(dbFile.path + "-wal").delete()
            File(dbFile.path + "-shm").delete()

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    // Safe chunked export (streaming up to 50,000 rows without OOM)
    suspend fun exportCsv(uri: Uri, filter: FilterCriteria): Boolean = withContext(Dispatchers.IO) {
        try {
            val columns = dao.getAllColumnConfigsDirect()
            val out = context.contentResolver.openOutputStream(uri) ?: return@withContext false
            val query = filter.searchQuery.trim()
            val chunkSize = 2000
            var offset = 0
            val allRows = mutableListOf<CsvRowEntity>()

            do {
                val chunk = dao.getExportChunk(query, filter.statusFilter, filter.categoryFilter, chunkSize, offset)
                allRows.addAll(chunk)
                offset += chunkSize
            } while (chunk.size == chunkSize && allRows.size < 50000)

            out.use { CsvExporter.export(it, columns, allRows) }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun exportExcel(uri: Uri, filter: FilterCriteria): Boolean = withContext(Dispatchers.IO) {
        try {
            val columns = dao.getAllColumnConfigsDirect()
            val out = context.contentResolver.openOutputStream(uri) ?: return@withContext false
            val query = filter.searchQuery.trim()
            val chunkSize = 2000
            var offset = 0
            val allRows = mutableListOf<CsvRowEntity>()

            do {
                val chunk = dao.getExportChunk(query, filter.statusFilter, filter.categoryFilter, chunkSize, offset)
                allRows.addAll(chunk)
                offset += chunkSize
            } while (chunk.size == chunkSize && allRows.size < 50000)

            out.use { ExcelExporter.export(it, columns, allRows) }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun exportPdf(uri: Uri, filter: FilterCriteria): Boolean = withContext(Dispatchers.IO) {
        try {
            val columns = dao.getAllColumnConfigsDirect()
            val out = context.contentResolver.openOutputStream(uri) ?: return@withContext false
            val query = filter.searchQuery.trim()
            val rows = dao.getPagedFilteredRows(query, filter.statusFilter, filter.categoryFilter, limit = 500, offset = 0)
            val summary = if (filter.isActive) "Filter Aktif (${rows.size} baris)" else "Semua Data (${rows.size} baris)"
            out.use { PdfExporter.export(it, columns, rows, filterSummary = summary) }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun isHeaderLine(values: List<String>): Boolean {
        val keywords = listOf("id", "no", "faktur", "tanggal", "date", "name", "nama", "customer", "kategori", "category", "produk", "product", "qty", "harga", "price", "total", "status", "ket")
        return values.any { v -> keywords.any { k -> v.lowercase().contains(k) } }
    }

    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val sb = java.lang.StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            if (c == '\"') {
                if (inQuotes && i + 1 < line.length && line[i + 1] == '\"') {
                    sb.append('\"')
                    i++
                } else {
                    inQuotes = !inQuotes
                }
            } else if (c == ',' && !inQuotes) {
                result.add(sb.toString().trim())
                sb.setLength(0)
            } else {
                sb.append(c)
            }
            i++
        }
        result.add(sb.toString().trim())
        return result
    }
}
