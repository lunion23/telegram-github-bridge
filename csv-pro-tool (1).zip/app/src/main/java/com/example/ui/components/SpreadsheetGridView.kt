package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ColumnConfigEntity
import com.example.data.model.ColumnType
import com.example.data.model.CsvRowEntity
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldAccent

@Composable
fun SpreadsheetGridView(
    rows: List<CsvRowEntity>,
    columns: List<ColumnConfigEntity>,
    sortColumnIndex: Int,
    isSortAscending: Boolean,
    onSortColumn: (Int) -> Unit,
    onEditRow: (CsvRowEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val horizontalScrollState = rememberScrollState()
    val visibleCols = columns.filter { it.isVisible }.sortedBy { it.displayOrder }

    if (rows.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Tabel Kosong atau Tidak Ada Data yang Cocok",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("spreadsheet_grid_view")
    ) {
        Box(modifier = Modifier.horizontalScroll(horizontalScrollState)) {
            Column {
                Row(
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.surface)
                        .border(
                            width = 1.dp,
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                        ),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .width(44.dp)
                            .height(44.dp)
                            .padding(4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "#",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp
                        )
                    }

                    visibleCols.forEach { col ->
                        val isSorted = sortColumnIndex == col.colIndex
                        val colWidth = getColumnWidth(col.colIndex)

                        Row(
                            modifier = Modifier
                                .width(colWidth)
                                .height(44.dp)
                                .clickable { onSortColumn(col.colIndex) }
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = col.headerName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (isSorted) CyanAccent else MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            if (isSorted) {
                                Icon(
                                    imageVector = if (isSortAscending) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                    contentDescription = "Urutkan",
                                    tint = CyanAccent,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .width(50.dp)
                            .height(44.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Aksi",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                LazyColumn(
                    modifier = Modifier.weight(1f, fill = false),
                    contentPadding = PaddingValues(bottom = 72.dp)
                ) {
                    itemsIndexed(rows, key = { _, row -> row.id }) { index, row ->
                        val isEven = index % 2 == 1
                        val rowBg = if (isEven) {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        } else {
                            MaterialTheme.colorScheme.surface
                        }

                        Row(
                            modifier = Modifier
                                .background(rowBg)
                                .border(
                                    width = 0.5.dp,
                                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                                )
                                .clickable { onEditRow(row) },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(44.dp)
                                    .height(40.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${index + 1}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            visibleCols.forEach { col ->
                                val cellVal = row.getCell(col.colIndex)
                                val colWidth = getColumnWidth(col.colIndex)
                                val isNumeric = col.columnType == ColumnType.NUMBER.name || col.columnType == ColumnType.CURRENCY.name

                                Box(
                                    modifier = Modifier
                                        .width(colWidth)
                                        .height(40.dp)
                                        .padding(horizontal = 8.dp),
                                    contentAlignment = if (isNumeric) Alignment.CenterEnd else Alignment.CenterStart
                                ) {
                                    Text(
                                        text = cellVal,
                                        fontSize = 12.sp,
                                        color = if (col.colIndex == 8) EmeraldAccent else MaterialTheme.colorScheme.onSurface,
                                        fontWeight = if (col.colIndex == 8 || col.colIndex == 0) FontWeight.SemiBold else FontWeight.Normal,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        textAlign = if (isNumeric) TextAlign.End else TextAlign.Start
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .width(50.dp)
                                    .height(40.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                IconButton(
                                    onClick = { onEditRow(row) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit Baris",
                                        tint = CyanAccent,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun getColumnWidth(index: Int): Dp {
    return when (index) {
        0 -> 120.dp
        1 -> 100.dp
        2 -> 170.dp
        3 -> 120.dp
        4 -> 190.dp
        5 -> 70.dp
        6 -> 125.dp
        7 -> 80.dp
        8 -> 135.dp
        9 -> 110.dp
        else -> 120.dp
    }
}
