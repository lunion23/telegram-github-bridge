package com.example.ffmpeg

/**
 * Helper untuk mem-parsing string 'time=' dari output stdout/stderr FFmpeg
 * secara real-time dan menghitung persentase progres (0 - 100%).
 */
object FFmpegProgressParser {

    // Regex untuk mencocokkan 'time=HH:MM:SS.xx' (misal: time=00:01:23.45)
    private val TIME_CODE_REGEX = Regex("""time=\s*(\d+):(\d+):(\d+(?:\.\d+)?)""")

    // Regex alternatif jika format berupa detik desimal langsung (misal: time=45.20)
    private val TIME_SECONDS_REGEX = Regex("""time=\s*(\d+(?:\.\d+)?)""")

    /**
     * Mengekstrak nilai waktu pemrosesan dalam detik dari satu baris log output FFmpeg.
     *
     * @param line Baris output log dari stream FFmpeg
     * @return Waktu dalam detik, atau null jika baris tidak mengandung informasi 'time='
     */
    fun parseTimeSeconds(line: String): Double? {
        if (!line.contains("time=")) return null

        // Format standar FFmpeg: time=00:00:04.50
        val timeCodeMatch = TIME_CODE_REGEX.find(line)
        if (timeCodeMatch != null) {
            val (hoursStr, minutesStr, secondsStr) = timeCodeMatch.destructured
            val hours = hoursStr.toDoubleOrNull() ?: 0.0
            val minutes = minutesStr.toDoubleOrNull() ?: 0.0
            val seconds = secondsStr.toDoubleOrNull() ?: 0.0
            return (hours * 3600.0) + (minutes * 60.0) + seconds
        }

        // Format sekunder jika berupa detik mentah
        val secondsMatch = TIME_SECONDS_REGEX.find(line)
        if (secondsMatch != null) {
            return secondsMatch.groupValues[1].toDoubleOrNull()
        }

        return null
    }

    /**
     * Menghitung persentase progres (0 - 100%) berdasarkan total durasi video target.
     *
     * @param currentTimeSec Nilai detik yang diekstrak dari output FFmpeg
     * @param trimStartSec Posisi detik awal pemotongan (offset jika -ss sesudah -i)
     * @param targetDurationSec Total durasi video potongan yang diharapkan (detik)
     * @return Nilai persentase dalam rentang 0 hingga 100
     */
    fun calculateProgressPercent(
        currentTimeSec: Double,
        trimStartSec: Double = 0.0,
        targetDurationSec: Double
    ): Int {
        if (targetDurationSec <= 0.0) return 0

        // Menghitung berapa lama durasi potongan yang telah selesai diproses
        val processedSeconds = if (currentTimeSec >= trimStartSec) {
            currentTimeSec - trimStartSec
        } else {
            // Ketika -ss diletakkan sebelum -i, FFmpeg me-reset waktu mulai dari 00:00:00
            currentTimeSec
        }

        val fraction = (processedSeconds / targetDurationSec).coerceIn(0.0, 1.0)
        return (fraction * 100.0).toInt().coerceIn(0, 100)
    }
}
