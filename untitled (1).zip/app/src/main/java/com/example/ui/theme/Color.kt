package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val IndustrialBlue = Color(0xFF1E3A8A)
val IndustrialBlueDark = Color(0xFF0F172A)
val CobaltBlue = Color(0xFF2563EB)
val SafetyAmber = Color(0xFFD97706)
val SafetyAmberLight = Color(0xFFFEF3C7)
val StatusGreen = Color(0xFF16A34A)
val StatusGreenLight = Color(0xFFDCFCE7)
val StatusRed = Color(0xFFDC2626)
val SlateBackground = Color(0xFFF8FAFC)
val CardBackground = Color(0xFFFFFFFF)
val BorderColor = Color(0xFFE2E8F0)
val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF64748B)

val PrimaryBlueLight = Color(0xFF1E3A8A)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFDBEAFE)
val OnPrimaryContainerLight = Color(0xFF1E3A8A)

val PrimaryBlueDark = Color(0xFF93C5FD)
val OnPrimaryDark = Color(0xFF1E3A8A)
val PrimaryContainerDark = Color(0xFF1E40AF)
val OnPrimaryContainerDark = Color(0xFFEFF6FF)
