package com.example.database

import androidx.room.TypeConverter
import com.example.model.ReplacementPart
import org.json.JSONArray
import org.json.JSONObject

class Converters {
    @TypeConverter
    fun fromPartsList(parts: List<ReplacementPart>?): String {
        if (parts == null) return "[]"
        val array = JSONArray()
        for (part in parts) {
            val obj = JSONObject()
            obj.put("id", part.id)
            obj.put("partNumber", part.partNumber)
            obj.put("partName", part.partName)
            obj.put("procurementType", part.procurementType)
            array.put(obj)
        }
        return array.toString()
    }

    @TypeConverter
    fun toPartsList(data: String?): List<ReplacementPart> {
        if (data.isNullOrEmpty()) return emptyList()
        val list = mutableListOf<ReplacementPart>()
        try {
            val array = JSONArray(data)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    ReplacementPart(
                        id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                        partNumber = obj.optString("partNumber", ""),
                        partName = obj.optString("partName", ""),
                        procurementType = obj.optString("procurementType", "Stock")
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list
    }
}
