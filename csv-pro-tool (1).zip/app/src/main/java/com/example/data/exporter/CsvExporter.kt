package com.example.data.exporter

import com.example.data.model.ColumnConfigEntity
import com.example.data.model.CsvRowEntity
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets

object CsvExporter {

    fun export(
        outputStream: OutputStream,
        columns: List<ColumnConfigEntity>,
        rows: List<CsvRowEntity>
    ) {
        val writer = OutputStreamWriter(outputStream, StandardCharsets.UTF_8)
        val visibleCols = columns.filter { it.isVisible }.sortedBy { it.displayOrder }

        val headerLine = visibleCols.joinToString(",") { escapeCsv(it.headerName) }
        writer.write(headerLine)
        writer.write("\r\n")

        for (row in rows) {
            val rowValues = visibleCols.map { col ->
                escapeCsv(row.getCell(col.colIndex))
            }
            writer.write(rowValues.joinToString(","))
            writer.write("\r\n")
        }

        writer.flush()
    }

    private fun escapeCsv(value: String): String {
        var str = value
        val mustQuote = str.contains(",") || str.contains("\"") || str.contains("\n") || str.contains("\r")
        if (str.contains("\"")) {
            str = str.replace("\"", "\"\"")
        }
        return if (mustQuote) "\"$str\"" else str
    }
}
