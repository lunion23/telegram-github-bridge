package com.example.data.model

import java.text.NumberFormat
import java.util.Locale

data class ConsolidatedCardItem(
    val recordId: String,
    val primaryDate: String,
    val customerOrEntity: String,
    val category: String,
    val totalItemsCount: Int,
    val totalAmount: Double,
    val status: String,
    val rows: List<CsvRowEntity>
) {
    val formattedTotal: String
        get() {
            return try {
                val format = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
                format.maximumFractionDigits = 0
                format.format(totalAmount)
            } catch (e: Exception) {
                "Rp %,.0f".format(Locale.GERMANY, totalAmount)
            }
        }

    companion object {
        fun fromRows(rowsForId: List<CsvRowEntity>): ConsolidatedCardItem {
            val first = rowsForId.firstOrNull()
            val recId = first?.recordId?.ifEmpty { first.col0 } ?: "TANPA-ID"
            val date = first?.col1?.ifEmpty { "-" } ?: "-"
            val customer = first?.col2?.ifEmpty { "-" } ?: "-"
            val category = first?.col3?.ifEmpty { "Umum" } ?: "Umum"
            val status = first?.col9?.ifEmpty { "Selesai" } ?: "Selesai"

            var sumTotal = 0.0
            for (row in rowsForId) {
                val parsed = row.col8.replace(".", "").replace(",", ".").replace("Rp", "").trim().toDoubleOrNull()
                if (parsed != null) {
                    sumTotal += parsed
                } else {
                    val qty = row.col5.trim().toDoubleOrNull() ?: 1.0
                    val price = row.col6.replace(".", "").replace(",", ".").replace("Rp", "").trim().toDoubleOrNull() ?: 0.0
                    val disc = row.col7.trim().toDoubleOrNull() ?: 0.0
                    val sub = qty * price * (1.0 - (disc / 100.0))
                    sumTotal += sub
                }
            }

            return ConsolidatedCardItem(
                recordId = recId,
                primaryDate = date,
                customerOrEntity = customer,
                category = category,
                totalItemsCount = rowsForId.size,
                totalAmount = sumTotal,
                status = status,
                rows = rowsForId
            )
        }
    }
}
