package com.example

import com.example.ffmpeg.BatchTrimParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit test untuk memverifikasi logika parsing Multi-Text Time Command Batch Trimming.
 */
class BatchTrimParserTest {

    @Test
    fun parseSingleTimeToSeconds_validFormats_parsesAccurately() {
        assertEquals(0.0, BatchTrimParser.parseSingleTimeToSeconds("00:00")!!, 0.001)
        assertEquals(10.0, BatchTrimParser.parseSingleTimeToSeconds("00:10")!!, 0.001)
        assertEquals(83.45, BatchTrimParser.parseSingleTimeToSeconds("01:23.45")!!, 0.001)
        assertEquals(3665.0, BatchTrimParser.parseSingleTimeToSeconds("01:01:05")!!, 0.001)
        assertEquals(5.0, BatchTrimParser.parseSingleTimeToSeconds("5")!!, 0.001)
        assertEquals(15.5, BatchTrimParser.parseSingleTimeToSeconds("15.5")!!, 0.001)
    }

    @Test
    fun parseLine_standardHyphenFormat_parsesCorrectly() {
        val range1 = BatchTrimParser.parseLine("00:00-00:10")
        assertNotNull(range1)
        assertEquals(0.0, range1!!.startSeconds, 0.001)
        assertEquals(10.0, range1.endSeconds, 0.001)

        val range2 = BatchTrimParser.parseLine("5-15")
        assertNotNull(range2)
        assertEquals(5.0, range2!!.startSeconds, 0.001)
        assertEquals(15.0, range2.endSeconds, 0.001)
    }

    @Test
    fun parseLine_withSpacesAndEnDash_parsesCorrectly() {
        val range = BatchTrimParser.parseLine("00:05.50 – 00:12.30")
        assertNotNull(range)
        assertEquals(5.50, range!!.startSeconds, 0.001)
        assertEquals(12.30, range.endSeconds, 0.001)
    }

    @Test
    fun parseLine_invalidInput_returnsNull() {
        assertNull(BatchTrimParser.parseLine("invalid-string"))
        assertNull(BatchTrimParser.parseLine("15-5")) // Start >= End
        assertNull(BatchTrimParser.parseLine(""))
        assertNull(BatchTrimParser.parseLine("# comment line"))
    }

    @Test
    fun parseMultiTextCommands_limitsToMax5Segments() {
        val multilineInput = """
            00:00-00:05
            00:05-00:10
            10-15
            15-20
            20-25
            25-30
            30-35
        """.trimIndent()

        val results = BatchTrimParser.parseMultiTextCommands(
            multiLineText = multilineInput,
            maxDurationSeconds = 60.0,
            maxLimit = 5
        )

        assertEquals("Harus secara otomatis membatasi maksimal hingga 5 segmen teratas", 5, results.size)
        assertEquals(0.0, results[0].startSeconds, 0.001)
        assertEquals(5.0, results[0].endSeconds, 0.001)
        assertEquals(20.0, results[4].startSeconds, 0.001)
        assertEquals(25.0, results[4].endSeconds, 0.001)
    }

    @Test
    fun parseMultiTextCommands_skipsBlankOrMalformedLines() {
        val multilineInput = """
            00:00-00:04
            
            invalid-entry
            04-08
            # Catatan
            08-12
        """.trimIndent()

        val results = BatchTrimParser.parseMultiTextCommands(multilineInput, 60.0, 5)
        assertEquals(3, results.size)
        assertEquals(4.0, results[0].endSeconds, 0.001)
        assertEquals(8.0, results[1].endSeconds, 0.001)
        assertEquals(12.0, results[2].endSeconds, 0.001)
    }
}
