package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextReplacement
import androidx.test.core.app.ApplicationProvider
import com.example.model.PaperSizePreset
import com.example.model.PdfRenderSource
import com.example.model.ShippingLabelData
import com.example.pdf.BarcodeVectorHelper
import com.example.pdf.ShippingLabelPdfGenerator
import com.example.ui.ShippingLabelScreen
import com.example.ui.components.applyHighContrastDocumentFilter
import com.example.ui.components.rotateBitmapIfNeeded
import com.example.ui.theme.MyApplicationTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun `app name matches Cetak Resi PDF`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Cetak Resi PDF", appName)
    }

    @Test
    fun `renderer draws non-blank pages across all paper presets and render sources`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val refBitmap = ShippingLabelPdfGenerator.loadReferenceBitmap(context)
        assertNotNull("Bundled reference_label.jpg asset must load", refBitmap)

        // Fake captured document bitmap with dark content
        val fakeCaptured = Bitmap.createBitmap(400, 600, Bitmap.Config.ARGB_8888).also { bmp ->
            val c = Canvas(bmp)
            c.drawColor(Color.DKGRAY)
        }
        val rotated = rotateBitmapIfNeeded(fakeCaptured, 90)
        assertEquals(600, rotated.width)
        assertEquals(400, rotated.height)

        val filtered = applyHighContrastDocumentFilter(fakeCaptured)
        assertEquals(400, filtered.width)

        val sampleData = ShippingLabelData.defaultFromReferenceImage()

        for (preset in PaperSizePreset.entries) {
            assertTrue("PDF widthPt must be positive", preset.widthPt > 100)
            assertTrue("PDF heightPt must be positive", preset.heightPt > 100)

            for (source in PdfRenderSource.entries) {
                val rendered = ShippingLabelPdfGenerator.renderPreviewBitmap(
                    data = sampleData,
                    paperPreset = preset,
                    renderSource = source,
                    referenceBitmap = refBitmap,
                    capturedBitmap = fakeCaptured,
                    targetWidthPx = 300
                )
                assertEquals(300, rendered.width)

                var hasInkPixels = false
                val step = 5
                var y = 0
                while (y < rendered.height && !hasInkPixels) {
                    var x = 0
                    while (x < rendered.width) {
                        if (rendered.getPixel(x, y) != Color.WHITE) {
                            hasInkPixels = true
                            break
                        }
                        x += step
                    }
                    y += step
                }
                assertTrue("Rendered page for $preset / $source must contain ink pixels", hasInkPixels)
            }
        }
    }

    @Test
    fun `barcode sanitization strips zero width unicode and caps length safely`() {
        val pastedWithZeroWidth = "\u200BJD0600216038\uFEFF\n"
        assertEquals("JD0600216038", BarcodeVectorHelper.sanitizeForCode128(pastedWithZeroWidth))

        val emptyOrEmojiOnly = "📦🚚"
        assertEquals("JD0600216038", BarcodeVectorHelper.sanitizeForCode128(emptyOrEmojiOnly))

        val overlong = "A".repeat(120)
        assertEquals(80, BarcodeVectorHelper.sanitizeForCode128(overlong).length)

        val extremeData = ShippingLabelData(
            waybillNumber = pastedWithZeroWidth,
            recipientAddress = "Jl.SangatPanjangTanpaSpasiSamaSekaliMelewatiBatasKotakResiPengiriman1234567890\nBaris Kedua\nBaris Ketiga\nBaris Keempat\nBaris Kelima",
            senderPhone = "********",
            notes = "Catatanbaris1\nCatatanbaris2\nCatatanbaris3"
        )
        val preview = ShippingLabelPdfGenerator.renderPreviewBitmap(
            data = extremeData,
            paperPreset = PaperSizePreset.THERMAL_100X200,
            renderSource = PdfRenderSource.VECTOR_RECONSTRUCTION,
            referenceBitmap = null,
            targetWidthPx = 400
        )
        assertEquals(400, preview.width)
        assertEquals(800, preview.height)
    }

    @Test
    fun `compose CUJ - camera capture navigation, compare mode, and edit label data flow`() {
        composeTestRule.setContent {
            MyApplicationTheme {
                ShippingLabelScreen()
            }
        }
        composeTestRule.waitForIdle()

        // Primary actions displayed in bottom bar
        composeTestRule.onNodeWithTag("print_pdf_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("save_pdf_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("share_pdf_button").assertIsDisplayed()

        // Navigate to CameraX Document Capture screen and back
        composeTestRule.onNodeWithTag("top_open_camera_button").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("camera_back_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("camera_back_button").performClick()
        composeTestRule.waitForIdle()

        // Scroll to A4 paper preset, select it, then scroll back up to toggle side-by-side comparison
        composeTestRule.onNodeWithTag("preset_a4").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("mode_compare_chip").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        // Open editor, modify recipient name, and apply
        composeTestRule.onNodeWithTag("top_edit_data_button").performClick()
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("input_recipient_name")
            .performScrollTo()
            .performTextReplacement("Budi Santoso")
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("editor_done_button").performClick()
        composeTestRule.waitForIdle()

        // Scroll to summary card and verify updated recipient name appears
        composeTestRule.onNodeWithText("Budi Santoso (PT MCDERMOTT)")
            .performScrollTo()
            .assertIsDisplayed()
    }
}
