---
name: youtube-shorts-bot
description: Proyek auto-konten YouTube Shorts: naskah via bot Telegram, diproses GitHub Actions, video dikirim balik ke Telegram
aliases: [auto shorts, bot telegram shorts, telegram-shorts-bot]
---

- ingin menghasilkan konten YouTube Shorts secara otomatis (auto content)
- sistem berjalan di GitHub: naskah diunggah lewat bot Telegram, GitHub memproses lalu mengirim hasilnya kembali ke Telegram
- memakai Python
- mengunggah ke GitHub lewat HP (mobile), ingin file zip diekstrak otomatis
