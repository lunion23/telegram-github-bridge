# PrintableReport Composable & Dynamic Image Layout Plan

A dedicated, modular Jetpack Compose component (`PrintableReport`) designed specifically for high-accuracy document print rendering and PDF preview. It enforces strict A4 proportion ratios, exact line weights, fixed print-safe margins, and calibrated font sizes across both Desain 1 (Dealer Standard) and Desain 2 (Hiba Group Image-Matched Format), while dynamically handling vehicle damage photos (rendering uploaded/picked photos or a crisp, clean empty box when omitted).

---

### User Review & Critical Decisions

> [!IMPORTANT]
> Based on your responses to the clarifying questions, the following critical decisions have been locked:
> - **Template Support**: `PrintableReport` will natively support **both Desain 1 (Standard Dealer) and Desain 2 (Hiba Group Image-Matched Form)** using a unified composable interface with a `templateOption` selector or automatic detection from `report.activeTemplate`.
> - **Empty Photo Container Styling**: When no image is input/uploaded by the user, the photo container will render as a **clean, crisp, empty white box framed with a solid 0.8dp black border** (avoiding messy placeholders or generic placeholder watermarks on official printouts).

- **Confirmed Decision 1**: Support both Desain 1 and Desain 2 within `PrintableReport` so any technical report can be viewed and printed with precise scaling.
- **Confirmed Decision 2**: Empty photo slots will remain completely plain, clean, and framed, maintaining professional engineering document integrity without clutter.
- **Open Action / Enhancement**: Provide an in-place "Import / Ganti Foto" button directly accessible from the preview screen in addition to the wizard, allowing users to attach or remove damage photos without leaving the preview.

---

### 1. Overview & Core Concept

- **What It Does**: Encapsulates the entire technical report visual layout into a reusable, standalone Composable named `PrintableReport`. It provides standard A4 document dimensions, calibrated typography, exact grid borders, and dynamic photo rendering (with or without imported media).
- **Target Audience / Persona**: Workshop foremen (*Mekanik / Kepala Bengkel*), fleet inspectors, and vehicle maintenance managers generating legal/official inspection records.
- **Key Value**: Guarantees that what the user sees on-screen matches the printed PDF page down to the millimeter, preventing text clipping, font mismatch, border bleed, or misaligned table cells.

---

### 2. User Experience & Visual Design

#### Key User Flows
1. **Interactive Preview**: In the *Pratinjau* tab, the user views the report rendered through `PrintableReport`. An interactive toggle allows switching between *Opsi 1 (Standar)* and *Opsi 2 (Sesuai Gambar)*.
2. **Image Import & Clean State**:
   - If an image has been selected via the Android Photo Picker or camera, `PrintableReport` scales and renders it within the designated "Foto Kerusakan" frame.
   - If no image is provided, `PrintableReport` displays a pristine white bordered frame, ready for physical photo attachment or clean stamping.
   - A quick "Pilih / Ganti Foto Kerusakan" button allows attaching a photo directly in the preview.
3. **Seamless Print / PDF Export**: Clicking "Prin PDF (Opsi 2)" or "Prin PDF (Opsi 1)" invokes Android `PrintManager` to print or save the document as a high-resolution PDF matching the composable layout.

#### Visual Styling & Layout Structure
- **Paper Frame**: Simulated A4 sheet elevation with 1dp slate border on screen, scaling cleanly across compact and tablet devices.
- **Outer Borders**:
  - *Desain 2*: Double outer black border (2.dp outer, 2.5.dp gap, 0.8.dp inner) matching the physical printed Hiba Group form.
  - *Desain 1*: Single crisp slate/navy border (1.5.dp) with clean blue section bars.
- **Typography Calibration**:
  - Title: 14sp–15sp Bold with uppercase styling.
  - Table Headers: 8.5sp–9sp Bold.
  - Cell Data & Checkmarks: 8.5sp–9.5sp Regular/Bold.
- **Photo Box**:
  - Exact 155dp vertical height aligned directly with the Uraian Kerusakan block.
  - `ContentScale.Crop` with rounded/sharp corners to ensure full coverage without distortion.

---

### 3. Key Product Decisions & Trade-Offs

#### Decision 1: Dedicated Standalone Composable File (`PrintableReport.kt`)
- **Chosen Approach**: Extract the print layout into `com.example.ui.components.PrintableReport`, rather than having it tied exclusively to `PreviewScreen.kt`.
- **Why**: Keeps UI code modular, testable, and reusable across multiple screens (e.g. PreviewScreen, print dialogs, or future PDF renderers).
- **Alternatives Considered**: Inlining the composable inside `PreviewScreen.kt`. Rejected because `PreviewScreen.kt` would become bloated and hard to maintain.

#### Decision 2: Zero-Permission Android Photo Picker Integration
- **Chosen Approach**: Use Android Jetpack `ActivityResultContracts.PickVisualMedia()` directly within Compose.
- **Why**: Google Play compliant, requires zero runtime storage permissions (`READ_EXTERNAL_STORAGE` is strictly avoided), and provides a native, secure OS photo selection sheet.

#### Decision 3: Image vs. Plain Container Behavior
- **Chosen Approach**: Condition on `report.damagePhotoUri.isNotBlank()`. If present and readable, decode bitmap and render with `Image(bitmap)`. If absent or blank, render `Box(Modifier.background(Color.White).border(0.8.dp, Color.Black))` with zero placeholder text or generic watermarks.
- **Why**: Matches user's explicit preference ("bila tida dinput gambar tampilan polos kosong bersih") and mirrors official physical forms.

---

### 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────┐
│                       UI Layer                              │
│                                                             │
│  ┌────────────────────────┐     ┌────────────────────────┐  │
│  │   FormWizardScreen     │     │     PreviewScreen      │  │
│  │  (Data Entry & Photo)  │     │  (Actions & Toolbar)   │  │
│  └───────────┬────────────┘     └───────────┬────────────┘  │
│              │                              │               │
│              ▼                              ▼               │
│  ┌───────────────────────────────────────────────────────┐  │
│  │             PrintableReport Composable                │  │
│  │                                                       │  │
│  │  ┌────────────────────────┐┌────────────────────────┐ │  │
│  │  │  PrintableHibaGroup    ││  PrintableStandard     │ │  │
│  │  │  (Desain 2: Gambar)    ││  (Desain 1: Standar)   │ │  │
│  │  │  - Double Frame        ││  - Clean Vertical Grid │ │  │
│  │  │  - Side-by-Side Photo  ││  - Section Dividers    │ │  │
│  │  │  - √ Checklist Table   ││  - Dynamic Photo Slot  │ │  │
│  │  └────────────────────────┘└────────────────────────┘ │  │
│  └───────────────────────────────────────────────────────┘  │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│                 Export & Persistence Engine                 │
│                                                             │
│   ┌─────────────────────┐       ┌──────────────────────┐    │
│   │    PdfExporter      │       │     AppDatabase      │    │
│   │  (Native Print &    │       │     (Room & DAO)     │    │
│   │   A4 PDF Document)  │       │                      │    │
│   └─────────────────────┘       └──────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

#### File Modifications Plan:
1. **Create `app/src/main/java/com/example/ui/components/PrintableReport.kt`**:
   - `PrintableReport(report, modifier, templateOption, onSelectPhoto)`
   - `PrintableHibaGroupReport(report, onSelectPhoto)`: Precise box-grid layout matching the document image, with side-by-side text/photo, dynamic image rendering (clean blank white box when none), checkmark tables, and signatures.
   - `PrintableStandardReport(report, onSelectPhoto)`: Modern dealer format with structured key-value tables and dynamic photo slot.
2. **Update `app/src/main/java/com/example/ui/screens/PreviewScreen.kt`**:
   - Embed `PrintableReport` directly into the paper card view.
   - Add image picker launcher so the user can import/change the photo right from the preview screen.
   - Maintain direct "Prin PDF (Opsi 2)", "Ekspor PDF", and "Ekspor Excel" buttons.
3. **Verify Build & Unit Tests**:
   - Run `compile_applet` and Robolectric unit tests to ensure zero compile or layout regressions.
