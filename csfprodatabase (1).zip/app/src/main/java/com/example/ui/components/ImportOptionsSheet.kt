package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DriveFolderUpload
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ImportMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImportOptionsSheet(
    onDismiss: () -> Unit,
    onPickFileSAF: (ImportMode) -> Unit,
    onPickDbFileSAF: (ImportMode) -> Unit,
    onExportDbSAF: () -> Unit,
    onLoadBundledAsset: (ImportMode) -> Unit,
    onLoadSample: (Int, ImportMode) -> Unit,
    onClearAllData: () -> Unit,
    sheetState: SheetState,
    modifier: Modifier = Modifier
) {
    var selectedMode by remember { mutableStateOf(ImportMode.UPDATE_EXISTING) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 6.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.DriveFolderUpload,
                            contentDescription = "Import & Kelola Data",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = "Kelola Data & Database",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Import CSV/Excel, cadangkan & pulihkan database SQLite (.db)",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Tutup")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // ========================================================
            // PANEL METODE SIMPAN FLEKSIBEL (UPDATE VS APPEND VS REPLACE)
            // ========================================================
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("import_mode_selector_card"),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "Metode Simpan Fleksibel:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Option 1: Update & Merge
                        FilterChip(
                            selected = selectedMode == ImportMode.UPDATE_EXISTING,
                            onClick = { selectedMode = ImportMode.UPDATE_EXISTING },
                            label = {
                                Text(
                                    text = "Perbarui",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Sync,
                                    contentDescription = null,
                                    modifier = Modifier.size(13.dp)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFFCCFBF1),
                                selectedLabelColor = Color(0xFF0F766E)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("select_mode_update")
                        )

                        // Option 2: Append
                        FilterChip(
                            selected = selectedMode == ImportMode.APPEND,
                            onClick = { selectedMode = ImportMode.APPEND },
                            label = {
                                Text(
                                    text = "Append",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.PlaylistAdd,
                                    contentDescription = null,
                                    modifier = Modifier.size(13.dp)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("select_mode_append")
                        )

                        // Option 3: Replace All
                        FilterChip(
                            selected = selectedMode == ImportMode.REPLACE_ALL,
                            onClick = { selectedMode = ImportMode.REPLACE_ALL },
                            label = {
                                Text(
                                    text = "Ganti DB",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.DeleteSweep,
                                    contentDescription = null,
                                    modifier = Modifier.size(13.dp)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.errorContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onErrorContainer
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("select_mode_replace")
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = when (selectedMode) {
                            ImportMode.UPDATE_EXISTING ->
                                "✓ Rekomendasi: Data yang sama (Nomor WO/item) akan diperbarui dengan data baru, data baru ditambahkan, dan data lama lainnya tetap aman tanpa dihapus."
                            ImportMode.APPEND ->
                                "✓ Data baru akan ditambahkan sebagai baris baru tanpa memperbarui data yang sudah ada."
                            ImportMode.REPLACE_ALL ->
                                "⚠ Perhatian: Seluruh database lama akan dikosongkan dan diganti bersih oleh data file ini."
                        },
                        fontSize = 10.sp,
                        color = when (selectedMode) {
                            ImportMode.UPDATE_EXISTING -> Color(0xFF0F766E)
                            ImportMode.APPEND -> Color(0xFF2E7D32)
                            ImportMode.REPLACE_ALL -> MaterialTheme.colorScheme.error
                        },
                        fontWeight = FontWeight.Medium,
                        lineHeight = 13.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            val modeShortLabel = when (selectedMode) {
                ImportMode.UPDATE_EXISTING -> "Perbarui Data Sama"
                ImportMode.APPEND -> "Append"
                ImportMode.REPLACE_ALL -> "Replace All"
            }

            // 1. Pick File SAF (.csv / .xlsx)
            ImportOptionCard(
                title = "Pilih File CSV / Excel (Dari HP)",
                subtitle = "Format .csv atau .xlsx (Metode: $modeShortLabel)",
                icon = Icons.Default.DriveFolderUpload,
                iconColor = MaterialTheme.colorScheme.primary,
                bgColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                testTag = "import_saf_file_option",
                onClick = {
                    onDismiss()
                    onPickFileSAF(selectedMode)
                }
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 2. Import SQLite Database (.db)
            ImportOptionCard(
                title = "Import Database SQLite (.db)",
                subtitle = "Pulihkan / gabungkan file .db (Metode: $modeShortLabel)",
                icon = Icons.Default.Storage,
                iconColor = Color(0xFF7C3AED),
                bgColor = Color(0xFFEDE9FE),
                testTag = "import_db_file_option",
                onClick = {
                    onDismiss()
                    onPickDbFileSAF(selectedMode)
                }
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 3. Export / Backup SQLite Database (.db)
            ImportOptionCard(
                title = "Cadangkan / Export Database (.db)",
                subtitle = "Simpan salinan database lengkap (.db) ke memori HP atau bagikan via WhatsApp / Drive",
                icon = Icons.Default.Storage,
                iconColor = Color(0xFF0D9488),
                bgColor = Color(0xFFCCFBF1),
                testTag = "export_db_file_option",
                onClick = {
                    onDismiss()
                    onExportDbSAF()
                }
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 4. Load Official CILEGONCSV.csv
            ImportOptionCard(
                title = "Muat CILEGONCSV.csv Asli (Resmi)",
                subtitle = "Dataset resmi bengkel armada Cilegon (33 baris lengkap) - Metode: $modeShortLabel",
                icon = Icons.Default.Description,
                iconColor = Color(0xFF0284C7),
                bgColor = Color(0xFFE0F2FE),
                testTag = "import_cilegon_official_option",
                onClick = {
                    onDismiss()
                    onLoadBundledAsset(selectedMode)
                }
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 5. Load 1,200 Sample Dataset
            ImportOptionCard(
                title = "Muat Sampel Cilegon (1.200 Baris)",
                subtitle = "Simulasi ribuan data armada logistik - Metode: $modeShortLabel",
                icon = Icons.Default.LocalShipping,
                iconColor = MaterialTheme.colorScheme.secondary,
                bgColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                testTag = "import_sample_1200_option",
                onClick = {
                    onDismiss()
                    onLoadSample(1200, selectedMode)
                }
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 6. Load 10,000 Stress Test
            ImportOptionCard(
                title = "Uji Beban Ekstrem (10.000 Baris)",
                subtitle = "Stress-test performa SQLite Room & Stream Parsing - Metode: $modeShortLabel",
                icon = Icons.Default.Speed,
                iconColor = Color(0xFF10B981),
                bgColor = Color(0xFFD1FAE5),
                testTag = "import_sample_10000_option",
                onClick = {
                    onDismiss()
                    onLoadSample(10000, selectedMode)
                }
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 7. Clear All Data
            ImportOptionCard(
                title = "Kosongkan Semua Data",
                subtitle = "Hapus seluruh riwayat data untuk memulai import bersih",
                icon = Icons.Default.DeleteSweep,
                iconColor = MaterialTheme.colorScheme.error,
                bgColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f),
                testTag = "clear_all_data_option",
                onClick = {
                    onDismiss()
                    onClearAllData()
                }
            )

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}

@Composable
private fun ImportOptionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconColor: Color,
    bgColor: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(bgColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = iconColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 15.sp
                )
            }
        }
    }
}
