package com.example.data.model

data class ImportProgress(
    val isImporting: Boolean = false,
    val processedRows: Long = 0L,
    val totalEstimatedRows: Long = 0L,
    val percentage: Int = 0,
    val currentSpeedRowsPerSec: Double = 0.0,
    val currentBatch: Int = 0,
    val statusText: String = "",
    val isCompleted: Boolean = false,
    val resultSummary: ImportResultSummary? = null,
    val error: String? = null
)

data class ImportResultSummary(
    val totalRowsInserted: Long,
    val totalWorkOrders: Int,
    val durationSeconds: Double,
    val filename: String,
    val mode: ImportMode = ImportMode.APPEND
)
