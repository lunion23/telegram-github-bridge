package com.example.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.example.model.TechnicalReport
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import kotlin.math.max
import kotlin.math.min

class TechnicalReportPdfGenerator(private val context: Context) {

    companion object {
        // A4 Dimensions in points (1190 x 1684 gives crisp 144 dpi rendering)
        const val PAGE_WIDTH = 1190
        const val PAGE_HEIGHT = 1684
    }

    /**
     * Generates a PDF file for the given technical report and returns the File.
     */
    fun generatePdf(report: TechnicalReport): File {
        val outputDir = File(context.filesDir, "reports")
        if (!outputDir.exists()) outputDir.mkdirs()

        val safeFilename = "Laporan_${report.reportNumber.replace("/", "_").replace(" ", "_")}_${report.id}.pdf"
        val pdfFile = File(outputDir, safeFilename)

        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = document.startPage(pageInfo)

        drawReportOnCanvas(page.canvas, report)

        document.finishPage(page)

        FileOutputStream(pdfFile).use { out ->
            document.writeTo(out)
        }
        document.close()

        return pdfFile
    }

    /**
     * Renders a Bitmap from the given PDF file using PdfRenderer for instant preview in Compose.
     */
    fun renderPdfToBitmap(pdfFile: File): Bitmap? {
        return try {
            val fileDescriptor = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
            val renderer = PdfRenderer(fileDescriptor)
            if (renderer.pageCount > 0) {
                val page = renderer.openPage(0)
                val bitmap = Bitmap.createBitmap(PAGE_WIDTH, PAGE_HEIGHT, Bitmap.Config.ARGB_8888)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()
                renderer.close()
                fileDescriptor.close()
                bitmap
            } else {
                renderer.close()
                fileDescriptor.close()
                null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun drawReportOnCanvas(canvas: Canvas, report: TechnicalReport) {
        // Draw white background
        val bgPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, PAGE_WIDTH.toFloat(), PAGE_HEIGHT.toFloat(), bgPaint)

        // Setup paints
        val linePaint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 2.5f
            isAntiAlias = true
        }

        val thinLinePaint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
            isAntiAlias = true
        }

        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 20f
            isAntiAlias = true
        }

        val textBold = Paint().apply {
            color = Color.BLACK
            textSize = 22f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val titlePaint = Paint().apply {
            color = Color.BLACK
            textSize = 34f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val smallText = Paint().apply {
            color = Color.BLACK
            textSize = 17f
            isAntiAlias = true
        }

        val smallBold = Paint().apply {
            color = Color.BLACK
            textSize = 17f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val margin = 40f
        val rightEdge = PAGE_WIDTH - margin
        val leftEdge = margin
        val contentWidth = rightEdge - leftEdge

        // Outer border
        val outerTop = 40f
        val outerBottom = PAGE_HEIGHT - 40f
        canvas.drawRect(leftEdge, outerTop, rightEdge, outerBottom, linePaint)

        // ================= HEADER SECTION =================
        val headerHeight = 150f
        val headerBottom = outerTop + headerHeight
        canvas.drawLine(leftEdge, headerBottom, rightEdge, headerBottom, linePaint)

        // Divider between Logo/Title and Top Right Info Box
        val topRightBoxWidth = 370f
        val splitHeaderX = rightEdge - topRightBoxWidth
        canvas.drawLine(splitHeaderX, outerTop, splitHeaderX, headerBottom, linePaint)

        // Company Emblem icon
        val logoCenterY = outerTop + headerHeight / 2
        val logoCirclePaint = Paint().apply {
            color = Color.DKGRAY
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawCircle(leftEdge + 45f, logoCenterY, 24f, logoCirclePaint)

        val logoInnerPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawCircle(leftEdge + 45f, logoCenterY - 4f, 10f, logoInnerPaint)

        // Company text
        val compPaint = Paint().apply {
            color = Color.BLACK
            textSize = 30f
            isFakeBoldText = true
            isAntiAlias = true
        }
        canvas.drawText(report.companyName, leftEdge + 80f, logoCenterY + 10f, compPaint)

        // Title: LAPORAN TEKNIK (centered in the remaining space of left header)
        val titleText = report.reportTitle
        val titleWidth = titlePaint.measureText(titleText)
        val titleX = leftEdge + 280f + (splitHeaderX - (leftEdge + 280f) - titleWidth) / 2
        canvas.drawText(titleText, titleX, logoCenterY + 11f, titlePaint)

        // Top Right Info Grid (5 rows: No.Laporan, Bengkel, Tanggal, Nama Alat, Komponen)
        val infoRowHeight = headerHeight / 5
        val infoLabels = listOf("No.Laporan", "Bengkel", "Tanggal", "Nama Alat", "Komponen")
        val infoValues = listOf(
            report.reportNumber,
            report.workshop,
            report.date,
            report.toolName,
            report.component
        )

        val labelColWidth = 145f
        canvas.drawLine(splitHeaderX + labelColWidth, outerTop, splitHeaderX + labelColWidth, headerBottom, thinLinePaint)

        for (i in 0 until 5) {
            val yTop = outerTop + (i * infoRowHeight)
            if (i > 0) {
                canvas.drawLine(splitHeaderX, yTop, rightEdge, yTop, thinLinePaint)
            }
            val textBaseline = yTop + infoRowHeight - 8f
            canvas.drawText(infoLabels[i], splitHeaderX + 10f, textBaseline, smallBold)
            canvas.drawText(infoValues[i], splitHeaderX + labelColWidth + 10f, textBaseline, smallText)
        }

        // ================= VEHICLE SPECS BAR (3 ROWS) =================
        val specsY1 = headerBottom
        val specsRowHeight = 36f
        val specsY2 = specsY1 + specsRowHeight
        val specsBottom = specsY2 + specsRowHeight
        canvas.drawLine(leftEdge, specsY2, rightEdge, specsY2, thinLinePaint)
        canvas.drawLine(leftEdge, specsBottom, rightEdge, specsBottom, linePaint)

        // Row 1: Pabrik Pembuat | [HINO] | Tipe | [DUTRO]
        val colW1 = 195f
        val colW2 = 345f
        val colW3 = 180f

        val xA1 = leftEdge + colW1
        val xA2 = xA1 + colW2
        val xA3 = xA2 + colW3

        canvas.drawLine(xA1, specsY1, xA1, specsBottom, thinLinePaint)
        canvas.drawLine(xA2, specsY1, xA2, specsBottom, thinLinePaint)
        canvas.drawLine(xA3, specsY1, xA3, specsBottom, thinLinePaint)

        // Row 1 Text
        canvas.drawText("Pabrik Pembuat", leftEdge + 10f, specsY1 + 25f, smallBold)
        canvas.drawText(report.manufacturer, xA1 + 10f, specsY1 + 25f, textBold)
        canvas.drawText("Tipe", xA2 + 10f, specsY1 + 25f, smallBold)
        canvas.drawText(report.vehicleType, xA3 + 10f, specsY1 + 25f, textBold)

        // Row 2 Text: Model | [W04DTPJ-53447] | Kode | [D127]
        canvas.drawText("Model", leftEdge + 10f, specsY2 + 25f, smallBold)
        canvas.drawText(report.model, xA1 + 10f, specsY2 + 25f, textBold)
        canvas.drawText("Kode", xA2 + 10f, specsY2 + 25f, smallBold)
        canvas.drawText(report.unitCode, xA3 + 10f, specsY2 + 25f, textBold)

        // Row 3: Tanggal Rusak & Km / Hm
        val specsY3 = specsBottom
        val specsY4 = specsY3 + specsRowHeight
        canvas.drawLine(leftEdge, specsY4, rightEdge, specsY4, linePaint)
        canvas.drawLine(xA1, specsY3, xA1, specsY4, thinLinePaint)
        canvas.drawLine(xA2, specsY3, xA2, specsY4, thinLinePaint)
        canvas.drawLine(xA3, specsY3, xA3, specsY4, thinLinePaint)

        canvas.drawText("Tanggal Rusak", leftEdge + 10f, specsY3 + 25f, smallBold)
        canvas.drawText(report.damageDate, xA1 + 10f, specsY3 + 25f, smallText)
        canvas.drawText("Km / Hm", xA2 + 10f, specsY3 + 25f, smallBold)
        canvas.drawText(report.odometer, xA3 + 10f, specsY3 + 25f, textBold)

        // ================= URAIAN KERUSAKAN BAR =================
        val uraianHeaderY = specsY4
        val uraianHeaderBottom = uraianHeaderY + 36f
        canvas.drawLine(leftEdge, uraianHeaderBottom, rightEdge, uraianHeaderBottom, linePaint)
        canvas.drawLine(xA1, uraianHeaderY, xA1, uraianHeaderBottom, thinLinePaint)

        canvas.drawText("Uraian Kerusakan", leftEdge + 10f, uraianHeaderY + 25f, smallBold)

        // Warranty Checkboxes: Masa Garansi | Setelah Masa Garansi
        val isMasaGaransi = report.warrantyStatus == "MASA_GARANSI"
        drawVectorCheckbox(canvas, xA1 + 20f, uraianHeaderY + 8f, 20f, isMasaGaransi, thinLinePaint)
        canvas.drawText("Masa Garansi", xA1 + 48f, uraianHeaderY + 25f, smallBold)

        val isSetelahGaransi = report.warrantyStatus == "SETELAH_GARANSI"
        drawVectorCheckbox(canvas, xA1 + 250f, uraianHeaderY + 8f, 20f, isSetelahGaransi, thinLinePaint)
        canvas.drawText("Setelah Masa Garansi", xA1 + 278f, uraianHeaderY + 25f, smallBold)

        // Section details (Split Left: text & analysis, Right: Foto Kerusakan)
        val detailsY = uraianHeaderBottom
        val detailsHeight = 440f
        val detailsBottom = detailsY + detailsHeight
        canvas.drawLine(leftEdge, detailsBottom, rightEdge, detailsBottom, linePaint)

        val photoColWidth = 420f
        val splitDetailsX = rightEdge - photoColWidth
        canvas.drawLine(splitDetailsX, detailsY, splitDetailsX, detailsBottom, linePaint)

        // Left Side Content
        var currY = detailsY + 32f
        canvas.drawText("Tanggal   : ${report.date}", leftEdge + 15f, currY, smallText)
        canvas.drawText("Status : ${report.status}", leftEdge + 340f, currY, smallBold)

        currY += 32f
        canvas.drawText("Kerusakan : ${report.damageDescription}", leftEdge + 15f, currY, smallBold)
        canvas.drawText("Lokasi : ${report.damageLocation}", leftEdge + 340f, currY, smallText)

        currY += 36f
        canvas.drawText("Analisa   :", leftEdge + 15f, currY, smallBold)
        currY += 26f
        // Draw wrapped analysis text
        val analysisLines = wrapText(report.analysis, textPaint, splitDetailsX - leftEdge - 40f)
        for (line in analysisLines.take(6)) {
            canvas.drawText(line, leftEdge + 15f, currY, textPaint)
            currY += 26f
        }

        // Kesimpulan block
        currY = detailsY + 280f
        canvas.drawText("Kesimpulan : Penggantian terakhir : ${report.lastReplacement}", leftEdge + 15f, currY, smallBold)
        currY += 30f
        canvas.drawText("No. Work Order", leftEdge + 140f, currY, smallText)
        canvas.drawText(": ${report.lastReplacementWo}", leftEdge + 360f, currY, smallText)
        currY += 30f
        canvas.drawText("Weekly terakhir", leftEdge + 140f, currY, smallText)
        canvas.drawText(": ${report.lastWeekly}", leftEdge + 360f, currY, smallText)
        currY += 30f
        canvas.drawText("No. Work Order", leftEdge + 140f, currY, smallText)
        canvas.drawText(": ${report.lastWeeklyWo}", leftEdge + 360f, currY, smallText)

        // Right Side: Foto Kerusakan
        canvas.drawText("Foto Kerusakan :", splitDetailsX + 15f, detailsY + 30f, smallBold)
        val photoRect = RectF(splitDetailsX + 15f, detailsY + 45f, rightEdge - 15f, detailsBottom - 15f)
        canvas.drawRect(photoRect, thinLinePaint)

        // Draw photo with aspect-ratio preservation
        drawPhotoInsideRect(canvas, report.photoPath, photoRect)

        // ================= PENYEBAB KERUSAKAN =================
        val causeHeaderY = detailsBottom
        val causeBarHeight = 32f
        val causeBarBottom = causeHeaderY + causeBarHeight
        canvas.drawLine(leftEdge, causeBarBottom, rightEdge, causeBarBottom, linePaint)

        val causeSplitX = leftEdge + 460f
        canvas.drawLine(causeSplitX, causeHeaderY, causeSplitX, causeHeaderY + 160f, linePaint)

        canvas.drawText("Penyebab Kerusakan :  √ = YA   X = TIDAK", leftEdge + 10f, causeHeaderY + 22f, smallBold)
        canvas.drawText("......................jika YA, tolong jelaskan!", causeSplitX + 15f, causeHeaderY + 22f, smallText)

        // Causes Checkboxes (5 rows)
        val causesY = causeBarBottom
        val causeRowH = 26f
        val causeList = listOf(
            Pair("1. Pemasangan", report.causePemasangan),
            Pair("2. Kwalitas Parts", report.causeKwalitasParts),
            Pair("3. Kesalahan Operasional", report.causeKesalahanOperasional),
            Pair("4. Sudah waktunya", report.causeSudahWaktunya),
            Pair("5. Lain-lain", report.causeLainLain)
        )

        for (i in causeList.indices) {
            val (label, checked) = causeList[i]
            val cY = causesY + (i * causeRowH)
            canvas.drawText(label, leftEdge + 15f, cY + 20f, smallText)
            drawVectorCheckbox(canvas, causeSplitX - 45f, cY + 4f, 18f, checked, thinLinePaint)
            if (i < 4) {
                canvas.drawLine(leftEdge, cY + causeRowH, causeSplitX, cY + causeRowH, thinLinePaint)
            }
        }

        // Cause explanation text
        val causeExplLines = wrapText(report.causeExplanation, textPaint, rightEdge - causeSplitX - 30f)
        var explY = causeBarBottom + 30f
        for (line in causeExplLines.take(4)) {
            canvas.drawText(line, causeSplitX + 20f, explY, textPaint)
            explY += 26f
        }

        val causesBottom = causesY + (5 * causeRowH)
        canvas.drawLine(leftEdge, causesBottom, rightEdge, causesBottom, linePaint)

        // ================= CARA MENGATASI KERUSAKAN =================
        val solutionTop = causesBottom
        val solutionHeaderH = 30f
        val solutionHeaderBottom = solutionTop + solutionHeaderH
        canvas.drawLine(leftEdge, solutionHeaderBottom, rightEdge, solutionHeaderBottom, linePaint)
        canvas.drawText("Cara mengatasi kerusakan :", leftEdge + 380f, solutionTop + 22f, smallBold)

        val solRowH = 26f
        val solBottom = solutionHeaderBottom + (3 * solRowH)
        canvas.drawLine(leftEdge, solBottom, rightEdge, solBottom, linePaint)
        canvas.drawLine(causeSplitX, solutionHeaderBottom, causeSplitX, solBottom, linePaint)

        val solList = listOf(
            Pair("1. Ganti Part Baru", report.solutionGantiPartBaru),
            Pair("2. Pemasangan atau Penyetelan Ulang", report.solutionPemasanganUlang),
            Pair("3. Modifikasi", report.solutionModifikasi)
        )

        for (i in solList.indices) {
            val (label, checked) = solList[i]
            val sY = solutionHeaderBottom + (i * solRowH)
            canvas.drawText(label, leftEdge + 15f, sY + 20f, smallText)
            drawVectorCheckbox(canvas, causeSplitX - 45f, sY + 4f, 18f, checked, thinLinePaint)
            if (i < 2) {
                canvas.drawLine(leftEdge, sY + solRowH, causeSplitX, sY + solRowH, thinLinePaint)
            }
        }

        // Action text on right (e.g. Ganti ban stip)
        val actText = report.solutionActionText
        val actX = causeSplitX + (rightEdge - causeSplitX - textBold.measureText(actText)) / 2
        canvas.drawText(actText, max(causeSplitX + 10f, actX), solutionHeaderBottom + 45f, textBold)

        // ================= TERTUNDA KARENA & USULAN PELAPOR =================
        val delayTop = solBottom
        val delayHeaderH = 30f
        val delayHeaderBottom = delayTop + delayHeaderH
        canvas.drawLine(leftEdge, delayHeaderBottom, rightEdge, delayHeaderBottom, linePaint)
        canvas.drawLine(causeSplitX, delayTop, causeSplitX, delayTop + 100f, linePaint)

        canvas.drawText("Tertunda Karena", leftEdge + 140f, delayTop + 22f, smallBold)
        canvas.drawText("Usulan Pelapor", causeSplitX + 220f, delayTop + 22f, smallBold)

        val delayContentBottom = delayTop + 100f
        canvas.drawLine(leftEdge, delayContentBottom, rightEdge, delayContentBottom, linePaint)

        // Delayed Reason Text
        if (report.delayedReason.isNotEmpty()) {
            val delayLines = wrapText(report.delayedReason, smallText, causeSplitX - leftEdge - 30f)
            var dY = delayHeaderBottom + 25f
            for (line in delayLines.take(3)) {
                canvas.drawText(line, leftEdge + 15f, dY, smallText)
                dY += 22f
            }
        }

        // Suggestion Text
        val suggLines = wrapText(report.reporterSuggestion, smallText, rightEdge - causeSplitX - 30f)
        var sY = delayHeaderBottom + 25f
        for (line in suggLines.take(3)) {
            canvas.drawText(line, causeSplitX + 15f, sY, smallText)
            sY += 22f
        }

        // ================= PARTS YANG HARUS DIGANTI TABLE =================
        val partsTop = delayContentBottom
        val partsBarH = 30f
        val partsBarBottom = partsTop + partsBarH
        canvas.drawLine(leftEdge, partsBarBottom, rightEdge, partsBarBottom, linePaint)
        canvas.drawText("Parts yang harus diganti :", leftEdge + 10f, partsTop + 22f, smallBold)

        // Table Header: No | No Parts | Nama Parts | Jenis Pengadaan Part (Stock, Order, Modifikasi, Pending)
        val tableHeaderY = partsBarBottom
        val tableHeaderH = 46f
        val tableHeaderBottom = tableHeaderY + tableHeaderH
        canvas.drawLine(leftEdge, tableHeaderBottom, rightEdge, tableHeaderBottom, linePaint)

        val pNoW = 45f
        val pNoPartW = 190f
        val pNameW = 285f
        val pTypeColW = (contentWidth - (pNoW + pNoPartW + pNameW)) / 4

        val colX1 = leftEdge + pNoW
        val colX2 = colX1 + pNoPartW
        val colX3 = colX2 + pNameW
        val colX4 = colX3 + pTypeColW
        val colX5 = colX4 + pTypeColW
        val colX6 = colX5 + pTypeColW

        // Vertical lines for parts table
        val partsTableBottom = tableHeaderBottom + (5 * 28f)
        canvas.drawLine(colX1, tableHeaderY, colX1, partsTableBottom, thinLinePaint)
        canvas.drawLine(colX2, tableHeaderY, colX2, partsTableBottom, thinLinePaint)
        canvas.drawLine(colX3, tableHeaderY, colX3, partsTableBottom, linePaint)
        canvas.drawLine(colX4, tableHeaderY + 22f, colX4, partsTableBottom, thinLinePaint)
        canvas.drawLine(colX5, tableHeaderY + 22f, colX5, partsTableBottom, thinLinePaint)
        canvas.drawLine(colX6, tableHeaderY + 22f, colX6, partsTableBottom, thinLinePaint)

        // Table Header labels
        canvas.drawText("No", leftEdge + 12f, tableHeaderY + 30f, smallBold)
        canvas.drawText("No Parts", colX1 + 55f, tableHeaderY + 30f, smallBold)
        canvas.drawText("Nama Parts", colX2 + 80f, tableHeaderY + 30f, smallBold)

        // Jenis Pengadaan Part span
        canvas.drawLine(colX3, tableHeaderY + 22f, rightEdge, tableHeaderY + 22f, thinLinePaint)
        canvas.drawText("Jenis Pengadaan Part", colX3 + 180f, tableHeaderY + 18f, smallBold)

        val typeSubLabels = listOf("Stock", "Order", "Modifikasi", "Pending")
        val typeCols = listOf(colX3, colX4, colX5, colX6)
        for (i in 0 until 4) {
            val label = typeSubLabels[i]
            val xStart = typeCols[i]
            val xCenter = xStart + (pTypeColW - smallBold.measureText(label)) / 2
            canvas.drawText(label, xCenter, tableHeaderY + 40f, smallBold)
        }

        // Table Rows (1 to 5)
        val rowH = 28f
        for (i in 0 until 5) {
            val rY = tableHeaderBottom + (i * rowH)
            val rBottom = rY + rowH
            canvas.drawLine(leftEdge, rBottom, rightEdge, rBottom, thinLinePaint)

            canvas.drawText("${i + 1}", leftEdge + 18f, rY + 20f, smallText)

            if (i < report.parts.size) {
                val part = report.parts[i]
                canvas.drawText(truncateText(part.partNumber, smallText, pNoPartW - 15f), colX1 + 10f, rY + 20f, smallText)
                canvas.drawText(truncateText(part.partName, smallText, pNameW - 15f), colX2 + 10f, rY + 20f, smallText)

                // Checkmark in corresponding procurement column
                val colIndex = when (part.procurementType.lowercase()) {
                    "stock" -> 0
                    "order" -> 1
                    "modifikasi" -> 2
                    "pending" -> 3
                    else -> 0
                }
                val checkX = typeCols[colIndex] + (pTypeColW / 2) - 9f
                drawVectorCheckmark(canvas, checkX, rY + 6f, 18f)
            }
        }
        canvas.drawLine(leftEdge, partsTableBottom, rightEdge, partsTableBottom, linePaint)

        // ================= SIGNATURE & FOOTER SECTION =================
        val signTop = partsTableBottom
        val signBottom = outerBottom
        val signSplitX = rightEdge - 420f
        canvas.drawLine(signSplitX, signTop, signSplitX, signBottom, linePaint)

        // Left Signature: "Mengetahui,"
        canvas.drawText("Mengetahui,", leftEdge + 240f, signTop + 24f, smallBold)
        val signLineY = signBottom - 25f
        canvas.drawText("(...................................)", leftEdge + 90f, signLineY, smallText)
        canvas.drawText("(...................................)", leftEdge + 350f, signLineY, smallText)

        // Right Signature: "Dilaporkan Oleh:"
        canvas.drawText("Dilaporkan Oleh:", signSplitX + 110f, signTop + 24f, smallBold)
        canvas.drawLine(signSplitX, signTop + 32f, rightEdge, signTop + 32f, thinLinePaint)

        val repSplitX = signSplitX + 100f
        canvas.drawLine(repSplitX, signTop + 32f, repSplitX, signTop + 88f, thinLinePaint)

        canvas.drawText("Nama", signSplitX + 15f, signTop + 54f, smallBold)
        canvas.drawText(": ${report.reporterName}", repSplitX + 15f, signTop + 54f, smallText)
        canvas.drawLine(signSplitX, signTop + 60f, rightEdge, signTop + 60f, thinLinePaint)

        canvas.drawText("Jabatan", signSplitX + 15f, signTop + 82f, smallBold)
        canvas.drawText(": ${report.reporterTitle}", repSplitX + 15f, signTop + 82f, smallText)
        canvas.drawLine(signSplitX, signTop + 88f, rightEdge, signTop + 88f, linePaint)

        canvas.drawText("(...................................)", signSplitX + 190f, signLineY, smallText)
    }

    private fun drawVectorCheckbox(canvas: Canvas, x: Float, y: Float, size: Float, checked: Boolean, paint: Paint) {
        val rect = RectF(x, y, x + size, y + size)
        canvas.drawRect(rect, paint)
        if (checked) {
            drawVectorCheckmark(canvas, x + 2f, y + 2f, size - 4f)
        }
    }

    private fun drawVectorCheckmark(canvas: Canvas, x: Float, y: Float, size: Float) {
        val checkPaint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 2.5f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            isAntiAlias = true
        }
        val path = Path().apply {
            moveTo(x + (size * 0.15f), y + (size * 0.55f))
            lineTo(x + (size * 0.42f), y + (size * 0.85f))
            lineTo(x + (size * 0.88f), y + (size * 0.15f))
        }
        canvas.drawPath(path, checkPaint)
    }

    private fun drawPhotoInsideRect(canvas: Canvas, photoPath: String?, rect: RectF) {
        val bitmap = loadBitmapFromPath(photoPath)
        if (bitmap != null) {
            // Center crop into rect preserving aspect ratio
            val srcAspect = bitmap.width.toFloat() / bitmap.height
            val dstAspect = rect.width() / rect.height()

            val srcRect = if (srcAspect > dstAspect) {
                // Image is wider than dst -> crop sides
                val targetW = (bitmap.height * dstAspect).toInt()
                val left = (bitmap.width - targetW) / 2
                Rect(left, 0, left + targetW, bitmap.height)
            } else {
                // Image is taller than dst -> crop top/bottom
                val targetH = (bitmap.width / dstAspect).toInt()
                val top = (bitmap.height - targetH) / 2
                Rect(0, top, bitmap.width, top + targetH)
            }
            canvas.drawBitmap(bitmap, srcRect, rect, null)
        } else {
            val hintPaint = Paint().apply {
                color = Color.GRAY
                textSize = 18f
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("[ Foto Kerusakan ]", rect.centerX(), rect.centerY(), hintPaint)
        }
    }

    private fun loadBitmapFromPath(path: String?): Bitmap? {
        if (path.isNullOrEmpty()) return null
        return try {
            when {
                path == "sample_damage.jpg" || path.contains("sample_damage") -> {
                    // Try assets first
                    try {
                        context.assets.open("sample_damage.jpg").use { input ->
                            BitmapFactory.decodeStream(input)
                        }
                    } catch (_: Exception) {
                        // Fallback to internal file or direct decode
                        val f = File(path)
                        if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
                    }
                }
                path.startsWith("/") -> {
                    val file = File(path)
                    if (file.exists()) BitmapFactory.decodeFile(file.absolutePath) else null
                }
                path.startsWith("public/") -> {
                    val file = File(path)
                    if (file.exists()) BitmapFactory.decodeFile(file.absolutePath) else null
                }
                else -> {
                    val file = File(context.filesDir, path)
                    if (file.exists()) BitmapFactory.decodeFile(file.absolutePath) else null
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun truncateText(text: String, paint: Paint, maxWidth: Float): String {
        if (paint.measureText(text) <= maxWidth) return text
        var truncated = text
        while (truncated.isNotEmpty() && paint.measureText("$truncated...") > maxWidth) {
            truncated = truncated.dropLast(1)
        }
        return if (truncated.isEmpty()) "" else "$truncated..."
    }

    private fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
        if (text.isEmpty()) return emptyList()
        val result = mutableListOf<String>()
        val paragraphs = text.split("\n")
        for (paragraph in paragraphs) {
            val words = paragraph.split(" ")
            var currentLine = StringBuilder()
            for (word in words) {
                val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
                if (paint.measureText(testLine) <= maxWidth) {
                    currentLine = StringBuilder(testLine)
                } else {
                    if (currentLine.isNotEmpty()) {
                        result.add(currentLine.toString())
                    }
                    currentLine = StringBuilder(word)
                }
            }
            if (currentLine.isNotEmpty()) {
                result.add(currentLine.toString())
            }
        }
        return result
    }
}
