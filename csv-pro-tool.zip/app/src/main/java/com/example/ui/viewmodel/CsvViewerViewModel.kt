package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ColumnConfigEntity
import com.example.data.model.ConsolidatedCardItem
import com.example.data.model.CsvRowEntity
import com.example.data.model.FilterCriteria
import com.example.data.repository.CsvRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ViewDisplayMode {
    CONSOLIDATED_CARDS,
    SPREADSHEET_TABLE
}

class CsvViewerViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = CsvRepository(application.applicationContext)

    private val _rowCount = MutableStateFlow(0)
    val rowCount: StateFlow<Int> = _rowCount.asStateFlow()

    val columnConfigs: StateFlow<List<ColumnConfigEntity>> = repository.columnConfigs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _distinctStatuses = MutableStateFlow<List<String>>(emptyList())
    val distinctStatuses: StateFlow<List<String>> = _distinctStatuses.asStateFlow()

    private val _distinctCategories = MutableStateFlow<List<String>>(emptyList())
    val distinctCategories: StateFlow<List<String>> = _distinctCategories.asStateFlow()

    private val _displayMode = MutableStateFlow(ViewDisplayMode.CONSOLIDATED_CARDS)
    val displayMode: StateFlow<ViewDisplayMode> = _displayMode.asStateFlow()

    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _filterCriteria = MutableStateFlow(FilterCriteria())
    val filterCriteria: StateFlow<FilterCriteria> = _filterCriteria.asStateFlow()

    // Pagination
    private val _currentPage = MutableStateFlow(0)
    val currentPage: StateFlow<Int> = _currentPage.asStateFlow()

    private val _totalFilteredCount = MutableStateFlow(0)
    val totalFilteredCount: StateFlow<Int> = _totalFilteredCount.asStateFlow()

    private val _pageSize = 100
    val pageSize: Int get() = _pageSize

    private val _consolidatedGroups = MutableStateFlow<List<ConsolidatedCardItem>>(emptyList())
    val consolidatedGroups: StateFlow<List<ConsolidatedCardItem>> = _consolidatedGroups.asStateFlow()

    private val _spreadsheetRows = MutableStateFlow<List<CsvRowEntity>>(emptyList())
    val spreadsheetRows: StateFlow<List<CsvRowEntity>> = _spreadsheetRows.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _progressMessage = MutableStateFlow<String?>(null)
    val progressMessage: StateFlow<String?> = _progressMessage.asStateFlow()

    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    // Dialog & Sheet States
    private val _showFilterDialog = MutableStateFlow(false)
    val showFilterDialog: StateFlow<Boolean> = _showFilterDialog.asStateFlow()

    private val _showColumnManagerDialog = MutableStateFlow(false)
    val showColumnManagerDialog: StateFlow<Boolean> = _showColumnManagerDialog.asStateFlow()

    private val _showAddRowDialog = MutableStateFlow(false)
    val showAddRowDialog: StateFlow<Boolean> = _showAddRowDialog.asStateFlow()

    private val _editingRow = MutableStateFlow<CsvRowEntity?>(null)
    val editingRow: StateFlow<CsvRowEntity?> = _editingRow.asStateFlow()

    private val _showExportDialog = MutableStateFlow(false)
    val showExportDialog: StateFlow<Boolean> = _showExportDialog.asStateFlow()

    private val _showHelpGuide = MutableStateFlow(false)
    val showHelpGuide: StateFlow<Boolean> = _showHelpGuide.asStateFlow()

    // Flexible Import Option (Append vs Replace All)
    private val _pendingImportUri = MutableStateFlow<Uri?>(null)
    val pendingImportUri: StateFlow<Uri?> = _pendingImportUri.asStateFlow()

    private val _showImportMethodDialog = MutableStateFlow(false)
    val showImportMethodDialog: StateFlow<Boolean> = _showImportMethodDialog.asStateFlow()

    private var filterJob: Job? = null

    init {
        viewModelScope.launch {
            repository.initializeDefaultsIfNeeded()
            refreshData()
        }
    }

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    fun toggleDisplayMode() {
        _displayMode.value = if (_displayMode.value == ViewDisplayMode.CONSOLIDATED_CARDS) {
            ViewDisplayMode.SPREADSHEET_TABLE
        } else {
            ViewDisplayMode.CONSOLIDATED_CARDS
        }
    }

    // 2 Search Columns
    fun updateSearchQuery(query: String) {
        _filterCriteria.value = _filterCriteria.value.copy(searchQuery = query)
        _currentPage.value = 0
        debounceRefresh()
    }

    fun updateSearchColumn2Index(colIndex: Int) {
        _filterCriteria.value = _filterCriteria.value.copy(searchColumn2Index = colIndex)
        _currentPage.value = 0
        debounceRefresh()
    }

    fun updateSearchQuery2(query: String) {
        _filterCriteria.value = _filterCriteria.value.copy(searchQuery2 = query)
        _currentPage.value = 0
        debounceRefresh()
    }

    fun clearSearch2() {
        _filterCriteria.value = _filterCriteria.value.copy(searchQuery2 = "")
        _currentPage.value = 0
        debounceRefresh()
    }

    fun setColumnFilter(colIndex: Int, text: String) {
        val updated = _filterCriteria.value.columnFilters.toMutableMap()
        if (text.isBlank()) {
            updated.remove(colIndex)
        } else {
            updated[colIndex] = text
        }
        _filterCriteria.value = _filterCriteria.value.copy(columnFilters = updated)
        _currentPage.value = 0
        refreshData()
    }

    fun setStatusFilter(status: String?) {
        _filterCriteria.value = _filterCriteria.value.copy(statusFilter = status)
        _currentPage.value = 0
        refreshData()
    }

    fun setCategoryFilter(category: String?) {
        _filterCriteria.value = _filterCriteria.value.copy(categoryFilter = category)
        _currentPage.value = 0
        refreshData()
    }

    fun setSortColumn(colIndex: Int) {
        val current = _filterCriteria.value
        val isAsc = if (current.sortColumnIndex == colIndex) !current.isSortAscending else true
        _filterCriteria.value = current.copy(sortColumnIndex = colIndex, isSortAscending = isAsc)
        refreshData()
    }

    fun clearAllFilters() {
        _filterCriteria.value = FilterCriteria()
        _currentPage.value = 0
        refreshData()
    }

    fun nextPage() {
        val maxPage = if (_totalFilteredCount.value > 0) (_totalFilteredCount.value - 1) / _pageSize else 0
        if (_currentPage.value < maxPage) {
            _currentPage.value += 1
            refreshData()
        }
    }

    fun previousPage() {
        if (_currentPage.value > 0) {
            _currentPage.value -= 1
            refreshData()
        }
    }

    private fun debounceRefresh() {
        filterJob?.cancel()
        filterJob = viewModelScope.launch {
            delay(250)
            refreshData()
        }
    }

    fun refreshData() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                // Update total row count & filter options
                _rowCount.value = repository.getRowCount()
                _distinctStatuses.value = repository.getDistinctStatuses()
                _distinctCategories.value = repository.getDistinctCategories()

                val currentFilter = _filterCriteria.value
                val page = _currentPage.value

                // 1. Fetch paged spreadsheet rows
                val (rows, total) = repository.getPagedFilteredRows(currentFilter, page = page, pageSize = _pageSize)
                _spreadsheetRows.value = rows
                _totalFilteredCount.value = total

                // 2. Fetch paged consolidated cards
                val groups = repository.getPagedConsolidatedGroups(currentFilter, page = page, pageSize = 50)
                _consolidatedGroups.value = groups
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isLoading.value = false
            }
        }
    }

    // Lazy load child rows when accordion is clicked
    fun loadChildRowsForGroup(recordId: String) {
        viewModelScope.launch {
            try {
                val childRows = repository.getChildRowsForCard(recordId)
                _consolidatedGroups.value = _consolidatedGroups.value.map { group ->
                    if (group.recordId == recordId) {
                        group.copy(rows = childRows, isRowsLoaded = true)
                    } else {
                        group
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Dynamic Column Addition & Deletion
    fun addNewColumn(name: String) {
        viewModelScope.launch {
            try {
                repository.addNewColumn(name)
                refreshData()
                _userMessage.value = "Kolom \"$name\" berhasil ditambahkan!"
            } catch (e: Exception) {
                _userMessage.value = "Gagal menambah kolom: ${e.localizedMessage}"
            }
        }
    }

    fun deleteColumn(colIndex: Int) {
        viewModelScope.launch {
            try {
                repository.deleteColumn(colIndex)
                // If search column 2 was pointing to deleted column, reset to default
                if (_filterCriteria.value.searchColumn2Index == colIndex) {
                    val fallbackCol = columnConfigs.value.firstOrNull { it.colIndex != colIndex }?.colIndex ?: 0
                    _filterCriteria.value = _filterCriteria.value.copy(searchColumn2Index = fallbackCol)
                }
                refreshData()
                _userMessage.value = "Kolom berhasil dihapus."
            } catch (e: Exception) {
                _userMessage.value = "Gagal menghapus kolom: ${e.localizedMessage}"
            }
        }
    }

    fun updateAllColumnConfigs(configs: List<ColumnConfigEntity>) {
        viewModelScope.launch {
            try {
                repository.updateColumnConfigs(configs)
                refreshData()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Flexible Import Workflow (Append vs Replace All)
    fun promptImportCsv(uri: Uri) {
        _pendingImportUri.value = uri
        _showImportMethodDialog.value = true
    }

    fun dismissImportMethodDialog() {
        _pendingImportUri.value = null
        _showImportMethodDialog.value = false
    }

    fun executeImportWithMethod(isReplaceAll: Boolean) {
        val uri = _pendingImportUri.value ?: return
        _showImportMethodDialog.value = false
        _pendingImportUri.value = null

        viewModelScope.launch {
            _isLoading.value = true
            _progressMessage.value = if (isReplaceAll) "Mengosongkan DB & mengimpor CSV..." else "Menambahkan data CSV ke database..."
            try {
                val count = repository.importCsvFromUri(uri, isReplaceAll = isReplaceAll) { progress ->
                    _progressMessage.value = "Mengimpor $progress baris..."
                }
                _currentPage.value = 0
                refreshData()
                val methodStr = if (isReplaceAll) "Replace All" else "Append"
                _userMessage.value = "Berhasil ($methodStr): $count baris CSV tersimpan!"
            } catch (e: Exception) {
                _userMessage.value = "Gagal impor CSV: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
                _progressMessage.value = null
            }
        }
    }

    fun loadSampleData(isReplaceAll: Boolean = true) {
        viewModelScope.launch {
            _isLoading.value = true
            _progressMessage.value = "Memuat data contoh..."
            try {
                repository.loadSampleData(isReplaceAll)
                _filterCriteria.value = FilterCriteria()
                _currentPage.value = 0
                refreshData()
                val mode = if (isReplaceAll) "Replace All" else "Append"
                _userMessage.value = "Data contoh berhasil dimuat ($mode)!"
            } catch (e: Exception) {
                _userMessage.value = "Gagal memuat: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
                _progressMessage.value = null
            }
        }
    }

    fun exportToCsv(uri: Uri) {
        viewModelScope.launch {
            _isLoading.value = true
            _progressMessage.value = "Mengekspor file CSV..."
            try {
                val success = repository.exportCsv(uri, _filterCriteria.value)
                if (success) {
                    _userMessage.value = "File CSV berhasil diekspor!"
                } else {
                    _userMessage.value = "Gagal mengekspor file CSV."
                }
            } catch (e: Exception) {
                _userMessage.value = "Error: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
                _progressMessage.value = null
            }
        }
    }

    fun exportToExcel(uri: Uri) {
        viewModelScope.launch {
            _isLoading.value = true
            _progressMessage.value = "Menyusun spreadsheet Excel..."
            try {
                val success = repository.exportExcel(uri, _filterCriteria.value)
                if (success) {
                    _userMessage.value = "Spreadsheet Excel berhasil disimpan!"
                } else {
                    _userMessage.value = "Gagal mengekspor Excel."
                }
            } catch (e: Exception) {
                _userMessage.value = "Error: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
                _progressMessage.value = null
            }
        }
    }

    fun exportToPdf(uri: Uri) {
        viewModelScope.launch {
            _isLoading.value = true
            _progressMessage.value = "Membuat dokumen PDF..."
            try {
                val success = repository.exportPdf(uri, _filterCriteria.value)
                if (success) {
                    _userMessage.value = "Dokumen PDF berhasil dibuat!"
                } else {
                    _userMessage.value = "Gagal mengekspor PDF."
                }
            } catch (e: Exception) {
                _userMessage.value = "Error: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
                _progressMessage.value = null
            }
        }
    }

    fun backupDatabase(uri: Uri) {
        viewModelScope.launch {
            _isLoading.value = true
            _progressMessage.value = "Menyimpan cadangan database SQLite..."
            try {
                val success = repository.backupDatabaseToUri(uri)
                if (success) {
                    _userMessage.value = "Cadangan Database (.db) berhasil diekspor!"
                } else {
                    _userMessage.value = "Gagal mengekspor file database."
                }
            } catch (e: Exception) {
                _userMessage.value = "Error backup: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
                _progressMessage.value = null
            }
        }
    }

    fun restoreDatabase(uri: Uri) {
        viewModelScope.launch {
            _isLoading.value = true
            _progressMessage.value = "Memulihkan database SQLite..."
            try {
                val success = repository.restoreDatabaseFromUri(uri)
                if (success) {
                    _currentPage.value = 0
                    refreshData()
                    _userMessage.value = "Database SQLite berhasil dipulihkan!"
                } else {
                    _userMessage.value = "Gagal memulihkan file database."
                }
            } catch (e: Exception) {
                _userMessage.value = "Error restore: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
                _progressMessage.value = null
            }
        }
    }

    fun addRow(row: CsvRowEntity) {
        viewModelScope.launch {
            try {
                repository.insertRow(row)
                refreshData()
                _userMessage.value = "Data baris baru berhasil ditambahkan!"
            } catch (e: Exception) {
                _userMessage.value = "Gagal menambah baris: ${e.localizedMessage}"
            }
        }
    }

    fun updateRow(row: CsvRowEntity) {
        viewModelScope.launch {
            try {
                repository.updateRow(row)
                refreshData()
                _userMessage.value = "Data berhasil diperbarui!"
            } catch (e: Exception) {
                _userMessage.value = "Gagal memperbarui: ${e.localizedMessage}"
            }
        }
    }

    fun deleteRow(id: Long) {
        viewModelScope.launch {
            try {
                repository.deleteRow(id)
                refreshData()
                _userMessage.value = "Baris berhasil dihapus."
            } catch (e: Exception) {
                _userMessage.value = "Gagal menghapus: ${e.localizedMessage}"
            }
        }
    }

    fun deleteGroup(recordId: String) {
        viewModelScope.launch {
            try {
                repository.deleteGroup(recordId)
                refreshData()
                _userMessage.value = "Grup ID $recordId berhasil dihapus."
            } catch (e: Exception) {
                _userMessage.value = "Gagal menghapus grup: ${e.localizedMessage}"
            }
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            try {
                repository.clearAll()
                _currentPage.value = 0
                refreshData()
                _userMessage.value = "Seluruh data berhasil dikosongkan."
            } catch (e: Exception) {
                _userMessage.value = "Gagal mengosongkan data: ${e.localizedMessage}"
            }
        }
    }

    fun openFilterDialog() { _showFilterDialog.value = true }
    fun closeFilterDialog() { _showFilterDialog.value = false }

    fun openColumnManager() { _showColumnManagerDialog.value = true }
    fun closeColumnManager() { _showColumnManagerDialog.value = false }

    fun openAddRowDialog() { _showAddRowDialog.value = true }
    fun closeAddRowDialog() { _showAddRowDialog.value = false }

    fun startEditingRow(row: CsvRowEntity) { _editingRow.value = row }
    fun closeEditingRow() { _editingRow.value = null }

    fun openExportDialog() { _showExportDialog.value = true }
    fun closeExportDialog() { _showExportDialog.value = false }

    fun openHelpGuide() { _showHelpGuide.value = true }
    fun closeHelpGuide() { _showHelpGuide.value = false }

    fun dismissUserMessage() { _userMessage.value = null }
}
