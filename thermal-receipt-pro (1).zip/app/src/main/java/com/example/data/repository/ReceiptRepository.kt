package com.example.data.repository

import com.example.data.local.ReceiptDao
import com.example.data.local.ReceiptEntity
import com.example.data.model.ReceiptData
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.Calendar

class ReceiptRepository(private val receiptDao: ReceiptDao) {

    val allReceipts: Flow<List<ReceiptData>> = receiptDao.getAllReceipts()
        .map { list -> list.map { it.toReceiptData() } }

    fun getTodayReceipts(): Flow<List<ReceiptData>> {
        val (start, end) = getTodayRange()
        return receiptDao.getReceiptsBetween(start, end)
            .map { list -> list.map { it.toReceiptData() } }
    }

    fun getTodayIncome(): Flow<Long> {
        val (start, end) = getTodayRange()
        return receiptDao.getIncomeBetween(start, end).map { it ?: 0L }
    }

    fun getTodayCount(): Flow<Int> {
        val (start, end) = getTodayRange()
        return receiptDao.getCountBetween(start, end)
    }

    suspend fun saveReceipt(data: ReceiptData): Long {
        val entity = ReceiptEntity.fromReceiptData(data)
        return receiptDao.insertReceipt(entity)
    }

    suspend fun deleteReceipt(id: Long) {
        receiptDao.deleteReceiptById(id)
    }

    suspend fun getReceiptById(id: Long): ReceiptData? {
        return receiptDao.getReceiptById(id)?.toReceiptData()
    }

    private fun getTodayRange(): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis

        cal.set(Calendar.HOUR_OF_DAY, 23)
        cal.set(Calendar.MINUTE, 59)
        cal.set(Calendar.SECOND, 59)
        cal.set(Calendar.MILLISECOND, 999)
        val end = cal.timeInMillis

        return Pair(start, end)
    }
}
