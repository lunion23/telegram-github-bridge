package com.example.ui.viewmodel

import android.app.Application
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.ReceiptData
import com.example.data.repository.ReceiptRepository
import com.example.util.PdfReceiptGenerator
import com.example.util.PrinterStatus
import com.example.util.ThermalBluetoothPrinter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class ReceiptViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ReceiptRepository
    val thermalPrinter: ThermalBluetoothPrinter = ThermalBluetoothPrinter(application)

    init {
        val database = AppDatabase.getDatabase(application)
        repository = ReceiptRepository(database.receiptDao())
    }

    // Current Receipt in Form
    private val _currentReceipt = MutableStateFlow(ReceiptData())
    val currentReceipt: StateFlow<ReceiptData> = _currentReceipt.asStateFlow()

    // Database Flows
    val allReceipts: StateFlow<List<ReceiptData>> = repository.allReceipts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val todayReceipts: StateFlow<List<ReceiptData>> = repository.getTodayReceipts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val todayIncome: StateFlow<Long> = repository.getTodayIncome()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val todayCount: StateFlow<Int> = repository.getTodayCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // History Search and Filter
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _filterTodayOnly = MutableStateFlow(false)
    val filterTodayOnly: StateFlow<Boolean> = _filterTodayOnly.asStateFlow()

    val filteredReceipts: StateFlow<List<ReceiptData>> = combine(
        allReceipts,
        todayReceipts,
        _searchQuery,
        _filterTodayOnly
    ) { all, today, query, todayOnly ->
        val baseList = if (todayOnly) today else all
        if (query.isBlank()) {
            baseList
        } else {
            val q = query.trim().lowercase()
            baseList.filter {
                it.resiCode.lowercase().contains(q) ||
                        it.recipientName.lowercase().contains(q) ||
                        it.senderName.lowercase().contains(q) ||
                        it.orderNo.lowercase().contains(q)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Bluetooth Printer State
    val printerStatus: StateFlow<PrinterStatus> = thermalPrinter.printerStatus

    private val _is80mm = MutableStateFlow(false)
    val is80mm: StateFlow<Boolean> = _is80mm.asStateFlow()

    private val _isPrinting = MutableStateFlow(false)
    val isPrinting: StateFlow<Boolean> = _isPrinting.asStateFlow()

    private val _printMessage = MutableStateFlow<String?>(null)
    val printMessage: StateFlow<String?> = _printMessage.asStateFlow()

    // PDF State
    private val _currentPdfFile = MutableStateFlow<File?>(null)
    val currentPdfFile: StateFlow<File?> = _currentPdfFile.asStateFlow()

    private val _pdfPreviewBitmap = MutableStateFlow<Bitmap?>(null)
    val pdfPreviewBitmap: StateFlow<Bitmap?> = _pdfPreviewBitmap.asStateFlow()

    private val _isPdfLoading = MutableStateFlow(false)
    val isPdfLoading: StateFlow<Boolean> = _isPdfLoading.asStateFlow()

    fun updateReceipt(updater: (ReceiptData) -> ReceiptData) {
        _currentReceipt.value = updater(_currentReceipt.value)
    }

    fun setPrintFormat(format: com.example.data.model.PrintFormatMode) {
        updateReceipt { it.copy(selectedFormat = format) }
        preparePdfPreview()
    }

    fun updateResiCode(code: String) {
        updateReceipt { it.copy(resiCode = code) }
    }

    fun generateNewResi() {
        val newResi = ReceiptData.generateRandomResi()
        updateReceipt { it.copy(resiCode = newResi) }
    }

    fun generateNewOrderNo() {
        val newOrder = ReceiptData.generateRandomOrderNo()
        updateReceipt { it.copy(orderNo = newOrder) }
    }

    fun applyPreset(presetType: String) {
        when (presetType) {
            "RETROSPORT" -> {
                _currentReceipt.value = ReceiptData(
                    resiCode = "JD0597328904561",
                    routingCode = "350-4BDO88-16A",
                    badge1 = "NP",
                    badge2 = "EZ",
                    dropPoint = "KANTOR BISNIS INDONESIA",
                    recipientName = "DIDIT ADHITYA A",
                    recipientPhone = "081234563149",
                    recipientAddress = "BANDUNG, LENGKONG-BDO, JL. BUAHBATU NO. 46B (KANTOR BISNIS INDONESIA) KEL. CIKAWAO, KEC. LENGKONG, KOTA BANDUNG, JAWA BARAT",
                    senderName = "RetroSport Jersey",
                    senderPhone = "085678904744",
                    senderAddress = "KAB.SERANG, Griya Serdang Indah (GSI) Blok B6 NO 12 RT 02 RW 04 Kel. Margatani Serdang Kec. Kramatwatu Kab. Serang Banten",
                    shippingFee = 7200,
                    paymentType = "TUNAI",
                    weightKg = "1.00 KG",
                    orderNo = "19793494884632704",
                    notes = "Diantar saat jam kerja"
                )
            }
            "COD_FASHION" -> {
                _currentReceipt.value = ReceiptData(
                    resiCode = ReceiptData.generateRandomResi(),
                    routingCode = "210-JKT12-04C",
                    badge1 = "COD",
                    badge2 = "EZ",
                    dropPoint = "HUB JAKARTA PUSAT",
                    recipientName = "SITI RAHMAWATI",
                    recipientPhone = "087788992211",
                    recipientAddress = "JAKARTA, MENTENG, JL. SURABAYA NO. 15 RT 03 RW 05 KEL. PEGANGSAAN KEC. MENTENG, JAKARTA PUSAT",
                    senderName = "Zhafira Boutique",
                    senderPhone = "081399887766",
                    senderAddress = "BANDUNG, PASTEUR, JL. DR. DJUNDJUNAN NO. 88, BANDUNG, JAWA BARAT",
                    shippingFee = 14500,
                    paymentType = "COD: IDR 185,000",
                    weightKg = "0.75 KG",
                    orderNo = ReceiptData.generateRandomOrderNo(),
                    notes = "Paket Pakaian Wanita - Jangan dibanting"
                )
            }
            "DOC_KILAT" -> {
                _currentReceipt.value = ReceiptData(
                    resiCode = ReceiptData.generateRandomResi(),
                    routingCode = "500-SBY01-09A",
                    badge1 = "NP",
                    badge2 = "DOC",
                    dropPoint = "HUB SURABAYA UTARA",
                    recipientName = "PT KARYA CIPTA ABADI",
                    recipientPhone = "082155443322",
                    recipientAddress = "SURABAYA, RUNGKUT, KAWASAN INDUSTRI SIER BLOK C-4, SURABAYA, JAWA TIMUR",
                    senderName = "NOTARIS YUDI SH",
                    senderPhone = "081122334455",
                    senderAddress = "SEMARANG, SIMPANG LIMA PLAZA LT. 3, SEMARANG, JAWA TENGAH",
                    shippingFee = 22000,
                    paymentType = "TUNAI",
                    weightKg = "0.20 KG",
                    orderNo = ReceiptData.generateRandomOrderNo(),
                    notes = "Dokumen Penting - Harap TTD Penerima Asli"
                )
            }
        }
    }

    fun saveCurrentReceiptToDatabase(onSaved: ((Long) -> Unit)? = null) {
        viewModelScope.launch {
            val id = repository.saveReceipt(_currentReceipt.value)
            _currentReceipt.value = _currentReceipt.value.copy(id = id)
            onSaved?.invoke(id)
        }
    }

    fun loadReceipt(data: ReceiptData) {
        _currentReceipt.value = data
    }

    fun deleteReceipt(id: Long) {
        viewModelScope.launch {
            repository.deleteReceipt(id)
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilterTodayOnly(todayOnly: Boolean) {
        _filterTodayOnly.value = todayOnly
    }

    fun setPaperWidth80mm(is80: Boolean) {
        _is80mm.value = is80
    }

    // Bluetooth Printing
    fun getPairedBluetoothDevices(): List<BluetoothDevice> {
        return thermalPrinter.getPairedDevices()
    }

    fun connectPrinter(device: BluetoothDevice) {
        viewModelScope.launch {
            thermalPrinter.connect(device)
        }
    }

    fun disconnectPrinter() {
        thermalPrinter.disconnect()
    }

    fun printTestReceipt() {
        viewModelScope.launch {
            _isPrinting.value = true
            _printMessage.value = "Mencetak test..."
            val ok = thermalPrinter.printTest()
            _printMessage.value = if (ok) "Test print berhasil!" else "Gagal mencetak test"
            _isPrinting.value = false
        }
    }

    fun printCurrentReceiptBluetooth() {
        viewModelScope.launch {
            _isPrinting.value = true
            _printMessage.value = "Mencetak label thermal..."
            // Auto save to database
            saveCurrentReceiptToDatabase()
            val ok = thermalPrinter.printReceiptGraphic(_currentReceipt.value, _is80mm.value)
            _printMessage.value = if (ok) "Berhasil mencetak ke printer thermal!" else "Gagal mencetak ke thermal printer"
            _isPrinting.value = false
        }
    }

    fun clearPrintMessage() {
        _printMessage.value = null
    }

    // PDF Actions
    fun preparePdfPreview() {
        viewModelScope.launch {
            _isPdfLoading.value = true
            withContext(Dispatchers.IO) {
                val file = PdfReceiptGenerator.generatePdfFile(getApplication(), _currentReceipt.value)
                _currentPdfFile.value = file
                val bitmap = PdfReceiptGenerator.renderPdfToBitmap(file)
                _pdfPreviewBitmap.value = bitmap
            }
            _isPdfLoading.value = false
        }
    }

    fun printPdfDirect(context: Context) {
        val file = _currentPdfFile.value ?: run {
            val f = PdfReceiptGenerator.generatePdfFile(context, _currentReceipt.value)
            _currentPdfFile.value = f
            f
        }
        // Also auto-save transaction to history
        saveCurrentReceiptToDatabase()
        PdfReceiptGenerator.printPdf(context, file, "Struk_${_currentReceipt.value.resiCode}")
    }

    fun sharePdfDirect(context: Context) {
        val file = _currentPdfFile.value ?: run {
            val f = PdfReceiptGenerator.generatePdfFile(context, _currentReceipt.value)
            _currentPdfFile.value = f
            f
        }
        PdfReceiptGenerator.sharePdf(context, file)
    }

    override fun onCleared() {
        super.onCleared()
        thermalPrinter.disconnect()
    }
}
