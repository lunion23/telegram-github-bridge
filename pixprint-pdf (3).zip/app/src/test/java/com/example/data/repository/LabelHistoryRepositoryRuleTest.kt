package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.model.HistoryActionType
import com.example.model.PaperSizePreset
import com.example.model.ShippingLabelData
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class LabelHistoryRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun saveAndObserveHistory_authenticatedOwner_roundTripsAndDeletesCleanly() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val repository = LabelHistoryRepository(firestore, auth)

        val customLabel = ShippingLabelData.defaultFromReferenceImage().copy(
            waybillNumber = "JD9988776655",
            recipientName = "Siti Aminah",
            shippingFeeAmount = "IDR 62,000"
        )

        val savedId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.saveHistoryEntry(
                data = customLabel,
                paperPreset = PaperSizePreset.A6_PORTRAIT,
                actionLabel = HistoryActionType.PRINTED
            )
        }
        assertTrue(savedId.isNotEmpty())

        val emittedItems = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeHistory(aliceUid).first { list -> list.any { it.id == savedId } }
        }
        val fetched = emittedItems.first { it.id == savedId }
        assertEquals("JD9988776655", fetched.waybillNumber)
        assertEquals("Siti Aminah", fetched.recipientName)
        assertEquals(PaperSizePreset.A6_PORTRAIT.name, fetched.paperPreset)
        assertEquals(HistoryActionType.PRINTED, fetched.actionLabel)
        assertNotNull(fetched.createdAt)

        // Update existing record
        withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.updateHistoryEntry(
                existingItem = fetched,
                updatedData = customLabel.copy(recipientName = "Siti Aminah Putri"),
                paperPreset = PaperSizePreset.A4_ACTUAL_SIZE,
                actionLabel = HistoryActionType.SAVED
            )
        }

        val updatedDoc = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.getHistoryItem(aliceUid, savedId)
        }
        assertNotNull(updatedDoc)
        assertEquals("Siti Aminah Putri", updatedDoc?.recipientName)
        assertEquals(PaperSizePreset.A4_ACTUAL_SIZE.name, updatedDoc?.paperPreset)

        // Delete record
        withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.deleteHistoryEntry(savedId)
        }
        val afterDelete = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.getHistoryItem(aliceUid, savedId)
        }
        assertNull(afterDelete)
    }

    @Test
    fun getHistoryItem_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = LabelHistoryRepository(firestore, auth)
        val savedId = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.saveHistoryEntry(
                data = ShippingLabelData.defaultFromReferenceImage(),
                paperPreset = PaperSizePreset.THERMAL_100X200
            )
        }

        signInTestUser(BOB_EMAIL)
        val bobRepo = LabelHistoryRepository(firestore, auth)
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                bobRepo.getHistoryItem(aliceUid, savedId)
            }
            fail("Expected FirebaseFirestoreException PERMISSION_DENIED for cross-user access")
        } catch (e: FirebaseFirestoreException) {
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, e.code)
        }
    }

    @Test
    fun observeHistory_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        auth.signOut()
        val repository = LabelHistoryRepository(firestore, auth)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeHistory(aliceUid).first()
            }
            fail("Expected exception wrapping PERMISSION_DENIED for unauthenticated user")
        } catch (e: Exception) {
            val firestoreException = checkNotNull(e.unwrapFirestoreException()) {
                "Expected nested FirebaseFirestoreException, got $e"
            }
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException.code)
        }
    }

    private companion object {
        const val ALICE_EMAIL = "alice@test.com"
        const val BOB_EMAIL = "bob@test.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
