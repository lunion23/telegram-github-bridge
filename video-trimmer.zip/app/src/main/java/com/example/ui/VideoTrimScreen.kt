package com.example.ui

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.LightTextMuted
import com.example.ui.theme.LightTextPrimary
import com.example.ui.theme.LightTextSecondary
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioViolet
import com.example.ui.theme.SuccessGreen
import com.example.util.MediaUtils
import java.io.File

/**
 * Layar utama pemotong video dengan integrasi biner FFmpeg,
 * slider rentang visual, pemantau progress bar dan persentase real-time,
 * serta terminal log diagnostik.
 */
@Composable
fun VideoTrimScreen(
    viewModel: VideoTrimViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // Launcher untuk memilih video dari penyimpanan lokal / galeri (zero permissions Photo Picker)
    val pickVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.onVideoSelected(uri)
        }
    }

    var showLogsDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(WindowInsets.statusBars.asPaddingValues())
    ) {
        // App Header Bar
        TopHeaderBar(
            isBinaryReady = uiState.isBinaryReady,
            onShowLogs = { showLogsDialog = true },
            onReloadSample = { viewModel.loadSampleVideo() }
        )

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Video Player Preview Box
            item {
                VideoPreviewCard(
                    videoFile = uiState.localVideoFile,
                    trimmedFile = uiState.trimmedOutputFile,
                    trimStartSec = uiState.trimStartSeconds,
                    trimEndSec = uiState.trimEndSeconds
                )
            }

            // 2. Video Info & Selection Actions
            item {
                VideoSelectionBar(
                    selectedTitle = uiState.selectedVideo?.title ?: "Belum ada video",
                    durationText = uiState.selectedVideo?.formattedDuration ?: "00:00",
                    onPickFromGallery = {
                        pickVideoLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                        )
                    },
                    onUseSample = { viewModel.loadSampleVideo() },
                    isTrimming = uiState.isTrimming
                )
            }

            // 3. Trim Range Visual Slider & Controls
            if (uiState.selectedVideo != null) {
                item {
                    TrimRangeControlsCard(
                        totalDurationSec = uiState.selectedVideo?.durationSeconds ?: 15.0,
                        startSec = uiState.trimStartSeconds,
                        endSec = uiState.trimEndSeconds,
                        isTrimming = uiState.isTrimming,
                        onRangeChange = { start, end -> viewModel.updateTrimRange(start, end) }
                    )
                }

                // 4. Fast Stream Copy Toggle
                item {
                    StreamCopyOptionCard(
                        useFastCopy = uiState.useFastStreamCopy,
                        isTrimming = uiState.isTrimming,
                        onToggle = { viewModel.toggleStreamCopy(it) }
                    )
                }
            }

            // 5. Real-time Progress Bar & Percentage Card
            item {
                RealtimeProgressCard(
                    isTrimming = uiState.isTrimming,
                    progressPercent = uiState.progressPercent,
                    currentTimeSec = uiState.currentTimeSeconds,
                    targetDurationSec = uiState.targetDurationSeconds,
                    statusText = uiState.statusMessage,
                    onStartTrim = { viewModel.startTrim() },
                    onCancelTrim = { viewModel.cancelTrim() },
                    hasSelectedVideo = uiState.localVideoFile != null
                )
            }

            // 6. Success Result Card
            if (uiState.trimmedOutputFile != null) {
                item {
                    TrimSuccessResultCard(
                        outputFile = uiState.trimmedOutputFile!!,
                        elapsedTimeMs = uiState.trimElapsedTimeMs,
                        onShare = { shareVideoFile(context, uiState.trimmedOutputFile!!) }
                    )
                }
            }

            // 7. Error Banner if any
            if (uiState.errorMessage != null) {
                item {
                    ErrorNotificationCard(
                        errorMessage = uiState.errorMessage!!,
                        onDismiss = { viewModel.clearError() }
                    )
                }
            }

            // Bottom Spacing for safe area
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Spacer(modifier = Modifier.padding(WindowInsets.navigationBars.asPaddingValues()))
            }
        }
    }

    // Modal Sheet untuk Log Diagnostik FFmpeg
    if (showLogsDialog) {
        FfmpegLogsBottomSheet(
            logs = uiState.recentLogs,
            binaryPath = uiState.binaryPath,
            onClose = { showLogsDialog = false }
        )
    }
}

/**
 * Top Bar Header dengan judul aplikasi dan indikator status biner.
 */
@Composable
private fun TopHeaderBar(
    isBinaryReady: Boolean,
    onShowLogs: () -> Unit,
    onReloadSample: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCut,
                    contentDescription = "Logo",
                    tint = StudioCyan,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "FFmpeg Video Trimmer",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = LightTextPrimary
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(if (isBinaryReady) SuccessGreen else Color(0xFFFFB300))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isBinaryReady) "Biner FFmpeg Aktif" else "Mode Kompatibilitas",
                        style = MaterialTheme.typography.labelSmall,
                        color = LightTextSecondary
                    )
                }
            }
        }

        Row {
            IconButton(
                onClick = onReloadSample,
                modifier = Modifier.testTag("reload_sample_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Muat Ulang Sampel",
                    tint = LightTextSecondary
                )
            }
            IconButton(
                onClick = onShowLogs,
                modifier = Modifier.testTag("open_logs_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Terminal,
                    contentDescription = "Lihat Log FFmpeg",
                    tint = StudioCyan
                )
            }
        }
    }
}

/**
 * Player video preview yang dapat memutar video sumber maupun hasil potongan.
 */
@Composable
private fun VideoPreviewCard(
    videoFile: File?,
    trimmedFile: File?,
    trimStartSec: Double,
    trimEndSec: Double
) {
    val activeFile = trimmedFile ?: videoFile
    var isPlaying by remember { mutableStateOf(false) }
    var videoViewRef by remember { mutableStateOf<VideoView?>(null) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, DarkBorder, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                if (activeFile != null && activeFile.exists()) {
                    AndroidView(
                        factory = { ctx ->
                            VideoView(ctx).apply {
                                setVideoPath(activeFile.absolutePath)
                                setOnPreparedListener { mp ->
                                    mp.isLooping = true
                                    // Seek ke posisi trim start untuk preview
                                    seekTo((trimStartSec * 1000).toInt())
                                }
                                setOnErrorListener { _, _, _ ->
                                    true
                                }
                                videoViewRef = this
                            }
                        },
                        update = { view ->
                            view.setVideoPath(activeFile.absolutePath)
                            view.seekTo((trimStartSec * 1000).toInt())
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    // Overlay Tombol Play/Pause jika sedang pause
                    if (!isPlaying) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.65f))
                                .clickable {
                                    videoViewRef?.let { vv ->
                                        vv.seekTo((trimStartSec * 1000).toInt())
                                        vv.start()
                                        isPlaying = true
                                    }
                                }
                                .testTag("preview_play_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Putar Preview",
                                tint = StudioCyan,
                                modifier = Modifier.size(34.dp)
                            )
                        }
                    } else {
                        // Area tap untuk pause
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clickable {
                                    videoViewRef?.pause()
                                    isPlaying = false
                                }
                        )
                    }
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Movie,
                            contentDescription = null,
                            tint = LightTextMuted,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Pilih video untuk mulai memotong",
                            style = MaterialTheme.typography.bodyMedium,
                            color = LightTextSecondary
                        )
                    }
                }

                // Badge jika yang diputar adalah file hasil potongan
                if (trimmedFile != null) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(10.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(SuccessGreen.copy(alpha = 0.9f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "Hasil Trim Baru",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.Black,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Info Bar Bawah Player
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = activeFile?.name ?: "Tidak ada file aktif",
                    style = MaterialTheme.typography.bodySmall,
                    color = LightTextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                if (activeFile != null) {
                    Text(
                        text = "${activeFile.length() / 1024} KB",
                        style = MaterialTheme.typography.labelSmall,
                        color = StudioCyan,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

/**
 * Bar pemilih video dari galeri lokal atau video sampel bawaan.
 */
@Composable
private fun VideoSelectionBar(
    selectedTitle: String,
    durationText: String,
    onPickFromGallery: () -> Unit,
    onUseSample: () -> Unit,
    isTrimming: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Button(
            onClick = onPickFromGallery,
            enabled = !isTrimming,
            modifier = Modifier
                .weight(1f)
                .height(48.dp)
                .testTag("select_video_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = DarkSurfaceVariant,
                contentColor = LightTextPrimary
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Pilih Galeri", maxLines = 1)
        }

        OutlinedButton(
            onClick = onUseSample,
            enabled = !isTrimming,
            modifier = Modifier
                .height(48.dp)
                .testTag("sample_video_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = StudioCyan)
        ) {
            Icon(Icons.Default.Movie, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Sampel")
        }
    }
}

/**
 * Kontrol visual pemilihan rentang waktu awal dan akhir potongan (dual-thumb slider).
 */
@Composable
private fun TrimRangeControlsCard(
    totalDurationSec: Double,
    startSec: Double,
    endSec: Double,
    isTrimming: Boolean,
    onRangeChange: (start: Double, end: Double) -> Unit
) {
    val durationTarget = (endSec - startSec).coerceAtLeast(0.0)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, DarkBorder, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Rentang Pemotongan (Trimming)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = LightTextPrimary
                )
                Text(
                    text = "Durasi: ${MediaUtils.formatSeconds(durationTarget, true)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = StudioCyan,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Dual thumb RangeSlider
            RangeSlider(
                value = startSec.toFloat()..endSec.toFloat(),
                onValueChange = { range ->
                    onRangeChange(range.start.toDouble(), range.endInclusive.toDouble())
                },
                valueRange = 0f..totalDurationSec.toFloat().coerceAtLeast(1f),
                enabled = !isTrimming,
                colors = SliderDefaults.colors(
                    thumbColor = StudioCyan,
                    activeTrackColor = StudioCyan,
                    inactiveTrackColor = DarkBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("trim_range_slider")
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Indikator Titik Mulai dan Titik Selesai
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TimecodeBadge(
                    label = "Awal (Start)",
                    timeText = MediaUtils.formatSeconds(startSec, true),
                    onStepBack = { onRangeChange((startSec - 0.5).coerceAtLeast(0.0), endSec) },
                    onStepForward = { onRangeChange((startSec + 0.5).coerceAtMost(endSec - 0.2), endSec) },
                    enabled = !isTrimming
                )

                TimecodeBadge(
                    label = "Akhir (End)",
                    timeText = MediaUtils.formatSeconds(endSec, true),
                    onStepBack = { onRangeChange(startSec, (endSec - 0.5).coerceAtLeast(startSec + 0.2)) },
                    onStepForward = { onRangeChange(startSec, (endSec + 0.5).coerceAtMost(totalDurationSec)) },
                    enabled = !isTrimming
                )
            }
        }
    }
}

/**
 * Badge pembacaan waktu dengan tombol penyesuaian presisi ±0.5 detik.
 */
@Composable
private fun TimecodeBadge(
    label: String,
    timeText: String,
    onStepBack: () -> Unit,
    onStepForward: () -> Unit,
    enabled: Boolean
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = LightTextSecondary)
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(DarkSurfaceVariant)
                .padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
            Text(
                text = "-",
                modifier = Modifier
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .clickable(enabled = enabled, onClick = onStepBack),
                color = StudioCyan,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = timeText,
                style = MaterialTheme.typography.bodyMedium,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = LightTextPrimary,
                modifier = Modifier.padding(horizontal = 6.dp)
            )
            Text(
                text = "+",
                modifier = Modifier
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .clickable(enabled = enabled, onClick = onStepForward),
                color = StudioCyan,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/**
 * Switch pilihan Stream Copy (-c copy) vs Re-encode.
 */
@Composable
private fun StreamCopyOptionCard(
    useFastCopy: Boolean,
    isTrimming: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, DarkBorder, RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Mode Fast Stream Copy (-c copy)",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = LightTextPrimary
                )
                Text(
                    text = if (useFastCopy) "Pemrosesan secepat kilat tanpa re-encoding (kualitas 100% utuh)"
                    else "Re-encode penuh (frame-accurate H.264/AAC)",
                    style = MaterialTheme.typography.labelSmall,
                    color = LightTextSecondary
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Switch(
                checked = useFastCopy,
                onCheckedChange = onToggle,
                enabled = !isTrimming,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = StudioCyan,
                    checkedTrackColor = StudioCyan.copy(alpha = 0.35f)
                ),
                modifier = Modifier.testTag("toggle_stream_copy")
            )
        }
    }
}

/**
 * Card utama yang menampilkan tombol trigger, ProgressBar, dan persentase TextView real-time.
 */
@Composable
private fun RealtimeProgressCard(
    isTrimming: Boolean,
    progressPercent: Int,
    currentTimeSec: Double,
    targetDurationSec: Double,
    statusText: String,
    onStartTrim: () -> Unit,
    onCancelTrim: () -> Unit,
    hasSelectedVideo: Boolean
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isTrimming) StudioCyan.copy(alpha = 0.5f) else DarkBorder,
                RoundedCornerShape(16.dp)
            )
            .animateContentSize(),
        colors = CardDefaults.cardColors(
            containerColor = if (isTrimming) DarkSurfaceVariant else DarkSurface
        )
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (isTrimming) {
                // Header status saat proses berjalan
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = StudioCyan,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Memotong dengan FFmpeg...",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = LightTextPrimary
                        )
                    }

                    // Tampilan Persentase Besar (TextView representation)
                    Text(
                        text = "$progressPercent%",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = StudioCyan,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.testTag("progress_percent_text")
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Komponen ProgressBar Real-time
                LinearProgressIndicator(
                    progress = { progressPercent / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .testTag("realtime_progress_bar"),
                    color = StudioCyan,
                    trackColor = DarkBorder
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Detail posisi detik pemrosesan
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Posisi: ${MediaUtils.formatSeconds(currentTimeSec, true)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = LightTextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Target: ${MediaUtils.formatSeconds(targetDurationSec, true)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = LightTextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Tombol Batalkan
                OutlinedButton(
                    onClick = onCancelTrim,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("cancel_trim_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF5252))
                ) {
                    Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Batalkan Proses")
                }
            } else {
                // Tombol Pemicu Utama (Trigger Button)
                Button(
                    onClick = onStartTrim,
                    enabled = hasSelectedVideo,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("start_trim_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StudioViolet,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.ContentCut, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "POTONG VIDEO SEKARANG",
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = statusText,
                    style = MaterialTheme.typography.labelSmall,
                    color = LightTextSecondary,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

/**
 * Card pemberitahuan hasil pemotongan berhasil.
 */
@Composable
private fun TrimSuccessResultCard(
    outputFile: File,
    elapsedTimeMs: Long,
    onShare: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SuccessGreen.copy(alpha = 0.4f), RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = SuccessGreen.copy(alpha = 0.1f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = SuccessGreen,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Video Berhasil Dipotong!",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = SuccessGreen
                    )
                    Text(
                        text = "Selesai dalam ${(elapsedTimeMs / 1000.0)} detik • Ukuran: ${outputFile.length() / 1024} KB",
                        style = MaterialTheme.typography.labelSmall,
                        color = LightTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Button(
                    onClick = onShare,
                    modifier = Modifier.testTag("share_trimmed_video_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Bagikan Video", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * Card banner notifikasi error.
 */
@Composable
private fun ErrorNotificationCard(
    errorMessage: String,
    onDismiss: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFFF5252).copy(alpha = 0.4f), RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFF5252).copy(alpha = 0.12f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Error,
                contentDescription = null,
                tint = Color(0xFFFF5252),
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = errorMessage,
                style = MaterialTheme.typography.bodySmall,
                color = LightTextPrimary,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onDismiss) {
                Icon(Icons.Default.Close, contentDescription = "Tutup", tint = LightTextSecondary)
            }
        }
    }
}

/**
 * Dialog / Bottom Sheet yang menampilkan baris output stdout / stderr FFmpeg secara real-time.
 */
@Composable
private fun FfmpegLogsBottomSheet(
    logs: List<String>,
    binaryPath: String,
    onClose: () -> Unit
) {
    val listState = rememberLazyListState()

    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.size - 1)
        }
    }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f)),
        color = DarkBackground
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Terminal, contentDescription = null, tint = StudioCyan)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Terminal Output FFmpeg",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = LightTextPrimary
                    )
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Tutup", tint = LightTextSecondary)
                }
            }

            Text(
                text = "Lokasi Biner: $binaryPath",
                style = MaterialTheme.typography.labelSmall,
                fontFamily = FontFamily.Monospace,
                color = LightTextMuted
            )

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = DarkBorder)
            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF0A0C10))
                    .padding(10.dp)
            ) {
                if (logs.isEmpty()) {
                    item {
                        Text(
                            text = "Belum ada output log dari proses FFmpeg.",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            color = LightTextMuted
                        )
                    }
                } else {
                    items(logs) { line ->
                        val isProgressLine = line.contains("time=")
                        val isErrorLine = line.contains("error", ignoreCase = true)

                        Text(
                            text = line,
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = when {
                                isProgressLine -> StudioCyan
                                isErrorLine -> Color(0xFFFF5252)
                                else -> LightTextSecondary
                            },
                            modifier = Modifier.padding(vertical = 1.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Helper untuk membagikan file video ke aplikasi lain (WhatsApp, Telegram, dll).
 */
private fun shareVideoFile(context: Context, file: File) {
    try {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Bagikan Video"))
    } catch (e: Exception) {
        // Fallback standard share
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file))
        }
        context.startActivity(Intent.createChooser(intent, "Bagikan Video"))
    }
}
