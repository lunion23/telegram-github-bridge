package com.example.ui.editor

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.example.ui.theme.CodeComment
import com.example.ui.theme.CodeKeyword
import com.example.ui.theme.CodeNumber
import com.example.ui.theme.CodeString
import com.example.ui.theme.CyanPrimaryDark
import java.util.regex.Pattern

object SyntaxHighlighter {

    private val KEYWORDS = listOf(
        "abstract", "as", "async", "await", "break", "case", "catch", "class", "const",
        "continue", "def", "default", "delete", "do", "else", "enum", "export", "extends",
        "false", "final", "finally", "fn", "for", "from", "function", "if", "implements",
        "import", "in", "interface", "let", "new", "null", "package", "private", "protected",
        "public", "return", "sealed", "static", "super", "switch", "this", "throw", "true",
        "try", "typeof", "val", "var", "void", "while", "with", "yield"
    )

    private val KEYWORD_PATTERN: Pattern = Pattern.compile(
        "\\b(" + KEYWORDS.joinToString("|") + ")\\b"
    )
    private val STRING_PATTERN: Pattern = Pattern.compile(
        "\"(\\\\.|[^\"\\\\])*\"|'(\\\\.|[^'\\\\])*'|`(\\\\.|[^`\\\\])*`"
    )
    private val NUMBER_PATTERN: Pattern = Pattern.compile(
        "\\b\\d+(\\.\\d+)?\\b"
    )
    private val COMMENT_PATTERN: Pattern = Pattern.compile(
        "//.*|/\\*[\\s\\S]*?\\*/|#.*"
    )
    private val MD_HEADING_PATTERN: Pattern = Pattern.compile(
        "^(#{1,6}\\s.*)$", Pattern.MULTILINE
    )
    private val MD_BOLD_PATTERN: Pattern = Pattern.compile(
        "\\*\\*(.*?)\\*\\*"
    )
    private val MD_CODE_INLINE_PATTERN: Pattern = Pattern.compile(
        "`([^`]+)`"
    )

    fun highlight(text: String, isDark: Boolean): AnnotatedString {
        if (text.isEmpty()) return AnnotatedString("")

        return buildAnnotatedString {
            append(text)

            // Numbers
            val numMatcher = NUMBER_PATTERN.matcher(text)
            while (numMatcher.find()) {
                addStyle(
                    SpanStyle(color = CodeNumber),
                    numMatcher.start(),
                    numMatcher.end()
                )
            }

            // Keywords
            val kwMatcher = KEYWORD_PATTERN.matcher(text)
            while (kwMatcher.find()) {
                addStyle(
                    SpanStyle(color = CodeKeyword, fontWeight = FontWeight.SemiBold),
                    kwMatcher.start(),
                    kwMatcher.end()
                )
            }

            // Strings
            val strMatcher = STRING_PATTERN.matcher(text)
            while (strMatcher.find()) {
                addStyle(
                    SpanStyle(color = CodeString),
                    strMatcher.start(),
                    strMatcher.end()
                )
            }

            // Comments
            val cmtMatcher = COMMENT_PATTERN.matcher(text)
            while (cmtMatcher.find()) {
                addStyle(
                    SpanStyle(color = CodeComment),
                    cmtMatcher.start(),
                    cmtMatcher.end()
                )
            }

            // Markdown Headings
            val hMatcher = MD_HEADING_PATTERN.matcher(text)
            while (hMatcher.find()) {
                addStyle(
                    SpanStyle(
                        color = CyanPrimaryDark,
                        fontWeight = FontWeight.Bold
                    ),
                    hMatcher.start(),
                    hMatcher.end()
                )
            }

            // Markdown Bold
            val boldMatcher = MD_BOLD_PATTERN.matcher(text)
            while (boldMatcher.find()) {
                addStyle(
                    SpanStyle(fontWeight = FontWeight.Bold),
                    boldMatcher.start(),
                    boldMatcher.end()
                )
            }

            // Markdown inline code
            val codeMatcher = MD_CODE_INLINE_PATTERN.matcher(text)
            while (codeMatcher.find()) {
                addStyle(
                    SpanStyle(
                        fontFamily = FontFamily.Monospace,
                        background = if (isDark) Color(0xFF263238) else Color(0xFFECEFF1)
                    ),
                    codeMatcher.start(),
                    codeMatcher.end()
                )
            }
        }
    }
}
