package com.example.data

import com.example.model.PaperSizePreset
import com.example.model.ShippingLabelData
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp
import java.io.File

/**
 * Type-safe Firestore model for a saved shipping label record in
 * `/users/{userId}/shipping_labels/{labelId}`.
 *
 * Every property provides a default value to support Firestore's no-arg constructor
 * reflection, `@DocumentId` maps document keys cleanly, and `@ServerTimestamp` handles
 * server-side timestamps without client clock skew.
 */
@IgnoreExtraProperties
data class SavedLabelRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "Resi Baru",
    val badgeLeft: String = "NP",
    val badgeRight: String = "EZ",
    val routingCode: String = "",
    val waybillNumber: String = "JD0600216038",
    val destinationBanner: String = "",
    val recipientName: String = "Penerima",
    val recipientPhone: String = "",
    val recipientAddress: String = "",
    val senderName: String = "",
    val senderPhone: String = "",
    val senderArea: String = "",
    val shippingFeeLabel: String = "BIAYA PENGIRIMAN",
    val shippingFeeAmount: String = "",
    val taxIncludedText: String = "Sudah Termasuk PPN",
    val paymentMethod: String = "",
    val weight: String = "",
    val printDate: String = "",
    val orderNumber: String = "",
    val expCode: String = "",
    val quantityText: String = "",
    val itemCategory: String = "",
    val notes: String = "",
    val companyNameAndTax: String = "",
    val companyAddressLine1: String = "",
    val companyAddressLine2: String = "",
    val websiteUrl: String = "",
    val stubBadgeText: String = "Lembar Pengirim",
    val paperPresetName: String = PaperSizePreset.THERMAL_100X200.name,
    val pinned: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toShippingLabelData(): ShippingLabelData = ShippingLabelData(
        badgeLeft = badgeLeft,
        badgeRight = badgeRight,
        routingCode = routingCode,
        waybillNumber = waybillNumber,
        destinationBanner = destinationBanner,
        recipientName = recipientName,
        recipientPhone = recipientPhone,
        recipientAddress = recipientAddress,
        senderName = senderName,
        senderPhone = senderPhone,
        senderArea = senderArea,
        shippingFeeLabel = shippingFeeLabel,
        shippingFeeAmount = shippingFeeAmount,
        taxIncludedText = taxIncludedText,
        paymentMethod = paymentMethod,
        weight = weight,
        printDate = printDate,
        orderNumber = orderNumber,
        expCode = expCode,
        quantityText = quantityText,
        itemCategory = itemCategory,
        notes = notes,
        companyNameAndTax = companyNameAndTax,
        companyAddressLine1 = companyAddressLine1,
        companyAddressLine2 = companyAddressLine2,
        websiteUrl = websiteUrl,
        stubBadgeText = stubBadgeText
    )

    fun toPaperSizePreset(): PaperSizePreset {
        return PaperSizePreset.entries.firstOrNull { it.name == paperPresetName }
            ?: PaperSizePreset.THERMAL_100X200
    }

    fun sanitizedForRules(ownerUid: String): SavedLabelRecord {
        val safeWaybill = waybillNumber.trim().ifBlank { "RESI-001" }.take(80)
        val safeRecipient = recipientName.trim().ifBlank { "Penerima" }.take(120)
        val computedTitle = title.trim()
            .ifBlank { "$safeWaybill - $safeRecipient" }
            .take(120)
        val validPreset = PaperSizePreset.entries
            .firstOrNull { it.name == paperPresetName }
            ?.name ?: PaperSizePreset.THERMAL_100X200.name

        return copy(
            userId = ownerUid,
            title = computedTitle,
            badgeLeft = badgeLeft.take(20),
            badgeRight = badgeRight.take(20),
            routingCode = routingCode.take(60),
            waybillNumber = safeWaybill,
            destinationBanner = destinationBanner.take(100),
            recipientName = safeRecipient,
            recipientPhone = recipientPhone.take(40),
            recipientAddress = recipientAddress.take(500),
            senderName = senderName.take(120),
            senderPhone = senderPhone.take(40),
            senderArea = senderArea.take(200),
            shippingFeeLabel = shippingFeeLabel.take(60),
            shippingFeeAmount = shippingFeeAmount.take(60),
            taxIncludedText = taxIncludedText.take(80),
            paymentMethod = paymentMethod.take(40),
            weight = weight.take(40),
            printDate = printDate.take(40),
            orderNumber = orderNumber.take(80),
            expCode = expCode.take(40),
            quantityText = quantityText.take(40),
            itemCategory = itemCategory.take(120),
            notes = notes.take(500),
            companyNameAndTax = companyNameAndTax.take(160),
            companyAddressLine1 = companyAddressLine1.take(160),
            companyAddressLine2 = companyAddressLine2.take(160),
            websiteUrl = websiteUrl.take(120),
            stubBadgeText = stubBadgeText.take(60),
            paperPresetName = validPreset
        )
    }

    companion object {
        fun fromShippingLabelData(
            data: ShippingLabelData,
            paperPreset: PaperSizePreset,
            customTitle: String = "",
            pinned: Boolean = false,
            existingId: String = "",
            existingCreatedAt: Timestamp? = null
        ): SavedLabelRecord {
            val safeWaybill = data.waybillNumber.trim().ifBlank { "RESI-001" }.take(80)
            val safeRecipient = data.recipientName.trim().ifBlank { "Penerima" }.take(120)
            val resolvedTitle = customTitle.trim()
                .ifBlank { "$safeWaybill • $safeRecipient" }
                .take(120)

            return SavedLabelRecord(
                id = existingId,
                title = resolvedTitle,
                badgeLeft = data.badgeLeft,
                badgeRight = data.badgeRight,
                routingCode = data.routingCode,
                waybillNumber = safeWaybill,
                destinationBanner = data.destinationBanner,
                recipientName = safeRecipient,
                recipientPhone = data.recipientPhone,
                recipientAddress = data.recipientAddress,
                senderName = data.senderName,
                senderPhone = data.senderPhone,
                senderArea = data.senderArea,
                shippingFeeLabel = data.shippingFeeLabel,
                shippingFeeAmount = data.shippingFeeAmount,
                taxIncludedText = data.taxIncludedText,
                paymentMethod = data.paymentMethod,
                weight = data.weight,
                printDate = data.printDate,
                orderNumber = data.orderNumber,
                expCode = data.expCode,
                quantityText = data.quantityText,
                itemCategory = data.itemCategory,
                notes = data.notes,
                companyNameAndTax = data.companyNameAndTax,
                companyAddressLine1 = data.companyAddressLine1,
                companyAddressLine2 = data.companyAddressLine2,
                websiteUrl = data.websiteUrl,
                stubBadgeText = data.stubBadgeText,
                paperPresetName = paperPreset.name,
                pinned = pinned,
                createdAt = existingCreatedAt,
                updatedAt = null
            )
        }
    }
}

/**
 * Represents a generated `.pdf` file stored in the app's local `filesDir/pdfs` directory.
 */
data class GeneratedPdfFileItem(
    val file: File,
    val name: String,
    val sizeBytes: Long,
    val lastModifiedMillis: Long
)
