package com.example.pdf

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import androidx.core.graphics.withTranslation
import com.example.model.PaperSizePreset
import com.example.model.PdfRenderSource
import com.example.model.ShippingLabelData
import kotlin.math.min

/**
 * Pixel-faithful vector renderer for the shipping label on a virtual 629 x 1272 canvas
 * matching every box, divider, rotated margin waybill, serif/sans-serif mix, Code 128 barcode,
 * 21x21 QR code, and tear-off "Lembar Pengirim" stub from the reference image.
 */
object ShippingLabelCanvasRenderer {

    const val VIRTUAL_WIDTH = 629f
    const val VIRTUAL_HEIGHT = 1272f

    private val sansRegular: Typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
    private val sansBold: Typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    private val serifRegular: Typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL)
    private val serifBold: Typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)

    /**
     * Renders a full PDF/Preview page according to [paperPreset] and [renderSource].
     */
    fun renderPage(
        canvas: Canvas,
        pageWidth: Float,
        pageHeight: Float,
        data: ShippingLabelData,
        paperPreset: PaperSizePreset,
        renderSource: PdfRenderSource = PdfRenderSource.VECTOR_RECONSTRUCTION,
        referenceBitmap: Bitmap? = null,
        capturedBitmap: Bitmap? = null
    ) {
        val whiteFill = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, pageWidth, pageHeight, whiteFill)

        if (renderSource == PdfRenderSource.CAPTURED_DOCUMENT && capturedBitmap != null) {
            val docRect = computeFittedImageRect(
                pageWidth = pageWidth,
                pageHeight = pageHeight,
                imageWidth = capturedBitmap.width.toFloat(),
                imageHeight = capturedBitmap.height.toFloat(),
                marginRatio = if (paperPreset == PaperSizePreset.A4_ACTUAL_SIZE) 0.04f else 0.015f
            )
            val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
            canvas.drawBitmap(capturedBitmap, null, docRect, bitmapPaint)
            return
        }

        val targetRect = computeTargetLabelRect(pageWidth, pageHeight, paperPreset)

        if (paperPreset.drawCropGuides) {
            drawSubtleCropMarks(canvas, targetRect)
        }

        if (renderSource == PdfRenderSource.ORIGINAL_REFERENCE_IMAGE && referenceBitmap != null) {
            val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
            canvas.drawBitmap(referenceBitmap, null, targetRect, bitmapPaint)
            return
        }

        val scaleX = targetRect.width() / VIRTUAL_WIDTH
        val scaleY = targetRect.height() / VIRTUAL_HEIGHT
        val scale = min(scaleX, scaleY)
        val dx = (targetRect.width() - VIRTUAL_WIDTH * scale) / 2f
        val dy = (targetRect.height() - VIRTUAL_HEIGHT * scale) / 2f

        canvas.withTranslation(targetRect.left + dx, targetRect.top + dy) {
            scale(scale, scale)
            drawVectorLabel(this, data)
        }
    }

    private fun computeTargetLabelRect(
        pageWidth: Float,
        pageHeight: Float,
        paperPreset: PaperSizePreset
    ): RectF {
        if (paperPreset == PaperSizePreset.A4_ACTUAL_SIZE) {
            // True 100 x 200 mm physical scale centered horizontally on A4 (210 x 297 mm)
            val labelW = pageWidth * (100f / 210f)
            val labelH = pageHeight * (200f / 297f)
            val left = (pageWidth - labelW) / 2f
            val top = (pageHeight - labelH) / 2f
            return RectF(left, top, left + labelW, top + labelH)
        }

        // Fit proportionally inside the selected thermal/A6 page
        val labelAspect = VIRTUAL_WIDTH / VIRTUAL_HEIGHT
        val pageAspect = pageWidth / pageHeight
        return if (pageAspect > labelAspect) {
            val h = pageHeight
            val w = h * labelAspect
            val left = (pageWidth - w) / 2f
            RectF(left, 0f, left + w, h)
        } else {
            val w = pageWidth
            val h = w / labelAspect
            val top = (pageHeight - h) / 2f
            RectF(0f, top, w, top + h)
        }
    }

    private fun computeFittedImageRect(
        pageWidth: Float,
        pageHeight: Float,
        imageWidth: Float,
        imageHeight: Float,
        marginRatio: Float
    ): RectF {
        if (imageWidth <= 0f || imageHeight <= 0f) {
            return RectF(0f, 0f, pageWidth, pageHeight)
        }
        val padX = pageWidth * marginRatio
        val padY = pageHeight * marginRatio
        val availW = (pageWidth - 2f * padX).coerceAtLeast(1f)
        val availH = (pageHeight - 2f * padY).coerceAtLeast(1f)
        val imageAspect = imageWidth / imageHeight
        val availAspect = availW / availH

        return if (availAspect > imageAspect) {
            val h = availH
            val w = h * imageAspect
            val left = (pageWidth - w) / 2f
            val top = (pageHeight - h) / 2f
            RectF(left, top, left + w, top + h)
        } else {
            val w = availW
            val h = w / imageAspect
            val left = (pageWidth - w) / 2f
            val top = (pageHeight - h) / 2f
            RectF(left, top, left + w, top + h)
        }
    }

    private fun drawSubtleCropMarks(canvas: Canvas, rect: RectF) {
        val guidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(180, 180, 180)
            style = Paint.Style.STROKE
            strokeWidth = 0.75f
            pathEffect = DashPathEffect(floatArrayOf(4f, 4f), 0f)
        }
        canvas.drawRect(rect, guidePaint)
    }

    /**
     * Draws the shipping label in the 629 x 1272 virtual coordinate system.
     */
    fun drawVectorLabel(canvas: Canvas, data: ShippingLabelData) {
        val blackFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(22, 22, 22)
            style = Paint.Style.FILL
        }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(20, 20, 20)
            style = Paint.Style.STROKE
            strokeWidth = 2.3f
        }
        val thinBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(20, 20, 20)
            style = Paint.Style.STROKE
            strokeWidth = 1.9f
        }

        val boxLeft = 31f
        val boxRight = 604f
        val boxTop = 70f
        val boxBottom = 682f

        // 1. Top-Right Service Badges ("NP" and "EZ")
        if (data.badgeLeft.isNotBlank()) {
            canvas.drawRect(330f, 19f, 454f, 59f, blackFill)
            drawCenteredText(
                canvas = canvas,
                text = data.badgeLeft,
                cx = 392f,
                cy = 39f,
                typeface = sansBold,
                textSize = 29f,
                color = Color.WHITE,
                scaleX = 0.96f,
                maxWidth = 114f
            )
        }
        if (data.badgeRight.isNotBlank()) {
            canvas.drawRect(484f, 19f, 604f, 59f, blackFill)
            drawCenteredText(
                canvas = canvas,
                text = data.badgeRight,
                cx = 544f,
                cy = 39f,
                typeface = sansBold,
                textSize = 29f,
                color = Color.WHITE,
                scaleX = 0.96f,
                maxWidth = 110f
            )
        }

        // 2. Repeated Vertical Side Margin Waybill Numbers (4 pairs, rotated +90 deg clockwise)
        val verticalYCenters = floatArrayOf(159f, 337f, 521f, 703f)
        for (cy in verticalYCenters) {
            drawRotated90Text(
                canvas = canvas,
                text = data.waybillNumber,
                cx = 16.5f,
                cy = cy,
                typeface = sansBold,
                textSize = 18.2f,
                scaleX = 0.80f
            )
            drawRotated90Text(
                canvas = canvas,
                text = data.waybillNumber,
                cx = 617.5f,
                cy = cy,
                typeface = sansBold,
                textSize = 18.2f,
                scaleX = 0.80f
            )
        }

        // 3. Main Upper Outer Border
        canvas.drawRect(boxLeft, boxTop, boxRight, boxBottom, borderPaint)

        // 4. Band A: Routing / Sorting Code (70..153)
        canvas.drawLine(boxLeft, 153f, boxRight, 153f, borderPaint)
        drawCenteredText(
            canvas = canvas,
            text = data.routingCode,
            cx = (boxLeft + boxRight) / 2f,
            cy = 112f,
            typeface = sansBold,
            textSize = 53f,
            color = Color.rgb(18, 18, 18),
            scaleX = 0.96f,
            maxWidth = boxRight - boxLeft - 28f
        )

        // 5. Band B: Primary Code 128 Barcode + Waybill Number (153..275)
        BarcodeVectorHelper.drawCode128(
            canvas = canvas,
            content = data.waybillNumber,
            left = 62f,
            top = 166f,
            right = 478f,
            bottom = 237f
        )
        drawCenteredText(
            canvas = canvas,
            text = data.waybillNumber,
            cx = 296f,
            cy = 255f,
            typeface = sansBold,
            textSize = 23f,
            color = Color.rgb(18, 18, 18),
            scaleX = 0.96f,
            maxWidth = 420f
        )

        // 6. Band C: Destination Hub Solid Black Banner (275..328)
        canvas.drawRect(boxLeft, 275f, boxRight, 328f, blackFill)
        drawCenteredText(
            canvas = canvas,
            text = data.destinationBanner,
            cx = (boxLeft + boxRight) / 2f,
            cy = 301.5f,
            typeface = sansBold,
            textSize = 28.5f,
            color = Color.WHITE,
            scaleX = 0.96f,
            letterSpacing = 0.03f,
            maxWidth = boxRight - boxLeft - 24f
        )

        // 7. Band D: Penerima (Recipient) Section (328..505)
        canvas.drawLine(boxLeft, 505f, boxRight, 505f, thinBorderPaint)
        drawLeftText(
            canvas = canvas,
            text = "Penerima: ${data.recipientName}",
            x = 37f,
            baselineY = 353f,
            typeface = sansBold,
            textSize = 22f,
            scaleX = 0.91f,
            maxWidth = 395f
        )
        drawRightText(
            canvas = canvas,
            text = data.recipientPhone,
            rightX = 599f,
            baselineY = 353f,
            typeface = sansBold,
            textSize = 21f,
            scaleX = 0.90f,
            maxWidth = 160f
        )
        drawWrappedText(
            canvas = canvas,
            text = data.recipientAddress,
            x = 37f,
            firstBaselineY = 385f,
            lineHeight = 25f,
            maxWidth = 561f,
            maxLines = 4,
            typeface = serifBold,
            textSize = 19.2f,
            scaleX = 0.95f
        )

        // 8. Band E: Pengirim (Sender) Section (505..604)
        canvas.drawLine(boxLeft, 604f, boxRight, 604f, thinBorderPaint)
        drawLeftText(
            canvas = canvas,
            text = "Pengirim: ${data.senderName}",
            x = 34f,
            baselineY = 527f,
            typeface = sansRegular,
            textSize = 18.8f,
            scaleX = 0.96f,
            maxWidth = 395f
        )
        drawRightText(
            canvas = canvas,
            text = data.senderPhone,
            rightX = 601f,
            baselineY = 527f,
            typeface = sansRegular,
            textSize = 18.5f,
            scaleX = 0.92f,
            maxWidth = 160f
        )
        drawLeftText(
            canvas = canvas,
            text = data.senderArea,
            x = 37f,
            baselineY = 552f,
            typeface = sansBold,
            textSize = 19.5f,
            scaleX = 0.85f,
            maxWidth = 555f
        )

        // 9. Band F: Info Grid Table (604..682)
        val col1Right = 177f
        val col2Right = 317f
        val col3Right = 454f
        val midRowY = 641f

        // Vertical & horizontal cell lines
        canvas.drawLine(col1Right, 604f, col1Right, boxBottom, borderPaint)
        canvas.drawLine(col2Right, 604f, col2Right, midRowY, borderPaint)
        canvas.drawLine(col3Right, 604f, col3Right, boxBottom, borderPaint)
        canvas.drawLine(col1Right, midRowY, boxRight, midRowY, thinBorderPaint)

        // Column 1: Black header + Fee + Tax note
        canvas.drawRect(boxLeft, 604f, col1Right, 636f, blackFill)
        drawCenteredText(
            canvas = canvas,
            text = data.shippingFeeLabel,
            cx = (boxLeft + col1Right) / 2f,
            cy = 620f,
            typeface = serifRegular,
            textSize = 12.2f,
            color = Color.WHITE,
            scaleX = 0.78f,
            maxWidth = col1Right - boxLeft - 8f
        )
        drawCenteredText(
            canvas = canvas,
            text = data.shippingFeeAmount,
            cx = (boxLeft + col1Right) / 2f,
            cy = 650f,
            typeface = serifBold,
            textSize = 19.5f,
            color = Color.rgb(18, 18, 18),
            scaleX = 0.90f,
            maxWidth = col1Right - boxLeft - 8f
        )
        drawCenteredText(
            canvas = canvas,
            text = data.taxIncludedText,
            cx = (boxLeft + col1Right) / 2f,
            cy = 670f,
            typeface = sansRegular,
            textSize = 13f,
            color = Color.rgb(18, 18, 18),
            scaleX = 0.74f,
            maxWidth = col1Right - boxLeft - 6f
        )

        // Top Row Cells: Payment | Weight | Print Date
        drawCenteredText(
            canvas = canvas,
            text = data.paymentMethod,
            cx = (col1Right + col2Right) / 2f,
            cy = 623f,
            typeface = serifRegular,
            textSize = 18.8f,
            color = Color.rgb(18, 18, 18),
            scaleX = 0.92f,
            maxWidth = col2Right - col1Right - 10f
        )
        drawCenteredText(
            canvas = canvas,
            text = data.weight,
            cx = (col2Right + col3Right) / 2f,
            cy = 623f,
            typeface = serifRegular,
            textSize = 18.5f,
            color = Color.rgb(18, 18, 18),
            scaleX = 0.94f,
            maxWidth = col3Right - col2Right - 10f
        )
        drawCenteredText(
            canvas = canvas,
            text = "Cetak ${data.printDate}",
            cx = (col3Right + boxRight) / 2f,
            cy = 623f,
            typeface = serifRegular,
            textSize = 17.5f,
            color = Color.rgb(18, 18, 18),
            scaleX = 0.88f,
            maxWidth = boxRight - col3Right - 8f
        )

        // Bottom Row Cells: Order No | Exp
        drawEllipsizedLeftText(
            canvas = canvas,
            text = "Order No ${data.orderNumber}",
            x = 191f,
            baselineY = 667f,
            typeface = serifRegular,
            textSize = 17.8f,
            scaleX = 0.89f,
            maxWidth = col3Right - 196f
        )
        val expDisplay = if (data.expCode.isNotBlank()) "Exp ${data.expCode}" else "Exp"
        drawLeftText(
            canvas = canvas,
            text = expDisplay,
            x = 465f,
            baselineY = 667f,
            typeface = sansRegular,
            textSize = 18.5f,
            scaleX = 0.94f,
            maxWidth = boxRight - 470f
        )

        // 10. Middle Unboxed Area: Notes + T&C + QR Code (682..890)
        val upperNotesText = if (data.notes.isNotBlank()) "Notes: ${data.notes}" else "Notes:"
        drawWrappedText(
            canvas = canvas,
            text = upperNotesText,
            x = 31f,
            firstBaselineY = 702f,
            lineHeight = 21f,
            maxWidth = 405f,
            maxLines = 4,
            typeface = sansRegular,
            textSize = 18.5f,
            scaleX = 0.90f
        )

        // 21x21 Crisp Vector QR Code
        BarcodeVectorHelper.drawQrCode(
            canvas = canvas,
            content = data.waybillNumber,
            left = 449f,
            top = 702f,
            size = 139f
        )

        // 4-line Company & Terms block (omitted cleanly when scanning non-courier/blank-company docs)
        val hasCompanyTerms = data.websiteUrl.isNotBlank() || data.companyNameAndTax.isNotBlank()
        val tcLinesUpper = if (hasCompanyTerms) {
            listOf(
                "Syarat dan ketentuan pengiriman dilihat pada website",
                data.companyNameAndTax,
                data.companyAddressLine1,
                data.companyAddressLine2
            )
        } else {
            listOf(
                data.companyNameAndTax,
                data.companyAddressLine1,
                data.companyAddressLine2
            ).filter { it.isNotBlank() }
        }
        tcLinesUpper.forEachIndexed { idx, line ->
            drawLeftText(
                canvas = canvas,
                text = line,
                x = 34f,
                baselineY = 815f + idx * 18.2f,
                typeface = if (idx == 0 && hasCompanyTerms) serifBold else sansBold,
                textSize = 15.6f,
                scaleX = 0.78f,
                maxWidth = 405f
            )
        }

        // 11. Secondary Barcode Above Tear-Off Stub (902..954)
        BarcodeVectorHelper.drawCode128(
            canvas = canvas,
            content = data.waybillNumber,
            left = 213f,
            top = 902f,
            right = 579f,
            bottom = 934f
        )
        drawCenteredText(
            canvas = canvas,
            text = data.waybillNumber,
            cx = 396f,
            cy = 946f,
            typeface = sansBold,
            textSize = 15.2f,
            color = Color.rgb(18, 18, 18),
            scaleX = 0.88f,
            maxWidth = 300f
        )

        // 12. Horizontal Tear-Off Divider (969)
        val stubLeft = 8f
        val stubRight = 613f
        canvas.drawLine(stubLeft, 969f, stubRight, 969f, thinBorderPaint)

        // 13. Lower Stub ("Lembar Pengirim") Summary (969..1087)
        drawLeftText(
            canvas = canvas,
            text = "Pengirim : ${data.senderName}",
            x = 31f,
            baselineY = 992f,
            typeface = sansBold,
            textSize = 18.2f,
            scaleX = 0.96f,
            maxWidth = 420f
        )
        drawRightText(
            canvas = canvas,
            text = data.formattedStubPhone(data.senderPhone),
            rightX = 588f,
            baselineY = 992f,
            typeface = sansBold,
            textSize = 18.2f,
            scaleX = 0.94f,
            maxWidth = 165f
        )

        drawLeftText(
            canvas = canvas,
            text = "Penerima : ${data.recipientName}",
            x = 31f,
            baselineY = 1020f,
            typeface = sansBold,
            textSize = 18.2f,
            scaleX = 0.96f,
            maxWidth = 420f
        )
        drawRightText(
            canvas = canvas,
            text = data.formattedStubPhone(data.recipientPhone),
            rightX = 588f,
            baselineY = 1020f,
            typeface = sansBold,
            textSize = 18.2f,
            scaleX = 0.94f,
            maxWidth = 165f
        )

        drawWrappedText(
            canvas = canvas,
            text = data.recipientAddress,
            x = 32f,
            firstBaselineY = 1047f,
            lineHeight = 20.5f,
            maxWidth = 556f,
            maxLines = 2,
            typeface = serifBold,
            textSize = 16.2f,
            scaleX = 0.95f
        )

        // 14. Stub Bottom Split Table (1087..1269)
        val stubTableTop = 1087f
        val stubSplitX = 228f
        canvas.drawLine(stubLeft, stubTableTop, stubRight, stubTableTop, thinBorderPaint)
        canvas.drawLine(stubSplitX, stubTableTop, stubSplitX, 1269f, borderPaint)

        // Left Column: TOTAL BIAYA + IDR + PPN + Solid Black "Lembar Pengirim"
        val leftColCenter = (stubLeft + stubSplitX) / 2f
        drawCenteredText(
            canvas = canvas,
            text = "TOTAL BIAYA",
            cx = leftColCenter,
            cy = 1118f,
            typeface = sansBold,
            textSize = 25.5f,
            color = Color.rgb(18, 18, 18),
            scaleX = 0.95f,
            maxWidth = stubSplitX - stubLeft - 12f
        )
        drawCenteredText(
            canvas = canvas,
            text = data.shippingFeeAmount,
            cx = leftColCenter,
            cy = 1154f,
            typeface = sansBold,
            textSize = 26f,
            color = Color.rgb(18, 18, 18),
            scaleX = 0.92f,
            maxWidth = stubSplitX - stubLeft - 12f
        )
        drawCenteredText(
            canvas = canvas,
            text = data.taxIncludedText,
            cx = leftColCenter,
            cy = 1186f,
            typeface = sansRegular,
            textSize = 16.5f,
            color = Color.rgb(45, 45, 45),
            scaleX = 0.92f,
            maxWidth = stubSplitX - stubLeft - 10f
        )

        canvas.drawRect(stubLeft, 1216f, stubSplitX, 1269f, blackFill)
        drawCenteredText(
            canvas = canvas,
            text = data.stubBadgeText,
            cx = leftColCenter,
            cy = 1243f,
            typeface = sansBold,
            textSize = 20.5f,
            color = Color.WHITE,
            scaleX = 0.94f,
            maxWidth = stubSplitX - stubLeft - 14f
        )

        // Right Column Sub-rows
        // Sub-row 1: Qty + Category (1087..1114)
        canvas.drawLine(stubSplitX, 1114f, stubRight, 1114f, thinBorderPaint)
        drawLeftText(
            canvas = canvas,
            text = "Qty : ${data.quantityText}    ${data.itemCategory}",
            x = 233f,
            baselineY = 1107f,
            typeface = sansRegular,
            textSize = 17.5f,
            scaleX = 0.95f,
            maxWidth = stubRight - 238f
        )

        // Sub-row 2: Notes (1114..1184)
        canvas.drawLine(stubSplitX, 1184f, stubRight, 1184f, thinBorderPaint)
        val stubNotes = if (data.notes.isNotBlank()) "Notes: ${data.notes}" else "Notes:"
        drawWrappedText(
            canvas = canvas,
            text = stubNotes,
            x = 233f,
            firstBaselineY = 1135f,
            lineHeight = 19f,
            maxWidth = stubRight - 240f,
            maxLines = 2,
            typeface = sansRegular,
            textSize = 17.5f,
            scaleX = 0.92f
        )

        // Sub-row 3: Cetak Date | Exp (1184..1212)
        val expSplitX = 508f
        canvas.drawLine(stubSplitX, 1212f, stubRight, 1212f, thinBorderPaint)
        canvas.drawLine(expSplitX, 1184f, expSplitX, 1212f, thinBorderPaint)
        drawLeftText(
            canvas = canvas,
            text = "Cetak ${data.printDate}",
            x = 244f,
            baselineY = 1204f,
            typeface = sansRegular,
            textSize = 16.5f,
            scaleX = 0.90f,
            maxWidth = expSplitX - 250f
        )
        drawLeftText(
            canvas = canvas,
            text = expDisplay,
            x = 528f,
            baselineY = 1204f,
            typeface = sansRegular,
            textSize = 16.5f,
            scaleX = 0.92f,
            maxWidth = stubRight - 532f
        )

        // Sub-row 4: 3-line Footer T&C (1212..1269)
        val tcLinesStub = if (hasCompanyTerms) {
            val termsHeader = if (data.websiteUrl.isNotBlank()) {
                "Syarat dan ketentuan pengiriman dilihat pada website ${data.websiteUrl}"
            } else {
                "Syarat dan ketentuan pengiriman berlaku"
            }
            listOf(
                termsHeader,
                data.companyNameAndTax,
                data.companyAddressLine1
            )
        } else {
            listOf(
                data.companyNameAndTax,
                data.companyAddressLine1
            ).filter { it.isNotBlank() }
        }
        tcLinesStub.forEachIndexed { idx, line ->
            drawLeftText(
                canvas = canvas,
                text = line,
                x = 236f,
                baselineY = 1230f + idx * 16.2f,
                typeface = if (idx == 0 && hasCompanyTerms) serifBold else sansRegular,
                textSize = 14.5f,
                scaleX = 0.77f,
                maxWidth = stubRight - 240f
            )
        }
    }

    private fun drawCenteredText(
        canvas: Canvas,
        text: String,
        cx: Float,
        cy: Float,
        typeface: Typeface,
        textSize: Float,
        color: Int = Color.rgb(18, 18, 18),
        scaleX: Float = 1f,
        letterSpacing: Float = 0f,
        maxWidth: Float = Float.MAX_VALUE
    ) {
        if (text.isEmpty()) return
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.typeface = typeface
            this.textSize = textSize
            this.textScaleX = scaleX
            this.letterSpacing = letterSpacing
            this.textAlign = Paint.Align.CENTER
        }
        fitPaintTextSize(paint, text, maxWidth)
        val baseline = cy - (paint.descent() + paint.ascent()) / 2f
        canvas.drawText(text, cx, baseline, paint)
    }

    private fun drawLeftText(
        canvas: Canvas,
        text: String,
        x: Float,
        baselineY: Float,
        typeface: Typeface,
        textSize: Float,
        color: Int = Color.rgb(18, 18, 18),
        scaleX: Float = 1f,
        maxWidth: Float = Float.MAX_VALUE
    ) {
        if (text.isEmpty()) return
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.typeface = typeface
            this.textSize = textSize
            this.textScaleX = scaleX
            this.textAlign = Paint.Align.LEFT
        }
        fitPaintTextSize(paint, text, maxWidth)
        canvas.drawText(text, x, baselineY, paint)
    }

    private fun drawRightText(
        canvas: Canvas,
        text: String,
        rightX: Float,
        baselineY: Float,
        typeface: Typeface,
        textSize: Float,
        color: Int = Color.rgb(18, 18, 18),
        scaleX: Float = 1f,
        maxWidth: Float = Float.MAX_VALUE
    ) {
        if (text.isEmpty()) return
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.typeface = typeface
            this.textSize = textSize
            this.textScaleX = scaleX
            this.textAlign = Paint.Align.RIGHT
        }
        fitPaintTextSize(paint, text, maxWidth)
        canvas.drawText(text, rightX, baselineY, paint)
    }

    private fun drawRotated90Text(
        canvas: Canvas,
        text: String,
        cx: Float,
        cy: Float,
        typeface: Typeface,
        textSize: Float,
        scaleX: Float = 0.82f
    ) {
        if (text.isEmpty()) return
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(18, 18, 18)
            this.typeface = typeface
            this.textSize = textSize
            this.textScaleX = scaleX
            this.textAlign = Paint.Align.CENTER
        }
        canvas.withTranslation(cx, cy) {
            rotate(90f)
            val baseline = -(paint.descent() + paint.ascent()) / 2f
            drawText(text, 0f, baseline, paint)
        }
    }

    private fun drawEllipsizedLeftText(
        canvas: Canvas,
        text: String,
        x: Float,
        baselineY: Float,
        typeface: Typeface,
        textSize: Float,
        color: Int = Color.rgb(18, 18, 18),
        scaleX: Float = 1f,
        maxWidth: Float
    ) {
        if (text.isEmpty() || maxWidth <= 0f) return
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.typeface = typeface
            this.textSize = textSize
            this.textScaleX = scaleX
            this.textAlign = Paint.Align.LEFT
        }
        val finalText = ellipsizeToWidth(paint, text, maxWidth, "...")
        canvas.drawText(finalText, x, baselineY, paint)
    }

    private fun drawWrappedText(
        canvas: Canvas,
        text: String,
        x: Float,
        firstBaselineY: Float,
        lineHeight: Float,
        maxWidth: Float,
        maxLines: Int,
        typeface: Typeface,
        textSize: Float,
        scaleX: Float = 1f
    ) {
        if (text.isEmpty() || maxWidth <= 0f || maxLines <= 0) return
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(18, 18, 18)
            this.typeface = typeface
            this.textSize = textSize
            this.textScaleX = scaleX
            this.textAlign = Paint.Align.LEFT
        }

        val lines = mutableListOf<String>()
        val paragraphs = text.replace("\r\n", "\n").split('\n')

        for (paragraph in paragraphs) {
            val trimmedPara = paragraph.trim()
            if (trimmedPara.isEmpty()) {
                if (lines.isNotEmpty()) lines.add("")
                continue
            }
            val words = trimmedPara.split(Regex("\\s+"))
            var currentLine = ""

            for (word in words) {
                if (paint.measureText(word) > maxWidth) {
                    if (currentLine.isNotEmpty()) {
                        lines.add(currentLine)
                        currentLine = ""
                    }
                    // Break ultra-long unbroken word by character width so it never overflows border
                    var chunk = ""
                    for (ch in word) {
                        val nextChunk = chunk + ch
                        if (paint.measureText(nextChunk) <= maxWidth || chunk.isEmpty()) {
                            chunk = nextChunk
                        } else {
                            lines.add(chunk)
                            chunk = ch.toString()
                        }
                    }
                    currentLine = chunk
                } else {
                    val candidate = if (currentLine.isEmpty()) word else "$currentLine $word"
                    if (paint.measureText(candidate) <= maxWidth || currentLine.isEmpty()) {
                        currentLine = candidate
                    } else {
                        lines.add(currentLine)
                        currentLine = word
                    }
                }
            }
            if (currentLine.isNotEmpty()) {
                lines.add(currentLine)
            }
        }

        val visibleLines = if (lines.size <= maxLines) {
            lines
        } else {
            val truncated = lines.take(maxLines).toMutableList()
            truncated[maxLines - 1] = ellipsizeToWidth(paint, truncated[maxLines - 1], maxWidth, "…")
            truncated
        }

        visibleLines.forEachIndexed { index, line ->
            canvas.drawText(line, x, firstBaselineY + index * lineHeight, paint)
        }
    }

    private fun ellipsizeToWidth(
        paint: Paint,
        text: String,
        maxWidth: Float,
        suffix: String
    ): String {
        if (paint.measureText(text) <= maxWidth) return text
        var end = text.length
        while (end > 0 && paint.measureText(text.substring(0, end).trimEnd() + suffix) > maxWidth) {
            end--
        }
        return if (end > 0) text.substring(0, end).trimEnd() + suffix else suffix
    }

    private fun fitPaintTextSize(paint: Paint, text: String, maxWidth: Float) {
        if (maxWidth == Float.MAX_VALUE || maxWidth <= 0f) return
        var currentSize = paint.textSize
        while (currentSize > 8f && paint.measureText(text) > maxWidth) {
            currentSize -= 0.5f
            paint.textSize = currentSize
        }
    }
}
