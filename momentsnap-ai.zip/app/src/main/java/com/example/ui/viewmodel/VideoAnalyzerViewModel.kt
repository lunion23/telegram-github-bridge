package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.VideoAnalysisResult
import com.example.data.model.VideoMoment
import com.example.data.repository.VideoAnalysisRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class VideoAnalyzerViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    private val repository = VideoAnalysisRepository(application, database.analysisDao())

    val savedAnalyses: StateFlow<List<VideoAnalysisResult>> = repository.savedAnalyses
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _currentAnalysis = MutableStateFlow<VideoAnalysisResult?>(null)
    val currentAnalysis: StateFlow<VideoAnalysisResult?> = _currentAnalysis.asStateFlow()

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _progressMessage = MutableStateFlow("Menyiapkan analisa video...")
    val progressMessage: StateFlow<String> = _progressMessage.asStateFlow()

    private val _targetSeekSecond = MutableStateFlow<Int?>(null)
    val targetSeekSecond: StateFlow<Int?> = _targetSeekSecond.asStateFlow()

    private val _activeTab = MutableStateFlow(0) // 0: Momen, 1: Hooks, 2: Deskripsi, 3: SEO
    val activeTab: StateFlow<Int> = _activeTab.asStateFlow()

    private val _youtubeInput = MutableStateFlow("")
    val youtubeInput: StateFlow<String> = _youtubeInput.asStateFlow()

    private val _titleInput = MutableStateFlow("")
    val titleInput: StateFlow<String> = _titleInput.asStateFlow()

    private val _notesInput = MutableStateFlow("")
    val notesInput: StateFlow<String> = _notesInput.asStateFlow()

    fun setYoutubeInput(url: String) {
        _youtubeInput.value = url
    }

    fun setTitleInput(title: String) {
        _titleInput.value = title
    }

    fun setNotesInput(notes: String) {
        _notesInput.value = notes
    }

    fun setActiveTab(tab: Int) {
        _activeTab.value = tab
    }

    fun seekToSecond(second: Int) {
        _targetSeekSecond.value = second
    }

    fun resetSeek() {
        _targetSeekSecond.value = null
    }

    fun clearCurrentAnalysis() {
        _currentAnalysis.value = null
        _targetSeekSecond.value = null
    }

    fun analyzeYouTube(url: String, title: String, notes: String) {
        if (url.isBlank()) return
        viewModelScope.launch {
            _isAnalyzing.value = true
            _progressMessage.value = "Menghubungkan ke video YouTube..."
            try {
                val result = repository.analyzeYouTubeVideo(
                    youtubeUrl = url,
                    titleHint = title,
                    userNotes = notes,
                    onProgressUpdate = { msg -> _progressMessage.value = msg }
                )
                _currentAnalysis.value = result
                _activeTab.value = 0
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isAnalyzing.value = false
            }
        }
    }

    fun analyzeLocalVideo(uri: Uri, title: String, notes: String) {
        viewModelScope.launch {
            _isAnalyzing.value = true
            _progressMessage.value = "Membuka video dari galeri lokal..."
            try {
                val result = repository.analyzeLocalVideo(
                    uri = uri,
                    titleHint = title,
                    userNotes = notes,
                    onProgressUpdate = { msg -> _progressMessage.value = msg }
                )
                _currentAnalysis.value = result
                _activeTab.value = 0
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isAnalyzing.value = false
            }
        }
    }

    fun loadSample(sample: VideoAnalysisResult) {
        viewModelScope.launch {
            _isAnalyzing.value = true
            _progressMessage.value = "Memuat data analisis video sampel..."
            val result = repository.loadSample(sample)
            _currentAnalysis.value = result
            _activeTab.value = 0
            _isAnalyzing.value = false
        }
    }

    fun selectSavedAnalysis(analysis: VideoAnalysisResult) {
        _currentAnalysis.value = analysis
        _activeTab.value = 0
    }

    fun deleteAnalysis(id: String) {
        viewModelScope.launch {
            repository.deleteAnalysis(id)
            if (_currentAnalysis.value?.id == id) {
                _currentAnalysis.value = null
            }
        }
    }

    fun getSamplePresets(): List<VideoAnalysisResult> {
        return repository.getSamplePresets()
    }
}
