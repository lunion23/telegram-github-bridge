package com.example.data.model

object SampleDataGenerator {
    fun generate10ColumnDataset(): List<CsvRowEntity> {
        val rows = mutableListOf<CsvRowEntity>()

        data class RawItem(
            val id: String,
            val date: String,
            val customer: String,
            val category: String,
            val product: String,
            val qty: String,
            val price: String,
            val discount: String,
            val total: String,
            val status: String
        )

        val rawList = listOf(
            RawItem("TRX-2026-001", "2026-10-01", "PT Maju Bersama", "Hardware", "Server Rack 42U", "2", "14500000", "5", "27550000", "Lunas"),
            RawItem("TRX-2026-001", "2026-10-01", "PT Maju Bersama", "Network", "Switch Cisco 24-Port", "4", "3850000", "0", "15400000", "Lunas"),
            RawItem("TRX-2026-001", "2026-10-01", "PT Maju Bersama", "Accessories", "Kabel UTP Cat6 305m", "6", "1250000", "10", "6750000", "Lunas"),

            RawItem("TRX-2026-002", "2026-10-02", "CV Cahaya Abadi", "Software", "Lisensi DB Enterprise", "1", "32000000", "0", "32000000", "Proses"),
            RawItem("TRX-2026-002", "2026-10-02", "CV Cahaya Abadi", "Software", "Cloud Backup 10TB/Thn", "1", "8500000", "15", "7225000", "Proses"),

            RawItem("TRX-2026-003", "2026-10-03", "Toko Berkah Mandiri", "Elektronik", "Monitor UltraWide 34\"", "5", "6200000", "5", "29450000", "Lunas"),
            RawItem("TRX-2026-003", "2026-10-03", "Toko Berkah Mandiri", "Elektronik", "Keyboard Mekanikal Pro", "10", "850000", "0", "8500000", "Lunas"),
            RawItem("TRX-2026-003", "2026-10-03", "Toko Berkah Mandiri", "Elektronik", "Mouse Wireless Ergonomic", "10", "420000", "0", "4200000", "Lunas"),

            RawItem("TRX-2026-004", "2026-10-04", "Dinas Kominfo", "Hardware", "Workstation AI 64GB", "3", "45000000", "8", "124200000", "Pending"),

            RawItem("TRX-2026-005", "2026-10-05", "Studio Animasi Kreatif", "Komputer", "GPU RTX 4090 24GB", "2", "31000000", "0", "62000000", "Lunas"),
            RawItem("TRX-2026-005", "2026-10-05", "Studio Animasi Kreatif", "Komputer", "RAM DDR5 64GB Kit", "4", "3200000", "5", "12160000", "Lunas"),

            RawItem("TRX-2026-006", "2026-10-06", "PT Sentosa Logistik", "Logistik", "Barcode Scanner Wireless", "12", "1100000", "10", "11880000", "Lunas"),
            RawItem("TRX-2026-006", "2026-10-06", "PT Sentosa Logistik", "Logistik", "Printer Thermal Resi", "4", "1850000", "0", "7400000", "Lunas"),

            RawItem("TRX-2026-007", "2026-10-07", "RS Medika Sejahtera", "Medis", "UPS Online 5000VA", "2", "18500000", "5", "35150000", "Lunas"),
            RawItem("TRX-2026-007", "2026-10-07", "RS Medika Sejahtera", "Network", "Access Point WiFi 6", "8", "2100000", "0", "16800000", "Lunas"),
            RawItem("TRX-2026-007", "2026-10-07", "RS Medika Sejahtera", "Hardware", "Tablet Medis Rugged 10\"", "5", "7500000", "10", "33750000", "Lunas"),

            RawItem("TRX-2026-008", "2026-10-08", "Universitas Tekno Nusantara", "Software", "Campus License IDE", "50", "450000", "20", "18000000", "Lunas"),

            RawItem("TRX-2026-009", "2026-10-09", "Bank Swasta Nasional", "Security", "Hardware Security Module", "2", "65000000", "0", "130000000", "Proses"),
            RawItem("TRX-2026-009", "2026-10-09", "Bank Swasta Nasional", "Security", "Firewall Appliance HA", "2", "48000000", "5", "91200000", "Proses"),

            RawItem("TRX-2026-010", "2026-10-10", "PT Karya Digital Mandiri", "Cloud", "Dedicated Server 128GB", "2", "12500000", "10", "22500000", "Lunas"),
            RawItem("TRX-2026-010", "2026-10-10", "PT Karya Digital Mandiri", "Cloud", "Domain & Wildcard SSL", "3", "1800000", "0", "5400000", "Lunas")
        )

        for (item in rawList) {
            rows.add(
                CsvRowEntity(
                    recordId = item.id,
                    col0 = item.id,
                    col1 = item.date,
                    col2 = item.customer,
                    col3 = item.category,
                    col4 = item.product,
                    col5 = item.qty,
                    col6 = item.price,
                    col7 = item.discount,
                    col8 = item.total,
                    col9 = item.status
                )
            )
        }

        return rows
    }
}
