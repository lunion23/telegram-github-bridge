package com.example.data.parser

import com.example.data.model.ImportProgress
import com.example.data.model.WorkOrderItem
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

object XlsxStreamParser {

    private const val DEFAULT_CHUNK_SIZE = 2500

    /**
     * Parses an XLSX (Excel) workbook stream using native ZipInputStream and XmlPullParser.
     * Extracts shared strings and row records without requiring heavy third-party dependencies.
     */
    suspend fun parseXlsxStreamInBatches(
        inputStream: InputStream,
        totalBytesEstimate: Long = 0L,
        chunkSize: Int = DEFAULT_CHUNK_SIZE,
        onBatchReady: suspend (batch: List<WorkOrderItem>, progress: ImportProgress) -> Unit
    ): Long = withContext(Dispatchers.IO) {
        val zipIn = ZipInputStream(inputStream)
        var sharedStrings: List<String> = emptyList()
        var sheet1Bytes: ByteArray? = null

        var entry: ZipEntry? = zipIn.nextEntry
        while (entry != null) {
            val name = entry.name
            if (name == "xl/sharedStrings.xml") {
                sharedStrings = parseSharedStrings(readEntryBytes(zipIn))
            } else if (name == "xl/worksheets/sheet1.xml") {
                sheet1Bytes = readEntryBytes(zipIn)
            }
            zipIn.closeEntry()
            entry = zipIn.nextEntry
        }

        if (sheet1Bytes == null) {
            return@withContext 0L
        }

        return@withContext parseSheetRows(
            sheetStream = ByteArrayInputStream(sheet1Bytes),
            sharedStrings = sharedStrings,
            totalBytesEstimate = totalBytesEstimate,
            chunkSize = chunkSize,
            onBatchReady = onBatchReady
        )
    }

    private fun readEntryBytes(zipIn: ZipInputStream): ByteArray {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var count = zipIn.read(buffer)
        while (count != -1) {
            out.write(buffer, 0, count)
            count = zipIn.read(buffer)
        }
        return out.toByteArray()
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val strings = mutableListOf<String>()
        val factory = XmlPullParserFactory.newInstance()
        val parser = factory.newPullParser()
        parser.setInput(ByteArrayInputStream(bytes), "UTF-8")

        var eventType = parser.eventType
        val currentText = StringBuilder()
        var inText = false

        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    if (parser.name == "t") {
                        inText = true
                        currentText.clear()
                    }
                }
                XmlPullParser.TEXT -> {
                    if (inText) {
                        currentText.append(parser.text)
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name == "t") {
                        inText = false
                    } else if (parser.name == "si") {
                        strings.add(currentText.toString())
                        currentText.clear()
                    }
                }
            }
            eventType = parser.next()
        }
        return strings
    }

    private suspend fun parseSheetRows(
        sheetStream: InputStream,
        sharedStrings: List<String>,
        totalBytesEstimate: Long,
        chunkSize: Int,
        onBatchReady: suspend (batch: List<WorkOrderItem>, progress: ImportProgress) -> Unit
    ): Long = withContext(Dispatchers.IO) {
        val factory = XmlPullParserFactory.newInstance()
        val parser = factory.newPullParser()
        parser.setInput(sheetStream, "UTF-8")

        var totalRows = 0L
        var batchNumber = 0
        val startTime = System.currentTimeMillis()

        var currentRowCells = mutableMapOf<Int, String>()
        var currentCellRef = ""
        var currentCellType = ""
        var currentCellValue = StringBuilder()
        var isReadingValue = false

        var headers = listOf<String>()
        val currentBatchList = ArrayList<WorkOrderItem>(chunkSize)

        var idxName = 0
        var idxMobil = 1
        var idxTrandate = 2
        var idxKm = 3
        var idxKeluhan = 4
        var idxTipe = 5
        var idxKode = 6
        var idxDesc = 7
        var idxCatatan = 8
        var idxStartTime = 9
        var idxEndTime = 10
        var idxQty = 11
        var idxTotal = 12
        var idxTotalPrice = 13
        var idxProductClass = 14
        var idxNoChassis = 15
        var idxNoMesin = 16

        var eventType = parser.eventType
        while (eventType != XmlPullParser.END_DOCUMENT) {
            if (!currentCoroutineContext().isActive) {
                throw CancellationException("Import XLSX dibatalkan.")
            }

            when (eventType) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "row" -> {
                            currentRowCells.clear()
                        }
                        "c" -> {
                            currentCellRef = parser.getAttributeValue(null, "r") ?: ""
                            currentCellType = parser.getAttributeValue(null, "t") ?: ""
                            currentCellValue.clear()
                        }
                        "v" -> {
                            isReadingValue = true
                            currentCellValue.clear()
                        }
                    }
                }
                XmlPullParser.TEXT -> {
                    if (isReadingValue) {
                        currentCellValue.append(parser.text)
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "v" -> {
                            isReadingValue = false
                        }
                        "c" -> {
                            val colIdx = colRefToIndex(currentCellRef)
                            val rawVal = currentCellValue.toString()
                            val resolvedVal = if (currentCellType == "s") {
                                val sIndex = rawVal.toIntOrNull() ?: -1
                                if (sIndex in sharedStrings.indices) sharedStrings[sIndex] else rawVal
                            } else {
                                rawVal
                            }
                            currentRowCells[colIdx] = resolvedVal
                        }
                        "row" -> {
                            if (currentRowCells.isNotEmpty()) {
                                if (headers.isEmpty()) {
                                    // First row is headers
                                    val maxCol = currentRowCells.keys.maxOrNull() ?: 0
                                    val headerList = mutableListOf<String>()
                                    for (c in 0..maxCol) {
                                        headerList.add(currentRowCells[c]?.trim()?.lowercase() ?: "")
                                    }
                                    headers = headerList

                                    idxName = headers.indexOfFirst { it == "name" || it.contains("id wo") || it.contains("no wo") }.coerceAtLeast(0)
                                    idxMobil = headers.indexOfFirst { it == "mobilname" || it.contains("mobil") || it.contains("nopol") }.coerceAtLeast(1)
                                    idxTrandate = headers.indexOfFirst { it == "trandate" || it.contains("tanggal") || it.contains("date") }.coerceAtLeast(2)
                                    idxKm = headers.indexOfFirst { it == "kmcurrent" || it.contains("km") || it.contains("odometer") }.coerceAtLeast(3)
                                    idxKeluhan = headers.indexOfFirst { it == "keluhan" || it.contains("keluhan") || it.contains("masalah") }.coerceAtLeast(4)
                                    idxTipe = headers.indexOfFirst { it == "tipe" || it.contains("tipe") || it.contains("type") }.coerceAtLeast(5)
                                    idxKode = headers.indexOfFirst { it == "kode" || it.contains("kode") || it.contains("code") }.coerceAtLeast(6)
                                    idxDesc = headers.indexOfFirst { it == "description" || it.contains("deskripsi") || it.contains("pekerjaan") }.coerceAtLeast(7)
                                    idxCatatan = headers.indexOfFirst { it == "catatan" || it.contains("catatan") || it.contains("note") }.coerceAtLeast(8)
                                    idxStartTime = headers.indexOfFirst { it == "starttime" || it.contains("start") }.coerceAtLeast(9)
                                    idxEndTime = headers.indexOfFirst { it == "endtime" || it.contains("end") }.coerceAtLeast(10)
                                    idxQty = headers.indexOfFirst { it == "qty" || it.contains("jumlah") }.coerceAtLeast(11)
                                    idxTotal = headers.indexOfFirst { it == "total" }.coerceAtLeast(12)
                                    idxTotalPrice = headers.indexOfFirst { it == "totalprice" || it.contains("harga") || it.contains("biaya") }.coerceAtLeast(13)
                                    idxProductClass = headers.indexOfFirst { it == "productclass" || it.contains("class") || it.contains("kategori") }.coerceAtLeast(14)
                                    idxNoChassis = headers.indexOfFirst { it == "nochassis" || it.contains("chassis") || it.contains("rangka") }.coerceAtLeast(15)
                                    idxNoMesin = headers.indexOfFirst { it == "nomesin" || it.contains("mesin") || it.contains("engine") }.coerceAtLeast(16)
                                } else {
                                    val item = buildItemFromMap(
                                        map = currentRowCells,
                                        idxName = idxName,
                                        idxMobil = idxMobil,
                                        idxTrandate = idxTrandate,
                                        idxKm = idxKm,
                                        idxKeluhan = idxKeluhan,
                                        idxTipe = idxTipe,
                                        idxKode = idxKode,
                                        idxDesc = idxDesc,
                                        idxCatatan = idxCatatan,
                                        idxStartTime = idxStartTime,
                                        idxEndTime = idxEndTime,
                                        idxQty = idxQty,
                                        idxTotal = idxTotal,
                                        idxTotalPrice = idxTotalPrice,
                                        idxProductClass = idxProductClass,
                                        idxNoChassis = idxNoChassis,
                                        idxNoMesin = idxNoMesin
                                    )
                                    currentBatchList.add(item)
                                    totalRows++

                                    if (currentBatchList.size >= chunkSize) {
                                        batchNumber++
                                        val elapsed = (System.currentTimeMillis() - startTime) / 1000.0
                                        val speed = if (elapsed > 0) totalRows / elapsed else 0.0
                                        val progress = ImportProgress(
                                            isImporting = true,
                                            processedRows = totalRows,
                                            totalEstimatedRows = totalRows,
                                            percentage = 50,
                                            currentSpeedRowsPerSec = speed,
                                            currentBatch = batchNumber,
                                            statusText = "Menyimpan transaksi batch Excel #$batchNumber (${currentBatchList.size} baris)..."
                                        )
                                        onBatchReady(currentBatchList.toList(), progress)
                                        currentBatchList.clear()
                                    }
                                }
                            }
                        }
                    }
                }
            }
            eventType = parser.next()
        }

        if (currentBatchList.isNotEmpty()) {
            batchNumber++
            val elapsed = (System.currentTimeMillis() - startTime) / 1000.0
            val speed = if (elapsed > 0) totalRows / elapsed else 0.0
            val progress = ImportProgress(
                isImporting = true,
                processedRows = totalRows,
                totalEstimatedRows = totalRows,
                percentage = 100,
                currentSpeedRowsPerSec = speed,
                currentBatch = batchNumber,
                statusText = "Menyimpan sisa batch akhir (${currentBatchList.size} baris)..."
            )
            onBatchReady(currentBatchList.toList(), progress)
            currentBatchList.clear()
        }

        return@withContext totalRows
    }

    private fun colRefToIndex(ref: String): Int {
        var col = 0
        for (ch in ref) {
            if (ch in 'A'..'Z') {
                col = col * 26 + (ch - 'A' + 1)
            }
        }
        return (col - 1).coerceAtLeast(0)
    }

    private fun buildItemFromMap(
        map: Map<Int, String>,
        idxName: Int,
        idxMobil: Int,
        idxTrandate: Int,
        idxKm: Int,
        idxKeluhan: Int,
        idxTipe: Int,
        idxKode: Int,
        idxDesc: Int,
        idxCatatan: Int,
        idxStartTime: Int,
        idxEndTime: Int,
        idxQty: Int,
        idxTotal: Int,
        idxTotalPrice: Int,
        idxProductClass: Int,
        idxNoChassis: Int,
        idxNoMesin: Int
    ): WorkOrderItem {
        fun get(i: Int): String = map[i]?.trim() ?: ""

        val rawName = get(idxName)
        val rawMobil = get(idxMobil)
        val rawDate = get(idxTrandate)
        val normDate = DateNormalizer.parse(rawDate)

        val rawKm = get(idxKm).replace(".", "").replace(",", "").toLongOrNull() ?: 0L
        val rawQty = get(idxQty).replace(",", ".").toDoubleOrNull() ?: 1.0
        val rawTotal = get(idxTotal).replace(",", ".").toDoubleOrNull() ?: rawQty
        val rawPrice = get(idxTotalPrice).replace("Rp", "").replace(".", "").replace(",", ".").trim().toDoubleOrNull() ?: 0.0

        return WorkOrderItem(
            name = if (rawName.isNotBlank()) rawName else "WO-EXCEL",
            mobilName = if (rawMobil.isNotBlank()) rawMobil else "Armada Cilegon",
            trandate = rawDate,
            trandateMillis = normDate.millis,
            trandateFormatted = normDate.formatted,
            kmCurrent = rawKm,
            keluhan = get(idxKeluhan),
            tipe = get(idxTipe).ifBlank { "Part" },
            kode = get(idxKode),
            description = get(idxDesc),
            catatan = get(idxCatatan),
            startTime = get(idxStartTime),
            endTime = get(idxEndTime),
            qty = rawQty,
            total = rawTotal,
            totalPrice = rawPrice,
            productClass = get(idxProductClass).ifBlank { "General" },
            noChassis = get(idxNoChassis),
            noMesin = get(idxNoMesin)
        )
    }
}
