package com.example.data.model

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class PrintFormatMode(val displayName: String, val shortName: String) {
    MAIN_LABEL("1. Label Utama", "Label Paket"),
    SENDER_COPY("2. Lembar Pengirim", "Pengirim"),
    COMBO_ALL("3. Lengkap (2-in-1)", "Paket + Pengirim"),
    SENDER_CLEAN("4. Pengirim Polos", "Pengirim Polos"),
    LABEL_ALT("5. Label Alternatif", "Label Alt")
}

data class ReceiptData(
    val id: Long = 0,
    val resiCode: String = "JD0597328904561",
    val routingCode: String = "350-4BDO88-16A",
    val badge1: String = "NP",
    val badge2: String = "EZ",
    val dropPoint: String = "KANTOR BISNIS INDONESIA",
    val recipientName: String = "DIDIT ADHITYA A",
    val recipientPhone: String = "081234563149",
    val recipientAddress: String = "BANDUNG, LENGKONG-BDO, JL. BUAHBATU NO. 46B (KANTOR BISNIS INDONESIA) KEL. CIKAWAO, KEC. LENGKONG, KOTA BANDUNG, JAWA BARAT",
    val senderName: String = "RetroSport Jersey",
    val senderPhone: String = "085678904744",
    val senderAddress: String = "KAB.SERANG, Griya Serdang Indah (GSI) Blok B6 NO 12 RT 02 RW 04 Kel. Margatani Serdang Kec. Kramatwatu Kab. Serang Banten",
    val shippingFee: Long = 7200,
    val paymentType: String = "TUNAI",
    val weightKg: String = "1.00 KG",
    val printDate: String = defaultCurrentDate(),
    val orderNo: String = "19793494884632704",
    val expNote: String = "",
    val notes: String = "Diantar saat jam kerja",
    val footerCompany: String = "PT GLOBAL JET EXPRESS, 0735697740 041 000\nLANDMARK PLUIT TOWER BLOK B1, LANTAI 8, 9A,\n10A, JL. PLUIT SELATAN RAYA, PENJARINGAN",
    val maskPhone: Boolean = true,
    // Fields for Lembar Pengirim (Image 1 & 2)
    val itemName: String = "Pakaian",
    val itemQty: String = "1 PCS",
    val expDate: String = defaultExpDate(),
    val selectedFormat: PrintFormatMode = PrintFormatMode.MAIN_LABEL,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun getFormattedFee(): String {
        val format = NumberFormat.getNumberInstance(Locale("id", "ID"))
        return "IDR " + format.format(shippingFee)
    }

    fun getDisplayRecipientPhone(): String {
        return if (maskPhone && recipientPhone.length >= 4) {
            "*******" + recipientPhone.takeLast(4)
        } else {
            recipientPhone
        }
    }

    fun getDisplaySenderPhone(): String {
        return if (maskPhone && senderPhone.length >= 4) {
            "*******" + senderPhone.takeLast(4)
        } else {
            senderPhone
        }
    }

    companion object {
        fun defaultCurrentDate(): String {
            val sdf = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
            return sdf.format(Date())
        }

        fun defaultExpDate(): String {
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_MONTH, 5)
            val sdf = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
            return sdf.format(cal.time)
        }

        fun generateRandomResi(): String {
            val digits = (10000000000L..99999999999L).random()
            return "JD$digits"
        }

        fun generateRandomOrderNo(): String {
            val digits = (10000000000000000L..99999999999999999L).random()
            return "$digits"
        }
    }
}
