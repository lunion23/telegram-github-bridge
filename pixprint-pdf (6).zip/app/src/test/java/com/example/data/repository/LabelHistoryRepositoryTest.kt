package com.example.data.repository

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.model.HistoryActionType
import com.example.model.PaperSizePreset
import com.example.model.ShippingLabelData
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class LabelHistoryRepositoryTest {

    private lateinit var database: AppDatabase
    private lateinit var repository: LabelHistoryRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = LabelHistoryRepository(database.labelHistoryDao())
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun `save, observe, update, and delete shipping label history locally without login`() = runBlocking {
        val initialList = repository.observeHistory().first()
        assertEquals(0, initialList.size)

        val sample = ShippingLabelData.defaultFromReferenceImage().copy(
            waybillNumber = "JD9988776655",
            recipientName = "Siti Aminah"
        )
        val saved = repository.saveHistoryEntry(
            data = sample,
            paperPreset = PaperSizePreset.THERMAL_100X200,
            actionLabel = HistoryActionType.SAVED
        )

        val fetched = repository.getHistoryItem(saved.id)
        assertNotNull(fetched)
        assertEquals("JD9988776655", fetched?.waybillNumber)
        assertEquals("Siti Aminah", fetched?.recipientName)

        val updated = repository.updateHistoryEntry(
            existingItem = saved,
            updatedData = sample.copy(recipientName = "Siti Aminah Putri"),
            paperPreset = PaperSizePreset.A6_PORTRAIT,
            actionLabel = HistoryActionType.PRINTED
        )
        assertEquals(saved.id, updated.id)
        assertEquals(saved.createdAtMillis, updated.createdAtMillis)

        val listAfterUpdate = repository.observeHistory().first()
        assertEquals(1, listAfterUpdate.size)
        assertEquals("Siti Aminah Putri", listAfterUpdate.first().recipientName)
        assertEquals(PaperSizePreset.A6_PORTRAIT.name, listAfterUpdate.first().paperPreset)
        assertEquals(HistoryActionType.PRINTED, listAfterUpdate.first().actionLabel)

        repository.deleteHistoryEntry(saved.id)
        assertNull(repository.getHistoryItem(saved.id))
        assertEquals(0, repository.observeHistory().first().size)
    }
}
