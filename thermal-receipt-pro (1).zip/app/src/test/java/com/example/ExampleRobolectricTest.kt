package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.ReceiptEntity
import com.example.data.model.PrintFormatMode
import com.example.data.model.ReceiptData
import com.example.util.BarcodeGenerator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Struk Express", appName)
    }

    @Test
    fun `test barcode generation for resi`() {
        val resi = "JD0597328904561"
        val barcodeBitmap = BarcodeGenerator.generateBarcode128(resi)
        assertNotNull(barcodeBitmap)
        assertTrue(barcodeBitmap!!.width > 0)
        assertTrue(barcodeBitmap.height > 0)

        val qrBitmap = BarcodeGenerator.generateQrCode(resi)
        assertNotNull(qrBitmap)
        assertTrue(qrBitmap!!.width > 0)
    }

    @Test
    fun `test receipt formatting`() {
        val receipt = ReceiptData(
            resiCode = "JD0597328904561",
            recipientPhone = "081234563149",
            shippingFee = 7200,
            maskPhone = true,
            itemName = "Pakaian",
            itemQty = "1 PCS"
        )
        assertEquals("IDR 7.200", receipt.getFormattedFee())
        assertEquals("*******3149", receipt.getDisplayRecipientPhone())
        assertEquals("Pakaian", receipt.itemName)
        assertEquals("1 PCS", receipt.itemQty)
    }

    @Test
    fun `test print format modes`() {
        assertEquals("1. Label Utama", PrintFormatMode.MAIN_LABEL.displayName)
        assertEquals("2. Lembar Pengirim", PrintFormatMode.SENDER_COPY.displayName)
        assertEquals("3. Lengkap (2-in-1)", PrintFormatMode.COMBO_ALL.displayName)
    }

    @Test
    fun `test receipt entity round trip with new fields`() {
        val data = ReceiptData(
            resiCode = "JD0598478445",
            itemName = "Sepatu Sneakers",
            itemQty = "2 PCS",
            expDate = "28-10-2026",
            selectedFormat = PrintFormatMode.SENDER_COPY
        )
        val entity = ReceiptEntity.fromReceiptData(data)
        val restored = entity.toReceiptData()

        assertEquals(data.resiCode, restored.resiCode)
        assertEquals("Sepatu Sneakers", restored.itemName)
        assertEquals("2 PCS", restored.itemQty)
        assertEquals("28-10-2026", restored.expDate)
        assertEquals(PrintFormatMode.SENDER_COPY, restored.selectedFormat)
    }
}
