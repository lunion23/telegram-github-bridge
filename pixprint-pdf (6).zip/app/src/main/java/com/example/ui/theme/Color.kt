package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Express Print Studio — Light Palette
val CrimsonPrimary = Color(0xFFDC2626)
val OnCrimsonPrimary = Color(0xFFFFFFFF)
val CrimsonContainer = Color(0xFFFFE4E6)
val OnCrimsonContainer = Color(0xFF7F1D1D)

val SlateSecondary = Color(0xFF334155)
val OnSlateSecondary = Color(0xFFFFFFFF)
val SlateContainer = Color(0xFFE2E8F0)
val OnSlateContainer = Color(0xFF0F172A)

val AmberTertiary = Color(0xFFB45309)
val OnAmberTertiary = Color(0xFFFFFFFF)
val AmberContainer = Color(0xFFFEF3C7)
val OnAmberContainer = Color(0xFF78350F)

val LightBackground = Color(0xFFF3F4F6)
val OnLightBackground = Color(0xFF0F172A)
val LightSurface = Color(0xFFFFFFFF)
val OnLightSurface = Color(0xFF0F172A)
val LightSurfaceVariant = Color(0xFFE5E7EB)
val OnLightSurfaceVariant = Color(0xFF475569)
val LightOutline = Color(0xFFCBD5E1)

// Express Print Studio — Dark Palette
val CrimsonPrimaryDark = Color(0xFFFB7185)
val OnCrimsonPrimaryDark = Color(0xFF4C0519)
val CrimsonContainerDark = Color(0xFF9F1239)
val OnCrimsonContainerDark = Color(0xFFFFE4E6)

val SlateSecondaryDark = Color(0xFFCBD5E1)
val OnSlateSecondaryDark = Color(0xFF1E293B)
val SlateContainerDark = Color(0xFF334155)
val OnSlateContainerDark = Color(0xFFF1F5F9)

val AmberTertiaryDark = Color(0xFFFBBF24)
val OnAmberTertiaryDark = Color(0xFF451A03)
val AmberContainerDark = Color(0xFF78350F)
val OnAmberContainerDark = Color(0xFFFEF3C7)

val DarkBackground = Color(0xFF0B0F19)
val OnDarkBackground = Color(0xFFF8FAFC)
val DarkSurface = Color(0xFF111827)
val OnDarkSurface = Color(0xFFF8FAFC)
val DarkSurfaceVariant = Color(0xFF1F2937)
val OnDarkSurfaceVariant = Color(0xFF94A3B8)
val DarkOutline = Color(0xFF334155)
