package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ReceiptData
import com.example.util.BarcodeGenerator

@Composable
fun ShippingLabelView(
    receipt: ReceiptData,
    modifier: Modifier = Modifier
) {
    // Generate barcode & QR code dynamically from current resiCode
    val barcodeBitmap = remember(receipt.resiCode) {
        BarcodeGenerator.generateBarcode128(receipt.resiCode, width = 600, height = 130)
    }
    val qrBitmap = remember(receipt.resiCode) {
        BarcodeGenerator.generateQrCode(receipt.resiCode, size = 200)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("shipping_label_card"),
        shape = RoundedCornerShape(4.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        // Outer Container with Left and Right vertical side text margins
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
                .height(IntrinsicSize.Min)
        ) {
            // Left Margin Vertical Resi Codes
            VerticalSideTextColumn(resiCode = receipt.resiCode, isLeft = true)

            // Center Content (Main Label Box with Black Border)
            Column(
                modifier = Modifier
                    .weight(1f)
                    .border(1.5.dp, Color.Black)
                    .background(Color.White)
            ) {
                // Top Routing Code and Badges
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = receipt.routingCode,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.Black,
                        fontFamily = FontFamily.SansSerif,
                        letterSpacing = 0.5.sp,
                        modifier = Modifier.weight(1f)
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        BlackBadge(text = receipt.badge1)
                        BlackBadge(text = receipt.badge2)
                    }
                }

                HorizontalDivider(thickness = 1.dp, color = Color.Black)

                // Barcode Section
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp, bottom = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (barcodeBitmap != null) {
                        Image(
                            bitmap = barcodeBitmap.asImageBitmap(),
                            contentDescription = "Barcode ${receipt.resiCode}",
                            modifier = Modifier
                                .fillMaxWidth(0.92f)
                                .height(52.dp)
                                .testTag("resi_barcode_image"),
                            contentScale = ContentScale.FillBounds
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.9f)
                                .height(50.dp)
                                .background(Color.LightGray)
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = receipt.resiCode,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.testTag("resi_code_text")
                    )
                }

                // Drop Point Black Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black)
                        .padding(vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = receipt.dropPoint.uppercase(),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 0.5.sp,
                        textAlign = TextAlign.Center
                    )
                }

                // Recipient Section
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Penerima: ${receipt.recipientName}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.5.sp,
                            color = Color.Black,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = receipt.getDisplayRecipientPhone(),
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.5.sp,
                            color = Color.Black
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = receipt.recipientAddress,
                        fontSize = 9.sp,
                        lineHeight = 12.sp,
                        color = Color.Black,
                        fontWeight = FontWeight.Normal
                    )
                }

                HorizontalDivider(thickness = 1.dp, color = Color.Black)

                // Sender Section
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Pengirim: ${receipt.senderName}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.5.sp,
                            color = Color.Black,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = receipt.getDisplaySenderPhone(),
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.5.sp,
                            color = Color.Black
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = receipt.senderAddress,
                        fontSize = 9.sp,
                        lineHeight = 12.sp,
                        color = Color.Black,
                        fontWeight = FontWeight.Normal
                    )
                }

                HorizontalDivider(thickness = 1.dp, color = Color.Black)

                // Shipping Details Table
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Row 1: Shipping Fee, Payment, Weight, Print Date
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(IntrinsicSize.Min)
                    ) {
                        // Col 1: Biaya Pengiriman
                        Column(
                            modifier = Modifier
                                .weight(1.3f)
                                .fillMaxHeight(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.Black)
                                    .padding(vertical = 1.5.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "BIAYA PENGIRIMAN",
                                    color = Color.White,
                                    fontSize = 7.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = receipt.getFormattedFee(),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                            Text(
                                text = "Sudah Termasuk PPH",
                                fontSize = 6.5.sp,
                                color = Color.DarkGray
                            )
                        }

                        VerticalDivider(thickness = 1.dp, color = Color.Black)

                        // Col 2: Tunai
                        Box(
                            modifier = Modifier
                                .weight(0.9f)
                                .fillMaxHeight(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = receipt.paymentType,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                        }

                        VerticalDivider(thickness = 1.dp, color = Color.Black)

                        // Col 3: Weight
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "• ${receipt.weightKg}",
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                        }

                        VerticalDivider(thickness = 1.dp, color = Color.Black)

                        // Col 4: Print Date
                        Box(
                            modifier = Modifier
                                .weight(1.2f)
                                .fillMaxHeight(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Cetak ${receipt.printDate}",
                                fontSize = 8.5.sp,
                                color = Color.Black
                            )
                        }
                    }

                    HorizontalDivider(thickness = 1.dp, color = Color.Black)

                    // Row 2: Order No & Exp
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(IntrinsicSize.Min)
                    ) {
                        // Spanning Col 1, 2, 3
                        Box(
                            modifier = Modifier
                                .weight(3.2f)
                                .padding(horizontal = 6.dp, vertical = 3.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                text = "Order No. ${receipt.orderNo}",
                                fontSize = 8.sp,
                                color = Color.Black
                            )
                        }

                        VerticalDivider(thickness = 1.dp, color = Color.Black)

                        // Col 4: Exp
                        Box(
                            modifier = Modifier
                                .weight(1.2f)
                                .padding(horizontal = 4.dp, vertical = 3.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                text = "Exp: ${receipt.expNote}",
                                fontSize = 8.sp,
                                color = Color.Black
                            )
                        }
                    }

                    HorizontalDivider(thickness = 1.dp, color = Color.Black)

                    // Row 3: Notes
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "Notes: ${receipt.notes}",
                            fontSize = 8.5.sp,
                            color = Color.Black
                        )
                    }
                }

                HorizontalDivider(thickness = 1.dp, color = Color.Black)

                // Footer Section (Terms & Address on left, QR Code on right)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Syarat dan ketentuan pengiriman dilihat pada website",
                            fontSize = 6.8.sp,
                            color = Color.DarkGray
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = receipt.footerCompany,
                            fontSize = 6.8.sp,
                            lineHeight = 9.sp,
                            fontWeight = FontWeight.Normal,
                            color = Color.Black
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    if (qrBitmap != null) {
                        Image(
                            bitmap = qrBitmap.asImageBitmap(),
                            contentDescription = "QR Code Resi",
                            modifier = Modifier
                                .size(64.dp)
                                .testTag("resi_qr_image"),
                            contentScale = ContentScale.Fit
                        )
                    }
                }
            }

            // Right Margin Vertical Resi Codes
            VerticalSideTextColumn(resiCode = receipt.resiCode, isLeft = false)
        }
    }
}

@Composable
private fun VerticalSideTextColumn(
    resiCode: String,
    isLeft: Boolean
) {
    Column(
        modifier = Modifier
            .width(20.dp)
            .fillMaxHeight(),
        verticalArrangement = Arrangement.SpaceAround,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val rotationAngle = if (isLeft) -90f else 90f
        repeat(4) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .wrapContentHeight(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = resiCode,
                    fontSize = 7.5.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = Color.DarkGray,
                    modifier = Modifier.rotate(rotationAngle),
                    maxLines = 1,
                    softWrap = false
                )
            }
        }
    }
}

@Composable
private fun BlackBadge(text: String) {
    Box(
        modifier = Modifier
            .background(Color.Black, shape = RoundedCornerShape(2.dp))
            .padding(horizontal = 10.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color.White,
            fontWeight = FontWeight.Black,
            fontSize = 13.sp,
            fontFamily = FontFamily.SansSerif
        )
    }
}
