package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.export.WorkOrderExporter
import com.example.data.export.WorkOrderPdfGenerator
import com.example.ui.components.PrintLayoutOption
import java.io.File
import com.example.data.local.DatabaseBackupManager
import com.example.data.local.PreferencesManager
import com.example.data.local.WorkOrderDatabase
import com.example.data.model.ColumnVisibilityState
import com.example.data.model.FilterCriteria
import com.example.data.model.FleetKpiStats
import com.example.data.model.ImportMode
import com.example.data.model.ImportProgress
import com.example.data.model.ImportResultSummary
import com.example.data.model.SearchTargetColumn
import com.example.data.model.WorkOrderColumn
import com.example.data.model.WorkOrderItem
import com.example.data.model.WorkOrderSummary
import com.example.data.repository.WorkOrderRepository
import com.example.data.sample.SampleDataGenerator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class ViewDisplayMode {
    CARDS_GROUPED,
    TABLE_VIEW
}

class WorkOrderViewModel(application: Application) : AndroidViewModel(application) {

    private val database = WorkOrderDatabase.getInstance(application)
    private val repository = WorkOrderRepository(database, database.workOrderDao())
    private val preferencesManager = PreferencesManager(application)

    // Column visibility preferences
    val columnVisibility: StateFlow<ColumnVisibilityState> = preferencesManager.columnVisibilityState

    // View display mode (Cards vs Table)
    private val _viewMode = MutableStateFlow(ViewDisplayMode.CARDS_GROUPED)
    val viewMode: StateFlow<ViewDisplayMode> = _viewMode.asStateFlow()

    // Filter & Search criteria
    private val _filterCriteria = MutableStateFlow(FilterCriteria())
    val filterCriteria: StateFlow<FilterCriteria> = _filterCriteria.asStateFlow()

    // Distinct chips for filtering
    val distinctTypes: StateFlow<List<String>> = repository.distinctTypes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val distinctProductClasses: StateFlow<List<String>> = repository.distinctProductClasses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Grouped Work Orders
    private val _groupedOrders = MutableStateFlow<List<WorkOrderSummary>>(emptyList())
    val groupedOrders: StateFlow<List<WorkOrderSummary>> = _groupedOrders.asStateFlow()

    // Raw items for Table View
    private val _tableItems = MutableStateFlow<List<WorkOrderItem>>(emptyList())
    val tableItems: StateFlow<List<WorkOrderItem>> = _tableItems.asStateFlow()

    // Executive KPI stats
    private val _kpiStats = MutableStateFlow(FleetKpiStats())
    val kpiStats: StateFlow<FleetKpiStats> = _kpiStats.asStateFlow()

    // Total database row count
    val totalItemCount: StateFlow<Int> = repository.totalItemCountFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Loading & Pagination state
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private var currentOffset = 0
    private val pageSize = 100
    private var hasMoreData = true

    // Detail Modal / Sheet state
    private val _selectedWorkOrder = MutableStateFlow<WorkOrderSummary?>(null)
    val selectedWorkOrder: StateFlow<WorkOrderSummary?> = _selectedWorkOrder.asStateFlow()

    private val _selectedWorkOrderItems = MutableStateFlow<List<WorkOrderItem>>(emptyList())
    val selectedWorkOrderItems: StateFlow<List<WorkOrderItem>> = _selectedWorkOrderItems.asStateFlow()

    // UI Dialogs / Sheets toggles
    private val _showColumnSettings = MutableStateFlow(false)
    val showColumnSettings: StateFlow<Boolean> = _showColumnSettings.asStateFlow()

    private val _showAdvancedFilter = MutableStateFlow(false)
    val showAdvancedFilter: StateFlow<Boolean> = _showAdvancedFilter.asStateFlow()

    private val _showDualSearch = MutableStateFlow(false)
    val showDualSearch: StateFlow<Boolean> = _showDualSearch.asStateFlow()

    // PDF Print Dialog state
    private val _printTargetSummary = MutableStateFlow<WorkOrderSummary?>(null)
    val printTargetSummary: StateFlow<WorkOrderSummary?> = _printTargetSummary.asStateFlow()

    private val _isGeneratingPdf = MutableStateFlow(false)
    val isGeneratingPdf: StateFlow<Boolean> = _isGeneratingPdf.asStateFlow()

    // In-app PDF Preview state
    private val _previewBitmap = MutableStateFlow<Bitmap?>(null)
    val previewBitmap: StateFlow<Bitmap?> = _previewBitmap.asStateFlow()

    private val _previewPdfFile = MutableStateFlow<File?>(null)
    val previewPdfFile: StateFlow<File?> = _previewPdfFile.asStateFlow()

    private val _previewDocTitle = MutableStateFlow("")
    val previewDocTitle: StateFlow<String> = _previewDocTitle.asStateFlow()

    // Import progress state
    private val _importProgress = MutableStateFlow(ImportProgress())
    val importProgress: StateFlow<ImportProgress> = _importProgress.asStateFlow()

    private var importJob: Job? = null
    private var queryJob: Job? = null

    init {
        viewModelScope.launch {
            val count = repository.getTotalItemCount()
            if (count == 0) {
                loadBundledCilegonAsset()
            } else {
                loadData(resetPagination = true)
                refreshKpiStats()
            }
        }
    }

    fun setViewMode(mode: ViewDisplayMode) {
        _viewMode.value = mode
        loadData(resetPagination = true)
    }

    fun updateSearchQuery(query: String) {
        _filterCriteria.value = _filterCriteria.value.copy(searchQuery = query)
        loadData(resetPagination = true)
    }

    fun toggleTypeFilter(tipe: String) {
        val current = _filterCriteria.value.selectedTypes
        val updated = if (current.contains(tipe)) current - tipe else current + tipe
        _filterCriteria.value = _filterCriteria.value.copy(selectedTypes = updated)
        loadData(resetPagination = true)
    }

    fun toggleProductClassFilter(cls: String) {
        val current = _filterCriteria.value.selectedProductClasses
        val updated = if (current.contains(cls)) current - cls else current + cls
        _filterCriteria.value = _filterCriteria.value.copy(selectedProductClasses = updated)
        loadData(resetPagination = true)
    }

    fun toggleDateSort() {
        _filterCriteria.value = _filterCriteria.value.copy(sortDateAscending = !_filterCriteria.value.sortDateAscending)
        loadData(resetPagination = true)
    }

    fun applyAdvancedFilter(
        mobil: String,
        chassis: String,
        keluhan: String,
        startDateMillis: Long?,
        endDateMillis: Long?
    ) {
        _filterCriteria.value = _filterCriteria.value.copy(
            specificMobil = mobil,
            specificChassis = chassis,
            specificKeluhan = keluhan,
            startDateMillis = startDateMillis,
            endDateMillis = endDateMillis
        )
        _showAdvancedFilter.value = false
        loadData(resetPagination = true)
    }

    fun clearAllFilters() {
        _filterCriteria.value = FilterCriteria()
        loadData(resetPagination = true)
    }

    fun toggleColumnVisibility(col: WorkOrderColumn) {
        val newState = columnVisibility.value.toggle(col)
        preferencesManager.saveColumnVisibility(newState)
    }

    fun openColumnSettings(show: Boolean) {
        _showColumnSettings.value = show
    }

    fun openAdvancedFilter(show: Boolean) {
        _showAdvancedFilter.value = show
    }

    fun openDualSearch(show: Boolean) {
        _showDualSearch.value = show
    }

    fun applyDualKeywordSearch(
        kw1: String,
        col1: SearchTargetColumn,
        kw2: String,
        col2: SearchTargetColumn
    ) {
        _filterCriteria.value = _filterCriteria.value.copy(
            dualKeyword1 = kw1.trim(),
            dualColumn1 = col1,
            dualKeyword2 = kw2.trim(),
            dualColumn2 = col2
        )
        _showDualSearch.value = false
        loadData(resetPagination = true)
    }

    fun clearDualKeywordSearch() {
        _filterCriteria.value = _filterCriteria.value.copy(
            dualKeyword1 = "",
            dualColumn1 = SearchTargetColumn.ALL,
            dualKeyword2 = "",
            dualColumn2 = SearchTargetColumn.ALL
        )
        loadData(resetPagination = true)
    }

    fun selectWorkOrderForDetail(summary: WorkOrderSummary) {
        _selectedWorkOrder.value = summary
        viewModelScope.launch {
            _selectedWorkOrderItems.value = repository.getWorkOrderItems(summary.name)
        }
    }

    fun selectWorkOrderByName(name: String) {
        viewModelScope.launch {
            val items = repository.getWorkOrderItems(name)
            if (items.isNotEmpty()) {
                val first = items.first()
                val summary = WorkOrderSummary(
                    name = first.name,
                    mobilName = first.mobilName,
                    trandateFormatted = first.trandateFormatted,
                    trandateMillis = first.trandateMillis,
                    kmCurrent = first.kmCurrent,
                    keluhan = first.keluhan,
                    noChassis = first.noChassis,
                    noMesin = first.noMesin,
                    itemCount = items.size,
                    totalCost = items.sumOf { it.totalPrice },
                    partCount = items.count { it.tipe.contains("PART", ignoreCase = true) },
                    jasaCount = items.count { it.tipe.contains("JASA", ignoreCase = true) },
                    startTime = items.firstOrNull { it.startTime.isNotBlank() }?.startTime ?: "-",
                    endTime = items.firstOrNull { it.endTime.isNotBlank() }?.endTime ?: "-"
                )
                _selectedWorkOrder.value = summary
                _selectedWorkOrderItems.value = items
            }
        }
    }

    fun closeWorkOrderDetail() {
        _selectedWorkOrder.value = null
        _selectedWorkOrderItems.value = emptyList()
    }

    fun loadData(resetPagination: Boolean = false) {
        if (resetPagination) {
            queryJob?.cancel()
        }
        queryJob = viewModelScope.launch {
            if (resetPagination) {
                currentOffset = 0
                hasMoreData = true
            }
            if (!hasMoreData && !resetPagination) return@launch

            _isLoading.value = true
            val criteria = _filterCriteria.value

            if (_viewMode.value == ViewDisplayMode.CARDS_GROUPED) {
                val results = repository.getGroupedWorkOrders(criteria, limit = pageSize, offset = currentOffset)
                if (resetPagination) {
                    _groupedOrders.value = results
                } else {
                    _groupedOrders.value = _groupedOrders.value + results
                }
                if (results.size < pageSize) {
                    hasMoreData = false
                }
            } else {
                val results = repository.getItemsForTable(criteria, limit = pageSize, offset = currentOffset)
                if (resetPagination) {
                    _tableItems.value = results
                } else {
                    _tableItems.value = _tableItems.value + results
                }
                if (results.size < pageSize) {
                    hasMoreData = false
                }
            }

            currentOffset += pageSize
            _isLoading.value = false
        }
    }

    fun loadMore() {
        if (!_isLoading.value && hasMoreData) {
            loadData(resetPagination = false)
        }
    }

    fun refreshKpiStats() {
        viewModelScope.launch {
            _kpiStats.value = repository.getFleetKpiStats()
        }
    }

    fun startImportFromUri(context: Context, uri: Uri, mode: ImportMode = ImportMode.UPDATE_EXISTING) {
        importJob?.cancel()
        importJob = viewModelScope.launch {
            val startTime = System.currentTimeMillis()
            val actionDesc = when (mode) {
                ImportMode.UPDATE_EXISTING -> "perbarui data sama (Update & Merge)"
                ImportMode.APPEND -> "menambahkan (Append)"
                ImportMode.REPLACE_ALL -> "mengganti (Replace All)"
            }
            _importProgress.value = ImportProgress(
                isImporting = true,
                statusText = "Mempersiapkan proses $actionDesc..."
            )

            try {
                val contentResolver = context.contentResolver
                val inputStream = contentResolver.openInputStream(uri)
                    ?: throw IllegalArgumentException("Tidak dapat membaca file terpilih.")

                val filename = uri.lastPathSegment ?: "Data_Work_Order.csv"
                val isXlsx = filename.endsWith(".xlsx", ignoreCase = true) ||
                        context.contentResolver.getType(uri)?.contains("spreadsheetml") == true

                val totalBytes = try {
                    contentResolver.openFileDescriptor(uri, "r")?.statSize ?: 0L
                } catch (_: Exception) {
                    0L
                }

                val result = if (isXlsx) {
                    repository.importXlsxStream(
                        inputStream = inputStream,
                        totalBytesEstimate = totalBytes,
                        chunkSize = 2500,
                        mode = mode
                    ) { progress ->
                        _importProgress.value = progress
                    }
                } else {
                    repository.importCsvStream(
                        inputStream = inputStream,
                        totalBytesEstimate = totalBytes,
                        chunkSize = 2500,
                        mode = mode
                    ) { progress ->
                        _importProgress.value = progress
                    }
                }

                val elapsed = (System.currentTimeMillis() - startTime) / 1000.0
                refreshKpiStats()
                loadData(resetPagination = true)

                _importProgress.value = ImportProgress(
                    isImporting = false,
                    isCompleted = true,
                    resultSummary = ImportResultSummary(
                        totalRowsInserted = result.totalRows,
                        totalWorkOrders = _kpiStats.value.totalWorkOrders,
                        durationSeconds = elapsed,
                        filename = filename,
                        mode = mode,
                        rowsUpdated = result.rowsUpdated,
                        rowsAdded = result.rowsAdded
                    )
                )

            } catch (e: CancellationException) {
                _importProgress.value = ImportProgress(
                    isImporting = false,
                    error = "Import dibatalkan oleh pengguna."
                )
            } catch (e: Exception) {
                _importProgress.value = ImportProgress(
                    isImporting = false,
                    error = "Gagal memproses file: ${e.localizedMessage}"
                )
            }
        }
    }

    /**
     * Loads the authentic pre-bundled CILEGONCSV.csv file directly from assets.
     */
    fun loadBundledCilegonAsset(mode: ImportMode = ImportMode.REPLACE_ALL) {
        importJob?.cancel()
        importJob = viewModelScope.launch {
            val startTime = System.currentTimeMillis()
            _importProgress.value = ImportProgress(
                isImporting = true,
                statusText = "Memuat file dataset resmi CILEGONCSV.csv..."
            )

            try {
                val app = getApplication<Application>()
                val assetStream = app.assets.open("CILEGONCSV.csv")
                val result = repository.importCsvStream(
                    inputStream = assetStream,
                    totalBytesEstimate = 50000L,
                    chunkSize = 2500,
                    mode = mode
                ) { progress ->
                    _importProgress.value = progress
                }

                val elapsed = (System.currentTimeMillis() - startTime) / 1000.0
                refreshKpiStats()
                loadData(resetPagination = true)

                _importProgress.value = ImportProgress(
                    isImporting = false,
                    isCompleted = true,
                    resultSummary = ImportResultSummary(
                        totalRowsInserted = result.totalRows,
                        totalWorkOrders = _kpiStats.value.totalWorkOrders,
                        durationSeconds = elapsed,
                        filename = "CILEGONCSV.csv (Asset Resmi)",
                        mode = mode,
                        rowsUpdated = result.rowsUpdated,
                        rowsAdded = result.rowsAdded
                    )
                )
            } catch (e: CancellationException) {
                _importProgress.value = ImportProgress(isImporting = false, error = "Import dibatalkan.")
            } catch (e: Exception) {
                _importProgress.value = ImportProgress(isImporting = false, error = e.localizedMessage)
            }
        }
    }

    fun loadSampleDataset(rowCount: Int, mode: ImportMode = ImportMode.REPLACE_ALL) {
        importJob?.cancel()
        importJob = viewModelScope.launch {
            val startTime = System.currentTimeMillis()
            _importProgress.value = ImportProgress(
                isImporting = true,
                statusText = "Menghasilkan sampel $rowCount baris data Cilegon..."
            )

            try {
                val sampleStream = SampleDataGenerator.createSampleCsvStream(rowCount)
                val result = repository.importCsvStream(
                    inputStream = sampleStream,
                    totalBytesEstimate = rowCount * 180L,
                    chunkSize = 2500,
                    mode = mode
                ) { progress ->
                    _importProgress.value = progress
                }

                val elapsed = (System.currentTimeMillis() - startTime) / 1000.0
                refreshKpiStats()
                loadData(resetPagination = true)

                _importProgress.value = ImportProgress(
                    isImporting = false,
                    isCompleted = true,
                    resultSummary = ImportResultSummary(
                        totalRowsInserted = result.totalRows,
                        totalWorkOrders = _kpiStats.value.totalWorkOrders,
                        durationSeconds = elapsed,
                        filename = "Sampel_Cilegon_${rowCount}_Baris.csv",
                        mode = mode,
                        rowsUpdated = result.rowsUpdated,
                        rowsAdded = result.rowsAdded
                    )
                )
            } catch (e: CancellationException) {
                _importProgress.value = ImportProgress(
                    isImporting = false,
                    error = "Import dibatalkan."
                )
            } catch (e: Exception) {
                _importProgress.value = ImportProgress(
                    isImporting = false,
                    error = e.localizedMessage
                )
            }
        }
    }

    fun cancelImport() {
        importJob?.cancel()
        _importProgress.value = ImportProgress(
            isImporting = false,
            error = "Proses import dibatalkan oleh pengguna."
        )
    }

    fun dismissImportSummary() {
        _importProgress.value = ImportProgress()
    }

    fun clearAllDatabaseRecords() {
        viewModelScope.launch {
            repository.clearAllData()
            refreshKpiStats()
            loadData(resetPagination = true)
        }
    }

    fun exportFilteredDataToCsv(context: Context) {
        viewModelScope.launch {
            _isLoading.value = true
            // Export current filtered dataset up to 5,000 rows
            val itemsToExport = repository.getItemsForTable(_filterCriteria.value, limit = 5000, offset = 0)
            if (itemsToExport.isNotEmpty()) {
                WorkOrderExporter.exportItemsToCsvAndShare(
                    context = context,
                    items = itemsToExport,
                    title = "WorkOrder_Armada_Export"
                )
            }
            _isLoading.value = false
        }
    }

    fun exportSelectedWorkOrder(context: Context) {
        val summary = _selectedWorkOrder.value ?: return
        val items = _selectedWorkOrderItems.value
        viewModelScope.launch {
            WorkOrderExporter.exportSingleWorkOrderReportAndShare(
                context = context,
                summary = summary,
                items = items
            )
        }
    }

    fun openPrintDialog(summary: WorkOrderSummary) {
        _printTargetSummary.value = summary
    }

    fun closePrintDialog() {
        _printTargetSummary.value = null
    }

    fun executePrint(context: Context, option: PrintLayoutOption) {
        val summary = _printTargetSummary.value ?: _selectedWorkOrder.value ?: return
        viewModelScope.launch {
            _isGeneratingPdf.value = true
            try {
                val items = if (_selectedWorkOrder.value?.name == summary.name && _selectedWorkOrderItems.value.isNotEmpty()) {
                    _selectedWorkOrderItems.value
                } else {
                    repository.getWorkOrderItems(summary.name)
                }

                val pdfFile = when (option) {
                    PrintLayoutOption.COMPACT_ORDER_KERJA -> {
                        WorkOrderPdfGenerator.generateCompactOrderKerjaPdf(context, summary, items)
                    }
                    PrintLayoutOption.FULL_DETAIL_REPORT -> {
                        WorkOrderPdfGenerator.generateFullDetailPdf(context, summary, items)
                    }
                    PrintLayoutOption.THREE_COLUMN_ORDER_KERJA -> {
                        WorkOrderPdfGenerator.generateThreeColumnSpjPdf(context, summary, items)
                    }
                }
                _printTargetSummary.value = null
                WorkOrderPdfGenerator.openOrSharePdf(
                    context = context,
                    file = pdfFile,
                    title = "Dokumen PDF Work Order ${summary.name}"
                )
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isGeneratingPdf.value = false
            }
        }
    }

    fun generatePreview(context: Context, option: PrintLayoutOption) {
        val summary = _printTargetSummary.value ?: _selectedWorkOrder.value ?: return
        viewModelScope.launch {
            _isGeneratingPdf.value = true
            try {
                val items = if (_selectedWorkOrder.value?.name == summary.name && _selectedWorkOrderItems.value.isNotEmpty()) {
                    _selectedWorkOrderItems.value
                } else {
                    repository.getWorkOrderItems(summary.name)
                }

                val pdfFile = when (option) {
                    PrintLayoutOption.COMPACT_ORDER_KERJA -> {
                        WorkOrderPdfGenerator.generateCompactOrderKerjaPdf(context, summary, items)
                    }
                    PrintLayoutOption.FULL_DETAIL_REPORT -> {
                        WorkOrderPdfGenerator.generateFullDetailPdf(context, summary, items)
                    }
                    PrintLayoutOption.THREE_COLUMN_ORDER_KERJA -> {
                        WorkOrderPdfGenerator.generateThreeColumnSpjPdf(context, summary, items)
                    }
                }

                val bmp = WorkOrderPdfGenerator.renderPdfToBitmap(pdfFile)
                if (bmp != null) {
                    val optionTitle = when (option) {
                        PrintLayoutOption.COMPACT_ORDER_KERJA -> "Order Kerja 2 Kolom"
                        PrintLayoutOption.FULL_DETAIL_REPORT -> "Detail Lengkap A4"
                        PrintLayoutOption.THREE_COLUMN_ORDER_KERJA -> "Order Kerja 3 Kolom LX-300"
                    }
                    _previewDocTitle.value = "${summary.name} ($optionTitle)"
                    _previewPdfFile.value = pdfFile
                    _previewBitmap.value = bmp
                    _printTargetSummary.value = null // tutup dialog opsi cetak agar preview tampil dominan
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isGeneratingPdf.value = false
            }
        }
    }

    fun closePreview() {
        _previewBitmap.value = null
        _previewPdfFile.value = null
        _previewDocTitle.value = ""
    }

    /**
     * Imports an external SQLite database (.db) file and restores or appends records based on ImportMode.
     */
    fun importDatabaseFromUri(context: Context, uri: Uri, mode: ImportMode = ImportMode.UPDATE_EXISTING) {
        importJob?.cancel()
        importJob = viewModelScope.launch {
            val startTime = System.currentTimeMillis()
            val modeDesc = when (mode) {
                ImportMode.UPDATE_EXISTING -> "perbarui data sama (Update & Merge)"
                ImportMode.APPEND -> "penambahan (Append)"
                ImportMode.REPLACE_ALL -> "pemulihan (Replace All)"
            }
            _importProgress.value = ImportProgress(
                isImporting = true,
                statusText = "Mempersiapkan proses $modeDesc database SQLite (.db)..."
            )

            val result = DatabaseBackupManager.importDatabaseFromUri(context, uri, mode = mode) { progress ->
                _importProgress.value = progress
            }

            if (result.isSuccess) {
                val totalInserted = result.getOrNull() ?: 0
                val elapsed = (System.currentTimeMillis() - startTime) / 1000.0
                refreshKpiStats()
                loadData(resetPagination = true)

                _importProgress.value = ImportProgress(
                    isImporting = false,
                    isCompleted = true,
                    resultSummary = ImportResultSummary(
                        totalRowsInserted = totalInserted.toLong(),
                        totalWorkOrders = _kpiStats.value.totalWorkOrders,
                        durationSeconds = elapsed,
                        filename = "Database SQLite (.db)",
                        mode = mode
                    )
                )
            } else {
                _importProgress.value = ImportProgress(
                    isImporting = false,
                    error = result.exceptionOrNull()?.localizedMessage ?: "Gagal memproses file database (.db)."
                )
            }
        }
    }

    /**
     * Exports the SQLite database (.db) to a user-specified SAF file location.
     */
    fun exportDatabaseToUri(context: Context, destinationUri: Uri) {
        viewModelScope.launch {
            _isLoading.value = true
            val result = DatabaseBackupManager.exportDatabaseToUri(context, destinationUri)
            _isLoading.value = false
            if (result.isSuccess) {
                android.widget.Toast.makeText(context, "Database (.db) berhasil dicadangkan!", android.widget.Toast.LENGTH_LONG).show()
            } else {
                android.widget.Toast.makeText(context, "Gagal mengekspor database: ${result.exceptionOrNull()?.localizedMessage}", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    /**
     * Backs up the SQLite database (.db) and opens Android Share Sheet.
     */
    fun exportDatabaseAndShare(context: Context) {
        viewModelScope.launch {
            _isLoading.value = true
            val result = DatabaseBackupManager.exportDatabaseAndShare(context)
            _isLoading.value = false
            if (result.isFailure) {
                android.widget.Toast.makeText(context, "Gagal membagikan database: ${result.exceptionOrNull()?.localizedMessage}", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }
}
