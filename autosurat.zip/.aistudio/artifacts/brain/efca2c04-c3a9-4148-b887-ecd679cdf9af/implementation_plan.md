# Generator Laporan Teknik Formal (PDF Generator & Digital Signature)

Aplikasi Android untuk pembuatan formulir dan dokumen resmi **Laporan Teknik / Berita Acara Kerusakan** (sesuai format formal standar Hiba Group / instansi teknis) dengan pengisian otomatis, preview dokumen interaktif, tata letak foto adaptif tanpa celah kosong, tanda tangan digital langsung di layar, serta ekspor & unduh PDF berkualitas cetak.

## User Review & Critical Decisions

> [!IMPORTANT]
> Berdasarkan jawaban klarifikasi yang telah dikonfirmasi:
> - **Tata Letak Foto Kerusakan**: Algoritma partisi adaptif tanpa celah (1 foto = 100% kotak penuh, 2 foto = berdampingan 50:50 penuh, 3 foto = tata letak proporsional penuh, 4 foto = matriks 2x2 penuh tanpa sisa ruang kosong).
> - **Kopsurat & Identitas**: Fleksibel dengan opsi upload logo instansi/perusahaan sendiri serta template default resmi Hiba Group.
> - **Penyimpanan**: Penyimpanan lokal lengkap (Room Database) untuk draf, riwayat dokumen yang dapat diedit ulang, diduplikasi, dan dicetak kembali kapan saja.

---

## 1. Overview & Core Concept

- **Apa yang Dibangun**: Aplikasi pembuatan formulir resmi Laporan Teknik dengan akurasi visual tinggi terhadap format asli di dokumen contoh (tabel terstruktur, checklist penyebab kerusakan, tabel suku cadang, dan kolom persetujuan).
- **Target Pengguna**: Supervisor bengkel, teknisi armada bus/truk, kepala seksi operasional, dan petugas lapangan yang perlu membuat laporan kerusakan teknis secara cepat dan langsung mencetak/membagikan PDF bertanda tangan di lapangan.
- **Nilai Utama**: Mengurangi waktu pembuatan laporan dari manual/kertas menjadi digital instan dalam hitungan menit, dengan hasil cetak PDF format baku A4 yang presisi, rapi, dan sah secara operasional.

---

## 2. User Experience & Visual Design

### Alur Utama Pengguna (User Flow)
1. **Beranda / Riwayat Laporan**: Menampilkan daftar laporan teknis yang tersimpan (draf & final), tombol buat laporan baru, pencarian nomor work order / plat nomor / kode unit.
2. **Formulir Pengisian Terstruktur (Accordion / Tabbed Form)**:
   - **Header & Info Unit**: No. Laporan, Bengkel, Tanggal, Pabrik Pembuat (e.g., HINO), Tipe (e.g., DUTRO), Model, Kode Unit (e.g., D127), Km/Hm, Nama Alat & Komponen.
   - **Uraian Kerusakan & Analisa**: Status masa garansi, status armada (Storing / Rutin), detail kerusakan, lokasi kejadian, analisa teknis, dan riwayat penggantian/work order terakhir.
   - **Foto Kerusakan (Multi-Photo Picker & Adaptive Frame)**: Pengguna dapat mengambil atau memilih 1 hingga 4 foto kerusakan. Kotak foto di dokumen otomatis mengisi seluruh luas bingkai foto tanpa menyisakan ruang kosong.
   - **Penyebab Kerusakan & Penanganan**: Checklist interaktif (Pemasangan, Kwalitas Parts, Kesalahan Operasional, Sudah Waktunya, Lain-lain) + penjelasan, serta tindakan penyelesaian (Ganti Part, Penyetelan, Modifikasi).
   - **Usulan & Tabel Suku Cadang**: Input usulan pelapor dan tabel dinamis suku cadang (No, No Parts, Nama Parts, Jenis Pengadaan: Stock / Order / Modifikasi / Pending).
   - **Tanda Tangan Digital (Signature Pad)**: Kanvas tanda tangan halus (smooth bezier stroke) untuk pihak *Mengetahui* (2 kolom tanda tangan) dan *Dilaporkan Oleh* (Nama & Jabatan).
3. **Live PDF Preview & Export Screen**:
   - Tampilan preview dokumen utuh A4 dengan kemampuan zoom dan pinch.
   - Tombol "Unduh PDF" (disimpan langsung ke folder Downloads perangkat).
   - Tombol "Bagikan PDF" (kirim via WhatsApp, Email, Google Drive).

### Visual Identity & Theme
- **Warna Utama**: Deep Industrial Slate (`#1E293B`), Safety Cobalt Blue (`#1E40AF`), Accent Amber (`#D97706`), dan White / Neutral Paper (`#F8FAFC`).
- **Desain Formulir**: Material 3 dengan card bertahap, status chip, feedback visual jelas, dan validasi input.
- **Kerapian Format Dokumen**: Grid tabel formal hitam-putih dengan garis pembatas tegas (border 1px / 2px formal grid), font sans-serif monospaced/clean formal untuk nilai input, dan penempatan cap / tanda tangan digital yang proporsional.

---

## 3. Key Product Decisions & Trade-Offs

- **Mesin Generate PDF**: Menggunakan Android Native `android.graphics.pdf.PdfDocument` yang dikombinasikan dengan Canvas drawing terukur (skala standar ISO 216 A4: 595 x 842 points pada 72 dpi, atau 1240 x 1754 pada 150 dpi untuk ketajaman tinggi).
  - *Mengapa*: Menghasilkan file PDF vektor asli yang ringan, sangat tajam saat dicetak, tidak memerlukan koneksi internet, dan 100% kompatibel tanpa dependensi pihak ketiga yang berat.
- **Algoritma Adaptive Photo Box**:
  - Menghitung koordinat kotak persegi panjang `Foto Kerusakan` pada lembar laporan.
  - Untuk 1 foto: `CenterCrop` mengisi 100% luas kotak `[left, top, right, bottom]`.
  - Untuk 2 foto: Membagi kotak menjadi 2 kolom (atau 2 baris sesuai orientasi gambar) dengan rasio presisi, tanpa margin pemisah berlebih agar penuh tanpa celah.
  - Untuk 3 foto: 1 foto utama di bagian atas (lebar penuh) dan 2 foto di bagian bawah (50:50).
  - Untuk 4 foto: Matriks 2 baris x 2 kolom (2x2) mengisi 100% luas kotak secara sempurna.
- **Tanda Tangan Digital**: Komponen Jetpack Compose Canvas dengan interpolasi kurva halus (Quad / Bezier path) yang diekspor sebagai bitmap transparan dan digambar langsung ke dalam kotak tanda tangan PDF.
- **Penyimpanan Lokal**: Room Database untuk menyimpan seluruh data laporan, metadata foto, tanda tangan, dan tanggal pembuatan.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────┐
│                   UI / Jetpack Compose                 │
│  ┌─────────────────┐ ┌───────────────┐ ┌─────────────┐ │
│  │ ReportListScreen│ │ ReportEditForm│ │ PdfPreview  │ │
│  └────────┬────────┘ └───────┬───────┘ └───────┬─────┘ │
│           │                  │                 │       │
│           ▼                  ▼                 ▼       │
│  ┌───────────────────────────────────────────────────┐ │
│  │              ReportViewModel / StateFlow          │ │
│  └───────────────────────────┬───────────────────────┘ │
└──────────────────────────────┼─────────────────────────┘
                               │
            ┌──────────────────┴──────────────────┐
            ▼                                     ▼
┌───────────────────────┐             ┌───────────────────────┐
│     ReportRepository  │             │   PdfEngineGenerator  │
│  ┌─────────────────┐  │             │  - Layout Measurer    │
│  │ Room Database   │  │             │  - Adaptive Grid Box  │
│  │ (LaporanEntity) │  │             │  - Signature Drawer   │
│  └─────────────────┘  │             │  - A4 Canvas Painter  │
└───────────────────────┘             └───────────┬───────────┘
                                                  ▼
                                      ┌───────────────────────┐
                                      │ FileProvider / Storage│
                                      │ (Download & Share PDF)│
                                      └───────────────────────┘
```

### Komponen Kunci yang Akan Diimplementasikan:
1. **Model & Database (Room)**:
   - `ReportEntity`: Menyimpan seluruh field formulir laporan teknis, checklist, usulan, suku cadang (JSON), path foto kerusakan, path tanda tangan.
   - `ReportDao` & `ReportRepository`.
2. **PdfEngineGenerator**:
   - `drawHeader()`: Kopsurat Hiba Group / Custom logo, judul LAPORAN TEKNIK, No. Laporan, Bengkel, Tanggal.
   - `drawVehicleSpecs()`: Pabrik pembuat, tipe, model, kode, km/hm, komponen.
   - `drawUraianKerusakan()`: Masa garansi, tanggal, status, uraian kerusakan, analisa, kesimpulan.
   - `drawAdaptivePhotoBox()`: Menangani 1, 2, 3, atau 4 foto dengan layout seamless tanpa celah kosong.
   - `drawChecklists()`: Kotak checklist penyebab kerusakan & penanganan.
   - `drawPartsTable()`: Tabel suku cadang dengan 5 baris data terstruktur.
   - `drawSignatures()`: Menggambar tanda tangan digital di kolom Mengetahui (2 pihak) dan Dilaporkan Oleh.
3. **SignaturePad Composable**:
   - Komponen tanda tangan interaktif layar sentuh dengan fitur Clear dan Save.
4. **PhotoPicker Integration**:
   - Menggunakan Photo Picker standar Android (`PickMultipleVisualMedia`) aman tanpa izin berbahaya.
5. **PDF Preview & Print/Export**:
   - Render PDF ke Bitmap preview menggunakan `android.graphics.pdf.PdfRenderer` untuk preview langsung di layar Compose.
   - Simpan PDF ke folder Downloads publik via MediaStore / FileProvider dan Intent `ACTION_SEND`.
