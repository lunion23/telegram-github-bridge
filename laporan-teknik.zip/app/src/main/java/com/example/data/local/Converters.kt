package com.example.data.local

import androidx.room.TypeConverter
import com.example.data.model.PartItem
import com.example.data.model.WarrantyStatus
import org.json.JSONArray
import org.json.JSONObject

class Converters {
    @TypeConverter
    fun fromWarrantyStatus(value: WarrantyStatus?): String {
        return value?.name ?: WarrantyStatus.AFTER_WARRANTY.name
    }

    @TypeConverter
    fun toWarrantyStatus(value: String?): WarrantyStatus {
        return try {
            if (value != null) WarrantyStatus.valueOf(value) else WarrantyStatus.AFTER_WARRANTY
        } catch (_: Exception) {
            WarrantyStatus.AFTER_WARRANTY
        }
    }

    @TypeConverter
    fun fromPartsList(parts: List<PartItem>?): String {
        if (parts.isNullOrEmpty()) return "[]"
        val array = JSONArray()
        for (item in parts) {
            val obj = JSONObject()
            obj.put("partNumber", item.partNumber)
            obj.put("partName", item.partName)
            obj.put("procurementType", item.procurementType)
            obj.put("notes", item.notes)
            array.put(obj)
        }
        return array.toString()
    }

    @TypeConverter
    fun toPartsList(data: String?): List<PartItem> {
        if (data.isNullOrEmpty()) return emptyList()
        val list = mutableListOf<PartItem>()
        try {
            val array = JSONArray(data)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    PartItem(
                        partNumber = obj.optString("partNumber", ""),
                        partName = obj.optString("partName", ""),
                        procurementType = obj.optString("procurementType", "Stock"),
                        notes = obj.optString("notes", "")
                    )
                )
            }
        } catch (_: Exception) {
            // fallback empty list
        }
        return list
    }
}
