package com.example.model

/**
 * Complete data model for the shipping label (resi pengiriman),
 * pre-populated by default to match the uploaded reference image verbatim.
 */
data class ShippingLabelData(
    val badgeLeft: String = "NP",
    val badgeRight: String = "EZ",
    val routingCode: String = "160-1BTH04-05",
    val waybillNumber: String = "JD0600216038",
    val destinationBanner: String = "PT MCDERMOTT",
    val recipientName: String = "Muhamad Arif",
    val recipientPhone: String = "********2959",
    val recipientAddress: String = "BATAM, BATU AMPAR-BTH, PT Mcdermott Gate 6. Jl. Bawal No.1. Batu Ampar. Batam",
    val senderName: String = "Adinda",
    val senderPhone: String = "********3923",
    val senderArea: String = "KAB.SERANG, serdang",
    val shippingFeeLabel: String = "BIAYA PENGIRIMAN",
    val shippingFeeAmount: String = "IDR 45,000",
    val taxIncludedText: String = "Sudah Termasuk PPN",
    val paymentMethod: String = "TUNAI",
    val weight: String = "0.56 KG",
    val printDate: String = "25-10-2026",
    val orderNumber: String = "19821215842810173...",
    val expCode: String = "",
    val quantityText: String = "1 PCS",
    val itemCategory: String = "BARANG MAKANAN LAINNYA",
    val notes: String = "",
    val companyNameAndTax: String = "PT GLOBAL JET EXPRESS, 0735697740041000",
    val companyAddressLine1: String = "LANDMARK PLUIT TOWER BLCK B1, LANTAI 8, 9A,",
    val companyAddressLine2: String = "10A JL. PLUIT SELATAN RAYA, PENJARINGAN",
    val websiteUrl: String = "www.jet.co.id",
    val stubBadgeText: String = "Lembar Pengirim"
) {
    fun formattedStubPhone(raw: String): String {
        val trimmed = raw.trim()
        val starEnd = trimmed.indexOfFirst { it != '*' }
        return if (starEnd > 0 && trimmed[starEnd] != ' ') {
            trimmed.substring(0, starEnd) + " " + trimmed.substring(starEnd)
        } else {
            trimmed
        }
    }

    companion object {
        fun defaultFromReferenceImage(): ShippingLabelData = ShippingLabelData()
    }
}

enum class PaperSizePreset(
    val widthMm: Float,
    val heightMm: Float,
    val drawCropGuides: Boolean = false
) {
    THERMAL_100X200(widthMm = 100f, heightMm = 200f, drawCropGuides = false),
    THERMAL_78X150(widthMm = 78f, heightMm = 150f, drawCropGuides = false),
    A6_PORTRAIT(widthMm = 105f, heightMm = 148f, drawCropGuides = false),
    A4_ACTUAL_SIZE(widthMm = 210f, heightMm = 297f, drawCropGuides = true);

    /** PDF points at 72 points per inch (1 inch = 25.4 mm). */
    val widthPt: Int
        get() = ((widthMm / 25.4f) * 72f).toInt()

    val heightPt: Int
        get() = ((heightMm / 25.4f) * 72f).toInt()
}

enum class PdfRenderSource {
    VECTOR_RECONSTRUCTION,
    ORIGINAL_REFERENCE_IMAGE,
    CAPTURED_DOCUMENT
}

enum class PreviewDisplayMode {
    GENERATED_PDF,
    COMPARE_SIDE_BY_SIDE
}
