package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.auth.authStateFlow
import com.example.auth.signOutFromGoogle
import com.example.ui.AuthScreen
import com.example.ui.ShippingLabelScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.ShippingLabelViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                AppContent()
            }
        }
    }
}

@Composable
fun AppContent(auth: FirebaseAuth = Firebase.auth) {
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser

    if (user == null) {
        // Unauthenticated session: compose sign-in screen only so feature ViewModels
        // and Firestore listeners are never instantiated before sign-in completes.
        AuthScreen(onAuthSuccess = {})
    } else {
        val context = LocalContext.current
        val scope = rememberCoroutineScope()
        val credentialManager = remember(context) { CredentialManager.create(context) }

        val shippingViewModel: ShippingLabelViewModel = viewModel(
            key = user.uid,
            factory = ShippingLabelViewModel.factory(user.uid)
        )

        ShippingLabelScreen(
            viewModel = shippingViewModel,
            userEmail = user.email,
            onSignOutClick = {
                signOutFromGoogle(
                    credentialManager = credentialManager,
                    onSignOutComplete = {},
                    scope = scope
                )
            }
        )
    }
}
