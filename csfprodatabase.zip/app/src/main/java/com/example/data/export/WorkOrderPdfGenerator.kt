package com.example.data.export

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.core.content.FileProvider
import com.example.data.model.WorkOrderItem
import com.example.data.model.WorkOrderSummary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * PDF generator for Work Orders:
 * 1. Compact Order Kerja Bengkel (matching continuous form physical workshop sheet)
 * 2. Full Detail Comprehensive Work Order (with parts, services, cost breakdowns)
 */
object WorkOrderPdfGenerator {

    private val idrFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply {
        maximumFractionDigits = 0
    }
    private val intFormat = NumberFormat.getIntegerInstance(Locale("id", "ID"))

    /**
     * OPSI 1: Cetak Ringkas (Format Order Kerja Bengkel sesuai lembar fisik continuous form)
     */
    suspend fun generateCompactOrderKerjaPdf(
        context: Context,
        summary: WorkOrderSummary,
        items: List<WorkOrderItem>
    ): File = withContext(Dispatchers.IO) {
        val document = PdfDocument()

        // Ukuran SPJ Continuous Form (612 pt x 420 pt - Standar Continuous Form Half Page)
        val pageWidth = 612
        val pageHeight = 420
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        // Paints konfigurasi tipografi dot-matrix / monospaced presisi
        val textPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = 8.5f
            typeface = Typeface.MONOSPACE
        }
        val boldPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = 8.5f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        val titlePaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = 12f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val subTitlePaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = 10f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val dottedPaint = Paint().apply {
            color = Color.DKGRAY
            strokeWidth = 0.8f
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(2f, 2.5f), 0f)
        }
        val perforationGuidePaint = Paint().apply {
            color = Color.LTGRAY
            strokeWidth = 0.5f
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(3f, 4f), 0f)
        }
        val punchHolePaint = Paint().apply {
            color = Color.parseColor("#D6D3D1")
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val punchHoleBorderPaint = Paint().apply {
            color = Color.parseColor("#A8A29E")
            style = Paint.Style.STROKE
            strokeWidth = 0.5f
            isAntiAlias = true
        }


        // 1. Ornamen Kertas Continuous Form: Lubang perforasi dot-matrix di sisi samping dokumen
        val holeRadius = 3.2f
        val leftMargin = 32f
        val rightMargin = pageWidth - 32f
        var holeY = 18f
        while (holeY < pageHeight - 10f) {
            // Lubang sisi kiri
            canvas.drawCircle(12f, holeY, holeRadius, punchHolePaint)
            canvas.drawCircle(12f, holeY, holeRadius, punchHoleBorderPaint)
            // Lubang sisi kanan
            canvas.drawCircle(pageWidth - 12f, holeY, holeRadius, punchHolePaint)
            canvas.drawCircle(pageWidth - 12f, holeY, holeRadius, punchHoleBorderPaint)
            holeY += 18f
        }
        // Garis batas sobekan perforasi tractor-feed
        canvas.drawLine(24f, 10f, 24f, pageHeight - 10f, perforationGuidePaint)
        canvas.drawLine(pageWidth - 24f, 10f, pageWidth - 24f, pageHeight - 10f, perforationGuidePaint)

        val colLeftX = leftMargin + 6f
        val colRightX = 224f
        val verticalDividerX = 216f
        val bottomLineY = 348f

        // 2. KOP KIRI ATAS: POOL (Sesuai spesifikasi: CLG (Nama pool), logo HIBA Group dihapus)
        val poolCode = if (summary.name.contains("CLG", ignoreCase = true)) "CLG" else {
            val prefix = summary.name.takeWhile { it.isLetter() }
            if (prefix.isNotBlank()) prefix.uppercase() else "CLG"
        }
        canvas.drawText(poolCode, colLeftX, 39f, boldPaint)

        // 3. HEADER TENGAH: ORDER KERJA BENGKEL & NO WORK ORDER
        canvas.drawText("ORDER KERJA BENGKEL", (pageWidth / 2).toFloat(), 24f, titlePaint)
        val docNumber = summary.name.ifBlank { "NO WORK ORDER" }
        canvas.drawText(docNumber, (pageWidth / 2).toFloat(), 39f, subTitlePaint)

        // 4. GARIS PEMBATAS HEADER 1 (Horizontal Dotted Line)
        canvas.drawLine(leftMargin, 50f, rightMargin, 50f, dottedPaint)

        // Parsing Armada & Pool info
        val mobilInfo = parseVehicleDetails(summary.mobilName)
        val noBody = mobilInfo.bodyNumber.ifBlank {
            if (mobilInfo.licensePlate.isNotBlank()) mobilInfo.licensePlate else summary.mobilName
        }
        val kmFormatted = if (summary.kmCurrent > 0) intFormat.format(summary.kmCurrent) else "-"

        // Data kolom mekanik / pemohon: otomatis cantumkan 2 nama mekanik jika ada nama berbeda dalam 1 nomor WO
        val distinctMechanics = extractDistinctMechanics(items)
        val mekanikDisplay = if (distinctMechanics.isNotEmpty()) {
            distinctMechanics.joinToString(" / ")
        } else {
            "AZIZ"
        }

        val mekanikName = mekanikDisplay
        val pemohonName = mekanikDisplay

        // Format tanggal: [dd-MMM-yyyy] & Jam Cetak: [hh:mm:ss a]
        val englishLocale = Locale.ENGLISH
        val currentDateFormatted = SimpleDateFormat("dd-MMM-yyyy", englishLocale).format(Date())
        val formattedTrandate = try {
            val parsed = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(summary.trandateFormatted)
            if (parsed != null) SimpleDateFormat("dd-MMM-yyyy", englishLocale).format(parsed)
            else currentDateFormatted
        } catch (_: Exception) {
            currentDateFormatted
        }
        val nowTimeFormatted = SimpleDateFormat("h:mm:ss a", englishLocale).format(Date())
        val formattedEndDate = if (summary.endTime.isNotBlank() && summary.endTime != "-") {
            "$formattedTrandate ${summary.endTime}"
        } else {
            formattedTrandate
        }

        // 5. BARIS METADATA 1 (No. Bodi vs Tanggal & Jam Cetak)
        canvas.drawText("No. Bodi : $noBody", colLeftX, 65f, boldPaint)
        canvas.drawText("Tanggal : $formattedTrandate", colRightX, 65f, boldPaint)
        canvas.drawText("Jam Cetak: $nowTimeFormatted", colRightX + 160f, 65f, textPaint)

        // 6. GARIS PEMBATAS METADATA 2 (Horizontal Dotted Line)
        canvas.drawLine(leftMargin, 74f, rightMargin, 74f, dottedPaint)

        // 7. BARIS METADATA 2 & 3 (KM, Pemohon vs Tgl Terima, Tanggal Selesai)
        canvas.drawText("KM : $kmFormatted", colLeftX, 90f, boldPaint)

        val pemohonLabel = "Pemohon : $pemohonName"
        val maxPemohonWidth = verticalDividerX - colLeftX - 6f
        val displayPemohon = if (boldPaint.measureText(pemohonLabel) > maxPemohonWidth) {
            var temp = pemohonLabel
            while (temp.length > 10 && boldPaint.measureText("$temp...") > maxPemohonWidth) {
                temp = temp.dropLast(1)
            }
            "$temp..."
        } else {
            pemohonLabel
        }
        canvas.drawText(displayPemohon, colLeftX, 108f, boldPaint)

        canvas.drawText("Tgl Terima    $formattedTrandate", colRightX, 90f, boldPaint)
        canvas.drawText("Tanggal Selesai : $formattedEndDate", colRightX + 160f, 90f, boldPaint)

        // 8. GARIS PEMBATAS METADATA 3 (Horizontal Dotted Line Sebelum Area Kerja)
        canvas.drawLine(leftMargin, 120f, rightMargin, 120f, dottedPaint)

        // 9. GARIS PEMBATAS VERTIKAL PEMISAH AREA KELUHAN & KETERANGAN PERBAIKAN
        canvas.drawLine(verticalDividerX, 120f, verticalDividerX, bottomLineY, dottedPaint)

        // 10. SISI KIRI: KELUHAN & TEKS KELUHAN ARMADA
        val areaHeaderY = 136f
        canvas.drawText("Keluhan:", colLeftX, areaHeaderY, boldPaint)

        var currentLeftY = areaHeaderY + 14f
        val keluhanText = summary.keluhan.ifBlank { "KOLOM KELUHAN" }
        val keluhanLines = wrapText(keluhanText, verticalDividerX - colLeftX - 10f, boldPaint)
        for (line in keluhanLines.take(12)) {
            if (currentLeftY < bottomLineY - 10f) {
                canvas.drawText(line, colLeftX, currentLeftY, boldPaint)
                currentLeftY += 13f
            }
        }

        // 11. SISI KANAN: KETERANGAN PERBAIKAN (CATATAN PEKERJAAN DENGAN BARIS BARU PER TANDA '-')
        canvas.drawText("Keterangan Perbaikan :", colRightX, areaHeaderY, boldPaint)

        var currentRightY = areaHeaderY + 14f
        val jobNotes = parseJobNotesWithDelimiters(items)

        if (jobNotes.isNotEmpty()) {
            val maxColWidth = rightMargin - colRightX - 8f
            for (note in jobNotes) {
                if (currentRightY >= bottomLineY - 14f) break
                val displayNote = if (note.startsWith("-") || note.startsWith("•")) note else "- $note"
                val noteLines = wrapText(displayNote, maxColWidth, boldPaint)
                for (nLine in noteLines) {
                    if (currentRightY < bottomLineY - 10f) {
                        canvas.drawText(nLine, colRightX, currentRightY, boldPaint)
                        currentRightY += 13f
                    }
                }
            }
        } else {
            // Panduan garis catatan kerja teknisi
            var lineSlot = 1
            while (lineSlot <= 12 && currentRightY < bottomLineY - 12f) {
                canvas.drawText(".........................................................................", colRightX, currentRightY, dottedPaint)
                currentRightY += 13.5f
                lineSlot++
            }
        }

        // 12. GARIS PEMBATAS HORIZONTAL BAWAH (Sebelum Tanda Tangan)
        canvas.drawLine(leftMargin, bottomLineY, rightMargin, bottomLineY, dottedPaint)

        // 13. AREA PENGESAHAN TANDA TANGAN (Sesuai Foto Tanpa Kotak Tabel)
        val sigY = bottomLineY + 18f

        // Sisi Kiri
        canvas.drawText("Dikerjakan oleh, $mekanikName", colLeftX, sigY, boldPaint)
        canvas.drawText("Tanda Tangan :", colLeftX, sigY + 26f, boldPaint)

        // Sisi Kanan
        val rightSigX = pageWidth - 140f
        canvas.drawText("Disetujui,", rightSigX, sigY, boldPaint)

        document.finishPage(page)

        // Simpan dokumen PDF
        val exportDir = File(context.cacheDir, "pdf_orders").apply { mkdirs() }
        val safeWoName = summary.name.replace("/", "-").replace(" ", "_")
        val file = File(exportDir, "Order_Kerja_${safeWoName}.pdf")

        FileOutputStream(file).use { out ->
            document.writeTo(out)
        }
        document.close()

        return@withContext file
    }

    /**
     * OPSI 3: Cetak Ringkas 3 Kolom (Format SPJ Continuous Form Printer LX-300 Sesuai Gambar 1)
     * Kolom 1: Keluhan
     * Kolom 2: Keterangan Perbaikan (Catatan pekerjaan dengan pemisah baris '-')
     * Kolom 3: Suku Cadang / Produk (Daftar part & quantity)
     */
    suspend fun generateThreeColumnSpjPdf(
        context: Context,
        summary: WorkOrderSummary,
        items: List<WorkOrderItem>
    ): File = withContext(Dispatchers.IO) {
        val document = PdfDocument()

        // Ukuran SPJ Continuous Form LX-300 (612 pt x 420 pt - Half Letter / Half Folio Lanskap)
        val pageWidth = 612
        val pageHeight = 420
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        // Konfigurasi Paint dot-matrix monospaced presisi
        val textPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = 8.5f
            typeface = Typeface.MONOSPACE
        }
        val boldPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = 8.5f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        val smallBoldPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = 7.5f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        val smallTextPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = 7.5f
            typeface = Typeface.MONOSPACE
        }
        val titlePaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = 12f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val subTitlePaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = 10f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val dottedPaint = Paint().apply {
            color = Color.DKGRAY
            strokeWidth = 0.8f
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(2f, 2.5f), 0f)
        }
        val perforationGuidePaint = Paint().apply {
            color = Color.LTGRAY
            strokeWidth = 0.5f
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(3f, 4f), 0f)
        }
        val punchHolePaint = Paint().apply {
            color = Color.parseColor("#D6D3D1")
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val punchHoleBorderPaint = Paint().apply {
            color = Color.parseColor("#A8A29E")
            style = Paint.Style.STROKE
            strokeWidth = 0.5f
            isAntiAlias = true
        }

        // 1. Ornamen Lubang Perforasi Continuous Form LX-300
        val holeRadius = 3.2f
        val leftMargin = 32f
        val rightMargin = pageWidth - 32f
        var holeY = 18f
        while (holeY < pageHeight - 10f) {
            canvas.drawCircle(12f, holeY, holeRadius, punchHolePaint)
            canvas.drawCircle(12f, holeY, holeRadius, punchHoleBorderPaint)
            canvas.drawCircle(pageWidth - 12f, holeY, holeRadius, punchHolePaint)
            canvas.drawCircle(pageWidth - 12f, holeY, holeRadius, punchHoleBorderPaint)
            holeY += 18f
        }
        canvas.drawLine(24f, 10f, 24f, pageHeight - 10f, perforationGuidePaint)
        canvas.drawLine(pageWidth - 24f, 10f, pageWidth - 24f, pageHeight - 10f, perforationGuidePaint)

        // 2. KOP KIRI ATAS: POOL
        val colLeftX = leftMargin + 4f
        val poolCode = if (summary.name.contains("CLG", ignoreCase = true)) "CLG" else {
            val prefix = summary.name.takeWhile { it.isLetter() }
            if (prefix.isNotBlank()) prefix.uppercase() else "CLG"
        }
        canvas.drawText(poolCode, colLeftX, 39f, boldPaint)

        // 3. HEADER TENGAH: ORDER KERJA BENGKEL & NOMOR WO
        canvas.drawText("ORDER KERJA BENGKEL", (pageWidth / 2).toFloat(), 24f, titlePaint)
        val docNumber = summary.name.ifBlank { "NO WORK ORDER" }
        canvas.drawText(docNumber, (pageWidth / 2).toFloat(), 39f, subTitlePaint)

        // 4. GARIS PEMBATAS HEADER 1
        canvas.drawLine(leftMargin, 50f, rightMargin, 50f, dottedPaint)

        // Metadata armada & mekanik
        val mobilInfo = parseVehicleDetails(summary.mobilName)
        val noBody = mobilInfo.bodyNumber.ifBlank {
            if (mobilInfo.licensePlate.isNotBlank()) mobilInfo.licensePlate else summary.mobilName
        }
        val kmFormatted = if (summary.kmCurrent > 0) intFormat.format(summary.kmCurrent) else "-"

        val distinctMechanics = extractDistinctMechanics(items)
        val mekanikDisplay = if (distinctMechanics.isNotEmpty()) {
            distinctMechanics.joinToString(" / ")
        } else {
            "AZIZ"
        }

        val mekanikName = mekanikDisplay
        val pemohonName = mekanikDisplay

        val englishLocale = Locale.ENGLISH
        val currentDateFormatted = SimpleDateFormat("dd-MMM-yyyy", englishLocale).format(Date())
        val formattedTrandate = try {
            val parsed = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(summary.trandateFormatted)
            if (parsed != null) SimpleDateFormat("dd-MMM-yyyy", englishLocale).format(parsed)
            else currentDateFormatted
        } catch (_: Exception) {
            currentDateFormatted
        }
        val nowTimeFormatted = SimpleDateFormat("h:mm:ss a", englishLocale).format(Date())
        val formattedEndDate = if (summary.endTime.isNotBlank() && summary.endTime != "-") {
            "$formattedTrandate ${summary.endTime}"
        } else {
            formattedTrandate
        }

        val metaMidX = 224f
        // 5. BARIS METADATA 1 (No. Bodi vs Tanggal & Jam Cetak)
        canvas.drawText("No. Bodi : $noBody", colLeftX, 65f, boldPaint)
        canvas.drawText("Tanggal : $formattedTrandate", metaMidX, 65f, boldPaint)
        canvas.drawText("Jam Cetak: $nowTimeFormatted", metaMidX + 160f, 65f, textPaint)

        // 6. GARIS PEMBATAS METADATA 2
        canvas.drawLine(leftMargin, 74f, rightMargin, 74f, dottedPaint)

        // 7. BARIS METADATA 2 & 3
        canvas.drawText("KM : $kmFormatted", colLeftX, 90f, boldPaint)
        canvas.drawText("Pemohon : $pemohonName", colLeftX, 108f, boldPaint)

        canvas.drawText("Tgl Terima    $formattedTrandate", metaMidX, 90f, boldPaint)
        canvas.drawText("Tanggal Selesai : $formattedEndDate", metaMidX + 160f, 90f, boldPaint)

        // 8. GARIS PEMBATAS METADATA 3 (Sebelum 3 Kolom Kerja)
        canvas.drawLine(leftMargin, 120f, rightMargin, 120f, dottedPaint)

        // DEFINISI 3 KOLOM KERJA:
        val div1X = 184f
        val div2X = 388f
        val bottomLineY = 348f

        // Garis pemisah kolom vertikal putus-putus
        canvas.drawLine(div1X, 120f, div1X, bottomLineY, dottedPaint)
        canvas.drawLine(div2X, 120f, div2X, bottomLineY, dottedPaint)

        val areaHeaderY = 136f

        // === KOLOM 1: KELUHAN ===
        canvas.drawText("Keluhan:", colLeftX, areaHeaderY, boldPaint)
        var currentCol1Y = areaHeaderY + 14f
        val keluhanText = summary.keluhan.ifBlank { "KOLOM KELUHAN" }
        val col1Width = div1X - colLeftX - 6f
        val keluhanLines = wrapText(keluhanText, col1Width, boldPaint)
        for (line in keluhanLines.take(13)) {
            if (currentCol1Y < bottomLineY - 10f) {
                canvas.drawText(line, colLeftX, currentCol1Y, boldPaint)
                currentCol1Y += 13f
            }
        }

        // === KOLOM 2: KETERANGAN PERBAIKAN ===
        val col2X = div1X + 6f
        val col2Width = div2X - col2X - 6f
        canvas.drawText("Keterangan Perbaikan:", col2X, areaHeaderY, boldPaint)
        var currentCol2Y = areaHeaderY + 14f
        val jobNotes = parseJobNotesWithDelimiters(items)

        if (jobNotes.isNotEmpty()) {
            for (note in jobNotes) {
                if (currentCol2Y >= bottomLineY - 14f) break
                val displayNote = if (note.startsWith("-") || note.startsWith("•")) note else "- $note"
                val noteLines = wrapText(displayNote, col2Width, boldPaint)
                for (nLine in noteLines) {
                    if (currentCol2Y < bottomLineY - 10f) {
                        canvas.drawText(nLine, col2X, currentCol2Y, boldPaint)
                        currentCol2Y += 13f
                    }
                }
            }
        } else {
            var lineSlot = 1
            while (lineSlot <= 12 && currentCol2Y < bottomLineY - 12f) {
                canvas.drawText("......................................", col2X, currentCol2Y, dottedPaint)
                currentCol2Y += 13.5f
                lineSlot++
            }
        }

        // === KOLOM 3: PART / PRODUK ===
        val col3X = div2X + 6f
        val col3Width = rightMargin - col3X - 4f
        canvas.drawText("Part / Produk:", col3X, areaHeaderY, boldPaint)

        // Subheader kolom part: DESKRIPSI PART & QTY
        val subHeaderY = areaHeaderY + 13f
        canvas.drawText("DESKRIPSI PART", col3X, subHeaderY, smallBoldPaint)
        canvas.drawText("QTY", rightMargin - 32f, subHeaderY, smallBoldPaint)
        canvas.drawLine(col3X, subHeaderY + 3f, rightMargin - 4f, subHeaderY + 3f, dottedPaint)

        var currentCol3Y = subHeaderY + 13f
        val partItems = items.filter { item ->
            val tipe = item.tipe.lowercase()
            tipe.contains("produk") || tipe.contains("part") || tipe.contains("barang") ||
            tipe.contains("material") || (!tipe.contains("jasa") && !tipe.contains("pekerjaan") && !tipe.contains("mekanik") && !tipe.contains("teknisi"))
        }

        if (partItems.isNotEmpty()) {
            for (item in partItems) {
                if (currentCol3Y >= bottomLineY - 12f) break
                val itemCode = item.kode.trim().ifBlank { "" }
                val itemDesc = item.description.trim().ifBlank { itemCode }
                val displayDesc = if (itemCode.isNotBlank() && !itemDesc.startsWith(itemCode)) {
                    "$itemCode $itemDesc"
                } else {
                    itemDesc
                }.uppercase()

                val qtyFormatted = if (item.qty == item.qty.toInt().toDouble()) {
                    "${item.qty.toInt()}"
                } else {
                    String.format(Locale.US, "%.1f", item.qty)
                }

                val maxDescWidth = col3Width - 40f
                val descLines = wrapText(displayDesc, maxDescWidth, smallTextPaint)
                val firstLine = descLines.firstOrNull() ?: displayDesc
                canvas.drawText(firstLine, col3X, currentCol3Y, smallTextPaint)
                canvas.drawText(qtyFormatted, rightMargin - 32f, currentCol3Y, smallBoldPaint)
                currentCol3Y += 11f

                for (extraLine in descLines.drop(1)) {
                    if (currentCol3Y < bottomLineY - 10f) {
                        canvas.drawText(extraLine, col3X + 4f, currentCol3Y, smallTextPaint)
                        currentCol3Y += 10.5f
                    }
                }
            }
        } else {
            canvas.drawText("(Tidak ada part)", col3X, currentCol3Y, smallTextPaint)
        }

        // 9. GARIS PEMBATAS HORIZONTAL BAWAH
        canvas.drawLine(leftMargin, bottomLineY, rightMargin, bottomLineY, dottedPaint)

        // 10. AREA PENGESAHAN TANDA TANGAN (Sesuai Gambar 1)
        val sigY = bottomLineY + 18f
        canvas.drawText("Dikerjakan oleh, $mekanikName", colLeftX, sigY, boldPaint)
        canvas.drawText("Tanda Tangan :", colLeftX, sigY + 26f, boldPaint)

        val rightSigX = pageWidth - 160f
        canvas.drawText("Disetujui,", rightSigX, sigY, boldPaint)
        canvas.drawText("( Ka. Regu / Mandor )", rightSigX, sigY + 26f, textPaint)

        document.finishPage(page)

        // Simpan dokumen PDF
        val exportDir = File(context.cacheDir, "pdf_orders").apply { mkdirs() }
        val safeWoName = summary.name.replace("/", "-").replace(" ", "_")
        val file = File(exportDir, "Order_Kerja_3Kolom_${safeWoName}.pdf")

        FileOutputStream(file).use { out ->
            document.writeTo(out)
        }
        document.close()

        return@withContext file
    }

    /**
     * OPSI 2: Cetak Full Detail (Rincian Lengkap Seluruh Kartu Work Order & Biaya)
     */
    suspend fun generateFullDetailPdf(
        context: Context,
        summary: WorkOrderSummary,
        items: List<WorkOrderItem>
    ): File = withContext(Dispatchers.IO) {
        val document = PdfDocument()

        // Standar Kertas A4 Portrait (595 pt x 842 pt)
        val pageWidth = 595
        val pageHeight = 842

        val titlePaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = 14f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val headerPaint = Paint().apply {
            color = Color.DKGRAY
            isAntiAlias = true
            textSize = 10f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val boldPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = 8.5f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val textPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = 8.5f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }
        val smallTextPaint = Paint().apply {
            color = Color.DKGRAY
            isAntiAlias = true
            textSize = 7.5f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }
        val borderPaint = Paint().apply {
            color = Color.GRAY
            strokeWidth = 0.7f
            style = Paint.Style.STROKE
        }
        val bgHeaderPaint = Paint().apply {
            color = Color.rgb(235, 240, 245)
            style = Paint.Style.FILL
        }
        val bgZebraPaint = Paint().apply {
            color = Color.rgb(248, 250, 252)
            style = Paint.Style.FILL
        }

        var currentPageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, currentPageNumber).create()
        var page = document.startPage(pageInfo)
        var canvas = page.canvas

        val margin = 36f
        val contentWidth = pageWidth - (margin * 2)

        // 1. Header Laporan
        canvas.drawText("LEMBAR DETAIL WORK ORDER & BIAYA BENGKEL", (pageWidth / 2).toFloat(), 42f, titlePaint)

        val nowFormatted = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.US).format(Date())
        val subText = "Nomor WO: ${summary.name}  |  Dicetak: $nowFormatted"
        val subPaint = Paint().apply {
            color = Color.GRAY
            isAntiAlias = true
            textSize = 9f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(subText, (pageWidth / 2).toFloat(), 56f, subPaint)

        canvas.drawLine(margin, 65f, pageWidth - margin, 65f, borderPaint)

        // 2. Info Blok Kendaraan
        val boxTop = 72f
        val boxHeight = 72f
        canvas.drawRoundRect(RectF(margin, boxTop, pageWidth - margin, boxTop + boxHeight), 4f, 4f, borderPaint)

        val col1X = margin + 10f
        val col2X = margin + 260f
        var rowY = boxTop + 16f
        val rowSpacing = 13.5f

        // Kolom 1
        canvas.drawText("Armada / Plat :", col1X, rowY, boldPaint)
        canvas.drawText(summary.mobilName, col1X + 75f, rowY, textPaint)

        canvas.drawText("No. Rangka   :", col1X, rowY + rowSpacing, boldPaint)
        canvas.drawText(summary.noChassis.ifBlank { "-" }, col1X + 75f, rowY + rowSpacing, textPaint)

        canvas.drawText("No. Mesin    :", col1X, rowY + (rowSpacing * 2), boldPaint)
        canvas.drawText(summary.noMesin.ifBlank { "-" }, col1X + 75f, rowY + (rowSpacing * 2), textPaint)

        canvas.drawText("Odometer KM  :", col1X, rowY + (rowSpacing * 3), boldPaint)
        canvas.drawText("${intFormat.format(summary.kmCurrent)} KM", col1X + 75f, rowY + (rowSpacing * 3), textPaint)

        // Kolom 2
        canvas.drawText("Tgl Transaksi :", col2X, rowY, boldPaint)
        canvas.drawText(summary.trandateFormatted, col2X + 75f, rowY, textPaint)

        canvas.drawText("Waktu Kerja   :", col2X, rowY + rowSpacing, boldPaint)
        canvas.drawText("${summary.startTime} s/d ${summary.endTime}", col2X + 75f, rowY + rowSpacing, textPaint)

        canvas.drawText("Total Item    :", col2X, rowY + (rowSpacing * 2), boldPaint)
        canvas.drawText("${summary.itemCount} Item (${summary.partCount} Part, ${summary.jasaCount} Jasa)", col2X + 75f, rowY + (rowSpacing * 2), textPaint)

        canvas.drawText("Total Biaya   :", col2X, rowY + (rowSpacing * 3), boldPaint)
        canvas.drawText(idrFormat.format(summary.totalCost), col2X + 75f, rowY + (rowSpacing * 3), boldPaint)

        // 3. Keluhan Baris
        val keluhanBoxTop = boxTop + boxHeight + 8f
        canvas.drawText("Keluhan Utama Armada:", margin, keluhanBoxTop + 10f, boldPaint)
        canvas.drawText(summary.keluhan.ifBlank { "Servis berkala & pemeriksaan standar" }, margin + 115f, keluhanBoxTop + 10f, textPaint)

        // 4. TABEL 1: RINCIAN SUKU CADANG & MATERIAL
        var tableY = keluhanBoxTop + 24f
        val headerRowHeight = 18f

        // Lebar kolom Tabel 1 (Total: 523f = contentWidth)
        val wNo = 26f
        val wTipe = 48f
        val wKode = 75f
        val wDesc = 242f
        val wQty = 42f
        val wPrice = 90f

        fun drawTable1Header(y: Float) {
            canvas.drawRect(RectF(margin, y, pageWidth - margin, y + headerRowHeight), bgHeaderPaint)
            canvas.drawRect(RectF(margin, y, pageWidth - margin, y + headerRowHeight), borderPaint)

            var curX = margin
            canvas.drawText("No", curX + 4f, y + 12f, headerPaint)
            curX += wNo
            canvas.drawText("Tipe", curX + 4f, y + 12f, headerPaint)
            curX += wTipe
            canvas.drawText("Kode Item", curX + 4f, y + 12f, headerPaint)
            curX += wKode
            canvas.drawText("Deskripsi Suku Cadang / Item", curX + 4f, y + 12f, headerPaint)
            curX += wDesc
            canvas.drawText("Qty", curX + 4f, y + 12f, headerPaint)
            curX += wQty
            canvas.drawText("Total (Rp)", curX + 4f, y + 12f, headerPaint)
        }

        // Judul Bagian Tabel 1
        canvas.drawText("1. TABEL RINCIAN SUKU CADANG & MATERIAL", margin, tableY - 6f, boldPaint)
        drawTable1Header(tableY)
        tableY += headerRowHeight

        val partItems = items.filter {
            !it.tipe.contains("JASA", ignoreCase = true) &&
            !it.tipe.contains("MEKANIK", ignoreCase = true) &&
            !it.tipe.contains("TEKNISI", ignoreCase = true)
        }
        val displayItems = if (partItems.isNotEmpty()) partItems else items

        displayItems.forEachIndexed { index, item ->
            val descLines = wrapText(item.description, wDesc - 8f, textPaint)
            val lineCount = maxOf(1, descLines.size)
            val itemRowHeight = maxOf(18f, (lineCount * 12.5f) + 5f)

            if (tableY + itemRowHeight > pageHeight - 120f) {
                document.finishPage(page)
                currentPageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, currentPageNumber).create()
                page = document.startPage(pageInfo)
                canvas = page.canvas

                canvas.drawText("LEMBAR DETAIL WORK ORDER (${summary.name}) - Halaman $currentPageNumber", (pageWidth / 2).toFloat(), 36f, smallTextPaint)
                tableY = 50f
                drawTable1Header(tableY)
                tableY += headerRowHeight
            }

            if (index % 2 == 1) {
                canvas.drawRect(RectF(margin, tableY, pageWidth - margin, tableY + itemRowHeight), bgZebraPaint)
            }
            canvas.drawRect(RectF(margin, tableY, pageWidth - margin, tableY + itemRowHeight), borderPaint)

            var curX = margin
            // No
            canvas.drawText("${index + 1}", curX + 4f, tableY + 12f, textPaint)
            curX += wNo
            canvas.drawLine(curX, tableY, curX, tableY + itemRowHeight, borderPaint)

            // Tipe
            val tipeColor = if (item.tipe.contains("PART", ignoreCase = true)) Color.rgb(20, 90, 160) else Color.rgb(180, 80, 20)
            val tipePaint = Paint(boldPaint).apply { color = tipeColor }
            canvas.drawText(item.tipe.take(7), curX + 4f, tableY + 12f, tipePaint)
            curX += wTipe
            canvas.drawLine(curX, tableY, curX, tableY + itemRowHeight, borderPaint)

            // Kode Item
            canvas.drawText(item.kode.take(14), curX + 4f, tableY + 12f, smallTextPaint)
            curX += wKode
            canvas.drawLine(curX, tableY, curX, tableY + itemRowHeight, borderPaint)

            // Deskripsi multiline
            descLines.forEachIndexed { lIdx, line ->
                canvas.drawText(line, curX + 4f, tableY + 12f + (lIdx * 12f), textPaint)
            }
            curX += wDesc
            canvas.drawLine(curX, tableY, curX, tableY + itemRowHeight, borderPaint)

            // Qty
            canvas.drawText("${item.qty}", curX + 4f, tableY + 12f, textPaint)
            curX += wQty
            canvas.drawLine(curX, tableY, curX, tableY + itemRowHeight, borderPaint)

            // Total Price
            val priceStr = if (item.totalPrice > 0) idrFormat.format(item.totalPrice) else "-"
            canvas.drawText(priceStr, curX + 4f, tableY + 12f, boldPaint)

            tableY += itemRowHeight
        }

        // Subtotal Suku Cadang jika terpisah
        val subtotalParts = displayItems.sumOf { it.totalPrice }
        val subtotalHeight = 16f
        canvas.drawRect(RectF(margin, tableY, pageWidth - margin, tableY + subtotalHeight), bgHeaderPaint)
        canvas.drawRect(RectF(margin, tableY, pageWidth - margin, tableY + subtotalHeight), borderPaint)
        canvas.drawText("Subtotal Suku Cadang / Material", margin + 10f, tableY + 11.5f, boldPaint)
        canvas.drawText(idrFormat.format(subtotalParts), pageWidth - margin - 8f, tableY + 11.5f, Paint(boldPaint).apply { textAlign = Paint.Align.RIGHT })
        tableY += subtotalHeight + 18f

        // 5. TABEL 2: CATATAN & INSTRUKSI PEKERJAAN (FULL TERPISAH TANPA TEKS TERPOTONG)
        val noteEntries = mutableListOf<String>()
        items.forEach { item ->
            val note = item.catatan.trim()
            val hasValidNote = note.isNotBlank() && note != "-"
            val isJasa = item.tipe.contains("JASA", ignoreCase = true)

            when {
                isJasa && hasValidNote -> {
                    if (note.contains(item.description, ignoreCase = true)) {
                        noteEntries.add(note)
                    } else {
                        noteEntries.add("${item.description} : $note")
                    }
                }
                isJasa -> {
                    noteEntries.add(item.description)
                }
                hasValidNote -> {
                    noteEntries.add("${item.description} : $note")
                }
            }
        }
        if (noteEntries.isEmpty()) {
            if (summary.keluhan.isNotBlank() && summary.keluhan != "-") {
                noteEntries.add(summary.keluhan)
            } else {
                noteEntries.add("Pemeriksaan dan perbaikan telah diselesaikan sesuai standar operasional bengkel.")
            }
        }

        val wNoteNo = 30f
        val wNoteText = contentWidth - wNoteNo // 493f full width

        fun drawTable2Header(y: Float) {
            canvas.drawRect(RectF(margin, y, pageWidth - margin, y + headerRowHeight), bgHeaderPaint)
            canvas.drawRect(RectF(margin, y, pageWidth - margin, y + headerRowHeight), borderPaint)

            canvas.drawText("No", margin + 6f, y + 12f, headerPaint)
            canvas.drawLine(margin + wNoteNo, y, margin + wNoteNo, y + headerRowHeight, borderPaint)
            canvas.drawText("Catatan / Instruksi Pekerjaan Lengkap", margin + wNoteNo + 8f, y + 12f, headerPaint)
        }

        // Cek ruang untuk Tabel 2 Header
        if (tableY > pageHeight - 140f) {
            document.finishPage(page)
            currentPageNumber++
            pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, currentPageNumber).create()
            page = document.startPage(pageInfo)
            canvas = page.canvas

            canvas.drawText("LEMBAR DETAIL WORK ORDER (${summary.name}) - Halaman $currentPageNumber", (pageWidth / 2).toFloat(), 36f, smallTextPaint)
            tableY = 50f
        }

        canvas.drawText("2. TABEL CATATAN & INSTRUKSI PEKERJAAN (DETAIL)", margin, tableY - 6f, boldPaint)
        drawTable2Header(tableY)
        tableY += headerRowHeight

        // Render baris catatan dengan dynamic multiline wrapping tanpa ada text hilang
        noteEntries.forEachIndexed { index, noteText ->
            val wrappedLines = wrapText(noteText, wNoteText - 16f, textPaint)
            val noteRowHeight = maxOf(20f, (wrappedLines.size * 13.5f) + 8f)

            if (tableY + noteRowHeight > pageHeight - 120f) {
                document.finishPage(page)
                currentPageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, currentPageNumber).create()
                page = document.startPage(pageInfo)
                canvas = page.canvas

                canvas.drawText("LEMBAR DETAIL WORK ORDER (${summary.name}) - Halaman $currentPageNumber", (pageWidth / 2).toFloat(), 36f, smallTextPaint)
                tableY = 50f
                drawTable2Header(tableY)
                tableY += headerRowHeight
            }

            if (index % 2 == 1) {
                canvas.drawRect(RectF(margin, tableY, pageWidth - margin, tableY + noteRowHeight), bgZebraPaint)
            }
            canvas.drawRect(RectF(margin, tableY, pageWidth - margin, tableY + noteRowHeight), borderPaint)

            // Kolom No
            canvas.drawText("${index + 1}", margin + 8f, tableY + 13.5f, textPaint)
            canvas.drawLine(margin + wNoteNo, tableY, margin + wNoteNo, tableY + noteRowHeight, borderPaint)

            // Teks Catatan Utuh (Multiline Wrap)
            wrappedLines.forEachIndexed { lIdx, line ->
                canvas.drawText(line, margin + wNoteNo + 8f, tableY + 13.5f + (lIdx * 13.5f), textPaint)
            }

            tableY += noteRowHeight
        }

        // Cek ruang untuk Rekapitulasi & Tanda Tangan
        if (tableY > pageHeight - 130f) {
            document.finishPage(page)
            currentPageNumber++
            pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, currentPageNumber).create()
            page = document.startPage(pageInfo)
            canvas = page.canvas

            canvas.drawText("LEMBAR DETAIL WORK ORDER (${summary.name}) - Halaman $currentPageNumber", (pageWidth / 2).toFloat(), 36f, smallTextPaint)
            tableY = 50f
        }

        // 6. Total Rekapitulasi di bawah tabel
        val summaryY = tableY + 12f
        canvas.drawRect(RectF(margin + 240f, summaryY, pageWidth - margin, summaryY + 36f), bgHeaderPaint)
        canvas.drawRect(RectF(margin + 240f, summaryY, pageWidth - margin, summaryY + 36f), borderPaint)

        canvas.drawText("GRAND TOTAL BIAYA WORK ORDER :", margin + 250f, summaryY + 16f, boldPaint)
        val grandTotalText = idrFormat.format(summary.totalCost)
        val totalPaint = Paint(titlePaint).apply {
            textSize = 12f
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText(grandTotalText, pageWidth - margin - 10f, summaryY + 24f, totalPaint)

        // 7. Penutup Tanda Tangan: otomatis cantumkan kedua mekanik bila ada dalam 1 nomor WO
        val sigY = summaryY + 54f
        val distinctMechanics = extractDistinctMechanics(items)

        if (distinctMechanics.size >= 2) {
            val col1X = margin + 10f
            val col2X = margin + 185f
            val col3X = margin + 360f

            // Mekanik 1
            canvas.drawText("Dikerjakan oleh (1),", col1X, sigY, boldPaint)
            val name1 = distinctMechanics[0]
            val dispName1 = if (textPaint.measureText(name1) > 115f) {
                var t = name1
                while (t.length > 5 && textPaint.measureText("$t...") > 115f) t = t.dropLast(1)
                "$t..."
            } else name1
            canvas.drawText("Nama        : $dispName1", col1X, sigY + 18f, textPaint)
            canvas.drawText("Tanda Tangan: ____________________", col1X, sigY + 36f, textPaint)

            // Mekanik 2
            canvas.drawText("Dikerjakan oleh (2),", col2X, sigY, boldPaint)
            val name2 = distinctMechanics[1]
            val dispName2 = if (textPaint.measureText(name2) > 115f) {
                var t = name2
                while (t.length > 5 && textPaint.measureText("$t...") > 115f) t = t.dropLast(1)
                "$t..."
            } else name2
            canvas.drawText("Nama        : $dispName2", col2X, sigY + 18f, textPaint)
            canvas.drawText("Tanda Tangan: ____________________", col2X, sigY + 36f, textPaint)

            // Ka. Regu
            canvas.drawText("Disetujui oleh,", col3X, sigY, boldPaint)
            canvas.drawText("Nama        : (Ka. Regu)", col3X, sigY + 18f, textPaint)
            canvas.drawText("Tanda Tangan: ____________________", col3X, sigY + 36f, textPaint)
        } else {
            val sigX = margin + 15f
            val sig2X = margin + 260f
            val mekanikNameFound = distinctMechanics.firstOrNull() ?: "____________________"

            canvas.drawText("Dikerjakan oleh,", sigX, sigY, boldPaint)
            canvas.drawText("Nama        : $mekanikNameFound", sigX, sigY + 18f, textPaint)
            canvas.drawText("Tanda Tangan: ____________________", sigX, sigY + 36f, textPaint)

            canvas.drawText("Disetujui oleh,", sig2X, sigY, boldPaint)
            canvas.drawText("Nama        : (Ka. Regu)", sig2X, sigY + 18f, textPaint)
            canvas.drawText("Tanda Tangan: ____________________", sig2X, sigY + 36f, textPaint)
        }

        document.finishPage(page)

        // Simpan dokumen PDF
        val exportDir = File(context.cacheDir, "pdf_orders").apply { mkdirs() }
        val safeWoName = summary.name.replace("/", "-").replace(" ", "_")
        val file = File(exportDir, "Detail_Lengkap_WO_${safeWoName}.pdf")

        FileOutputStream(file).use { out ->
            document.writeTo(out)
        }
        document.close()

        return@withContext file
    }

    /**
     * Membuka dokumen PDF langsung menggunakan aplikasi penampil PDF perangkat, atau membagikannya
     */
    fun openOrSharePdf(context: Context, file: File, title: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        // Intent untuk menampilkan PDF
        val viewIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        // Intent untuk berbagi
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, file.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        // Chooser terpadu
        val chooser = Intent.createChooser(shareIntent, title).apply {
            putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(viewIntent))
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        context.startActivity(chooser)
    }

    /**
     * Mengubah halaman file PDF menjadi Bitmap beresolusi tajam untuk ditampilkan
     * langsung di layar Pratinjau aplikasi tanpa perlu aplikasi pembaca PDF eksternal.
     */
    fun renderPdfToBitmap(pdfFile: File, pageIndex: Int = 0): Bitmap? {
        return try {
            val pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
            val renderer = PdfRenderer(pfd)
            if (pageIndex >= renderer.pageCount) {
                renderer.close()
                pfd.close()
                return null
            }
            val page = renderer.openPage(pageIndex)
            val scale = 2 // 2x resolusi tajam
            val bitmap = Bitmap.createBitmap(page.width * scale, page.height * scale, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.WHITE)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            page.close()
            renderer.close()
            pfd.close()
            bitmap
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    // Helper teks multiline
    private fun wrapText(text: String, maxWidth: Float, paint: Paint): List<String> {
        val words = text.split(" ")
        val lines = mutableListOf<String>()
        var currentLine = ""

        for (word in words) {
            val candidate = if (currentLine.isEmpty()) word else "$currentLine $word"
            if (paint.measureText(candidate) <= maxWidth) {
                currentLine = candidate
            } else {
                if (currentLine.isNotEmpty()) lines.add(currentLine)
                currentLine = word
            }
        }
        if (currentLine.isNotEmpty()) lines.add(currentLine)
        return lines
    }

    /**
     * Memecah catatan pekerjaan menjadi butir-butir instruksi baris terpisah.
     * Bila terdapat simbol `-` atau karakter baris baru (\n), teks akan otomatis dipisah
     * menjadi baris pengerjaan baru di bawahnya.
     */
    fun parseJobNotesWithDelimiters(items: List<WorkOrderItem>): List<String> {
        val rawList = mutableListOf<String>()

        // 1. Ambil catatan dari setiap item jika ada
        for (item in items) {
            val c = item.catatan.trim()
            if (c.isNotBlank() && c != "-" && !c.equals("null", ignoreCase = true)) {
                rawList.add(c)
            }
            // Jika item bertipe PEKERJAAN atau JASA, tambahkan juga deskripsinya jika relevan
            val isJobType = item.tipe.contains("pekerjaan", ignoreCase = true) ||
                            item.tipe.contains("jasa", ignoreCase = true)
            if (isJobType && item.description.isNotBlank() && !item.description.equals("jasa", ignoreCase = true)) {
                val d = item.description.trim()
                if (!rawList.contains(d)) {
                    rawList.add(d)
                }
            }
        }

        val result = mutableListOf<String>()
        for (raw in rawList) {
            val lines = raw.split("\n", "\r")
            for (line in lines) {
                val trimmed = line.trim()
                if (trimmed.isBlank() || trimmed == "-") continue
                if (trimmed.contains("-")) {
                    val segments = trimmed.split("-")
                        .map { it.trim().uppercase() }
                        .filter { it.isNotBlank() }
                    for (seg in segments) {
                        if (!result.contains(seg)) {
                            result.add(seg)
                        }
                    }
                } else {
                    val upper = trimmed.uppercase()
                    if (!result.contains(upper)) {
                        result.add(upper)
                    }
                }
            }
        }
        return result
    }

    private data class ParsedVehicle(
        val bodyNumber: String,
        val licensePlate: String
    )

    private fun parseVehicleDetails(mobilName: String): ParsedVehicle {
        // Format umum: "APE117 - A 7751 KL" atau "B 9281 UXT (HINO 500)"
        val parts = mobilName.split("-", "(").map { it.trim() }
        return when {
            parts.size >= 2 -> {
                ParsedVehicle(bodyNumber = parts[0], licensePlate = parts[1].replace(")", "").trim())
            }
            else -> {
                ParsedVehicle(bodyNumber = "", licensePlate = mobilName)
            }
        }
    }

    /**
     * Mendeteksi seluruh nama mekanik yang tercatat pada item Work Order.
     * Mengambil baris item pada nomor WO yang sama di mana kolom tipe bertuliskan 'mekanik' atau 'teknisi',
     * lalu membaca nama mekanik dari kolom deskripsi.
     * Juga menangani deteksi nama mekanik ganda dalam satu baris (misal 'MEKANIK 1 / MEKANIK 2').
     */
    fun extractDistinctMechanics(items: List<WorkOrderItem>): List<String> {
        val detected = mutableListOf<String>()

        // 1. Prioritas utama: baris item dengan kolom tipe 'mekanik' atau 'teknisi', ambil kolom description
        for (item in items) {
            val tipe = item.tipe.lowercase()
            if (tipe.contains("mekanik") || tipe.contains("teknisi")) {
                detected.addAll(cleanSingleOrMultiMechanic(item.description))
            }
        }

        // 2. Jika belum ditemukan atau deteksi tambahan dari teks regex deskripsi & catatan
        if (detected.isEmpty()) {
            for (item in items) {
                val combined = "${item.description} ${item.catatan}"
                if (combined.contains("mekanik", ignoreCase = true) || combined.contains("teknisi", ignoreCase = true)) {
                    val matches = Regex("(?i)(?:mekanik|teknisi)\\s*[:=]?\\s*([A-Za-z0-9 .'-]+)").findAll(combined)
                    for (match in matches) {
                        val raw = match.groupValues.getOrNull(1)
                        if (!raw.isNullOrBlank()) {
                            detected.addAll(cleanSingleOrMultiMechanic(raw))
                        }
                    }
                }
            }
        }

        // 3. Fallback jika masih kosong: cek tipe JASA non-jasa
        if (detected.isEmpty()) {
            val fallback = items.firstOrNull {
                it.tipe.equals("JASA", ignoreCase = true) && !it.description.contains("jasa", ignoreCase = true)
            }?.description
            if (!fallback.isNullOrBlank()) {
                detected.addAll(cleanSingleOrMultiMechanic(fallback))
            }
        }

        // Filter nama yang valid dan hilangkan duplikasi (case-insensitive)
        val unique = mutableListOf<String>()
        val seen = mutableSetOf<String>()
        for (name in detected) {
            val upper = name.trim().uppercase()
            if (upper.isNotBlank() && upper.length >= 2 && seen.add(upper)) {
                unique.add(upper)
            }
        }
        return unique
    }

    private fun cleanSingleOrMultiMechanic(raw: String): List<String> {
        val cleaned = raw.replace(Regex("(?i)^(?:mekanik|teknisi)\\s*[:=-]?\\s*"), "").trim()
        if (cleaned.isBlank() || cleaned == "-" || cleaned.equals("null", ignoreCase = true)) return emptyList()

        // Jika dalam 1 deskripsi terdapat dua nama dipisah tanda '/' atau '&' atau ','
        val splits = cleaned.split(Regex("[,/&]"))
        return if (splits.size > 1) {
            splits.map { it.replace(Regex("(?i)^(?:mekanik|teknisi)\\s*[:=-]?\\s*"), "").trim().uppercase() }
                .filter { it.isNotBlank() && it.length >= 2 && !it.equals("MEKANIK", ignoreCase = true) && !it.equals("TEKNISI", ignoreCase = true) }
        } else {
            val single = cleaned.uppercase()
            if (single.isNotBlank() && single.length >= 2 && !single.equals("MEKANIK", ignoreCase = true) && !single.equals("TEKNISI", ignoreCase = true)) {
                listOf(single)
            } else {
                emptyList()
            }
        }
    }
}
