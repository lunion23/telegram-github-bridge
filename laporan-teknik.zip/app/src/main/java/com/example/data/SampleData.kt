package com.example.data

import com.example.data.model.PartItem
import com.example.data.model.TechnicalReport
import com.example.data.model.WarrantyStatus

object SampleData {
    // Desain 1: Format Standar Dealer
    fun createSampleReport(): TechnicalReport {
        return TechnicalReport(
            id = 0,
            activeTemplate = 1,
            title = "LAPORAN TEKNIK",
            companyName = "Hiba Group",
            reportNumber = "2/LP/CLG/6/2026",
            workshop = "CILEGON",
            reportDate = "2026-06-20",

            // Informasi Unit/Alat
            manufacturer = "HINO",
            unitType = "J08EUFR",
            model = "RK8J",
            unitCode = "GLX357",
            toolName = "BAN",
            damageDate = "2026-06-20",
            mileageKmHm = "139333",
            component = "UNDERBODY",

            // Status Garansi
            warrantyStatus = WarrantyStatus.AFTER_WARRANTY,

            // Detail Kerusakan & Lokasi
            damageDetail = "Ban belakang kiri bagian dalam pecah (POS D)",
            location = "Tol Cinere",
            workshopHistory = "Inspeksi terakhir tanggal 18 Juni 2026 (No. WO: CLG1-WO-2606-00620)",
            tireHistory = "Pengecekan ban terakhir tanggal 18 Juni 2026 (No. WO: CLG1-WO-2606-00661)",
            attachments = "Foto Kerusakan terlampir",

            // Penyebab Kerusakan
            causeInstallation = false,
            causeInstallationNotes = "- Kondisi tread and pressure ban bagus",
            causeQuality = false,
            causeQualityNotes = "- Kondisi sistem rem normal, Alat kunci roda, dongkrak dan ban stip tersedia",
            causeOperational = false,
            causeOperationalNotes = "- Kondisi ban bocor terkena benda tajam",
            causeTimeExpired = false,
            causeTimeExpiredNotes = "Kesimpulan: Ban bocor dikarenakan terkena benda tajam saat melaju di jalan",
            causeOthers = true,
            causeOthersNotes = "Pecah ban akibat benda tajam di jalan tol",

            // Cara Mengatasi Kerusakan
            solutionReplacePart = true,
            solutionReplacePartNotes = "Ganti ban baru",
            solutionReinstallAdjust = false,
            solutionReinstallAdjustNotes = "",
            solutionModification = false,
            solutionModificationNotes = "",

            // Tabel Parts yang Harus Diganti
            partsList = listOf(
                PartItem(
                    partNumber = "42611-1234 / G357",
                    partName = "BAN LUAR 11R22.5",
                    procurementType = "Stock",
                    notes = "Ganti ban POS D"
                ),
                PartItem(
                    partNumber = "42612-5678 / G357",
                    partName = "BAN DALAM & FLAP 11R22.5",
                    procurementType = "Stock",
                    notes = "Satu set ban baru"
                )
            ),

            // Bagian Penandatangan
            approvedByName = "Yudi Indrawan",
            approvedByTitle = "WA.KA. Bengkel",
            reportedByName = "Ahmad Supriyadi",
            reportedByTitle = "Mekanik / Foreman",
            signDate = "2026-06-20"
        )
    }

    // Desain 2: Format Hiba Group Sesuai Gambar
    fun createSampleReportHibaGroup(): TechnicalReport {
        return TechnicalReport(
            id = 0,
            activeTemplate = 2,
            title = "LAPORAN TEKNIK",
            companyName = "Hiba Group",
            reportNumber = "1/LT-CLG/III/2026",
            workshop = "Cilegon",
            reportDate = "12-Mar-26",

            // Informasi Unit/Alat
            manufacturer = "HINO",
            unitType = "DUTRO",
            model = "W04DTPJ-53447",
            unitCode = "D127",
            toolName = "Ban",
            damageDate = "12-Mar-26",
            mileageKmHm = "598916",
            component = "Underbody",

            // Status Garansi
            warrantyStatus = WarrantyStatus.AFTER_WARRANTY,

            // Detail Kerusakan & Lokasi Sesuai Gambar
            storingStatus = "Storing",
            damageDetail = "Ban kempes",
            location = "Tol tangerang - merak",
            analysisNotes = "Setelah di lakukan storing oleh team cikupa di temukan ban depan kiri kempes",
            conclusionNotes = "",
            lastReplacement = "9-5-2022 (km.415513)",
            lastReplacementWo = "KLD1-WO-2205-00381",
            lastWeeklyCheck = "5-3-2026 (km.598234)",
            lastWeeklyCheckWo = "CLG1-WO-2603-00225",
            attachments = "Foto Kerusakan terlampir",
            damagePhotoUri = "sample",

            // Penyebab Kerusakan: √ = YA  X = TIDAK
            causeInstallation = false,
            causeInstallationNotes = "",
            causeQuality = false,
            causeQualityNotes = "",
            causeOperational = false,
            causeOperationalNotes = "",
            causeTimeExpired = true, // √ di gambar
            causeTimeExpiredNotes = "",
            causeOthers = false,
            causeOthersNotes = "",

            // Cara Mengatasi Kerusakan
            solutionReplacePart = false,
            solutionReplacePartNotes = "",
            solutionReinstallAdjust = true, // √ di gambar
            solutionReinstallAdjustNotes = "Ganti ban stip",
            solutionModification = false,
            solutionModificationNotes = "",

            // Tertunda & Usulan
            pendingReason = "",
            reporterProposal = "Segera akan di lakukan program pengecekan atau penggantian terkait part tersebut terhadap RK8J supaya tidak terjadi kejadian serupa",

            // Parts yang harus diganti (5 baris kosong sesuai form gambar)
            partsList = listOf(
                PartItem(
                    partNumber = "",
                    partName = "",
                    procurementType = "Stock",
                    notes = ""
                )
            ),

            // Bagian Penandatangan
            knownBy1 = "",
            knownBy2 = "SUHERMAN",
            approvedByName = "Yudi Indrawan",
            approvedByTitle = "Wa.Ka.Bengkel",
            reportedByName = "Yudi Indrawan",
            reportedByTitle = "Wa.Ka.Bengkel",
            signDate = "12-Mar-26"
        )
    }
}
