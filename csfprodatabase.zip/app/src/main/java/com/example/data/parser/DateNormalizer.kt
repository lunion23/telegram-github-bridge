package com.example.data.parser

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object DateNormalizer {

    private val supportedFormats = listOf(
        "yyyy-MM-dd HH:mm:ss",
        "yyyy-MM-dd HH:mm",
        "yyyy-MM-dd",
        "dd/MM/yyyy HH:mm:ss",
        "dd/MM/yyyy HH:mm",
        "dd/MM/yyyy",
        "dd-MM-yyyy HH:mm:ss",
        "dd-MM-yyyy HH:mm",
        "dd-MM-yyyy",
        "MM/dd/yyyy",
        "yyyy/MM/dd",
        "d/M/yyyy",
        "d-M-yyyy",
        "dd MMM yyyy"
    )

    private val standardOutputFormat = object : ThreadLocal<SimpleDateFormat>() {
        override fun initialValue(): SimpleDateFormat {
            return SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                timeZone = TimeZone.getDefault()
            }
        }
    }

    data class NormalizedDateResult(
        val millis: Long,
        val formatted: String
    )

    /**
     * Parses and normalizes various date strings into consistent epoch millis and ISO yyyy-MM-dd.
     * Thread-safe across multiple concurrent coroutines.
     */
    fun parse(rawInput: String?): NormalizedDateResult {
        val formatter = standardOutputFormat.get() ?: SimpleDateFormat("yyyy-MM-dd", Locale.US)

        if (rawInput.isNullOrBlank()) {
            val now = System.currentTimeMillis()
            return NormalizedDateResult(now, formatter.format(Date(now)))
        }

        val cleaned = rawInput.trim()

        // Check if pure epoch number
        cleaned.toLongOrNull()?.let { num ->
            val epoch = if (num < 10_000_000_000L) num * 1000L else num
            return NormalizedDateResult(epoch, formatter.format(Date(epoch)))
        }

        for (pattern in supportedFormats) {
            try {
                val sdf = SimpleDateFormat(pattern, Locale.US).apply {
                    isLenient = true
                }
                val parsedDate = sdf.parse(cleaned)
                if (parsedDate != null) {
                    val millis = parsedDate.time
                    val formatted = formatter.format(parsedDate)
                    return NormalizedDateResult(millis, formatted)
                }
            } catch (_: Exception) {
                // Try next pattern
            }
        }

        // Fallback: current time
        val fallbackMillis = System.currentTimeMillis()
        return NormalizedDateResult(fallbackMillis, cleaned)
    }

    fun formatDisplay(millis: Long): String {
        return try {
            val sdf = SimpleDateFormat("dd MMM yyyy", Locale("id", "ID"))
            sdf.format(Date(millis))
        } catch (_: Exception) {
            val formatter = standardOutputFormat.get() ?: SimpleDateFormat("yyyy-MM-dd", Locale.US)
            formatter.format(Date(millis))
        }
    }
}
