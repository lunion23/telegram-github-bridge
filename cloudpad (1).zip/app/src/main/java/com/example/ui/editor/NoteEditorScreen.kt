package com.example.ui.editor

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Note
import com.example.export.ExportManager
import com.example.files.LocalFileManager
import com.example.ui.components.ExportBottomSheet
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteEditorScreen(
    initialNote: Note,
    sourceUri: Uri? = null,
    onSaveNote: (Note) -> Unit,
    onDeleteNote: (String) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var title by remember(initialNote.id) { mutableStateOf(initialNote.title) }
    var contentValue by remember(initialNote.id) {
        mutableStateOf(TextFieldValue(initialNote.content, TextRange(initialNote.content.length)))
    }
    var tags by remember(initialNote.id) { mutableStateOf(initialNote.tags) }
    var isPinned by remember(initialNote.id) { mutableStateOf(initialNote.isPinned) }
    var fileExtension by remember(initialNote.id) { mutableStateOf(initialNote.fileExtension.ifBlank { "txt" }) }
    var newTagInput by remember { mutableStateOf("") }
    var showTagInput by remember { mutableStateOf(false) }
    var showExtensionMenu by remember { mutableStateOf(false) }

    var selectedTabIndex by remember { mutableIntStateOf(0) } // 0: Editor, 1: Preview
    var showOptionsMenu by remember { mutableStateOf(false) }
    var showExportSheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val currentNote = remember(title, contentValue.text, tags, isPinned, fileExtension) {
        initialNote.copy(
            title = title,
            content = contentValue.text,
            tags = tags,
            isPinned = isPinned,
            fileExtension = fileExtension,
            updatedAt = System.currentTimeMillis()
        )
    }

    // Debounced auto-save for real-time cloud sync while editing
    var hasUserEdited by remember(initialNote.id) { mutableStateOf(false) }
    LaunchedEffect(title, contentValue.text, tags, isPinned, fileExtension) {
        if (!hasUserEdited) {
            hasUserEdited = true
            return@LaunchedEffect
        }
        if (title.isNotBlank() || contentValue.text.isNotBlank()) {
            delay(800)
            onSaveNote(currentNote)
        }
    }

    // Auto-save on exit
    fun saveAndExit() {
        if (title.isNotBlank() || contentValue.text.isNotBlank()) {
            onSaveNote(currentNote)
        }
        onNavigateBack()
    }

    BackHandler {
        saveAndExit()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (title.isBlank()) "Catatan Baru" else title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = ".${fileExtension.uppercase()} • ${currentNote.wordCount} kata",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { saveAndExit() },
                        modifier = Modifier.testTag("btn_editor_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Kembali"
                        )
                    }
                },
                actions = {
                    // Quick Pin Toggle
                    IconButton(
                        onClick = { isPinned = !isPinned },
                        modifier = Modifier.testTag("btn_toggle_pin")
                    ) {
                        Icon(
                            imageVector = if (isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                            contentDescription = "Sematkan",
                            tint = if (isPinned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Export Button
                    IconButton(
                        onClick = { showExportSheet = true },
                        modifier = Modifier.testTag("btn_editor_export")
                    ) {
                        Icon(Icons.Default.SaveAlt, contentDescription = "Ekspor")
                    }

                    // Share Button
                    IconButton(
                        onClick = {
                            val intent = ExportManager.createShareIntent(context, currentNote, fileExtension)
                            context.startActivity(intent)
                        },
                        modifier = Modifier.testTag("btn_editor_share")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "Bagikan")
                    }

                    // More Menu
                    Box {
                        IconButton(onClick = { showOptionsMenu = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Pilihan")
                        }
                        DropdownMenu(
                            expanded = showOptionsMenu,
                            onDismissRequest = { showOptionsMenu = false }
                        ) {
                            if (sourceUri != null) {
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.save_to_original_file)) },
                                    onClick = {
                                        showOptionsMenu = false
                                        scope.launch {
                                            val result = LocalFileManager.writeNoteToUri(
                                                context = context,
                                                uri = sourceUri,
                                                content = contentValue.text
                                            )
                                            result.onSuccess {
                                                Toast.makeText(
                                                    context,
                                                    "Berhasil disimpan ke file asli",
                                                    Toast.LENGTH_SHORT
                                                ).show()
                                            }.onFailure { err ->
                                                Toast.makeText(
                                                    context,
                                                    err.message ?: "Tidak dapat menulis ke file asli, gunakan Ekspor.",
                                                    Toast.LENGTH_LONG
                                                ).show()
                                            }
                                        }
                                    },
                                    leadingIcon = {
                                        Icon(
                                            Icons.Default.Save,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                )
                            }
                            DropdownMenuItem(
                                text = { Text("Hapus Catatan") },
                                onClick = {
                                    showOptionsMenu = false
                                    onDeleteNote(initialNote.id)
                                    onNavigateBack()
                                },
                                leadingIcon = {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            if (selectedTabIndex == 0) {
                FormattingToolbar(
                    onInsert = { prefix, suffix ->
                        val start = minOf(contentValue.selection.start, contentValue.selection.end)
                        val end = maxOf(contentValue.selection.start, contentValue.selection.end)
                        val selectedText = if (start != end) contentValue.text.substring(start, end) else ""
                        val replacement = "$prefix$selectedText$suffix"
                        val newText = contentValue.text.replaceRange(start, end, replacement)
                        val newCursor = start + prefix.length + selectedText.length
                        contentValue = TextFieldValue(newText, TextRange(newCursor))
                    }
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // View Mode Tab: Edit vs Preview
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = MaterialTheme.colorScheme.surfaceContainer
            ) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = { Text("Editor Kode & Teks") },
                    icon = { Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.testTag("tab_edit_mode")
                )
                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = { Text("Pratinjau") },
                    icon = { Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.testTag("tab_preview_mode")
                )
            }

            // Title & Format Header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                BasicTextField(
                    value = title,
                    onValueChange = { title = it },
                    textStyle = MaterialTheme.typography.titleLarge.copy(
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold
                    ),
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    decorationBox = { innerTextField ->
                        if (title.isEmpty()) {
                            Text(
                                text = stringResource(R.string.note_title_placeholder),
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                fontWeight = FontWeight.Bold
                            )
                        }
                        innerTextField()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .testTag("input_note_title")
                )

                // Tags and Extension Selector Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Extension indicator / switcher
                    Box {
                        Surface(
                            onClick = { showExtensionMenu = true },
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Code,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = ".${fileExtension.uppercase()} ▾",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = showExtensionMenu,
                            onDismissRequest = { showExtensionMenu = false }
                        ) {
                            ExportManager.PRESET_EXTENSIONS.forEach { ext ->
                                DropdownMenuItem(
                                    text = { Text(".${ext.uppercase()}") },
                                    onClick = {
                                        fileExtension = ext
                                        showExtensionMenu = false
                                    }
                                )
                            }
                        }
                    }

                    // Existing tags
                    tags.forEach { tag ->
                        AssistChip(
                            onClick = {
                                tags = tags.filter { it != tag }
                            },
                            label = { Text("#$tag") },
                            trailingIcon = {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Hapus tag",
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        )
                    }

                    // Add tag button / input
                    if (!showTagInput) {
                        AssistChip(
                            onClick = { showTagInput = true },
                            label = { Text("+ Tag") },
                            leadingIcon = {
                                Icon(
                                    Icons.Default.Add,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        )
                    } else {
                        OutlinedTextField(
                            value = newTagInput,
                            onValueChange = { newTagInput = it },
                            placeholder = { Text("tag baru") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = {
                                val clean = newTagInput.trim().removePrefix("#")
                                if (clean.isNotBlank() && !tags.contains(clean)) {
                                    tags = tags + clean
                                }
                                newTagInput = ""
                                showTagInput = false
                            }),
                            modifier = Modifier
                                .width(120.dp)
                                .height(46.dp),
                            textStyle = TextStyle(fontSize = 12.sp)
                        )
                    }
                }
            }

            // Main Editor Body or Preview
            if (selectedTabIndex == 0) {
                // Code & Markdown Editor
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    BasicTextField(
                        value = contentValue,
                        onValueChange = { contentValue = it },
                        textStyle = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 15.sp,
                            lineHeight = 22.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                        decorationBox = { innerTextField ->
                            if (contentValue.text.isEmpty()) {
                                Text(
                                    text = stringResource(R.string.note_content_placeholder),
                                    style = TextStyle(
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 15.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                    )
                                )
                            }
                            innerTextField()
                        },
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("input_note_content")
                    )
                }
            } else {
                // Rendered Preview
                NotePreview(
                    note = currentNote,
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState())
                )
            }
        }
    }

    // Export Bottom Sheet
    if (showExportSheet) {
        ExportBottomSheet(
            note = currentNote,
            sheetState = sheetState,
            onDismissRequest = { showExportSheet = false }
        )
    }
}

@Composable
fun FormattingToolbar(
    onInsert: (prefix: String, suffix: String) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        tonalElevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            ToolbarButton(label = "H1") { onInsert("# ", "") }
            ToolbarButton(label = "H2") { onInsert("## ", "") }
            ToolbarButton(label = "H3") { onInsert("### ", "") }
            ToolbarIconButton(icon = Icons.Default.FormatBold, desc = "Tebal") { onInsert("**", "**") }
            ToolbarIconButton(icon = Icons.Default.FormatItalic, desc = "Miring") { onInsert("*", "*") }
            ToolbarButton(label = "`Code`") { onInsert("`", "`") }
            ToolbarButton(label = "```Block") { onInsert("```\n", "\n```") }
            ToolbarIconButton(icon = Icons.AutoMirrored.Filled.FormatListBulleted, desc = "Daftar") { onInsert("- ", "") }
            ToolbarButton(label = "☑ Check") { onInsert("- [ ] ", "") }
            ToolbarButton(label = "🔗 Link") { onInsert("[", "](https://)") }
            ToolbarButton(label = "🕒 Waktu") {
                val nowStr = SimpleDateFormat("HH:mm, dd MMM yyyy", Locale.getDefault()).format(Date())
                onInsert(nowStr, "")
            }
        }
    }
}

@Composable
private fun ToolbarButton(label: String, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.padding(2.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun ToolbarIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    desc: String,
    onClick: () -> Unit
) {
    IconButton(
        onClick = onClick,
        modifier = Modifier.size(36.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = desc,
            tint = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
fun NotePreview(note: Note, modifier: Modifier = Modifier) {
    val isDark = androidx.compose.foundation.isSystemInDarkTheme()
    val highlightedText = remember(note.content, isDark) {
        SyntaxHighlighter.highlight(note.content, isDark)
    }

    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainer
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            if (note.title.isNotBlank()) {
                Text(
                    text = note.title,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            if (note.content.isBlank()) {
                Text(
                    text = "Pratinjau kosong. Tulis sesuatu di tab Editor!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Text(
                    text = highlightedText,
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 15.sp,
                        lineHeight = 22.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        }
    }
}
