package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.PrintFormatMode
import com.example.data.model.ReceiptData

@Entity(tableName = "receipts")
data class ReceiptEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val resiCode: String,
    val routingCode: String,
    val badge1: String,
    val badge2: String,
    val dropPoint: String,
    val recipientName: String,
    val recipientPhone: String,
    val recipientAddress: String,
    val senderName: String,
    val senderPhone: String,
    val senderAddress: String,
    val shippingFee: Long,
    val paymentType: String,
    val weightKg: String,
    val printDate: String,
    val orderNo: String,
    val expNote: String,
    val notes: String,
    val footerCompany: String,
    val maskPhone: Boolean,
    val itemName: String = "Pakaian",
    val itemQty: String = "1 PCS",
    val expDate: String = "25-10-2026",
    val selectedFormat: String = PrintFormatMode.MAIN_LABEL.name,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toReceiptData(): ReceiptData = ReceiptData(
        id = id,
        resiCode = resiCode,
        routingCode = routingCode,
        badge1 = badge1,
        badge2 = badge2,
        dropPoint = dropPoint,
        recipientName = recipientName,
        recipientPhone = recipientPhone,
        recipientAddress = recipientAddress,
        senderName = senderName,
        senderPhone = senderPhone,
        senderAddress = senderAddress,
        shippingFee = shippingFee,
        paymentType = paymentType,
        weightKg = weightKg,
        printDate = printDate,
        orderNo = orderNo,
        expNote = expNote,
        notes = notes,
        footerCompany = footerCompany,
        maskPhone = maskPhone,
        itemName = itemName,
        itemQty = itemQty,
        expDate = expDate,
        selectedFormat = try {
            PrintFormatMode.valueOf(selectedFormat)
        } catch (_: Exception) {
            PrintFormatMode.MAIN_LABEL
        },
        createdAt = createdAt
    )

    companion object {
        fun fromReceiptData(data: ReceiptData): ReceiptEntity = ReceiptEntity(
            id = data.id,
            resiCode = data.resiCode,
            routingCode = data.routingCode,
            badge1 = data.badge1,
            badge2 = data.badge2,
            dropPoint = data.dropPoint,
            recipientName = data.recipientName,
            recipientPhone = data.recipientPhone,
            recipientAddress = data.recipientAddress,
            senderName = data.senderName,
            senderPhone = data.senderPhone,
            senderAddress = data.senderAddress,
            shippingFee = data.shippingFee,
            paymentType = data.paymentType,
            weightKg = data.weightKg,
            printDate = data.printDate,
            orderNo = data.orderNo,
            expNote = data.expNote,
            notes = data.notes,
            footerCompany = data.footerCompany,
            maskPhone = data.maskPhone,
            itemName = data.itemName,
            itemQty = data.itemQty,
            expDate = data.expDate,
            selectedFormat = data.selectedFormat.name,
            createdAt = data.createdAt
        )
    }
}
