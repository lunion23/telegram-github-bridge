package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.example.ui.screens.FormEditScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.PdfPreviewScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.ReportViewModel
import com.example.viewmodel.ScreenDestination

class MainActivity : ComponentActivity() {

    private val reportViewModel: ReportViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val context = LocalContext.current
                val toastMsg by reportViewModel.toastMessage.collectAsState()

                LaunchedEffect(toastMsg) {
                    toastMsg?.let { msg ->
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        reportViewModel.clearToast()
                    }
                }

                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .windowInsetsPadding(WindowInsets.safeDrawing),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation(viewModel = reportViewModel)
                }
            }
        }
    }
}

@Composable
fun AppNavigation(viewModel: ReportViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    when (currentScreen) {
        is ScreenDestination.History -> {
            HistoryScreen(viewModel = viewModel)
        }
        is ScreenDestination.EditForm -> {
            FormEditScreen(viewModel = viewModel)
        }
        is ScreenDestination.PdfPreview -> {
            PdfPreviewScreen(viewModel = viewModel)
        }
    }
}
