package com.example.ffmpeg

import java.io.File

/**
 * Antarmuka callback (listener) untuk mengirimkan pembaruan persentase
 * dan status eksekusi FFmpeg ke UI thread secara real-time.
 */
interface FFmpegProgressListener {
    /**
     * Dipanggil saat proses trimming FFmpeg dimulai.
     */
    fun onStart()

    /**
     * Pembaruan progres real-time yang diekstrak dari output FFmpeg.
     *
     * @param progressPercent Persentase progres (0 - 100)
     * @param currentTimeSeconds Posisi waktu pemrosesan saat ini dalam detik
     * @param totalTargetDurationSeconds Total durasi target potongan video dalam detik
     */
    fun onProgress(
        progressPercent: Int,
        currentTimeSeconds: Double,
        totalTargetDurationSeconds: Double
    )

    /**
     * Log mentah baris demi baris dari stdout / stderr FFmpeg.
     * Berguna untuk debugging dan inspeksi diagnostic.
     *
     * @param logLine Baris teks dari output stream FFmpeg
     */
    fun onLog(logLine: String)

    /**
     * Dipanggil saat proses trimming selesai dengan sukses.
     *
     * @param outputFile File video hasil potongan
     * @param totalTimeTakenMs Total waktu yang dibutuhkan dalam milidetik
     */
    fun onSuccess(outputFile: File, totalTimeTakenMs: Long)

    /**
     * Dipanggil jika terjadi error selama proses eksekusi.
     *
     * @param error Pengecualian / error yang tertangkap
     */
    fun onError(error: Throwable)
}
