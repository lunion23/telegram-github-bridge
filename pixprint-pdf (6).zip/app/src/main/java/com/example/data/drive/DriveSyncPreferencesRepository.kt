package com.example.data.drive

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.DriveSyncMode
import com.example.model.DriveSyncPreferences
import java.io.IOException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONObject

private val Context.driveSyncDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "drive_sync_preferences"
)

class DriveSyncPreferencesRepository(
    private val dataStore: DataStore<Preferences>
) {
    constructor(context: Context) : this(context.applicationContext.driveSyncDataStore)

    val preferencesFlow: Flow<DriveSyncPreferences> = dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { prefs ->
            prefs.toDriveSyncPreferences()
        }

    suspend fun getSnapshot(): DriveSyncPreferences = preferencesFlow.first()

    suspend fun setDriveConnected(connected: Boolean) {
        dataStore.edit { prefs ->
            prefs[KEY_IS_CONNECTED] = connected
        }
    }

    suspend fun setAutoSyncHistory(enabled: Boolean) {
        dataStore.edit { prefs ->
            prefs[KEY_AUTO_SYNC_HISTORY] = enabled
        }
    }

    suspend fun setAutoUploadPdf(enabled: Boolean) {
        dataStore.edit { prefs ->
            prefs[KEY_AUTO_UPLOAD_PDF] = enabled
        }
    }

    suspend fun setSyncMode(mode: DriveSyncMode) {
        dataStore.edit { prefs ->
            prefs[KEY_SYNC_MODE] = mode.name
        }
    }

    suspend fun setDriveFolderName(rawFolderName: String): String {
        val sanitized = DriveSyncPreferences.sanitizeDriveFolderName(rawFolderName)
        dataStore.edit { prefs ->
            val previous = prefs[KEY_DRIVE_FOLDER_NAME] ?: DriveSyncPreferences.DEFAULT_DRIVE_FOLDER_NAME
            prefs[KEY_DRIVE_FOLDER_NAME] = sanitized
            if (previous != sanitized) {
                prefs[KEY_CACHED_FOLDER_ID] = ""
                prefs[KEY_CACHED_SYNC_FILE_ID] = ""
            }
        }
        return sanitized
    }

    suspend fun recordDeletionTombstone(itemId: String, deletedAtMillis: Long = System.currentTimeMillis()) {
        if (itemId.isBlank()) return
        dataStore.edit { prefs ->
            val existing = decodeTombstones(prefs[KEY_TOMBSTONES_JSON]).toMutableMap()
            val prev = existing[itemId] ?: 0L
            existing[itemId] = maxOf(prev, deletedAtMillis)
            prefs[KEY_TOMBSTONES_JSON] = encodeTombstones(pruneTombstones(existing))
        }
    }

    suspend fun updateAfterSyncSuccess(
        folderId: String,
        syncFileId: String,
        mergedTombstones: Map<String, Long>,
        syncedAtMillis: Long,
        statusMessage: String
    ) {
        dataStore.edit { prefs ->
            prefs[KEY_IS_CONNECTED] = true
            prefs[KEY_CACHED_FOLDER_ID] = folderId
            prefs[KEY_CACHED_SYNC_FILE_ID] = syncFileId
            prefs[KEY_TOMBSTONES_JSON] = encodeTombstones(pruneTombstones(mergedTombstones))
            prefs[KEY_LAST_SYNC_TIME] = syncedAtMillis
            prefs[KEY_LAST_SYNC_MESSAGE] = statusMessage
            prefs[KEY_LAST_SYNC_SUCCESS] = true
        }
    }

    suspend fun updateAfterSyncFailure(errorMessage: String) {
        dataStore.edit { prefs ->
            prefs[KEY_LAST_SYNC_MESSAGE] = errorMessage
            prefs[KEY_LAST_SYNC_SUCCESS] = false
        }
    }

    suspend fun disconnectAndResetCloudSession(statusMessage: String) {
        dataStore.edit { prefs ->
            prefs[KEY_IS_CONNECTED] = false
            prefs[KEY_CACHED_FOLDER_ID] = ""
            prefs[KEY_CACHED_SYNC_FILE_ID] = ""
            prefs[KEY_LAST_SYNC_MESSAGE] = statusMessage
            prefs[KEY_LAST_SYNC_SUCCESS] = true
        }
    }

    private fun Preferences.toDriveSyncPreferences(): DriveSyncPreferences {
        return DriveSyncPreferences(
            isDriveConnected = this[KEY_IS_CONNECTED] ?: false,
            autoSyncHistory = this[KEY_AUTO_SYNC_HISTORY] ?: true,
            autoUploadPdf = this[KEY_AUTO_UPLOAD_PDF] ?: false,
            syncMode = DriveSyncMode.fromStoredName(this[KEY_SYNC_MODE]),
            driveFolderName = this[KEY_DRIVE_FOLDER_NAME] ?: DriveSyncPreferences.DEFAULT_DRIVE_FOLDER_NAME,
            cachedFolderId = this[KEY_CACHED_FOLDER_ID] ?: "",
            cachedSyncFileId = this[KEY_CACHED_SYNC_FILE_ID] ?: "",
            lastSyncTimeMillis = this[KEY_LAST_SYNC_TIME] ?: 0L,
            lastSyncMessage = this[KEY_LAST_SYNC_MESSAGE] ?: "",
            lastSyncSuccess = this[KEY_LAST_SYNC_SUCCESS] ?: true,
            deletedTombstones = decodeTombstones(this[KEY_TOMBSTONES_JSON])
        )
    }

    companion object {
        private const val MAX_TOMBSTONES = 500

        private val KEY_IS_CONNECTED = booleanPreferencesKey("is_drive_connected")
        private val KEY_AUTO_SYNC_HISTORY = booleanPreferencesKey("auto_sync_history")
        private val KEY_AUTO_UPLOAD_PDF = booleanPreferencesKey("auto_upload_pdf")
        private val KEY_SYNC_MODE = stringPreferencesKey("drive_sync_mode")
        private val KEY_DRIVE_FOLDER_NAME = stringPreferencesKey("drive_folder_name")
        private val KEY_CACHED_FOLDER_ID = stringPreferencesKey("cached_folder_id")
        private val KEY_CACHED_SYNC_FILE_ID = stringPreferencesKey("cached_sync_file_id")
        private val KEY_LAST_SYNC_TIME = longPreferencesKey("last_sync_time_millis")
        private val KEY_LAST_SYNC_MESSAGE = stringPreferencesKey("last_sync_message")
        private val KEY_LAST_SYNC_SUCCESS = booleanPreferencesKey("last_sync_success")
        private val KEY_TOMBSTONES_JSON = stringPreferencesKey("deleted_tombstones_json")

        internal fun pruneTombstones(source: Map<String, Long>): Map<String, Long> {
            if (source.size <= MAX_TOMBSTONES) return source
            return source.entries
                .sortedByDescending { it.value }
                .take(MAX_TOMBSTONES)
                .associate { it.key to it.value }
        }

        internal fun encodeTombstones(map: Map<String, Long>): String {
            val obj = JSONObject()
            for ((id, timestamp) in map) {
                if (id.isNotBlank() && timestamp > 0L) {
                    obj.put(id, timestamp)
                }
            }
            return obj.toString()
        }

        internal fun decodeTombstones(raw: String?): Map<String, Long> {
            if (raw.isNullOrBlank()) return emptyMap()
            return try {
                val obj = JSONObject(raw)
                val result = mutableMapOf<String, Long>()
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val ts = obj.optLong(key, 0L)
                    if (key.isNotBlank() && ts > 0L) {
                        result[key] = ts
                    }
                }
                result
            } catch (_: Exception) {
                emptyMap()
            }
        }
    }
}
