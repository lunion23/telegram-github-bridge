package com.example.viewmodel

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.R
import com.example.data.drive.DriveAuthManager
import com.example.data.drive.DriveAuthOutcome
import com.example.data.drive.DriveHistorySyncOrchestrator
import com.example.data.drive.DriveSyncPreferencesRepository
import com.example.data.drive.DriveUnauthorizedException
import com.example.data.drive.GoogleDriveRestClient
import com.example.data.drive.PlayServicesDriveAuthManager
import com.example.data.local.AppDatabase
import com.example.data.repository.LabelHistoryRepository
import com.example.model.DriveSyncMode
import com.example.model.DriveSyncPreferences
import com.example.model.HistoryActionType
import com.example.model.LabelHistoryItem
import com.example.model.PaperSizePreset
import com.example.model.PdfRenderSource
import com.example.model.PreviewDisplayMode
import com.example.model.ShippingLabelData
import com.example.model.resolvedPaperPreset
import com.example.model.toShippingLabelData
import com.example.pdf.ShippingLabelPdfGenerator
import com.example.pdf.ShippingLabelPdfGenerator.findActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface HistoryUiState {
    data object Loading : HistoryUiState
    data class Success(val items: List<LabelHistoryItem>) : HistoryUiState
    data class Error(val message: String) : HistoryUiState
}

private sealed interface PendingDriveAction {
    data object ConnectAndSync : PendingDriveAction
    data class SyncNow(val silentAutoSync: Boolean = false) : PendingDriveAction
    data object UploadAllPdfs : PendingDriveAction
    data class UploadSinglePdf(val item: LabelHistoryItem) : PendingDriveAction
}

data class ShippingLabelUiState(
    val labelData: ShippingLabelData = ShippingLabelData.defaultFromReferenceImage(),
    val paperPreset: PaperSizePreset = PaperSizePreset.THERMAL_100X200,
    val renderSource: PdfRenderSource = PdfRenderSource.VECTOR_RECONSTRUCTION,
    val previewDisplayMode: PreviewDisplayMode = PreviewDisplayMode.GENERATED_PDF,
    val previewBitmap: Bitmap? = null,
    val comparisonLabelBitmap: Bitmap? = null,
    val referenceBitmap: Bitmap? = null,
    val capturedDocumentBitmap: Bitmap? = null,
    val activeHistoryItem: LabelHistoryItem? = null,
    val isEditorOpen: Boolean = false,
    val isCameraOpen: Boolean = false,
    val isHistoryOpen: Boolean = false,
    val isDriveSyncOpen: Boolean = false,
    val isZoomDialogOpen: Boolean = false,
    val isGeneratingPdf: Boolean = false,
    val isSavingHistory: Boolean = false,
    val isSyncingDrive: Boolean = false,
    val pendingAuthIntentSender: IntentSender? = null,
    val snackbarMessage: String? = null
)

class ShippingLabelViewModel(
    private val repository: LabelHistoryRepository? = null,
    private val drivePrefsRepository: DriveSyncPreferencesRepository? = null,
    private val driveAuthManager: DriveAuthManager? = null,
    private val driveSyncOrchestrator: DriveHistorySyncOrchestrator? = null,
    private val referenceBitmapLoader: suspend () -> Bitmap? = { null }
) : ViewModel() {

    private val _uiState = MutableStateFlow(ShippingLabelUiState())
    val uiState: StateFlow<ShippingLabelUiState> = _uiState.asStateFlow()

    val historyState: StateFlow<HistoryUiState> =
        if (repository != null) {
            repository.observeHistory()
                .map<List<LabelHistoryItem>, HistoryUiState> { items ->
                    HistoryUiState.Success(items)
                }
                .catch { error ->
                    Log.w(TAG, "Error observing shipping label history", error)
                    emit(
                        HistoryUiState.Error(
                            error.localizedMessage ?: "Gagal memuat riwayat data"
                        )
                    )
                }
                .stateIn(
                    scope = viewModelScope,
                    started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                    initialValue = HistoryUiState.Loading
                )
        } else {
            MutableStateFlow<HistoryUiState>(HistoryUiState.Success(emptyList())).asStateFlow()
        }

    val drivePrefsState: StateFlow<DriveSyncPreferences> =
        if (drivePrefsRepository != null) {
            drivePrefsRepository.preferencesFlow
                .stateIn(
                    scope = viewModelScope,
                    started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                    initialValue = DriveSyncPreferences()
                )
        } else {
            MutableStateFlow(DriveSyncPreferences()).asStateFlow()
        }

    private var previewRenderJob: Job? = null
    private var pendingDriveAction: PendingDriveAction? = null

    init {
        viewModelScope.launch {
            val refBitmap = withContext(Dispatchers.IO) {
                runCatching { referenceBitmapLoader() }.getOrNull()
            }
            _uiState.update { it.copy(referenceBitmap = refBitmap) }
            refreshPreviewBitmap(debounceMs = 0L)
        }
    }

    fun updateLabelData(transform: (ShippingLabelData) -> ShippingLabelData) {
        _uiState.update { state ->
            state.copy(
                labelData = transform(state.labelData),
                renderSource = PdfRenderSource.VECTOR_RECONSTRUCTION
            )
        }
        refreshPreviewBitmap(debounceMs = 120L)
    }

    fun resetToSampleData(context: Context) {
        _uiState.update { state ->
            state.copy(
                labelData = ShippingLabelData.defaultFromReferenceImage(),
                activeHistoryItem = null,
                renderSource = PdfRenderSource.VECTOR_RECONSTRUCTION,
                snackbarMessage = context.getString(R.string.msg_data_reset)
            )
        }
        refreshPreviewBitmap(debounceMs = 0L)
    }

    fun selectPaperPreset(preset: PaperSizePreset) {
        _uiState.update { it.copy(paperPreset = preset) }
        refreshPreviewBitmap(debounceMs = 0L)
    }

    fun selectRenderSource(source: PdfRenderSource) {
        if (source == PdfRenderSource.CAPTURED_DOCUMENT && _uiState.value.capturedDocumentBitmap == null) {
            setCameraOpen(true)
            return
        }
        _uiState.update { it.copy(renderSource = source) }
        refreshPreviewBitmap(debounceMs = 0L)
    }

    fun selectPreviewDisplayMode(mode: PreviewDisplayMode) {
        _uiState.update { it.copy(previewDisplayMode = mode) }
    }

    fun setEditorOpen(open: Boolean) {
        _uiState.update { it.copy(isEditorOpen = open) }
        if (!open) {
            refreshPreviewBitmap(debounceMs = 0L)
        }
    }

    fun setCameraOpen(open: Boolean) {
        _uiState.update { it.copy(isCameraOpen = open) }
    }

    fun setHistoryOpen(open: Boolean) {
        _uiState.update { it.copy(isHistoryOpen = open) }
    }

    fun setDriveSyncOpen(open: Boolean) {
        _uiState.update { it.copy(isDriveSyncOpen = open) }
    }

    fun consumePendingAuthIntentSender() {
        _uiState.update { it.copy(pendingAuthIntentSender = null) }
    }

    fun onDocumentCaptured(context: Context, bitmap: Bitmap) {
        val aspect = bitmap.width.toFloat() / bitmap.height.toFloat().coerceAtLeast(1f)
        val recommendedPreset = if (aspect > 0.62f && _uiState.value.paperPreset == PaperSizePreset.THERMAL_100X200) {
            PaperSizePreset.A4_ACTUAL_SIZE
        } else {
            _uiState.value.paperPreset
        }

        _uiState.update { state ->
            state.copy(
                capturedDocumentBitmap = bitmap,
                renderSource = PdfRenderSource.CAPTURED_DOCUMENT,
                previewDisplayMode = PreviewDisplayMode.GENERATED_PDF,
                paperPreset = recommendedPreset,
                isCameraOpen = false,
                snackbarMessage = context.getString(R.string.msg_captured_applied)
            )
        }
        refreshPreviewBitmap(debounceMs = 0L)
    }

    fun onCameraError(context: Context, reason: String) {
        _uiState.update {
            it.copy(snackbarMessage = context.getString(R.string.msg_capture_failed, reason))
        }
    }

    fun setZoomDialogOpen(open: Boolean) {
        _uiState.update { it.copy(isZoomDialogOpen = open) }
    }

    fun clearSnackbarMessage() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    // --- Flexible Google Drive Sync Settings & Actions ---

    fun updateDriveSyncMode(mode: DriveSyncMode) {
        val prefsRepo = drivePrefsRepository ?: return
        viewModelScope.launch {
            prefsRepo.setSyncMode(mode)
        }
    }

    fun updateDriveAutoSync(enabled: Boolean) {
        val prefsRepo = drivePrefsRepository ?: return
        viewModelScope.launch {
            prefsRepo.setAutoSyncHistory(enabled)
        }
    }

    fun updateDriveAutoUploadPdf(enabled: Boolean) {
        val prefsRepo = drivePrefsRepository ?: return
        viewModelScope.launch {
            prefsRepo.setAutoUploadPdf(enabled)
        }
    }

    fun saveDriveFolderName(context: Context, rawFolderName: String) {
        val prefsRepo = drivePrefsRepository ?: return
        viewModelScope.launch {
            val sanitized = prefsRepo.setDriveFolderName(rawFolderName)
            _uiState.update {
                it.copy(
                    snackbarMessage = context.getString(R.string.msg_drive_folder_saved, sanitized)
                )
            }
        }
    }

    fun connectAndSyncGoogleDrive(context: Context) {
        if (_uiState.value.isSyncingDrive) return
        requestAuthorizationAndExecute(
            context = context.applicationContext,
            action = PendingDriveAction.ConnectAndSync,
            allowInteractiveResolution = true
        )
    }

    fun syncGoogleDriveNow(context: Context, silentAutoSync: Boolean = false) {
        if (_uiState.value.isSyncingDrive) return
        requestAuthorizationAndExecute(
            context = context.applicationContext,
            action = PendingDriveAction.SyncNow(silentAutoSync = silentAutoSync),
            allowInteractiveResolution = !silentAutoSync
        )
    }

    fun uploadAllPdfsToDrive(context: Context) {
        if (_uiState.value.isSyncingDrive) return
        requestAuthorizationAndExecute(
            context = context.applicationContext,
            action = PendingDriveAction.UploadAllPdfs,
            allowInteractiveResolution = true
        )
    }

    fun uploadSingleItemPdfToDrive(context: Context, item: LabelHistoryItem) {
        if (_uiState.value.isSyncingDrive) return
        requestAuthorizationAndExecute(
            context = context.applicationContext,
            action = PendingDriveAction.UploadSinglePdf(item),
            allowInteractiveResolution = true
        )
    }

    fun onDriveAuthorizationActivityResult(
        context: Context,
        resultCode: Int,
        data: Intent?
    ) {
        val authMgr = driveAuthManager ?: return
        val actionToResume = pendingDriveAction
        pendingDriveAction = null

        if (resultCode != Activity.RESULT_OK && data == null) {
            _uiState.update {
                it.copy(
                    isSyncingDrive = false,
                    snackbarMessage = context.getString(R.string.msg_drive_auth_cancelled)
                )
            }
            return
        }

        val tokenResult = authMgr.extractTokenFromActivityResult(context.applicationContext, data)
        tokenResult.fold(
            onSuccess = { accessToken ->
                viewModelScope.launch {
                    drivePrefsRepository?.setDriveConnected(true)
                    executeAuthorizedDriveAction(
                        appContext = context.applicationContext,
                        accessToken = accessToken,
                        action = actionToResume ?: PendingDriveAction.ConnectAndSync,
                        allowRetryOnUnauthorized = false
                    )
                }
            },
            onFailure = { error ->
                val message = if (resultCode == Activity.RESULT_CANCELED) {
                    context.getString(R.string.msg_drive_auth_cancelled)
                } else {
                    context.getString(
                        R.string.msg_drive_auth_failed,
                        error.localizedMessage ?: "Izin ditolak"
                    )
                }
                _uiState.update {
                    it.copy(
                        isSyncingDrive = false,
                        snackbarMessage = message
                    )
                }
            }
        )
    }

    fun disconnectGoogleDrive(context: Context) {
        val prefsRepo = drivePrefsRepository ?: return
        viewModelScope.launch {
            driveAuthManager?.revokeTokenBestEffort("")
            val disconnectedMsg = context.getString(R.string.msg_drive_disconnected)
            prefsRepo.disconnectAndResetCloudSession(disconnectedMsg)
            _uiState.update {
                it.copy(
                    isSyncingDrive = false,
                    pendingAuthIntentSender = null,
                    snackbarMessage = disconnectedMsg
                )
            }
        }
    }

    private fun requestAuthorizationAndExecute(
        context: Context,
        action: PendingDriveAction,
        allowInteractiveResolution: Boolean
    ) {
        val authMgr = driveAuthManager ?: return
        if (driveSyncOrchestrator == null) return

        _uiState.update { it.copy(isSyncingDrive = true) }
        viewModelScope.launch {
            when (val outcome = authMgr.authorizeDriveScope(context)) {
                is DriveAuthOutcome.Granted -> {
                    drivePrefsRepository?.setDriveConnected(true)
                    executeAuthorizedDriveAction(
                        appContext = context,
                        accessToken = outcome.accessToken,
                        action = action,
                        allowRetryOnUnauthorized = allowInteractiveResolution
                    )
                }

                is DriveAuthOutcome.NeedsResolution -> {
                    if (allowInteractiveResolution) {
                        pendingDriveAction = action
                        _uiState.update {
                            it.copy(
                                isSyncingDrive = false,
                                pendingAuthIntentSender = outcome.intentSender
                            )
                        }
                    } else {
                        _uiState.update { it.copy(isSyncingDrive = false) }
                    }
                }

                is DriveAuthOutcome.Failed -> {
                    drivePrefsRepository?.updateAfterSyncFailure(outcome.message)
                    _uiState.update { state ->
                        state.copy(
                            isSyncingDrive = false,
                            snackbarMessage = if (allowInteractiveResolution) {
                                context.getString(R.string.msg_drive_auth_failed, outcome.message)
                            } else {
                                state.snackbarMessage
                            }
                        )
                    }
                }
            }
        }
    }

    private suspend fun executeAuthorizedDriveAction(
        appContext: Context,
        accessToken: String,
        action: PendingDriveAction,
        allowRetryOnUnauthorized: Boolean
    ) {
        val orchestrator = driveSyncOrchestrator ?: run {
            _uiState.update { it.copy(isSyncingDrive = false) }
            return
        }

        _uiState.update { it.copy(isSyncingDrive = true) }
        try {
            when (action) {
                is PendingDriveAction.ConnectAndSync -> {
                    val summary = orchestrator.performSync(accessToken = accessToken)
                    _uiState.update {
                        it.copy(
                            isSyncingDrive = false,
                            snackbarMessage = appContext.getString(
                                R.string.msg_drive_sync_success,
                                summary.uploadedItemCount,
                                summary.restoredItemCount,
                                summary.uploadedPdfCount
                            )
                        )
                    }
                }

                is PendingDriveAction.SyncNow -> {
                    val summary = orchestrator.performSync(accessToken = accessToken)
                    _uiState.update { state ->
                        state.copy(
                            isSyncingDrive = false,
                            snackbarMessage = if (action.silentAutoSync) {
                                state.snackbarMessage
                            } else {
                                appContext.getString(
                                    R.string.msg_drive_sync_success,
                                    summary.uploadedItemCount,
                                    summary.restoredItemCount,
                                    summary.uploadedPdfCount
                                )
                            }
                        )
                    }
                }

                is PendingDriveAction.UploadAllPdfs -> {
                    val (count, folderName) = orchestrator.uploadAllHistoryPdfs(accessToken = accessToken)
                    _uiState.update {
                        it.copy(
                            isSyncingDrive = false,
                            snackbarMessage = appContext.getString(
                                R.string.msg_drive_all_pdfs_uploaded,
                                count,
                                folderName
                            )
                        )
                    }
                }

                is PendingDriveAction.UploadSinglePdf -> {
                    val (updatedItem, folderName) = orchestrator.uploadSingleItemPdf(
                        accessToken = accessToken,
                        item = action.item
                    )
                    _uiState.update { state ->
                        val updatedActive = if (state.activeHistoryItem?.id == updatedItem.id) {
                            updatedItem
                        } else {
                            state.activeHistoryItem
                        }
                        state.copy(
                            isSyncingDrive = false,
                            activeHistoryItem = updatedActive,
                            snackbarMessage = appContext.getString(
                                R.string.msg_drive_pdf_uploaded,
                                updatedItem.waybillNumber,
                                folderName
                            )
                        )
                    }
                }
            }
        } catch (unauthorized: DriveUnauthorizedException) {
            driveAuthManager?.clearCachedToken(appContext, accessToken)
            if (allowRetryOnUnauthorized) {
                requestAuthorizationAndExecute(
                    context = appContext,
                    action = action,
                    allowInteractiveResolution = true
                )
            } else {
                val errMsg = unauthorized.localizedMessage ?: "Sesi berakhir"
                drivePrefsRepository?.updateAfterSyncFailure(errMsg)
                _uiState.update { it.copy(isSyncingDrive = false) }
            }
        } catch (error: Exception) {
            Log.w(TAG, "Google Drive sync action failed", error)
            val errMsg = error.localizedMessage ?: "Kesalahan jaringan"
            drivePrefsRepository?.updateAfterSyncFailure(errMsg)
            val isSilent = (action as? PendingDriveAction.SyncNow)?.silentAutoSync == true
            _uiState.update { state ->
                state.copy(
                    isSyncingDrive = false,
                    snackbarMessage = if (isSilent) {
                        state.snackbarMessage
                    } else {
                        appContext.getString(R.string.msg_drive_sync_error, errMsg)
                    }
                )
            }
        }
    }

    private fun triggerAutoDriveSyncIfEnabled(context: Context) {
        val prefsRepo = drivePrefsRepository ?: return
        val appContext = context.applicationContext
        viewModelScope.launch {
            val prefs = prefsRepo.getSnapshot()
            if (prefs.isDriveConnected && prefs.autoSyncHistory && !_uiState.value.isSyncingDrive) {
                syncGoogleDriveNow(appContext, silentAutoSync = true)
            }
        }
    }

    // --- Local History Persistence (Offline-First) ---

    fun saveCurrentToHistory(context: Context, forceNew: Boolean = false) {
        val repo = repository ?: return
        if (_uiState.value.isSavingHistory) return

        val snapshot = _uiState.value
        val existingTarget = if (!forceNew) snapshot.activeHistoryItem else null

        _uiState.update { it.copy(isSavingHistory = true) }
        viewModelScope.launch {
            val result = runCatching {
                if (existingTarget != null) {
                    val updated = repo.updateHistoryEntry(
                        existingItem = existingTarget,
                        updatedData = snapshot.labelData,
                        paperPreset = snapshot.paperPreset,
                        actionLabel = HistoryActionType.SAVED
                    )
                    updated to false
                } else {
                    val created = repo.saveHistoryEntry(
                        data = snapshot.labelData,
                        paperPreset = snapshot.paperPreset,
                        actionLabel = HistoryActionType.SAVED
                    )
                    created to true
                }
            }

            _uiState.update { state ->
                val savedItem = result.getOrNull()?.first ?: state.activeHistoryItem
                state.copy(
                    isSavingHistory = false,
                    activeHistoryItem = savedItem,
                    snackbarMessage = result.fold(
                        onSuccess = { (_, createdNew) ->
                            if (createdNew) {
                                context.getString(R.string.msg_history_saved)
                            } else {
                                context.getString(R.string.msg_history_updated)
                            }
                        },
                        onFailure = { err ->
                            context.getString(
                                R.string.msg_history_error,
                                err.localizedMessage ?: "Error"
                            )
                        }
                    )
                )
            }

            if (result.isSuccess) {
                triggerAutoDriveSyncIfEnabled(context)
            }
        }
    }

    fun loadHistoryItem(context: Context, item: LabelHistoryItem, openEditorAfter: Boolean = false) {
        val loadedData = item.toShippingLabelData()
        val loadedPreset = item.resolvedPaperPreset()
        _uiState.update { state ->
            state.copy(
                labelData = loadedData,
                paperPreset = loadedPreset,
                renderSource = PdfRenderSource.VECTOR_RECONSTRUCTION,
                previewDisplayMode = PreviewDisplayMode.GENERATED_PDF,
                activeHistoryItem = item,
                isHistoryOpen = false,
                isEditorOpen = openEditorAfter,
                snackbarMessage = context.getString(R.string.msg_history_loaded, item.waybillNumber)
            )
        }
        refreshPreviewBitmap(debounceMs = 0L)
    }

    fun deleteHistoryItem(context: Context, item: LabelHistoryItem) {
        val repo = repository ?: return
        if (item.id.isBlank()) return
        viewModelScope.launch {
            val result = runCatching {
                repo.deleteHistoryEntry(item.id)
                drivePrefsRepository?.recordDeletionTombstone(item.id)
            }
            _uiState.update { state ->
                val clearedActive = if (state.activeHistoryItem?.id == item.id) null else state.activeHistoryItem
                state.copy(
                    activeHistoryItem = clearedActive,
                    snackbarMessage = result.fold(
                        onSuccess = { context.getString(R.string.msg_history_deleted) },
                        onFailure = { err ->
                            context.getString(
                                R.string.msg_history_error,
                                err.localizedMessage ?: "Error"
                            )
                        }
                    )
                )
            }
            if (result.isSuccess) {
                triggerAutoDriveSyncIfEnabled(context)
            }
        }
    }

    private fun recordAutoHistorySilently(context: Context, actionType: String) {
        val repo = repository ?: return
        val snapshot = _uiState.value
        if (snapshot.renderSource == PdfRenderSource.CAPTURED_DOCUMENT) return

        viewModelScope.launch {
            val saveResult = runCatching {
                val latestMatch = (historyState.value as? HistoryUiState.Success)
                    ?.items
                    ?.firstOrNull { existing ->
                        existing.waybillNumber == snapshot.labelData.waybillNumber.trim() &&
                            existing.recipientName == snapshot.labelData.recipientName.trim() &&
                            existing.recipientAddress == snapshot.labelData.recipientAddress.trim() &&
                            existing.senderName == snapshot.labelData.senderName.trim() &&
                            existing.shippingFeeAmount == snapshot.labelData.shippingFeeAmount.trim() &&
                            existing.notes == snapshot.labelData.notes.trim() &&
                            existing.paperPreset == snapshot.paperPreset.name
                    }

                if (latestMatch != null) {
                    repo.updateHistoryEntry(
                        existingItem = latestMatch,
                        updatedData = snapshot.labelData,
                        paperPreset = snapshot.paperPreset,
                        actionLabel = actionType
                    )
                } else {
                    repo.saveHistoryEntry(
                        data = snapshot.labelData,
                        paperPreset = snapshot.paperPreset,
                        actionLabel = actionType
                    )
                }
            }.onFailure { err ->
                Log.w(TAG, "Auto-save history failed", err)
            }

            if (saveResult.isSuccess) {
                triggerAutoDriveSyncIfEnabled(context)
            }
        }
    }

    private fun refreshPreviewBitmap(debounceMs: Long) {
        previewRenderJob?.cancel()
        previewRenderJob = viewModelScope.launch {
            if (debounceMs > 0L) {
                delay(debounceMs)
            }
            val snapshot = _uiState.value
            val (pageBitmap, label1to2Bitmap) = withContext(Dispatchers.Default) {
                ensureActive()
                val pageBmp = ShippingLabelPdfGenerator.renderPreviewBitmap(
                    data = snapshot.labelData,
                    paperPreset = snapshot.paperPreset,
                    renderSource = snapshot.renderSource,
                    referenceBitmap = snapshot.referenceBitmap,
                    capturedBitmap = snapshot.capturedDocumentBitmap,
                    targetWidthPx = 944
                )
                ensureActive()
                val compareBmp = if (
                    snapshot.paperPreset == PaperSizePreset.THERMAL_100X200 &&
                    snapshot.renderSource == PdfRenderSource.VECTOR_RECONSTRUCTION
                ) {
                    pageBmp
                } else {
                    ShippingLabelPdfGenerator.renderPreviewBitmap(
                        data = snapshot.labelData,
                        paperPreset = PaperSizePreset.THERMAL_100X200,
                        renderSource = PdfRenderSource.VECTOR_RECONSTRUCTION,
                        referenceBitmap = snapshot.referenceBitmap,
                        capturedBitmap = snapshot.capturedDocumentBitmap,
                        targetWidthPx = 629
                    )
                }
                pageBmp to compareBmp
            }
            _uiState.update {
                it.copy(
                    previewBitmap = pageBitmap,
                    comparisonLabelBitmap = label1to2Bitmap
                )
            }
        }
    }

    fun printPdf(activityContext: Context) {
        val state = _uiState.value
        try {
            val sanitizedWaybill = state.labelData.waybillNumber
                .replace(Regex("[^A-Za-z0-9_-]"), "_")
                .take(48)
                .ifBlank { "Resi" }
            val jobName = if (state.renderSource == PdfRenderSource.CAPTURED_DOCUMENT) {
                "Dokumen_Scan"
            } else {
                activityContext.getString(R.string.print_job_name, sanitizedWaybill)
            }
            ShippingLabelPdfGenerator.launchSystemPrint(
                context = activityContext,
                jobName = jobName,
                data = state.labelData,
                paperPreset = state.paperPreset,
                renderSource = state.renderSource,
                referenceBitmap = state.referenceBitmap,
                capturedBitmap = state.capturedDocumentBitmap
            )
            recordAutoHistorySilently(activityContext, HistoryActionType.PRINTED)
        } catch (e: Exception) {
            _uiState.update {
                it.copy(
                    snackbarMessage = activityContext.getString(
                        R.string.msg_print_error,
                        e.localizedMessage ?: "Error"
                    )
                )
            }
        }
    }

    fun savePdfToUri(context: Context, destinationUri: Uri, displayFileName: String) {
        val state = _uiState.value
        _uiState.update { it.copy(isGeneratingPdf = true) }
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val out = context.contentResolver.openOutputStream(destinationUri)
                        ?: throw IllegalStateException("OutputStream null")
                    out.use { stream ->
                        ShippingLabelPdfGenerator.writePdfToStream(
                            outputStream = stream,
                            data = state.labelData,
                            paperPreset = state.paperPreset,
                            renderSource = state.renderSource,
                            referenceBitmap = state.referenceBitmap,
                            capturedBitmap = state.capturedDocumentBitmap
                        )
                    }
                }
            }
            if (result.isSuccess) {
                recordAutoHistorySilently(context, HistoryActionType.DOWNLOADED)
            }
            _uiState.update { current ->
                current.copy(
                    isGeneratingPdf = false,
                    snackbarMessage = result.fold(
                        onSuccess = {
                            context.getString(R.string.msg_pdf_saved_success, displayFileName)
                        },
                        onFailure = { err ->
                            context.getString(
                                R.string.msg_pdf_save_error,
                                err.localizedMessage ?: "Error"
                            )
                        }
                    )
                )
            }
        }
    }

    fun sharePdf(activityContext: Context) {
        val state = _uiState.value
        _uiState.update { it.copy(isGeneratingPdf = true) }
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    ShippingLabelPdfGenerator.generateCachePdfFile(
                        context = activityContext,
                        data = state.labelData,
                        paperPreset = state.paperPreset,
                        renderSource = state.renderSource,
                        referenceBitmap = state.referenceBitmap,
                        capturedBitmap = state.capturedDocumentBitmap
                    )
                }
            }
            _uiState.update { it.copy(isGeneratingPdf = false) }
            result.onSuccess { pdfFile ->
                try {
                    val authority = "${activityContext.packageName}.fileprovider"
                    val contentUri = FileProvider.getUriForFile(activityContext, authority, pdfFile)
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/pdf"
                        putExtra(Intent.EXTRA_STREAM, contentUri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    val chooser = Intent.createChooser(
                        shareIntent,
                        activityContext.getString(R.string.share_chooser_title)
                    )
                    val activity = activityContext.findActivity()
                    if (activity != null) {
                        activity.startActivity(chooser)
                    } else {
                        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        activityContext.startActivity(chooser)
                    }
                    recordAutoHistorySilently(activityContext, HistoryActionType.SHARED)
                } catch (e: Exception) {
                    _uiState.update {
                        it.copy(
                            snackbarMessage = activityContext.getString(
                                R.string.msg_share_error,
                                e.localizedMessage ?: "Error"
                            )
                        )
                    }
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        snackbarMessage = activityContext.getString(
                            R.string.msg_share_error,
                            err.localizedMessage ?: "Error"
                        )
                    )
                }
            }
        }
    }

    companion object {
        private const val TAG = "ShippingLabelVM"
        private const val STOP_TIMEOUT_MILLIS = 5000L

        fun factory(): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val db = AppDatabase.getInstance(app)
                val historyRepo = LabelHistoryRepository(db.labelHistoryDao())
                val drivePrefsRepo = DriveSyncPreferencesRepository(app)
                val authManager = PlayServicesDriveAuthManager()
                val orchestrator = DriveHistorySyncOrchestrator(
                    historyRepository = historyRepo,
                    prefsRepository = drivePrefsRepo,
                    remoteDataSource = GoogleDriveRestClient()
                )
                ShippingLabelViewModel(
                    repository = historyRepo,
                    drivePrefsRepository = drivePrefsRepo,
                    driveAuthManager = authManager,
                    driveSyncOrchestrator = orchestrator,
                    referenceBitmapLoader = { ShippingLabelPdfGenerator.loadReferenceBitmap(app) }
                )
            }
        }

        fun previewOrTestFactory(): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[APPLICATION_KEY]
                ShippingLabelViewModel(
                    repository = null,
                    drivePrefsRepository = null,
                    driveAuthManager = null,
                    driveSyncOrchestrator = null,
                    referenceBitmapLoader = {
                        if (app != null) ShippingLabelPdfGenerator.loadReferenceBitmap(app) else null
                    }
                )
            }
        }
    }
}
