package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.TechnicalReport
import kotlinx.coroutines.flow.Flow

@Dao
interface ReportDao {
    @Query("SELECT * FROM technical_reports ORDER BY updatedAt DESC")
    fun getAllReports(): Flow<List<TechnicalReport>>

    @Query("SELECT COUNT(*) FROM technical_reports")
    suspend fun getReportCount(): Int

    @Query("SELECT * FROM technical_reports WHERE id = :id LIMIT 1")
    suspend fun getReportById(id: Long): TechnicalReport?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: TechnicalReport): Long

    @Update
    suspend fun updateReport(report: TechnicalReport)

    @Delete
    suspend fun deleteReport(report: TechnicalReport)

    @Query("DELETE FROM technical_reports WHERE id = :id")
    suspend fun deleteReportById(id: Long)
}
