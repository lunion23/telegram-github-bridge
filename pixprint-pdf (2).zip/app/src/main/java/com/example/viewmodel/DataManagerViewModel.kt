package com.example.viewmodel

import android.graphics.Bitmap
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.GeneratedPdfFileItem
import com.example.data.SavedLabelRecord
import com.example.data.ShippingLabelRepository
import com.example.model.PaperSizePreset
import com.example.model.PdfRenderSource
import com.example.model.ShippingLabelData
import com.example.pdf.LocalPdfArchiveManager
import java.io.File
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface SavedLabelsStreamState {
    data object Loading : SavedLabelsStreamState
    data class Success(val records: List<SavedLabelRecord>) : SavedLabelsStreamState
    data class Error(val message: String) : SavedLabelsStreamState
}

enum class DataManagerTab {
    SAVED_LABELS,
    GENERATED_PDFS
}

data class DataManagerControlState(
    val isOpen: Boolean = false,
    val selectedTab: DataManagerTab = DataManagerTab.SAVED_LABELS,
    val searchQuery: String = "",
    val pinnedOnly: Boolean = false,
    val activeRecordId: String? = null,
    val isSavingOrWorking: Boolean = false,
    val pdfFiles: List<GeneratedPdfFileItem> = emptyList(),
    val feedbackEvent: DataManagerFeedback? = null
)

sealed interface DataManagerFeedback {
    data object RecordSaved : DataManagerFeedback
    data object RecordUpdated : DataManagerFeedback
    data object RecordDeleted : DataManagerFeedback
    data object RecordLoaded : DataManagerFeedback
    data class PdfArchived(val fileName: String) : DataManagerFeedback
    data object PdfDeleted : DataManagerFeedback
    data object AllPdfsCleared : DataManagerFeedback
    data class ErrorMessage(val message: String) : DataManagerFeedback
}

/**
 * Plain [ViewModel] managing persistent shipping label records in Firestore and
 * locally generated PDF documents on device.
 */
class DataManagerViewModel(
    private val repository: ShippingLabelRepository,
    private val pdfArchiveManager: LocalPdfArchiveManager,
    currentUserId: String
) : ViewModel() {

    val labelsStreamState: StateFlow<SavedLabelsStreamState> = repository.observeLabels(currentUserId)
        .map<List<SavedLabelRecord>, SavedLabelsStreamState> { SavedLabelsStreamState.Success(it) }
        .catch { error ->
            Log.w(TAG, "Error observing saved shipping labels", error)
            emit(
                SavedLabelsStreamState.Error(
                    error.localizedMessage ?: "Gagal memuat data resi dari server."
                )
            )
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = SavedLabelsStreamState.Loading
        )

    private val _controlState = MutableStateFlow(DataManagerControlState())
    val controlState: StateFlow<DataManagerControlState> = _controlState.asStateFlow()

    init {
        refreshPdfFiles()
    }

    fun setDataManagerOpen(open: Boolean) {
        _controlState.update { it.copy(isOpen = open) }
        if (open) {
            refreshPdfFiles()
        }
    }

    fun selectTab(tab: DataManagerTab) {
        _controlState.update { it.copy(selectedTab = tab) }
        if (tab == DataManagerTab.GENERATED_PDFS) {
            refreshPdfFiles()
        }
    }

    fun updateSearchQuery(query: String) {
        _controlState.update { it.copy(searchQuery = query) }
    }

    fun setPinnedOnly(pinnedOnly: Boolean) {
        _controlState.update { it.copy(pinnedOnly = pinnedOnly) }
    }

    fun setActiveRecordId(recordId: String?) {
        _controlState.update { it.copy(activeRecordId = recordId) }
    }

    fun consumeFeedbackEvent() {
        _controlState.update { it.copy(feedbackEvent = null) }
    }

    fun refreshPdfFiles() {
        viewModelScope.launch {
            val files = pdfArchiveManager.listGeneratedPdfs()
            _controlState.update { it.copy(pdfFiles = files) }
        }
    }

    fun saveAsNewRecord(
        data: ShippingLabelData,
        paperPreset: PaperSizePreset,
        customTitle: String = ""
    ) {
        _controlState.update { it.copy(isSavingOrWorking = true) }
        viewModelScope.launch {
            val result = repository.createLabel(
                data = data,
                paperPreset = paperPreset,
                customTitle = customTitle
            )
            _controlState.update { state ->
                result.fold(
                    onSuccess = { newId ->
                        state.copy(
                            isSavingOrWorking = false,
                            activeRecordId = newId,
                            feedbackEvent = DataManagerFeedback.RecordSaved
                        )
                    },
                    onFailure = { err ->
                        state.copy(
                            isSavingOrWorking = false,
                            feedbackEvent = DataManagerFeedback.ErrorMessage(
                                err.localizedMessage ?: "Gagal menyimpan data resi."
                            )
                        )
                    }
                )
            }
        }
    }

    fun updateRecordFromStudio(
        existingRecord: SavedLabelRecord,
        updatedData: ShippingLabelData,
        paperPreset: PaperSizePreset
    ) {
        _controlState.update { it.copy(isSavingOrWorking = true) }
        viewModelScope.launch {
            val merged = SavedLabelRecord.fromShippingLabelData(
                data = updatedData,
                paperPreset = paperPreset,
                customTitle = existingRecord.title,
                pinned = existingRecord.pinned,
                existingId = existingRecord.id,
                existingCreatedAt = existingRecord.createdAt
            )
            val result = repository.updateLabel(merged)
            _controlState.update { state ->
                result.fold(
                    onSuccess = {
                        state.copy(
                            isSavingOrWorking = false,
                            feedbackEvent = DataManagerFeedback.RecordUpdated
                        )
                    },
                    onFailure = { err ->
                        state.copy(
                            isSavingOrWorking = false,
                            feedbackEvent = DataManagerFeedback.ErrorMessage(
                                err.localizedMessage ?: "Gagal memperbarui data resi."
                            )
                        )
                    }
                )
            }
        }
    }

    fun renameRecord(record: SavedLabelRecord, newTitle: String) {
        val trimmed = newTitle.trim()
        if (trimmed.isEmpty()) return
        viewModelScope.launch {
            val result = repository.updateLabel(record.copy(title = trimmed))
            result.onFailure { err ->
                _controlState.update {
                    it.copy(
                        feedbackEvent = DataManagerFeedback.ErrorMessage(
                            err.localizedMessage ?: "Gagal mengubah judul resi."
                        )
                    )
                }
            }
        }
    }

    fun duplicateRecord(record: SavedLabelRecord) {
        _controlState.update { it.copy(isSavingOrWorking = true) }
        viewModelScope.launch {
            val copyTitle = "${record.title.take(105)} (Salinan)"
            val result = repository.createLabel(
                data = record.toShippingLabelData(),
                paperPreset = record.toPaperSizePreset(),
                customTitle = copyTitle,
                pinned = false
            )
            _controlState.update { state ->
                result.fold(
                    onSuccess = {
                        state.copy(
                            isSavingOrWorking = false,
                            feedbackEvent = DataManagerFeedback.RecordSaved
                        )
                    },
                    onFailure = { err ->
                        state.copy(
                            isSavingOrWorking = false,
                            feedbackEvent = DataManagerFeedback.ErrorMessage(
                                err.localizedMessage ?: "Gagal menduplikat resi."
                            )
                        )
                    }
                )
            }
        }
    }

    fun togglePin(record: SavedLabelRecord) {
        viewModelScope.launch {
            val result = repository.setLabelPinned(record.id, !record.pinned)
            result.onFailure { err ->
                _controlState.update {
                    it.copy(
                        feedbackEvent = DataManagerFeedback.ErrorMessage(
                            err.localizedMessage ?: "Gagal mengubah sematan resi."
                        )
                    )
                }
            }
        }
    }

    fun deleteRecord(recordId: String) {
        viewModelScope.launch {
            val result = repository.deleteLabel(recordId)
            _controlState.update { state ->
                result.fold(
                    onSuccess = {
                        state.copy(
                            activeRecordId = if (state.activeRecordId == recordId) null else state.activeRecordId,
                            feedbackEvent = DataManagerFeedback.RecordDeleted
                        )
                    },
                    onFailure = { err ->
                        state.copy(
                            feedbackEvent = DataManagerFeedback.ErrorMessage(
                                err.localizedMessage ?: "Gagal menghapus data resi."
                            )
                        )
                    }
                )
            }
        }
    }

    fun archivePdfSnapshot(
        data: ShippingLabelData,
        paperPreset: PaperSizePreset,
        renderSource: PdfRenderSource,
        referenceBitmap: Bitmap?,
        capturedBitmap: Bitmap? = null,
        onReadyFile: ((File) -> Unit)? = null
    ) {
        _controlState.update { it.copy(isSavingOrWorking = true) }
        viewModelScope.launch {
            runCatching {
                pdfArchiveManager.archiveLabelPdf(
                    data = data,
                    paperPreset = paperPreset,
                    renderSource = renderSource,
                    referenceBitmap = referenceBitmap,
                    capturedBitmap = capturedBitmap
                )
            }.onSuccess { createdFile ->
                val files = pdfArchiveManager.listGeneratedPdfs()
                _controlState.update {
                    it.copy(
                        isSavingOrWorking = false,
                        pdfFiles = files,
                        feedbackEvent = if (onReadyFile == null) {
                            DataManagerFeedback.PdfArchived(createdFile.name)
                        } else {
                            null
                        }
                    )
                }
                onReadyFile?.invoke(createdFile)
            }.onFailure { err ->
                _controlState.update {
                    it.copy(
                        isSavingOrWorking = false,
                        feedbackEvent = DataManagerFeedback.ErrorMessage(
                            err.localizedMessage ?: "Gagal membuat file PDF."
                        )
                    )
                }
            }
        }
    }

    fun deleteLocalPdfFile(file: File) {
        viewModelScope.launch {
            pdfArchiveManager.deletePdfFile(file)
            val files = pdfArchiveManager.listGeneratedPdfs()
            _controlState.update {
                it.copy(
                    pdfFiles = files,
                    feedbackEvent = DataManagerFeedback.PdfDeleted
                )
            }
        }
    }

    fun clearAllLocalPdfs() {
        viewModelScope.launch {
            pdfArchiveManager.clearAllPdfFiles()
            val files = pdfArchiveManager.listGeneratedPdfs()
            _controlState.update {
                it.copy(
                    pdfFiles = files,
                    feedbackEvent = DataManagerFeedback.AllPdfsCleared
                )
            }
        }
    }

    private companion object {
        const val TAG = "DataManagerVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
