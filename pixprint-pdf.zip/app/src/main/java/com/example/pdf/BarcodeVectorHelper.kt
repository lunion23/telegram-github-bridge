package com.example.pdf

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.oned.Code128Writer
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel

/**
 * Renders true vector 1D Code 128 barcodes and 2D QR Codes directly onto an Android [Canvas].
 * When backed by [android.graphics.pdf.PdfDocument], every bar and module is emitted as a
 * razor-sharp PDF vector rectangle with zero bitmap scaling blur.
 */
object BarcodeVectorHelper {

    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.FILL
        isAntiAlias = false
    }

    /**
     * Draws a crisp 1D Code 128 barcode filling [left]..[right] and [top]..[bottom].
     */
    fun drawCode128(
        canvas: Canvas,
        content: String,
        left: Float,
        top: Float,
        right: Float,
        bottom: Float
    ) {
        val safeContent = content.trim().ifEmpty { "JD0600216038" }
        val encoded: BooleanArray = try {
            Code128Writer().encode(safeContent)
        } catch (_: Exception) {
            Code128Writer().encode("JD0600216038")
        }

        val totalModules = encoded.size
        if (totalModules == 0) return

        val availableWidth = right - left
        val moduleWidth = availableWidth / totalModules.toFloat()

        var i = 0
        while (i < totalModules) {
            if (encoded[i]) {
                var runEnd = i + 1
                while (runEnd < totalModules && encoded[runEnd]) {
                    runEnd++
                }
                val barLeft = left + i * moduleWidth
                val barRight = left + runEnd * moduleWidth
                canvas.drawRect(barLeft, top, barRight, bottom, barPaint)
                i = runEnd
            } else {
                i++
            }
        }
    }

    /**
     * Draws a crisp 2D QR Code filling the square [left], [top] with side length [size].
     * Uses ErrorCorrectionLevel.L and MARGIN = 0 to match the exact 21x21 module density
     * of standard express logistics thermal labels.
     */
    fun drawQrCode(
        canvas: Canvas,
        content: String,
        left: Float,
        top: Float,
        size: Float
    ) {
        val safeContent = content.trim().ifEmpty { "JD0600216038" }
        val hints = mapOf(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.L,
            EncodeHintType.MARGIN to 0,
            EncodeHintType.CHARACTER_SET to "UTF-8"
        )

        val matrix = try {
            QRCodeWriter().encode(safeContent, BarcodeFormat.QR_CODE, 1, 1, hints)
        } catch (_: Exception) {
            QRCodeWriter().encode("JD0600216038", BarcodeFormat.QR_CODE, 1, 1, hints)
        }

        val matrixW = matrix.width
        val matrixH = matrix.height
        if (matrixW <= 0 || matrixH <= 0) return

        val cellW = size / matrixW.toFloat()
        val cellH = size / matrixH.toFloat()

        for (y in 0 until matrixH) {
            val rowTop = top + y * cellH
            val rowBottom = top + (y + 1) * cellH
            var x = 0
            while (x < matrixW) {
                if (matrix.get(x, y)) {
                    var runEnd = x + 1
                    while (runEnd < matrixW && matrix.get(runEnd, y)) {
                        runEnd++
                    }
                    // Slight 0.05f overlap prevents hairline subpixel gaps in some PDF viewers
                    val rectLeft = left + x * cellW
                    val rectRight = left + runEnd * cellW + 0.05f
                    canvas.drawRect(rectLeft, rowTop, rectRight, rowBottom + 0.05f, barPaint)
                    x = runEnd
                } else {
                    x++
                }
            }
        }
    }
}
