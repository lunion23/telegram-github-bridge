package com.example

import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleRobolectricTest {

  @Test
  fun testAppNameConstant() {
    val expectedName = "Social Video Downloader"
    assertEquals("Social Video Downloader", expectedName)
  }
}
