package com.example.data.repository

import com.example.data.analyzer.VideoAnalyzerEngine
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * GeminiVideoAiRepository
 *
 * Repositori ini mendefinisikan persona, instruksi sistem (system instructions),
 * dan template prompt terstruktur (structured prompts) untuk Google Gemini AI.
 *
 * Dirancang agar modular:
 * 1. Mendukung ekstraksi momen viral, trimming in/out timestamp, hook 3 detik,
 *    naskah deskripsi TikTok/Reels/Shorts, metrik audiens, dan SEO.
 * 2. Arsitektur terbuka (pluggable): memudahkan pergantian model AI (Gemini 3.8 Flash,
 *    Gemini 3.5 Flash-Lite, OpenAI, Claude, atau backend AI kustom).
 */
class GeminiVideoAiRepository {

    companion object {
        /**
         * System Instruction untuk memandu Gemini AI agar berpikir seperti
         * Head of Short-form Content & Algorithm Strategist kelas dunia.
         */
        const val SYSTEM_INSTRUCTION = """
Anda adalah "MomentSnap AI Specialist" - ahli strategi video viral, kurator momen konten pendek (short-form video editor), dan pakar algoritma media sosial (TikTok, Instagram Reels, YouTube Shorts).

Tugas Anda:
1. Menganalisis judul, transkrip, durasi, dan konteks video secara mendalam.
2. Menemukan momen-momen puncak (climax, plot twist, edukasi berbobot, atau kontroversi sehat) dengan stempel waktu pemotongan (in/out timestamp) yang presisi.
3. Menulis kalimat pembuka (opening hook) penahan scroll 3 detik pertama dengan berbagai teknik psikologi audiens (Curiosity Gap, FOMO, Problem-Solution).
4. Menyusun judul video ber-CTR tinggi yang memicu klik tanpa clickbait murahan.
5. Menghasilkan naskah deskripsi khusus yang disesuaikan dengan kultur masing-masing platform (TikTok santai & interaktif, Reels aesthetic & shareable, Shorts to-the-point & call-to-action).
6. Menghitung estimasi analitik keterlibatan audiens (retensi puncak, waktu posting prime time).
7. Menyusun strategi kata kunci SEO dan kumpulan tagar relevan.

PENTING:
Selalu berikan keluaran dalam format JSON valid tanpa kode markdown wrapper (tanpa ```json) agar dapat langsung diproses oleh sistem.
"""

        /**
         * Template Prompt Utama untuk Analisis Lengkap Video
         */
        fun buildVideoAnalysisPrompt(
            videoTitle: String,
            videoSource: String,
            durationSeconds: Int,
            transcriptOrNotes: String = ""
        ): String {
            return """
Lakukan analisis cerdas dan ekstraksi momen viral dari video berikut:
- Judul Video: "$videoTitle"
- Sumber/URL: "$videoSource"
- Total Durasi Video: $durationSeconds detik (format menit: ${VideoMoment.formatTime(durationSeconds)})
- Catatan Konteks / Transkrip Konten: "${transcriptOrNotes.ifBlank { "Topik umum kreator konten dan video digital" }}"

Hasilkan keluaran JSON terstruktur dengan format persis seperti spesifikasi di bawah ini:
{
  "summaryPoints": [
    "Poin ringkasan utama 1",
    "Poin ringkasan utama 2",
    "Poin ringkasan utama 3"
  ],
  "moments": [
    {
      "startSecond": 15,
      "endSecond": 45,
      "title": "Judul segmen momen menarik",
      "keyQuoteOrText": "Kutipan atau transkrip inti momen ini",
      "reasonWhyViral": "Penjelasan mengapa momen ini berpotensi viral tinggi",
      "viralScore": 95
    }
  ],
  "hooks": [
    {
      "hookText": "Kalimat pembuka 3 detik pertama...",
      "hookType": "Curiosity Gap",
      "deliveryTip": "Instruksi visual atau intonasi bicara saat membawakan hook"
    }
  ],
  "titleSuggestions": [
    {
      "titleText": "Ide judul atraktif ber-CTR tinggi",
      "category": "Curiosity & High CTR",
      "estimatedCtr": "11.5% CTR"
    }
  ],
  "socialCaptions": [
    {
      "platform": "TIKTOK",
      "captionText": "Naskah caption santai dan pemicu komentar untuk TikTok...",
      "callToAction": "Drop pendapat kalian di bawah! 👇",
      "hashtags": ["#fyp", "#videoviral", "#contentcreator"]
    },
    {
      "platform": "REELS",
      "captionText": "Naskah caption engaging dan aesthetic untuk Instagram Reels...",
      "callToAction": "Save postingan ini untuk dipelajari nanti! 📌",
      "hashtags": ["#reelsviral", "#creatorsid", "#tipsig"]
    },
    {
      "platform": "SHORTS",
      "captionText": "Naskah caption to-the-point untuk YouTube Shorts...",
      "callToAction": "Subscribe untuk tips menarik lainnya! 🔔",
      "hashtags": ["#shorts", "#youtubeshorts", "#viralshorts"]
    }
  ],
  "audienceMetrics": {
    "overallScore": 92,
    "viralProbability": "Sangat Tinggi (94%)",
    "bestPostingTime": "19:00 - 21:00 WIB",
    "targetAudience": "Kreator Konten & Audiens Muda",
    "retentionPeakTime": "Detik 15 - 45",
    "engagementFactors": [
      "Hook pembuka sangat kuat",
      "Penyampaian to-the-point tanpa jeda kosong",
      "Visual dan narasi memancing reaksi audiens"
    ]
  },
  "seoData": {
    "primaryKeywords": ["kata kunci 1", "kata kunci 2"],
    "longTailKeywords": ["frasa pencarian panjang 1", "frasa pencarian panjang 2"],
    "recommendedTags": ["#tagar1", "#tagar2", "#tagar3"],
    "searchOptimizedDescription": "Deskripsi teroptimasi algoritma pencarian Google dan YouTube."
  }
}
""".trimIndent()
        }

        /**
         * Template Prompt Khusus untuk Regenerasi Hooks
         */
        fun buildHooksPrompt(videoTitle: String, keyTopic: String): String {
            return """
Buatkan 4 variasi kalimat pembuka video (3-second hooks) untuk topik: "$videoTitle".
Kategori yang dibutuhkan:
1. Curiosity Gap (Memicu rasa penasaran tanpa akhir)
2. FOMO / Exclusivity (Rasa takut tertinggal informasi rahasia)
3. Problem - Solution (Menyoroti masalah nyata lalu menawarkan solusi instan)
4. Relatable Pain (Mengangkat keresahan sehari-hari yang dirasakan banyak orang)

Setiap hook harus menyertakan "deliveryTip" (tips gestur kamera/intonasi suara). Format JSON array:
[{"hookText": "...", "hookType": "...", "deliveryTip": "..."}]
""".trimIndent()
        }

        /**
         * Template Prompt Khusus untuk Regenerasi Judul Viral
         */
        fun buildTitlesPrompt(videoTitle: String, targetAudience: String): String {
            return """
Buatkan 5 variasi judul video YouTube & Media Sosial berkinerja tinggi (High Click-Through Rate) untuk:
Topik: "$videoTitle"
Target Audiens: "$targetAudience"

Sertakan kategori gaya judul dan estimasi CTR (misal: 10.5% CTR). Format JSON array:
[{"titleText": "...", "category": "...", "estimatedCtr": "..."}]
""".trimIndent()
        }

        /**
         * Template Prompt Khusus untuk Deskripsi & Tagar Media Sosial
         */
        fun buildSocialCaptionsPrompt(videoTitle: String, topMomentText: String): String {
            return """
Buatkan 3 paket caption media sosial untuk mempromosikan klip video:
- Judul: "$videoTitle"
- Cuplikan Momen Kunci: "$topMomentText"

Wajib sediakan untuk 3 platform:
1. TIKTOK (Format santai, memicu perdebatan di komentar, tagar FYP)
2. REELS (Format edukatif/inspiratif, mendorong Save & Share)
3. SHORTS (Format ringkas, CTA Subscribe, tagar Shorts)

Format JSON array:
[{"platform": "TIKTOK|REELS|SHORTS", "captionText": "...", "callToAction": "...", "hashtags": ["#tag1", "#tag2"]}]
""".trimIndent()
        }
    }

    /**
     * Memproses respon mentah JSON dari Gemini AI menjadi domain model VideoAnalysisResult.
     * Dilengkapi fallback parser yang aman dari kesalahan format.
     */
    fun parseGeminiResponse(
        jsonString: String,
        id: String = UUID.randomUUID().toString(),
        title: String,
        source: String,
        sourceType: VideoSourceType,
        durationSeconds: Int,
        thumbnailUrl: String
    ): VideoAnalysisResult {
        return runCatching {
            // Bersihkan markdown fence jika model AI menyertakannya secara tidak sengaja
            val cleanJson = jsonString
                .trim()
                .removePrefix("```json")
                .removePrefix("```")
                .removeSuffix("```")
                .trim()

            val root = JSONObject(cleanJson)

            // 1. Parse Summary Points
            val summaries = mutableListOf<String>()
            val summaryArr = root.optJSONArray("summaryPoints")
            if (summaryArr != null) {
                for (i in 0 until summaryArr.length()) {
                    summaries.add(summaryArr.getString(i))
                }
            }

            // 2. Parse Moments
            val moments = mutableListOf<VideoMoment>()
            val momentArr = root.optJSONArray("moments")
            if (momentArr != null) {
                for (i in 0 until momentArr.length()) {
                    val mObj = momentArr.getJSONObject(i)
                    moments.add(
                        VideoMoment(
                            id = UUID.randomUUID().toString(),
                            startSecond = mObj.optInt("startSecond", (i * 30).coerceAtMost(durationSeconds)),
                            endSecond = mObj.optInt("endSecond", ((i * 30) + 25).coerceAtMost(durationSeconds)),
                            title = mObj.optString("title", "Momen Menarik #${i + 1}"),
                            keyQuoteOrText = mObj.optString("keyQuoteOrText", ""),
                            reasonWhyViral = mObj.optString("reasonWhyViral", ""),
                            viralScore = mObj.optInt("viralScore", 85)
                        )
                    )
                }
            }

            // 3. Parse Hooks
            val hooks = mutableListOf<VideoHook>()
            val hookArr = root.optJSONArray("hooks")
            if (hookArr != null) {
                for (i in 0 until hookArr.length()) {
                    val hObj = hookArr.getJSONObject(i)
                    hooks.add(
                        VideoHook(
                            id = "hook_${i + 1}",
                            hookText = hObj.optString("hookText", ""),
                            hookType = hObj.optString("hookType", "Curiosity"),
                            deliveryTip = hObj.optString("deliveryTip", "")
                        )
                    )
                }
            }

            // 4. Parse Title Suggestions
            val titles = mutableListOf<TitleSuggestion>()
            val titleArr = root.optJSONArray("titleSuggestions")
            if (titleArr != null) {
                for (i in 0 until titleArr.length()) {
                    val tObj = titleArr.getJSONObject(i)
                    titles.add(
                        TitleSuggestion(
                            id = "title_${i + 1}",
                            titleText = tObj.optString("titleText", ""),
                            category = tObj.optString("category", "General"),
                            estimatedCtr = tObj.optString("estimatedCtr", "8.5% CTR")
                        )
                    )
                }
            }

            // 5. Parse Social Captions
            val captions = mutableListOf<SocialCaption>()
            val captionArr = root.optJSONArray("socialCaptions")
            if (captionArr != null) {
                for (i in 0 until captionArr.length()) {
                    val cObj = captionArr.getJSONObject(i)
                    val pStr = cObj.optString("platform", "TIKTOK")
                    val platform = runCatching { SocialPlatform.valueOf(pStr) }.getOrDefault(SocialPlatform.TIKTOK)
                    val tagsArr = cObj.optJSONArray("hashtags")
                    val tags = mutableListOf<String>()
                    if (tagsArr != null) {
                        for (j in 0 until tagsArr.length()) tags.add(tagsArr.getString(j))
                    }
                    captions.add(
                        SocialCaption(
                            platform = platform,
                            captionText = cObj.optString("captionText", ""),
                            callToAction = cObj.optString("callToAction", ""),
                            hashtags = tags
                        )
                    )
                }
            }

            // 6. Parse Audience Metrics
            val audObj = root.optJSONObject("audienceMetrics")
            val factorsArr = audObj?.optJSONArray("engagementFactors")
            val factors = mutableListOf<String>()
            if (factorsArr != null) {
                for (k in 0 until factorsArr.length()) factors.add(factorsArr.getString(k))
            }
            val audience = AudienceEngagementStats(
                overallScore = audObj?.optInt("overallScore", 90) ?: 90,
                viralProbability = audObj?.optString("viralProbability", "Tinggi (88%)") ?: "Tinggi",
                bestPostingTime = audObj?.optString("bestPostingTime", "19:00 - 21:00 WIB") ?: "19:00 WIB",
                targetAudience = audObj?.optString("targetAudience", "Kreator Konten") ?: "Umum",
                retentionPeakTime = audObj?.optString("retentionPeakTime", "Detik 15 - 45") ?: "00:15 - 00:45",
                engagementFactors = if (factors.isNotEmpty()) factors else listOf("Hook pembuka memikat", "Retensi visual tinggi")
            )

            // 7. Parse SEO Data
            val seoObj = root.optJSONObject("seoData")
            fun parseList(key: String): List<String> {
                val list = mutableListOf<String>()
                val arr = seoObj?.optJSONArray(key) ?: return list
                for (j in 0 until arr.length()) list.add(arr.getString(j))
                return list
            }
            val seo = SeoData(
                primaryKeywords = parseList("primaryKeywords").ifEmpty { listOf("video viral", "konten kreator") },
                longTailKeywords = parseList("longTailKeywords").ifEmpty { listOf("trik algoritma video pendek", "cara edit klip viral") },
                recommendedTags = parseList("recommendedTags").ifEmpty { listOf("#fyp", "#videoviral", "#contentcreator") },
                searchOptimizedDescription = seoObj?.optString("searchOptimizedDescription", "") ?: ""
            )

            VideoAnalysisResult(
                id = id,
                title = title,
                sourceUriOrUrl = source,
                sourceType = sourceType,
                durationSeconds = durationSeconds,
                thumbnailUrl = thumbnailUrl,
                summaryPoints = summaries.ifEmpty { listOf("Analisis video selesai dengan fokus pada retensi audiens tinggi.") },
                moments = moments.ifEmpty { VideoAnalyzerEngine.analyzeVideo(title, source, sourceType, durationSeconds).moments },
                hooks = hooks.ifEmpty { VideoAnalyzerEngine.analyzeVideo(title, source, sourceType, durationSeconds).hooks },
                titleSuggestions = titles.ifEmpty { VideoAnalyzerEngine.analyzeVideo(title, source, sourceType, durationSeconds).titleSuggestions },
                socialCaptions = captions.ifEmpty { VideoAnalyzerEngine.analyzeVideo(title, source, sourceType, durationSeconds).socialCaptions },
                audienceMetrics = audience,
                seoData = seo
            )
        }.getOrElse {
            // Jika parsing gagal, kembalikan analisa cerdas dari engine lokal bawaan
            VideoAnalyzerEngine.analyzeVideo(
                titleInput = title,
                source = source,
                sourceType = sourceType,
                customDurationSec = durationSeconds
            )
        }
    }

    /**
     * Mensimulasikan pemanggilan analisis dengan Gemini AI atau mengembalikan
     * hasil terstruktur siap pakai. Dapat disambungkan langsung ke Firebase.ai
     * atau backend AI lainnya.
     */
    suspend fun analyzeWithAi(
        title: String,
        source: String,
        sourceType: VideoSourceType,
        durationSeconds: Int,
        userNotes: String = "",
        externalAiResponseJson: String? = null
    ): VideoAnalysisResult = withContext(Dispatchers.Default) {
        val thumb = if (sourceType == VideoSourceType.YOUTUBE) {
            val yId = VideoAnalyzerEngine.extractYouTubeVideoId(source) ?: "dQw4w9WgXcQ"
            VideoAnalyzerEngine.getYouTubeThumbnailUrl(yId)
        } else {
            "https://picsum.photos/seed/${UUID.randomUUID().toString().take(6)}/640/360"
        }

        if (!externalAiResponseJson.isNullOrBlank()) {
            parseGeminiResponse(
                jsonString = externalAiResponseJson,
                title = title,
                source = source,
                sourceType = sourceType,
                durationSeconds = durationSeconds,
                thumbnailUrl = thumb
            )
        } else {
            // Gunakan engine pemrosesan konten lokal
            VideoAnalyzerEngine.analyzeVideo(
                titleInput = title,
                source = source,
                sourceType = sourceType,
                customDurationSec = durationSeconds,
                userNotes = userNotes
            )
        }
    }
}
