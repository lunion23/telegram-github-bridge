package com.example

import com.example.termux.TermuxManager
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit test untuk memverifikasi logika pembuatan perintah FFmpeg untuk Termux.
 */
class TermuxManagerTest {

    @Test
    fun generateTermuxCommand_streamCopy_generatesCorrectCommand() {
        val command = TermuxManager.generateTermuxCommand(
            inputPath = "/sdcard/Download/input.mp4",
            outputPath = "/sdcard/Download/output.mp4",
            startSeconds = 5.0,
            endSeconds = 15.0,
            useStreamCopy = true
        )

        assertTrue("Perintah harus memanggil ffmpeg", command.startsWith("ffmpeg"))
        assertTrue("Harus menyertakan -ss 5.000", command.contains("-ss 5.000"))
        assertTrue("Harus menyertakan -t 10.000 (durasi 15 - 5)", command.contains("-t 10.000"))
        assertTrue("Harus menggunakan -c copy", command.contains("-c copy"))
        assertTrue("Harus menyertakan input", command.contains("\"/sdcard/Download/input.mp4\""))
        assertTrue("Harus menyertakan output", command.contains("\"/sdcard/Download/output.mp4\""))
    }

    @Test
    fun generateTermuxCommand_reencode_generatesH264Flags() {
        val command = TermuxManager.generateTermuxCommand(
            inputPath = "/sdcard/input.mp4",
            outputPath = "/sdcard/output.mp4",
            startSeconds = 0.0,
            endSeconds = 3.5,
            useStreamCopy = false
        )

        assertTrue("Harus menyertakan libx264 saat stream copy dimatikan", command.contains("libx264"))
        assertTrue("Harus menyertakan aac", command.contains("aac"))
    }

    @Test
    fun generateFullTermuxScript_containsInstallGuide() {
        val script = TermuxManager.generateFullTermuxScript(
            inputPath = "/data/input.mp4",
            outputPath = "/data/output.mp4",
            startSeconds = 1.0,
            endSeconds = 5.0,
            useStreamCopy = true
        )

        assertTrue("Skrip harus menyertakan petunjuk instalasi ffmpeg", script.contains("pkg install ffmpeg"))
    }
}
