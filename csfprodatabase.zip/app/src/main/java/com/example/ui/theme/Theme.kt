package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = FleetDarkPrimary,
    onPrimary = Color(0xFF00354F),
    primaryContainer = Color(0xFF004D70),
    onPrimaryContainer = Color(0xFFBBE9FF),
    secondary = FleetDarkSecondary,
    onSecondary = Color(0xFF452B00),
    secondaryContainer = Color(0xFF633F00),
    onSecondaryContainer = Color(0xFFFFDDB3),
    tertiary = Color(0xFF6EE7B7),
    onTertiary = Color(0xFF003824),
    background = FleetDarkBackground,
    surface = FleetDarkSurface,
    surfaceVariant = FleetDarkSurfaceVariant,
    onBackground = Color(0xFFF1F5F9),
    onSurface = Color(0xFFF1F5F9),
    outline = Color(0xFF64748B)
)

private val LightColorScheme = lightColorScheme(
    primary = FleetPrimary,
    onPrimary = FleetOnPrimary,
    primaryContainer = FleetPrimaryContainer,
    onPrimaryContainer = FleetOnPrimaryContainer,
    secondary = FleetSecondary,
    onSecondary = FleetOnSecondary,
    secondaryContainer = FleetSecondaryContainer,
    onSecondaryContainer = FleetOnSecondaryContainer,
    tertiary = FleetTertiary,
    onTertiary = FleetOnTertiary,
    tertiaryContainer = FleetTertiaryContainer,
    onTertiaryContainer = FleetOnTertiaryContainer,
    background = FleetBackground,
    surface = FleetSurface,
    surfaceVariant = FleetSurfaceVariant,
    onBackground = Color(0xFF0F172A),
    onSurface = Color(0xFF0F172A),
    outline = FleetOutline,
    outlineVariant = FleetOutlineVariant
)

@Composable
fun FleetTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep branded corporate colors for consistency
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
