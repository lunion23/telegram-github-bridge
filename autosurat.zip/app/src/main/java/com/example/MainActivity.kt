package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.PdfPreviewScreen
import com.example.ui.screens.ReportEditScreen
import com.example.ui.screens.ReportListScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.ReportViewModel
import com.example.ui.viewmodel.ScreenState

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppNavHost()
            }
        }
    }
}

@Composable
fun MainAppNavHost(viewModel: ReportViewModel = viewModel()) {
    val screenState by viewModel.screenState.collectAsState()
    val reportsList by viewModel.reportsList.collectAsState()
    val currentReport by viewModel.currentReport.collectAsState()
    val currentParts by viewModel.currentParts.collectAsState()

    AnimatedContent(
        targetState = screenState,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "ScreenTransition",
        modifier = Modifier.fillMaxSize()
    ) { state ->
        when (state) {
            is ScreenState.List -> {
                ReportListScreen(
                    reports = reportsList,
                    onNewReport = { viewModel.startNewReport() },
                    onEditReport = { rep -> viewModel.editReport(rep) },
                    onPreviewReport = { rep -> viewModel.previewReport(rep) },
                    onDuplicateReport = { rep -> viewModel.duplicateReport(rep) },
                    onDeleteReport = { rep -> viewModel.deleteReport(rep) }
                )
            }
            is ScreenState.Edit -> {
                ReportEditScreen(
                    report = currentReport,
                    parts = currentParts,
                    onUpdateReport = { transform -> viewModel.updateCurrentReport(transform) },
                    onUpdatePart = { index, transform -> viewModel.updatePartItem(index, transform) },
                    onAddPhotos = { newUris -> viewModel.addPhotos(newUris) },
                    onRemovePhoto = { index -> viewModel.removePhoto(index) },
                    onClearAllPhotos = { viewModel.clearAllPhotos() },
                    onSaveDraft = {
                        viewModel.saveDraft {
                            viewModel.navigateToList()
                        }
                    },
                    onPreviewPdf = {
                        viewModel.saveDraft {
                            viewModel.previewReport(currentReport)
                        }
                    },
                    onBack = { viewModel.navigateToList() }
                )
            }
            is ScreenState.Preview -> {
                PdfPreviewScreen(
                    report = state.report,
                    onBack = { viewModel.navigateToList() },
                    onEdit = { viewModel.editReport(state.report) }
                )
            }
        }
    }
}
