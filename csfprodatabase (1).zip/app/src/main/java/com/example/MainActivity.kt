package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.net.Uri
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ImportMode
import com.example.ui.components.AdvancedFilterSheet
import com.example.ui.components.ColumnVisibilitySheet
import com.example.ui.components.DualSearchSheet
import com.example.ui.components.FilterChipsRow
import com.example.ui.components.ImportModeDialog
import com.example.ui.components.ImportOptionsSheet
import com.example.ui.components.ImportProgressDialog
import com.example.ui.components.KpiDashboardCards
import com.example.data.export.WorkOrderPdfGenerator
import com.example.ui.components.PdfPreviewDialog
import com.example.ui.components.PrintOptionDialog
import com.example.ui.components.TopFleetBar
import com.example.ui.components.WorkOrderCardItem
import com.example.ui.components.WorkOrderDetailSheet
import com.example.ui.components.WorkOrderTableView
import com.example.ui.theme.FleetTheme
import com.example.ui.viewmodel.ViewDisplayMode
import com.example.ui.viewmodel.WorkOrderViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: WorkOrderViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FleetTheme {
                WorkOrderApp(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkOrderApp(viewModel: WorkOrderViewModel) {
    val context = LocalContext.current

    val viewMode by viewModel.viewMode.collectAsStateWithLifecycle()
    val filterCriteria by viewModel.filterCriteria.collectAsStateWithLifecycle()
    val groupedOrders by viewModel.groupedOrders.collectAsStateWithLifecycle()
    val tableItems by viewModel.tableItems.collectAsStateWithLifecycle()
    val kpiStats by viewModel.kpiStats.collectAsStateWithLifecycle()
    val totalRowCount by viewModel.totalItemCount.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val selectedWorkOrder by viewModel.selectedWorkOrder.collectAsStateWithLifecycle()
    val selectedWoItems by viewModel.selectedWorkOrderItems.collectAsStateWithLifecycle()
    val columnVisibility by viewModel.columnVisibility.collectAsStateWithLifecycle()
    val showColumnSettings by viewModel.showColumnSettings.collectAsStateWithLifecycle()
    val showAdvancedFilter by viewModel.showAdvancedFilter.collectAsStateWithLifecycle()
    val showDualSearch by viewModel.showDualSearch.collectAsStateWithLifecycle()
    val importProgress by viewModel.importProgress.collectAsStateWithLifecycle()
    val printTargetSummary by viewModel.printTargetSummary.collectAsStateWithLifecycle()
    val isGeneratingPdf by viewModel.isGeneratingPdf.collectAsStateWithLifecycle()
    val previewBitmap by viewModel.previewBitmap.collectAsStateWithLifecycle()
    val previewPdfFile by viewModel.previewPdfFile.collectAsStateWithLifecycle()
    val previewDocTitle by viewModel.previewDocTitle.collectAsStateWithLifecycle()

    // State for pending file import to prompt for ImportMode (Update vs Append vs Replace All)
    var pendingImportUri by remember { mutableStateOf<Uri?>(null) }
    var pendingImportIsDb by remember { mutableStateOf(false) }
    var pendingImportFileName by remember { mutableStateOf("") }
    var pendingImportMode by remember { mutableStateOf(ImportMode.UPDATE_EXISTING) }

    // SAF File Picker for CSV / Excel files
    val openDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            val name = it.lastPathSegment?.substringAfterLast('/') ?: "Data_Work_Order.csv"
            pendingImportUri = it
            pendingImportIsDb = false
            pendingImportFileName = name
        }
    }

    // SAF File Picker for SQLite Database (.db) files
    val openDbLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            val name = it.lastPathSegment?.substringAfterLast('/') ?: "Database_Backup.db"
            pendingImportUri = it
            pendingImportIsDb = true
            pendingImportFileName = name
        }
    }

    // SAF File Creator for SQLite Database (.db) backup export
    val createDbLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/x-sqlite3")
    ) { uri ->
        uri?.let { viewModel.exportDatabaseToUri(context, it) }
    }

    // Modal sheet states
    var showImportOptionsSheet by remember { mutableStateOf(false) }
    val importSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val detailSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val columnSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val filterSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val dualSearchSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val cardsListState = rememberLazyListState()

    // Infinite scroll for Grouped Cards
    val shouldLoadMoreCards by remember {
        derivedStateOf {
            val totalItems = cardsListState.layoutInfo.totalItemsCount
            val lastVisibleIndex = cardsListState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            totalItems > 0 && lastVisibleIndex >= totalItems - 4
        }
    }

    LaunchedEffect(shouldLoadMoreCards) {
        if (shouldLoadMoreCards && !isLoading) {
            viewModel.loadMore()
        }
    }

    // Predictive Back Handling
    BackHandler(
        enabled = previewBitmap != null || printTargetSummary != null || showImportOptionsSheet || selectedWorkOrder != null || showColumnSettings || showAdvancedFilter || showDualSearch || filterCriteria.isActive
    ) {
        when {
            previewBitmap != null -> viewModel.closePreview()
            printTargetSummary != null -> viewModel.closePrintDialog()
            showImportOptionsSheet -> showImportOptionsSheet = false
            selectedWorkOrder != null -> viewModel.closeWorkOrderDetail()
            showColumnSettings -> viewModel.openColumnSettings(false)
            showAdvancedFilter -> viewModel.openAdvancedFilter(false)
            showDualSearch -> viewModel.openDualSearch(false)
            filterCriteria.isActive -> viewModel.clearAllFilters()
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars),
        topBar = {
            TopFleetBar(
                searchQuery = filterCriteria.searchQuery,
                onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                totalRowCount = totalRowCount,
                currentViewMode = viewMode,
                onToggleViewMode = {
                    viewModel.setViewMode(
                        if (viewMode == ViewDisplayMode.CARDS_GROUPED) ViewDisplayMode.TABLE_VIEW
                        else ViewDisplayMode.CARDS_GROUPED
                    )
                },
                onOpenImportMenu = { showImportOptionsSheet = true },
                onExportClick = {
                    viewModel.exportFilteredDataToCsv(context)
                },
                onOpenColumnSettings = { viewModel.openColumnSettings(true) },
                onOpenAdvancedFilter = { viewModel.openAdvancedFilter(true) },
                onOpenDualSearch = { viewModel.openDualSearch(true) },
                isDualSearchActive = filterCriteria.isDualSearchActive,
                hasActiveFilters = filterCriteria.isActive,
                onClearAllData = { viewModel.clearAllDatabaseRecords() },
                onImportDatabase = {
                    openDbLauncher.launch(
                        arrayOf("application/x-sqlite3", "application/vnd.sqlite3", "application/octet-stream", "*/*")
                    )
                },
                onExportDatabase = {
                    val timeStamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())
                    createDbLauncher.launch("datacsv_backup_$timeStamp.db")
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showImportOptionsSheet = true },
                icon = {
                    Icon(
                        imageVector = Icons.Default.FileUpload,
                        contentDescription = "Import Data CSV",
                        modifier = Modifier.size(20.dp)
                    )
                },
                text = {
                    Text(
                        text = "Import Data CSV",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("floating_import_csv_button")
            )
        }
    ) { innerPadding ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .windowInsetsPadding(WindowInsets.navigationBars),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Executive KPI Cards
                KpiDashboardCards(
                    stats = kpiStats,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 2.dp)
                )

                // Filter Chips Row
                FilterChipsRow(
                    filterCriteria = filterCriteria,
                    onToggleDateSort = { viewModel.toggleDateSort() },
                    onOpenDualSearch = { viewModel.openDualSearch(true) },
                    onClearDualSearch = { viewModel.clearDualKeywordSearch() },
                    onClearFilters = { viewModel.clearAllFilters() }
                )

                Spacer(modifier = Modifier.height(2.dp))

                // Content View based on current ViewMode
                Box(modifier = Modifier.weight(1f)) {
                    if (viewMode == ViewDisplayMode.CARDS_GROUPED) {
                        if (groupedOrders.isEmpty() && !isLoading) {
                            EmptyState(
                                onImportClick = {
                                    showImportOptionsSheet = true
                                },
                                onLoadBundledAsset = { viewModel.loadBundledCilegonAsset() },
                                onLoadSample = { viewModel.loadSampleDataset(1200) }
                            )
                        } else {
                            LazyColumn(
                                state = cardsListState,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .testTag("grouped_work_orders_list"),
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(
                                    items = groupedOrders,
                                    key = { "${it.name}_${it.trandateFormatted}_${it.trandateMillis}_${it.kmCurrent}" }
                                ) { summary ->
                                    WorkOrderCardItem(
                                        summary = summary,
                                        onClick = { viewModel.selectWorkOrderForDetail(summary) },
                                        onPrintClick = { viewModel.openPrintDialog(summary) }
                                    )
                                }

                                if (isLoading) {
                                    item {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(16.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                             CircularProgressIndicator(strokeWidth = 2.dp)
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        // Responsive Horizontal Table View
                        WorkOrderTableView(
                            items = tableItems,
                            visibilityState = columnVisibility,
                            isLoading = isLoading,
                            onLoadMore = { viewModel.loadMore() },
                            onRowClick = { woName -> viewModel.selectWorkOrderByName(woName) }
                        )
                    }
                }
            }
        }
    }

    // 1. Real-time Import Progress / Success Dialog
    ImportProgressDialog(
        progress = importProgress,
        onCancelImport = { viewModel.cancelImport() },
        onDismissSuccess = { viewModel.dismissImportSummary() }
    )

    // 2. Flexible Import Mode Dialog (Update vs Append vs Replace All)
    if (pendingImportUri != null) {
        ImportModeDialog(
            fileName = pendingImportFileName,
            isDatabaseFile = pendingImportIsDb,
            initialMode = pendingImportMode,
            onDismiss = { pendingImportUri = null },
            onConfirm = { mode ->
                val uri = pendingImportUri ?: return@ImportModeDialog
                pendingImportUri = null
                if (pendingImportIsDb) {
                    viewModel.importDatabaseFromUri(context, uri, mode = mode)
                } else {
                    viewModel.startImportFromUri(context, uri, mode = mode)
                }
            }
        )
    }

    // 3. Work Order Detail Modal BottomSheet
    if (selectedWorkOrder != null) {
        WorkOrderDetailSheet(
            summary = selectedWorkOrder,
            items = selectedWoItems,
            onDismiss = { viewModel.closeWorkOrderDetail() },
            onExportDetail = { viewModel.exportSelectedWorkOrder(context) },
            onPrintPdf = {
                selectedWorkOrder?.let { viewModel.openPrintDialog(it) }
            },
            sheetState = detailSheetState
        )
    }

    // 4. Modal Dialog Pilihan Cetak Dokumen PDF (Ringkas vs Full Detail)
    if (printTargetSummary != null) {
        PrintOptionDialog(
            woName = printTargetSummary!!.name,
            onDismiss = { viewModel.closePrintDialog() },
            onPreview = { option ->
                viewModel.generatePreview(context, option)
            },
            onConfirmPrint = { option ->
                viewModel.executePrint(context, option)
            }
        )
    }

    // 5. Modal Pratinjau (Preview) Halaman PDF Langsung di Layar Aplikasi
    if (previewBitmap != null && previewPdfFile != null) {
        PdfPreviewDialog(
            bitmap = previewBitmap!!,
            documentTitle = previewDocTitle,
            onDismiss = { viewModel.closePreview() },
            onPrintOrOpen = {
                val file = previewPdfFile ?: return@PdfPreviewDialog
                WorkOrderPdfGenerator.openOrSharePdf(
                    context = context,
                    file = file,
                    title = previewDocTitle
                )
            },
            onShare = {
                val file = previewPdfFile ?: return@PdfPreviewDialog
                WorkOrderPdfGenerator.openOrSharePdf(
                    context = context,
                    file = file,
                    title = previewDocTitle
                )
            }
        )
    }

    // 5. Indikator Loading Saat Membuat PDF
    if (isGeneratingPdf) {
        androidx.compose.ui.window.Dialog(onDismissRequest = {}) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                Row(
                    modifier = Modifier.padding(24.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
                    Spacer(modifier = Modifier.width(16.dp))
                    Text("Menyiapkan Dokumen PDF...", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }

    // 4. Column Visibility Settings BottomSheet
    if (showColumnSettings) {
        ColumnVisibilitySheet(
            visibilityState = columnVisibility,
            onToggleColumn = { viewModel.toggleColumnVisibility(it) },
            onDismiss = { viewModel.openColumnSettings(false) },
            sheetState = columnSheetState
        )
    }

    // 5. Advanced Filter BottomSheet
    if (showAdvancedFilter) {
        AdvancedFilterSheet(
            criteria = filterCriteria,
            onApply = { mobil, chassis, keluhan, start, end ->
                viewModel.applyAdvancedFilter(mobil, chassis, keluhan, start, end)
            },
            onClear = { viewModel.clearAllFilters() },
            onDismiss = { viewModel.openAdvancedFilter(false) },
            sheetState = filterSheetState
        )
    }

    // 6. Import Options BottomSheet (Accessible from top bar & empty state)
    if (showImportOptionsSheet) {
        ImportOptionsSheet(
            onDismiss = { showImportOptionsSheet = false },
            onPickFileSAF = { mode ->
                pendingImportMode = mode
                openDocumentLauncher.launch(
                    arrayOf("text/*", "application/vnd.ms-excel", "text/comma-separated-values", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "*/*")
                )
            },
            onPickDbFileSAF = { mode ->
                pendingImportMode = mode
                openDbLauncher.launch(
                    arrayOf("application/x-sqlite3", "application/vnd.sqlite3", "application/octet-stream", "*/*")
                )
            },
            onExportDbSAF = {
                val timeStamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())
                createDbLauncher.launch("datacsv_backup_$timeStamp.db")
            },
            onLoadBundledAsset = { mode -> viewModel.loadBundledCilegonAsset(mode) },
            onLoadSample = { count, mode -> viewModel.loadSampleDataset(count, mode) },
            onClearAllData = { viewModel.clearAllDatabaseRecords() },
            sheetState = importSheetState
        )
    }

    // 7. Dual Keyword Multi-Column Search BottomSheet
    if (showDualSearch) {
        DualSearchSheet(
            criteria = filterCriteria,
            onApply = { kw1, col1, kw2, col2 ->
                viewModel.applyDualKeywordSearch(kw1, col1, kw2, col2)
            },
            onClear = { viewModel.clearDualKeywordSearch() },
            onDismiss = { viewModel.openDualSearch(false) },
            sheetState = dualSearchSheetState
        )
    }
}

@Composable
private fun EmptyState(
    onImportClick: () -> Unit,
    onLoadBundledAsset: () -> Unit,
    onLoadSample: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(20.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Assignment,
                contentDescription = "Work Order Empty",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Belum Ada Data Work Order",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "Gunakan dataset resmi CILEGONCSV.csv, lakukan simulasi jutaan baris data, atau pilih file CSV / Excel (.xlsx) dari memori perangkat.",
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(20.dp))

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onLoadBundledAsset,
                modifier = Modifier.testTag("load_cilegon_asset_button")
            ) {
                Text("Muat CILEGONCSV.csv Resmi")
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = onLoadSample,
                    modifier = Modifier.testTag("load_sample_data_button")
                ) {
                    Text("Simulasi 1.200 Baris")
                }

                OutlinedButton(
                    onClick = onImportClick,
                    modifier = Modifier.testTag("import_empty_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.FileUpload,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Pilih CSV/XLSX")
                }
            }
        }
    }
}
