# Video Trimmer FFmpeg Engine

A standalone Android video trimming application powered by an embedded FFmpeg binary runner. The application features automated binary extraction from application assets, permission configuration (`chmod +x`), real-time `time=` progress parsing from `stderr` via Kotlin Coroutines, and an interactive Jetpack Compose UI with dual-thumb trim controls, video preview, and real-time progress monitoring.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following user preferences were confirmed during the clarification phase:

- **Confirmed Decision 1**: Interactive video player with dual-handle trim slider to select start and end points visually.
- **Confirmed Decision 2**: Fast stream copy mode (`-c copy`) without full re-encoding for high performance and lossless quality.
- **Confirmed Decision 3**: FFmpeg asset extraction with safe fallback demo simulation mode if the physical executable is absent or restricted by OS security policies.

---

### 1. Overview & Core Concept

- **What It Does**: Allows users to pick any video from their device or use a built-in sample, preview playback, select start and end trimming timestamps via interactive range controls, and execute an embedded FFmpeg binary process to produce a clean trimmed output video with live percentage progress tracking.
- **Target Audience / Persona**: Mobile content creators, video editors, and Android developers seeking a reference implementation for executing standalone command-line binaries on Android without Termux or external packages.
- **Key Value**: Pure on-device, private, zero-cloud video trimming with real-time process monitoring and robust process lifecycle management.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Initialization**: App launches, extracts the embedded FFmpeg binary from assets to `context.filesDir/ffmpeg`, makes it executable (`setExecutable(true)` / `chmod 755`), and verifies binary readiness.
  2. **Video Selection**: User picks a video file via the modern Android Photo Picker (`ActivityResultContracts.PickVisualMedia`) or selects a bundled/generated test clip.
  3. **Range Adjustment**: User scrubs the video, tests playback, and adjusts the start/end trim handles (with live timestamp formatted as `HH:MM:SS.mmm`).
  4. **Trim Execution**: User taps "Trim Video", background coroutine executes the command via `ProcessBuilder`, parses `time=HH:MM:SS.xx` output from standard error in real-time, calculates progress `(currentTime - startTime) / targetDuration * 100%`, and streams live updates.
  5. **Completion & Preview**: When complete, displays success status, elapsed time, output file size, and offers an instant preview of the trimmed video.

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Dark Studio / Cinematic Editing suite aesthetic (`#121316` dark surface with vibrant electric cyan `#00E5FF` and deep violet `#7C4DFF` accents).
  - *Color Palette & Tokens*:
    - Background: `#111216` (Deep Charcoal)
    - Surface / Card: `#1A1D24` (Elevated slate with subtle 1dp border `#2A2E39`)
    - Primary Accent: `#00E5FF` (Electric Cyan for active track and handles)
    - Secondary Accent: `#7C4DFF` (Deep Violet for primary execution button)
    - Success / Alert: `#00E676` (Neon Green for completion badge)
  - *Typography & Hierarchy*: Bold tabular numerical readouts for precise timecodes (`HH:MM:SS.mmm`), clean Medium headers, and legible status indicators.
  - *Interactive Feedback*: Smooth linear progress bar with glowing percentage indicator, pulse animation during trimming, and snackbar/dialog notifications.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Architecture & Execution Engine (`ProcessBuilder` with Coroutines)**
  - *Chosen Approach*: `Dispatchers.IO` background execution using Java `ProcessBuilder`, redirecting error stream (`redirectErrorStream(true)` or reading `errorStream` directly), parsing standard output lines via `bufferedReader().forEachLine {}`, and emitting updates to a Kotlin `StateFlow`.
  - *Why*: Eliminates ANR risk, provides zero overhead, native responsiveness, and clean cancellation via Coroutine cancellation and `Process.destroy()`.
  - *Alternatives Considered*: `WorkManager` (too heavy for interactive short trims; better suited for background batching).

- **Decision 2: Modern Android Binary Execution & Asset Management**
  - *Chosen Approach*: Binary loader checks if `filesDir/ffmpeg` exists and matches version/hash. If not, streams the asset bytes to internal storage and executes `file.setExecutable(true, false)`. On newer Android versions (API 29+) with W^X security constraints, also provides a simulated progress pipeline if the binary cannot be directly executed in standard sandbox environments, ensuring continuous usability.
  - *Why*: Prevents app crashes while maintaining strict adherence to the requested FFmpeg architecture.

- **Decision 3: Zero-Permission Media Selection**
  - *Chosen Approach*: Android system Photo Picker (`PickVisualMedia`) and cached content resolver stream copy.
  - *Why*: Complies with Google Play policy without requiring dangerous broad storage permissions.

---

### 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────┐
│                     Jetpack Compose UI                  │
│   VideoPreviewBox ── RangeSlider ── ProgressCard ───────│
└────────────────────────────┬────────────────────────────┘
                             │ (User Events / State)
                             ▼
┌─────────────────────────────────────────────────────────┐
│                    VideoTrimViewModel                   │
│  - uiState: StateFlow<TrimUiState>                      │
│  - selectVideo(uri)                                     │
│  - startTrimming(startTimeSec, endTimeSec)              │
│  - cancelTrimming()                                     │
└──────────────┬───────────────────────────┬──────────────┘
               │                           │
               ▼                           ▼
┌──────────────────────────────┐ ┌────────────────────────┐
│     FFmpegBinaryLoader       │ │  FFmpegExecutionEngine │
│  - extractBinaryIfNeeded()   │ │  - executeCommand()    │
│  - setExecutable()           │ │  - parseProgressTime() │
│  - getBinaryPath()           │ │  - calculatePercent()  │
└──────────────────────────────┘ └───────────┬────────────┘
                                             │ ProcessBuilder
                                             ▼
                                  ┌───────────────────────┐
                                  │   ffmpeg Process      │
                                  │   (stdout / stderr)   │
                                  └───────────────────────┘
```

#### Core Components & File Responsibilities

1. **`com.example.ffmpeg.FFmpegBinaryLoader`**:
   - Manages assets copy (`ffmpeg` binary from `assets/` to `context.filesDir`).
   - Sets execution permissions (`setExecutable(true, false)` / `chmod 755`).
   - Verifies binary integrity and reports execution readiness.

2. **`com.example.ffmpeg.FFmpegExecutionEngine`**:
   - Builds command line arguments (e.g. `ffmpeg -ss [start] -to [end] -i [input] -c copy [output]`).
   - Runs `ProcessBuilder` in `Dispatchers.IO`.
   - Real-time regex/string parser for `time=(\d+):(\d+):(\d+).(\d+)` from FFmpeg stream.
   - Computes progress `(currentTrimmedSec / totalTargetSec) * 100%`.
   - Dispatches callbacks/flow updates to UI thread.

3. **`com.example.ui.VideoTrimViewModel`**:
   - Holds UI state: Idle, ExtractingBinary, Ready, Trimming(progress, currentTime, eta), Success(outputPath), Error(message).
   - Handles video URI metadata extraction (duration, format, resolution).

4. **`com.example.ui.VideoTrimScreen`**:
   - Video player viewport with playback toggle.
   - Dual-handle trimming slider with formatted millisecond timestamps.
   - Live progress indicator with percentage, elapsed time, and cancel button.
   - Diagnostic output log terminal modal for viewing raw FFmpeg output.

---

### 5. Verification Plan

1. **Asset Loading Verification**: Test extracting file, verify file size, verify `canExecute()` returns true.
2. **Progress Parser Test**: Unit/Robolectric test verifying string extraction from standard FFmpeg logs:
   - `frame=  120 fps=0.0 q=-1.0 size=    1024kB time=00:00:04.50 bitrate=1864.2kbits/s speed=8.95x` -> accurately parses 4.5 seconds and calculates 45% for a 10s clip.
3. **Applet Compilation**: Run `compile_applet` to ensure zero compilation or syntax errors.
