package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

val Blue700 = Color(0xFF1D4ED8)
val Blue600 = Color(0xFF2563EB)
val Blue400 = Color(0xFF60A5FA)
val Blue100 = Color(0xFFDBEAFE)

val Amber600 = Color(0xFFD97706)
val Amber400 = Color(0xFFFBBF24)

val Green600 = Color(0xFF16A34A)
val Red600 = Color(0xFFDC2626)
