package com.example.ffmpeg

import com.example.util.MediaUtils

/**
 * Representasi rentang waktu pemotongan video untuk operasi batch.
 */
data class TrimTimeRange(
    val startSeconds: Double,
    val endSeconds: Double
) {
    val durationSeconds: Double
        get() = (endSeconds - startSeconds).coerceAtLeast(0.0)

    val formattedDisplay: String
        get() = "${MediaUtils.formatSeconds(startSeconds, true)} - ${MediaUtils.formatSeconds(endSeconds, true)} (${MediaUtils.formatSeconds(durationSeconds, true)})"
}

/**
 * Parser untuk Multi-Text Time Command Batch Trimming.
 * Mengonversi baris teks seperti "00:00-00:10" atau "5-15" menjadi [TrimTimeRange].
 */
object BatchTrimParser {

    /**
     * Mem-parsing string penanda waktu tunggal ke detik desimal.
     * Contoh yang didukung:
     * - "01:23.45" (MM:SS.mmm)
     * - "00:01:23.45" (HH:MM:SS.mmm)
     * - "15" atau "15.5" (detik mentah)
     */
    fun parseSingleTimeToSeconds(timeStr: String): Double? {
        val trimmed = timeStr.trim()
        if (trimmed.isEmpty()) return null

        // Cek apakah berupa angka detik desimal mentah (misal: "12", "15.5")
        trimmed.toDoubleOrNull()?.let {
            if (it >= 0.0) return it
        }

        // Cek format berbasis waktu dengan titik dua (:)
        val parts = trimmed.split(":")
        return when (parts.size) {
            3 -> {
                val h = parts[0].toDoubleOrNull() ?: return null
                val m = parts[1].toDoubleOrNull() ?: return null
                val s = parts[2].toDoubleOrNull() ?: return null
                (h * 3600.0) + (m * 60.0) + s
            }
            2 -> {
                val m = parts[0].toDoubleOrNull() ?: return null
                val s = parts[1].toDoubleOrNull() ?: return null
                (m * 60.0) + s
            }
            else -> null
        }
    }

    /**
     * Mem-parsing satu baris teks perintah rentang waktu.
     * Mendukung tanda pemisah strip '-', en-dash '–', em-dash '—', atau kata 'to' / 's/d'.
     *
     * @param line Baris teks yang akan di-parsing
     * @param maxDurationSeconds Durasi maksimal video yang dijadikan batas atas
     */
    fun parseLine(line: String, maxDurationSeconds: Double = Double.MAX_VALUE): TrimTimeRange? {
        val cleanLine = line.trim()
        if (cleanLine.isEmpty() || cleanLine.startsWith("#") || cleanLine.startsWith("//")) {
            return null
        }

        // Regex untuk menemukan pemisah rentang
        val separatorRegex = Regex("""\s*[-–—]\s*|\s+to\s+|\s+s/d\s+""")
        val parts = cleanLine.split(separatorRegex).filter { it.isNotBlank() }

        if (parts.size != 2) return null

        val start = parseSingleTimeToSeconds(parts[0]) ?: return null
        val end = parseSingleTimeToSeconds(parts[1]) ?: return null

        // Waktu mulai harus lebih kecil dari waktu akhir
        if (start >= end) return null

        val clampedStart = start.coerceAtLeast(0.0)
        val clampedEnd = if (maxDurationSeconds > 0) end.coerceAtMost(maxDurationSeconds) else end

        if (clampedStart >= clampedEnd) return null

        return TrimTimeRange(clampedStart, clampedEnd)
    }

    /**
     * Mem-parsing teks multi-baris menjadi daftar [TrimTimeRange].
     * Secara otomatis membatasi eksekusi maksimal hingga [maxLimit] video teratas (default: 5).
     *
     * @param multiLineText String multi-baris yang diketikkan pengguna
     * @param maxDurationSeconds Batas maksimal durasi video
     * @param maxLimit Batas maksimal jumlah rentang yang dieksekusi (sesuai spesifikasi: 5)
     */
    fun parseMultiTextCommands(
        multiLineText: String,
        maxDurationSeconds: Double = Double.MAX_VALUE,
        maxLimit: Int = 5
    ): List<TrimTimeRange> {
        val lines = multiLineText.lines()
        val parsedRanges = mutableListOf<TrimTimeRange>()

        for (line in lines) {
            val range = parseLine(line, maxDurationSeconds)
            if (range != null) {
                parsedRanges.add(range)
                if (parsedRanges.size >= maxLimit) {
                    break
                }
            }
        }

        return parsedRanges
    }
}
