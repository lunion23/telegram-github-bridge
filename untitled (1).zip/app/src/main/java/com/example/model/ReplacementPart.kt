package com.example.model

data class ReplacementPart(
    val id: String = java.util.UUID.randomUUID().toString(),
    val partNumber: String = "",
    val partName: String = "",
    val procurementType: String = "Stock" // Stock, Order, Modifikasi, Pending
)
