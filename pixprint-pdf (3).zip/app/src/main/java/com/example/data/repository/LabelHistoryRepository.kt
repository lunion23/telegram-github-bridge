package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.OperationType
import com.example.data.handleFirestoreError
import com.example.model.HistoryActionType
import com.example.model.LabelHistoryItem
import com.example.model.PaperSizePreset
import com.example.model.ShippingLabelData
import com.example.model.toHistoryItem
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import java.util.UUID
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class LabelHistoryRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    // CRITICAL: Always initialize with custom database ID from firebase_applet_config.xml
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Pengguna harus masuk dengan Google sebelum menyimpan riwayat.")
    }

    /**
     * Real-time stream of label history records for [userId].
     * Query includes `.whereEqualTo("userId", userId)` to align strictly with `firestore.rules`.
     */
    fun observeHistory(userId: String): Flow<List<LabelHistoryItem>> {
        val path = "users/$userId/labelHistory"
        return db.collection("users")
            .document(userId)
            .collection("labelHistory")
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    LabelHistoryItem::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedByDescending { item ->
                    item.updatedAt ?: item.createdAt ?: Timestamp(0, 0)
                }
            }
            .catch { error ->
                if (error is Exception) {
                    handleFirestoreError(error, OperationType.LIST, path)
                }
                throw error
            }
    }

    /**
     * Fetches a single history item by [historyId] under [ownerUserId].
     */
    suspend fun getHistoryItem(ownerUserId: String, historyId: String): LabelHistoryItem? {
        val docRef = db.collection("users")
            .document(ownerUserId)
            .collection("labelHistory")
            .document(historyId)
        return try {
            val snap = docRef.get().await()
            snap.toObject(
                LabelHistoryItem::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            throw e
        }
    }

    /**
     * Creates a new shipping label history entry for the signed-in user and returns the new document ID.
     */
    suspend fun saveHistoryEntry(
        data: ShippingLabelData,
        paperPreset: PaperSizePreset,
        actionLabel: String = HistoryActionType.SAVED
    ): String {
        val uid = requireUserId()
        val historyId = UUID.randomUUID().toString()
        val docRef = db.collection("users")
            .document(uid)
            .collection("labelHistory")
            .document(historyId)
        val item = data.toHistoryItem(
            userId = uid,
            paperPreset = paperPreset,
            actionLabel = actionLabel,
            id = historyId,
            createdAt = null
        )
        try {
            docRef.set(item).await()
            return historyId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    /**
     * Updates an existing history entry while preserving immutable `userId` and `createdAt`.
     */
    suspend fun updateHistoryEntry(existingItem: LabelHistoryItem, updatedData: ShippingLabelData, paperPreset: PaperSizePreset, actionLabel: String = existingItem.actionLabel) {
        val uid = requireUserId()
        require(existingItem.id.isNotBlank()) { "ID riwayat tidak boleh kosong untuk pembaruan" }
        requireNotNull(existingItem.createdAt) { "createdAt tidak boleh null saat memperbarui riwayat" }

        val docRef = db.collection("users")
            .document(uid)
            .collection("labelHistory")
            .document(existingItem.id)

        val updatedModel = updatedData.toHistoryItem(
            userId = uid,
            paperPreset = paperPreset,
            actionLabel = actionLabel,
            id = existingItem.id,
            createdAt = existingItem.createdAt
        ).copy(updatedAt = null)

        try {
            docRef.set(updatedModel).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    /**
     * Deletes a history entry belonging to the currently signed-in user.
     */
    suspend fun deleteHistoryEntry(historyId: String) {
        val uid = requireUserId()
        require(historyId.isNotBlank()) { "ID riwayat tidak boleh kosong" }
        val docRef = db.collection("users")
            .document(uid)
            .collection("labelHistory")
            .document(historyId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }
}
