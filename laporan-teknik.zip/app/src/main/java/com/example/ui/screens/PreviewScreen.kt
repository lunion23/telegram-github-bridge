package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.export.ExcelExporter
import com.example.export.PdfExporter
import com.example.ui.components.CameraCaptureDialog
import com.example.ui.components.DamagePhotoSourceDialog
import com.example.ui.components.PrintableReport
import com.example.ui.viewmodel.ReportViewModel
import java.io.File

@Composable
fun PreviewScreen(
    viewModel: ReportViewModel,
    onNavigateToEdit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val report by viewModel.currentReport.collectAsState()
    val context = LocalContext.current

    var exportedPdfFile by remember { mutableStateOf<File?>(null) }
    var exportedExcelFile by remember { mutableStateOf<File?>(null) }
    var showExportDialog by remember { mutableStateOf(false) }
    var exportType by remember { mutableStateOf("PDF") } // "PDF" or "Excel"
    var showPrintOptionsDialog by remember { mutableStateOf(false) }
    var showPhotoSourceDialog by remember { mutableStateOf(false) }
    var showCameraCaptureDialog by remember { mutableStateOf(false) }

    // Zero-permission Photo Picker launcher for importing/changing damage photo
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.setDamagePhotoUri(uri.toString())
            Toast.makeText(context, "Foto kerusakan berhasil dimuat ke dokumen!", Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Action Bar with Template Selector and Direct Print Action
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 3.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                // Header & Template Switcher
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Pratinjau Dokumen Cetak",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (report.activeTemplate == 2) "Format: Opsi 2 (Sesuai Gambar / Hiba Group)" else "Format: Opsi 1 (Standar Dealer)",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    // Chips to switch view
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = report.activeTemplate == 1,
                            onClick = { viewModel.setTemplate(1) },
                            label = { Text("Opsi 1 (Standar)", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.testTag("preview_chip_template_1")
                        )
                        FilterChip(
                            selected = report.activeTemplate == 2,
                            onClick = { viewModel.setTemplate(2) },
                            label = { Text("Opsi 2 (Gambar)", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFFDBEAFE),
                                selectedLabelColor = Color(0xFF1E3A8A)
                            ),
                            modifier = Modifier.testTag("preview_chip_template_2")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Primary Quick Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // MAIN BUTTON: PRIN PDF OPSI 2 (SESUAI GAMBAR)
                    Button(
                        onClick = {
                            try {
                                PdfExporter.printReport(context, report, templateOption = 2)
                                Toast.makeText(context, "Membuka printer untuk Opsi 2 (Desain Gambar)...", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "Gagal mencetak PDF: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                        modifier = Modifier
                            .weight(1.3f)
                            .testTag("btn_prin_pdf_opsi_2")
                    ) {
                        Icon(imageVector = Icons.Default.Print, contentDescription = null, modifier = Modifier.size(17.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(5.dp))
                        Text("Prin PDF (Opsi 2)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    // Button: Ekspor PDF (File)
                    Button(
                        onClick = {
                            try {
                                val file = PdfExporter.generatePdf(context, report, templateOption = report.activeTemplate)
                                exportedPdfFile = file
                                exportType = "PDF"
                                showExportDialog = true
                            } catch (e: Exception) {
                                Toast.makeText(context, "Gagal membuat PDF: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_export_pdf")
                    ) {
                        Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Ekspor PDF", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    // Button: Ekspor Excel
                    Button(
                        onClick = {
                            try {
                                val file = ExcelExporter.generateExcel(context, report)
                                exportedExcelFile = file
                                exportType = "Excel"
                                showExportDialog = true
                            } catch (e: Exception) {
                                Toast.makeText(context, "Gagal membuat Excel: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D)),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_export_excel")
                    ) {
                        Icon(imageVector = Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Excel", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    // Button: Simpan ke Arsip
                    OutlinedButton(
                        onClick = {
                            viewModel.saveCurrentReport {
                                Toast.makeText(context, "Laporan berhasil disimpan ke arsip!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.testTag("btn_simpan_arsip")
                    ) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                }

                // Quick photo bar if photo is imported
                if (report.damagePhotoUri.isNotBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Foto Kerusakan: Terlampir",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF15803D)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = { showPhotoSourceDialog = true },
                                modifier = Modifier.height(28.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Ganti Foto", fontSize = 10.sp)
                            }
                            OutlinedButton(
                                onClick = {
                                    viewModel.setDamagePhotoUri("")
                                    Toast.makeText(context, "Foto dihapus (tampilan polos)", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Kosongkan", fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }

        // Paper-style document preview using dedicated PrintableReport composable
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 5.dp),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .border(1.dp, Color(0xFF94A3B8), RoundedCornerShape(4.dp))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(10.dp)
                ) {
                    PrintableReport(
                        report = report,
                        templateOption = report.activeTemplate,
                        onSelectPhoto = { showPhotoSourceDialog = true },
                        onRemovePhoto = {
                            viewModel.setDamagePhotoUri("")
                            Toast.makeText(context, "Foto dihapus (tampilan polos)", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }

        // Bottom Bar with "Edit Kembali" and direct Share/Print options
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onNavigateToEdit,
                    modifier = Modifier.testTag("btn_edit_kembali")
                ) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Edit Formulir")
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Prin PDF Opsi 1 / Pilihan
                    OutlinedButton(
                        onClick = { showPrintOptionsDialog = true },
                        modifier = Modifier.testTag("btn_pilihan_cetak")
                    ) {
                        Icon(imageVector = Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Pilih Opsi Prin")
                    }

                    // Direct Share Button
                    Button(
                        onClick = {
                            try {
                                val file = PdfExporter.generatePdf(context, report, templateOption = report.activeTemplate)
                                PdfExporter.sharePdf(context, file)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Gagal membagikan PDF: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.testTag("btn_share_langsung")
                    ) {
                        Icon(imageVector = Icons.Default.IosShare, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Bagikan PDF")
                    }
                }
            }
        }
    }

    // Print Options Dialog (Choice between Option 1 and Option 2)
    if (showPrintOptionsDialog) {
        AlertDialog(
            onDismissRequest = { showPrintOptionsDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Print, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Pilih Format Cetak PDF", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Pilih format tata letak dokumen yang ingin dicetak atau diekspor ke PDF:")

                    // Card Opsi 2 (Recommended)
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.5.dp, Color(0xFF2563EB), RoundedCornerShape(8.dp))
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Opsi 2: Sesuai Desain Gambar", fontWeight = FontWeight.Bold, color = Color(0xFF1E3A8A), fontSize = 13.sp)
                                Surface(
                                    color = Color(0xFF2563EB),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text("REKOMENDASI", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Format resmi Hiba Group dengan tabel berbingkai ganda, kolom Uraian & Foto Kerusakan bersanding, penyebab checklist, dan kotak persetujuan.", fontSize = 11.sp, color = Color(0xFF334155))
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    showPrintOptionsDialog = false
                                    viewModel.setTemplate(2)
                                    PdfExporter.printReport(context, report, templateOption = 2)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Prin PDF Format Opsi 2", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }

                    // Card Opsi 1 (Dealer Standard)
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp))
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("Opsi 1: Format Standar Dealer", fontWeight = FontWeight.Bold, color = Color(0xFF0F172A), fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Format dokumen modern dengan layout vertikal bersih, tabel rincian part, dan kolom penandatanganan teknisi.", fontSize = 11.sp, color = Color(0xFF475569))
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = {
                                    showPrintOptionsDialog = false
                                    viewModel.setTemplate(1)
                                    PdfExporter.printReport(context, report, templateOption = 1)
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Prin PDF Format Opsi 1", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showPrintOptionsDialog = false }) {
                    Text("Tutup")
                }
            }
        )
    }

    // Export Success Dialog
    if (showExportDialog) {
        val currentFile = if (exportType == "PDF") exportedPdfFile else exportedExcelFile
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            title = {
                Text(
                    text = "Dokumen $exportType Berhasil Dibuat!",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    Text("File laporan berhasil dibuat dalam format pilihan:")
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = currentFile?.name ?: "",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (report.activeTemplate == 2 && exportType == "PDF") "(Format Opsi 2: Sesuai Desain Gambar)" else "(Format Standar)",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (exportType == "PDF") {
                        Button(
                            onClick = {
                                showExportDialog = false
                                currentFile?.let { file ->
                                    PdfExporter.printPdf(context, file, "Laporan_Teknik")
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A))
                        ) {
                            Icon(imageVector = Icons.Default.Print, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Prin")
                        }
                    }

                    Button(
                        onClick = {
                            showExportDialog = false
                            currentFile?.let { file ->
                                if (exportType == "PDF") {
                                    PdfExporter.sharePdf(context, file)
                                } else {
                                    ExcelExporter.shareExcel(context, file)
                                }
                            }
                        },
                        modifier = Modifier.testTag("btn_dialog_bagikan")
                    ) {
                        Icon(imageVector = Icons.Default.IosShare, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Bagikan")
                    }
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        showExportDialog = false
                        currentFile?.let { file ->
                            if (exportType == "PDF") {
                                PdfExporter.openPdf(context, file)
                            } else {
                                ExcelExporter.openExcel(context, file)
                            }
                        }
                    },
                    modifier = Modifier.testTag("btn_dialog_buka")
                ) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Buka File")
                }
            }
        )
    }

    // Dialog Pemilihan Sumber Foto (Kamera CameraX, Galeri, Sampel, Kosongkan)
    DamagePhotoSourceDialog(
        isOpen = showPhotoSourceDialog,
        onDismiss = { showPhotoSourceDialog = false },
        onLaunchCamera = { showCameraCaptureDialog = true },
        onLaunchGallery = {
            photoPickerLauncher.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
            )
        },
        onSelectSample = {
            viewModel.setDamagePhotoUri("sample")
            Toast.makeText(context, "Foto contoh ban kerusakan dimuat!", Toast.LENGTH_SHORT).show()
        },
        onClearPhoto = {
            viewModel.setDamagePhotoUri("")
            Toast.makeText(context, "Foto dikosongkan (tampilan polos)", Toast.LENGTH_SHORT).show()
        },
        hasPhoto = report.damagePhotoUri.isNotBlank()
    )

    // Dialog Pengambilan Foto Kamera CameraX
    CameraCaptureDialog(
        isOpen = showCameraCaptureDialog,
        onDismiss = { showCameraCaptureDialog = false },
        onPhotoCaptured = { savedUri ->
            viewModel.setDamagePhotoUri(savedUri)
            Toast.makeText(context, "Foto kerusakan berhasil disimpan ke dokumen!", Toast.LENGTH_SHORT).show()
        }
    )
}
