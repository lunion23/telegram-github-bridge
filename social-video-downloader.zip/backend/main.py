"""
Social Video Downloader Backend API
Framework: FastAPI + yt-dlp
Mendukung ekstraksi link video dari TikTok, Instagram, YouTube, X (Twitter), Facebook, dan platform lainnya.
"""

import math
import logging
from typing import List, Optional
from fastapi import FastAPI, HTTPException, Query, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, HttpUrl
import yt_dlp
import requests

# Konfigurasi logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("video-downloader")

app = FastAPI(
    title="Social Video Downloader API",
    description="API untuk ekstraksi direct link download video media sosial menggunakan yt-dlp",
    version="1.0.0"
)

# Aktifkan CORS agar dapat diakses dari browser maupun aplikasi mobile
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class ExtractRequest(BaseModel):
    url: str


class VideoFormatOption(BaseModel):
    format_id: str
    resolution: str
    extension: str
    download_url: str
    filesize_formatted: Optional[str] = None
    is_audio_only: bool = False


class VideoInfoResponse(BaseModel):
    title: str
    author: Optional[str] = "Unknown"
    thumbnail: Optional[str] = None
    duration: Optional[str] = None
    platform: Optional[str] = "Social Media"
    webpage_url: str
    formats: List[VideoFormatOption]


def format_bytes(size_bytes: Optional[int]) -> Optional[str]:
    """Mengubah ukuran bytes ke string yang mudah dibaca (KB, MB, GB)."""
    if not size_bytes or size_bytes <= 0:
        return None
    units = ["B", "KB", "MB", "GB", "TB"]
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return f"{s} {units[i]}"


def format_seconds(seconds: Optional[int]) -> Optional[str]:
    """Mengubah detik ke format mm:ss atau hh:mm:ss."""
    if seconds is None or seconds < 0:
        return None
    hrs = seconds // 3600
    mins = (seconds % 3600) // 60
    secs = seconds % 60
    if hrs > 0:
        return f"{hrs:02d}:{mins:02d}:{secs:02d}"
    return f"{mins:02d}:{secs:02d}"


def detect_platform(url: str, extractor: Optional[str]) -> str:
    """Mendeteksi nama platform sosial dari extractor atau URL."""
    url_lower = url.lower()
    if extractor:
        ext_lower = extractor.lower()
        if "tiktok" in ext_lower:
            return "TikTok"
        if "instagram" in ext_lower:
            return "Instagram"
        if "youtube" in ext_lower:
            return "YouTube"
        if "twitter" in ext_lower or "x" in ext_lower:
            return "X (Twitter)"
        if "facebook" in ext_lower:
            return "Facebook"

    if "tiktok.com" in url_lower:
        return "TikTok"
    if "instagram.com" in url_lower:
        return "Instagram"
    if "youtube.com" in url_lower or "youtu.be" in url_lower:
        return "YouTube"
    if "twitter.com" in url_lower or "x.com" in url_lower:
        return "X (Twitter)"
    if "facebook.com" in url_lower or "fb.watch" in url_lower:
        return "Facebook"
    return extractor.capitalize() if extractor else "Video"


@app.get("/")
def root():
    """Health check dan informasi API."""
    return {
        "status": "online",
        "service": "Social Video Downloader API",
        "version": "1.0.0",
        "endpoints": {
            "extract": "POST /api/extract",
            "health": "GET /api/health",
            "stream": "GET /api/stream?url=..."
        }
    }


@app.get("/api/health")
def health_check():
    return {"status": "ok", "message": "Server berjalan normal"}


@app.post("/api/extract", response_model=VideoInfoResponse)
def extract_video_info(request: ExtractRequest):
    """
    Menerima URL video media sosial dan mengembalikan direct link download beserta metadata.
    """
    target_url = request.url.strip()
    if not target_url:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="URL tidak boleh kosong")

    logger.info(f"Mengekstrak URL: {target_url}")

    ydl_opts = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "format": "best",
        "ignoreerrors": False,
        "nocheckcertificate": True,
        "user_agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
        ),
    }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(target_url, download=False)
    except Exception as e:
        logger.error(f"Gagal mengekstrak {target_url}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Gagal mengekstrak video dari URL tersebut. Pastikan URL valid dan publik. Detail: {str(e)}"
        )

    if not info:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Informasi video tidak ditemukan")

    title = info.get("title") or "Video Download"
    author = info.get("uploader") or info.get("channel") or info.get("creator") or "Unknown"
    thumbnail = info.get("thumbnail")
    duration = format_seconds(info.get("duration"))
    platform = detect_platform(target_url, info.get("extractor"))
    webpage_url = info.get("webpage_url") or target_url

    parsed_formats: List[VideoFormatOption] = []
    seen_resolutions = set()

    raw_formats = info.get("formats", [])
    
    # 1. Cari video dengan gabungan audio + video (format direct download terbaik)
    combined_formats = []
    for f in raw_formats:
        url = f.get("url")
        if not url:
            continue
        vcodec = f.get("vcodec", "none")
        acodec = f.get("acodec", "none")
        ext = f.get("ext", "mp4")
        height = f.get("height")
        filesize = f.get("filesize") or f.get("filesize_approx")

        # Jika memiliki stream video dan audio (bukan stream terpisah)
        if vcodec != "none" and acodec != "none":
            res_label = f"{height}p" if height else (f.get("format_note") or "Standard")
            combined_formats.append((height or 0, {
                "format_id": str(f.get("format_id", "best")),
                "resolution": res_label,
                "extension": ext,
                "download_url": url,
                "filesize_formatted": format_bytes(filesize),
                "is_audio_only": False
            }))

    # Urutkan dari resolusi tertinggi ke terendah
    combined_formats.sort(key=lambda x: x[0], reverse=True)

    for _, fmt in combined_formats:
        res = fmt["resolution"]
        if res not in seen_resolutions:
            seen_resolutions.add(res)
            parsed_formats.append(VideoFormatOption(**fmt))

    # 2. Jika tidak ada format gabungan terdeteksi (seperti TikTok/Instagram yang memberikan 1 single URL)
    if not parsed_formats:
        single_url = info.get("url")
        if single_url:
            filesize = info.get("filesize") or info.get("filesize_approx")
            ext = info.get("ext", "mp4")
            height = info.get("height")
            res_label = f"{height}p HD" if height else "HD Video"
            parsed_formats.append(VideoFormatOption(
                format_id="best",
                resolution=res_label,
                extension=ext,
                download_url=single_url,
                filesize_formatted=format_bytes(filesize),
                is_audio_only=False
            ))

    # 3. Tambahkan opsi ekstraksi Audio (MP3 / M4A) jika tersedia
    audio_formats = []
    for f in raw_formats:
        url = f.get("url")
        if not url:
            continue
        vcodec = f.get("vcodec", "none")
        acodec = f.get("acodec", "none")
        if vcodec == "none" and acodec != "none":
            filesize = f.get("filesize") or f.get("filesize_approx")
            abr = f.get("abr")
            abr_label = f"{int(abr)} kbps" if abr else "Audio"
            audio_formats.append((abr or 0, VideoFormatOption(
                format_id=str(f.get("format_id", "audio")),
                resolution=f"Audio Only ({abr_label})",
                extension=f.get("ext", "mp3"),
                download_url=url,
                filesize_formatted=format_bytes(filesize),
                is_audio_only=True
            )))

    if audio_formats:
        # Ambil audio dengan bitrate terbaik
        audio_formats.sort(key=lambda x: x[0], reverse=True)
        parsed_formats.append(audio_formats[0][1])

    # Fallback terakhir jika formats tetap kosong
    if not parsed_formats and info.get("url"):
        parsed_formats.append(VideoFormatOption(
            format_id="default",
            resolution="Best Quality",
            extension="mp4",
            download_url=info["url"],
            filesize_formatted=None,
            is_audio_only=False
        ))

    return VideoInfoResponse(
        title=title,
        author=author,
        thumbnail=thumbnail,
        duration=duration,
        platform=platform,
        webpage_url=webpage_url,
        formats=parsed_formats
    )


@app.get("/api/stream")
def proxy_stream(url: str = Query(..., description="Direct media URL to stream")):
    """
    Streaming proxy fallback untuk platform yang membatasi User-Agent atau Referer.
    """
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
        )
    }

    try:
        req = requests.get(url, headers=headers, stream=True, timeout=30)
        req.raise_for_status()

        def iterfile():
            for chunk in req.iter_content(chunk_size=1024 * 1024):
                if chunk:
                    yield chunk

        content_type = req.headers.get("content-type", "video/mp4")
        return StreamingResponse(iterfile(), media_type=content_type)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"Gagal streaming media: {str(e)}"
        )


if __name__ == "__main__":
    import uvicorn
    # Jalankan server secara lokal pada port 8000
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
