package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SampleData
import com.example.data.local.AppDatabase
import com.example.data.model.PartItem
import com.example.data.model.TechnicalReport
import com.example.data.model.WarrantyStatus
import com.example.data.repository.ReportRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReportViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ReportRepository

    init {
        val db = AppDatabase.getInstance(application)
        repository = ReportRepository(db.reportDao())
    }

    private val _currentReport = MutableStateFlow(createInitialReport())
    val currentReport: StateFlow<TechnicalReport> = _currentReport.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val savedReports: StateFlow<List<TechnicalReport>> = _searchQuery
        .flatMapLatest { query -> repository.searchReports(query) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    private val _currentStep = MutableStateFlow(0) // 0: Header & Unit, 1: Kerusakan & Lokasi, 2: Penyebab & Cara, 3: Parts & Tanda Tangan
    val currentStep: StateFlow<Int> = _currentStep.asStateFlow()

    fun setStep(step: Int) {
        _currentStep.value = step.coerceIn(0, 3)
    }

    fun nextStep() {
        if (_currentStep.value < 3) {
            _currentStep.value += 1
        }
    }

    fun previousStep() {
        if (_currentStep.value > 0) {
            _currentStep.value -= 1
        }
    }

    fun updateReport(modifier: (TechnicalReport) -> TechnicalReport) {
        _currentReport.value = modifier(_currentReport.value)
    }

    fun setReport(report: TechnicalReport) {
        _currentReport.value = report
    }

    fun setTemplate(template: Int) {
        _currentReport.value = _currentReport.value.copy(activeTemplate = template)
        _snackbarMessage.value = if (template == 2) "Beralih ke Desain 2 (Hiba Group)" else "Beralih ke Desain 1 (Standar)"
    }

    fun fillSampleData(template: Int = 1) {
        if (template == 2) {
            _currentReport.value = SampleData.createSampleReportHibaGroup()
            _snackbarMessage.value = "Contoh data Desain 2 (Hiba Group) berhasil dimuat!"
        } else {
            _currentReport.value = SampleData.createSampleReport()
            _snackbarMessage.value = "Contoh data Desain 1 (Standar) berhasil dimuat!"
        }
    }

    fun setDamagePhotoUri(uri: String) {
        _currentReport.value = _currentReport.value.copy(damagePhotoUri = uri)
        _snackbarMessage.value = "Foto kerusakan berhasil dipilih."
    }

    fun resetToBlank() {
        _currentReport.value = createInitialReport()
        _currentStep.value = 0
        _snackbarMessage.value = "Formulir direset ke data baru."
    }

    fun addPart(item: PartItem = PartItem()) {
        val currentList = _currentReport.value.partsList.toMutableList()
        currentList.add(item)
        _currentReport.value = _currentReport.value.copy(partsList = currentList)
    }

    fun updatePart(index: Int, updated: PartItem) {
        val currentList = _currentReport.value.partsList.toMutableList()
        if (index in currentList.indices) {
            currentList[index] = updated
            _currentReport.value = _currentReport.value.copy(partsList = currentList)
        }
    }

    fun removePart(index: Int) {
        val currentList = _currentReport.value.partsList.toMutableList()
        if (index in currentList.indices) {
            currentList.removeAt(index)
            _currentReport.value = _currentReport.value.copy(partsList = currentList)
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun saveCurrentReport(onSuccess: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val reportToSave = _currentReport.value
            val savedId = repository.saveReport(reportToSave)
            _currentReport.value = reportToSave.copy(id = savedId)
            _snackbarMessage.value = "Laporan berhasil disimpan ke arsip!"
            onSuccess(savedId)
        }
    }

    fun loadReport(report: TechnicalReport) {
        _currentReport.value = report
        _snackbarMessage.value = "Laporan ${report.reportNumber.ifBlank { "tersimpan" }} dibuka."
    }

    fun deleteReport(report: TechnicalReport) {
        viewModelScope.launch {
            repository.deleteReport(report)
            if (_currentReport.value.id == report.id) {
                resetToBlank()
            }
            _snackbarMessage.value = "Laporan berhasil dihapus."
        }
    }

    fun duplicateReport(report: TechnicalReport) {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        _currentReport.value = report.copy(
            id = 0,
            reportNumber = "${report.reportNumber}_copy",
            reportDate = today,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        _snackbarMessage.value = "Salinan laporan dibuat. Silakan edit dan simpan."
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    private fun createInitialReport(): TechnicalReport {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        return TechnicalReport(
            title = "LAPORAN TEKNIK",
            companyName = "Hiba Group",
            reportNumber = "",
            workshop = "",
            reportDate = today,
            warrantyStatus = WarrantyStatus.AFTER_WARRANTY,
            causeOthers = true,
            solutionReplacePart = true,
            attachments = "Foto Kerusakan terlampir",
            signDate = today,
            activeTemplate = 2 // Default to Desain 2 (Hiba Group) as requested by user
        )
    }
}
