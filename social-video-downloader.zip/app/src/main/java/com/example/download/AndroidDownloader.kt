package com.example.download

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.widget.Toast

class AndroidDownloader(private val context: Context) {

    private val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    fun downloadFile(
        url: String,
        title: String,
        extension: String,
        isAudio: Boolean = false
    ): Long {
        return try {
            val sanitizedTitle = title
                .replace(Regex("[\\\\/:*?\"<>|]"), "_")
                .trim()
                .take(60)
                .ifEmpty { "download_${System.currentTimeMillis()}" }

            val ext = if (extension.startsWith(".")) extension else ".$extension"
            val fileName = "$sanitizedTitle$ext"

            val mimeType = if (isAudio) "audio/mpeg" else "video/mp4"

            val request = DownloadManager.Request(Uri.parse(url))
                .setMimeType(mimeType)
                .setTitle(sanitizedTitle)
                .setDescription("Downloading via Social Video Downloader")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(true)

            val downloadId = downloadManager.enqueue(request)
            Toast.makeText(context, "Download dimulai: $fileName", Toast.LENGTH_SHORT).show()
            downloadId
        } catch (e: Exception) {
            Toast.makeText(context, "Gagal memulai download: ${e.message}", Toast.LENGTH_LONG).show()
            -1L
        }
    }
}
