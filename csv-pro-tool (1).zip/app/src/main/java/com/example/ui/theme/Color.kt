package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SlateDarkBg = Color(0xFF0B0F17)
val SlateDarkSurface = Color(0xFF131B28)
val SlateDarkCard = Color(0xFF1E293B)
val SlateDarkBorder = Color(0xFF334155)
val SlateDarkTextPrimary = Color(0xFFF8FAFC)
val SlateDarkTextSecondary = Color(0xFF94A3B8)
val EmeraldAccent = Color(0xFF10B981)
val CyanAccent = Color(0xFF0EA5E9)
val AmberAccent = Color(0xFFF59E0B)
val RoseAccent = Color(0xFFF43F5E)

val SlateLightBg = Color(0xFFF8FAFC)
val SlateLightSurface = Color(0xFFFFFFFF)
val SlateLightCard = Color(0xFFF1F5F9)
val SlateLightBorder = Color(0xFFCBD5E1)
val SlateLightTextPrimary = Color(0xFF0F172A)
val SlateLightTextSecondary = Color(0xFF64748B)
val CyanPrimaryLight = Color(0xFF0284C7)
val EmeraldSecondaryLight = Color(0xFF059669)
