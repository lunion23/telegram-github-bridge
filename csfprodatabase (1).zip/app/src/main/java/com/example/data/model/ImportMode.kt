package com.example.data.model

/**
 * Flexible Storage Method for Importing Data (CSV, Excel, or SQLite .db).
 * - UPDATE_EXISTING: Updates existing matching records (same WO/items) with new data and adds new records, without deleting other existing data.
 * - APPEND: Adds all imported records as new lines to the database without updating existing data.
 * - REPLACE_ALL: Clears existing database records completely and replaces with imported records.
 */
enum class ImportMode(
    val title: String,
    val subtitle: String
) {
    UPDATE_EXISTING(
        title = "Perbarui Data Sama (Update & Merge)",
        subtitle = "Perbarui data yang sama dengan data baru, tambahkan data baru, tanpa menghapus data lama."
    ),
    APPEND(
        title = "Append (Tambahkan Saja)",
        subtitle = "Tambahkan seluruh data baru sebagai baris tambahan tanpa memperbarui data lama."
    ),
    REPLACE_ALL(
        title = "Replace All (Ganti Database)",
        subtitle = "Kosongkan seluruh database lama dan ganti bersih dengan data file ini."
    )
}
