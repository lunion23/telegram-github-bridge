package com.example.data.model

enum class WorkOrderColumn(
    val id: String,
    val displayName: String,
    val defaultVisible: Boolean = true,
    val minWidthDp: Int = 120
) {
    NAME("name", "ID WO", true, 130),
    MOBIL_NAME("mobil_name", "Armada / Plat", true, 140),
    TRANDATE("trandate", "Tanggal", true, 110),
    KM_CURRENT("km_current", "KM Odometer", true, 110),
    KELUHAN("keluhan", "Keluhan", true, 180),
    TIPE("tipe", "Tipe", true, 90),
    KODE("kode", "Kode", true, 100),
    DESCRIPTION("description", "Deskripsi Pekerjaan / Part", true, 200),
    CATATAN("catatan", "Catatan", false, 160),
    START_TIME("start_time", "Waktu Mulai", false, 110),
    END_TIME("end_time", "Waktu Selesai", false, 110),
    QTY("qty", "Qty", true, 70),
    TOTAL("total", "Total Satuan", false, 90),
    TOTAL_PRICE("total_price", "Total Biaya (Rp)", true, 130),
    PRODUCT_CLASS("product_class", "Kategori / Class", false, 140),
    NO_CHASSIS("no_chassis", "No Chassis", false, 160),
    NO_MESIN("no_mesin", "No Mesin", false, 140)
}

data class ColumnVisibilityState(
    val visibleColumns: Set<WorkOrderColumn> = WorkOrderColumn.values().filter { it.defaultVisible }.toSet()
) {
    fun isVisible(col: WorkOrderColumn): Boolean = visibleColumns.contains(col)

    fun toggle(col: WorkOrderColumn): ColumnVisibilityState {
        val updated = if (visibleColumns.contains(col)) {
            // Keep at least 1 column visible
            if (visibleColumns.size > 1) visibleColumns - col else visibleColumns
        } else {
            visibleColumns + col
        }
        return copy(visibleColumns = updated)
    }

    fun serializedString(): String = visibleColumns.joinToString(",") { it.id }

    companion object {
        fun fromSerialized(raw: String?): ColumnVisibilityState {
            if (raw.isNullOrBlank()) return ColumnVisibilityState()
            val ids = raw.split(",").toSet()
            val set = WorkOrderColumn.values().filter { ids.contains(it.id) }.toSet()
            return if (set.isNotEmpty()) ColumnVisibilityState(set) else ColumnVisibilityState()
        }
    }
}
