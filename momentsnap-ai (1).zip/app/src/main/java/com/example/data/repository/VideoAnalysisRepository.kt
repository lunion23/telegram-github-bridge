package com.example.data.repository

import android.content.Context
import android.net.Uri
import com.example.data.analyzer.VideoAnalyzerEngine
import com.example.data.local.AnalysisDao
import com.example.data.local.SavedAnalysisEntity
import com.example.data.model.VideoAnalysisResult
import com.example.data.model.VideoSourceType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class VideoAnalysisRepository(
    private val context: Context,
    private val dao: AnalysisDao,
    val geminiAiRepository: GeminiVideoAiRepository = GeminiVideoAiRepository()
) {

    val savedAnalyses: Flow<List<VideoAnalysisResult>> = dao.getAllAnalyses().map { entities ->
        entities.map { it.toDomain() }
    }

    /**
     * Menghasilkan teks structured prompt resmi untuk dikirim ke Gemini AI.
     */
    fun getStructuredGeminiPrompt(
        title: String,
        source: String,
        durationSeconds: Int,
        userNotes: String = ""
    ): String {
        return GeminiVideoAiRepository.buildVideoAnalysisPrompt(title, source, durationSeconds, userNotes)
    }

    /**
     * Memproses respon JSON dari model Gemini AI eksternal atau backend custom.
     */
    suspend fun analyzeWithCustomGeminiOutput(
        rawJsonResponse: String,
        title: String,
        source: String,
        sourceType: VideoSourceType,
        durationSeconds: Int
    ): VideoAnalysisResult = withContext(Dispatchers.IO) {
        val result = geminiAiRepository.parseGeminiResponse(
            jsonString = rawJsonResponse,
            title = title,
            source = source,
            sourceType = sourceType,
            durationSeconds = durationSeconds,
            thumbnailUrl = if (sourceType == VideoSourceType.YOUTUBE) {
                val yId = VideoAnalyzerEngine.extractYouTubeVideoId(source) ?: "dQw4w9WgXcQ"
                VideoAnalyzerEngine.getYouTubeThumbnailUrl(yId)
            } else "https://picsum.photos/640/360"
        )
        dao.insertAnalysis(SavedAnalysisEntity.fromDomain(result))
        result
    }

    suspend fun analyzeLocalVideo(
        uri: Uri,
        titleHint: String = "",
        userNotes: String = "",
        onProgressUpdate: (String) -> Unit = {}
    ): VideoAnalysisResult = withContext(Dispatchers.IO) {
        onProgressUpdate("Mengekstrak metadata & durasi video lokal...")
        delay(600)
        val (detectedTitle, durationSec) = VideoAnalyzerEngine.extractLocalVideoMetadata(context, uri)
        val effectiveTitle = if (titleHint.isNotBlank()) titleHint else detectedTitle

        onProgressUpdate("Menganalisis fluktuasi konten & mendeteksi momen menarik...")
        delay(800)
        onProgressUpdate("Mengekstrak stempel waktu pemotongan (trimming) & hook retensi...")
        delay(700)
        onProgressUpdate("Menyusun deskripsi multi-platform, statistik audiens & SEO...")
        delay(500)

        val result = VideoAnalyzerEngine.analyzeVideo(
            titleInput = effectiveTitle,
            source = uri.toString(),
            sourceType = VideoSourceType.LOCAL,
            customDurationSec = durationSec,
            userNotes = userNotes
        )
        // Automatically save to Room
        dao.insertAnalysis(SavedAnalysisEntity.fromDomain(result))
        result
    }

    suspend fun analyzeYouTubeVideo(
        youtubeUrl: String,
        titleHint: String = "",
        userNotes: String = "",
        onProgressUpdate: (String) -> Unit = {}
    ): VideoAnalysisResult = withContext(Dispatchers.IO) {
        onProgressUpdate("Menghubungkan ke tautan YouTube & memvalidasi video...")
        delay(600)
        val videoId = VideoAnalyzerEngine.extractYouTubeVideoId(youtubeUrl)
        val defaultTitle = if (videoId != null) "YouTube Highlight: $videoId" else "Video YouTube"
        val effectiveTitle = if (titleHint.isNotBlank()) titleHint else defaultTitle

        onProgressUpdate("Mengekstrak transkrip konten & mendeteksi segmen berpotensi viral...")
        delay(900)
        onProgressUpdate("Membuat stempel waktu klip (in/out) & variasi hook 3 detik...")
        delay(700)
        onProgressUpdate("Menghitung estimasi keterlibatan audiens, tagar & strategi SEO...")
        delay(500)

        val result = VideoAnalyzerEngine.analyzeVideo(
            titleInput = effectiveTitle,
            source = youtubeUrl,
            sourceType = VideoSourceType.YOUTUBE,
            customDurationSec = 420,
            userNotes = userNotes
        )
        dao.insertAnalysis(SavedAnalysisEntity.fromDomain(result))
        result
    }

    suspend fun loadSample(sample: VideoAnalysisResult): VideoAnalysisResult = withContext(Dispatchers.IO) {
        dao.insertAnalysis(SavedAnalysisEntity.fromDomain(sample))
        sample
    }

    suspend fun saveAnalysis(result: VideoAnalysisResult) = withContext(Dispatchers.IO) {
        dao.insertAnalysis(SavedAnalysisEntity.fromDomain(result))
    }

    suspend fun deleteAnalysis(id: String) = withContext(Dispatchers.IO) {
        dao.deleteAnalysisById(id)
    }

    fun getSamplePresets(): List<VideoAnalysisResult> {
        return VideoAnalyzerEngine.getSamplePresets()
    }
}
