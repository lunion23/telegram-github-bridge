package com.example

import com.example.data.model.Note
import com.example.export.BulkTransferManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class BulkTransferManagerTest {

    @Test
    fun jsonBackupRoundTrip_preservesAllFieldsAndSpecialCharacters() {
        val notes = listOf(
            Note(
                id = "note-1_abc",
                title = "Catatan \"Penting\"\nBaris 2",
                content = "fun main() {\n\tprintln(\"Halo \\ Dunia!\")\n}",
                tags = listOf("kotlin", "kerja"),
                isPinned = true,
                fileExtension = "kt",
                createdAt = 1700000000000L,
                updatedAt = 1700000050000L
            ),
            Note(
                id = "note-2_xyz",
                title = "Script Python",
                content = "print('hello')",
                tags = emptyList(),
                isPinned = false,
                fileExtension = "py",
                createdAt = 1700000100000L,
                updatedAt = 1700000200000L
            )
        )

        val json = BulkTransferManager.serializeNotesToBackupJson(notes, exportedAt = 1700000300000L)
        val parsed = BulkTransferManager.tryParseNotesFromJson(json)

        assertNotNull(parsed)
        assertEquals(2, parsed!!.size)

        assertEquals(notes[0].id, parsed[0].id)
        assertEquals(notes[0].title, parsed[0].title)
        assertEquals(notes[0].content, parsed[0].content)
        assertEquals(notes[0].tags, parsed[0].tags)
        assertEquals(notes[0].isPinned, parsed[0].isPinned)
        assertEquals(notes[0].fileExtension, parsed[0].fileExtension)
        assertEquals(notes[0].createdAt, parsed[0].createdAt)
        assertEquals(notes[0].updatedAt, parsed[0].updatedAt)

        assertEquals(notes[1].id, parsed[1].id)
        assertEquals(notes[1].title, parsed[1].title)
        assertEquals(notes[1].content, parsed[1].content)
        assertTrue(parsed[1].tags.isEmpty())
        assertFalse(parsed[1].isPinned)
        assertEquals("py", parsed[1].fileExtension)
    }

    @Test
    fun tryParseNotesFromJson_supportsSingleNoteAndArray_rejectsUnrelatedJson() {
        val singleNoteJson = """
            {
              "id": "single_1",
              "title": "Single Note",
              "content": "Body text",
              "tags": ["umum"],
              "isPinned": true,
              "fileExtension": "md"
            }
        """.trimIndent()
        val singleParsed = BulkTransferManager.tryParseNotesFromJson(singleNoteJson)
        assertNotNull(singleParsed)
        assertEquals(1, singleParsed!!.size)
        assertEquals("Single Note", singleParsed[0].title)
        assertEquals("md", singleParsed[0].fileExtension)

        val arrayJson = """
            [
              {"title": "A", "content": "1"},
              {"title": "B", "content": "2"}
            ]
        """.trimIndent()
        val arrayParsed = BulkTransferManager.tryParseNotesFromJson(arrayJson)
        assertNotNull(arrayParsed)
        assertEquals(2, arrayParsed!!.size)
        assertEquals("B", arrayParsed[1].title)

        val packageJson = """{"name": "my-app", "version": "1.0.0"}"""
        assertNull(BulkTransferManager.tryParseNotesFromJson(packageJson))
    }

    @Test
    fun zipExportAndImportRoundTrip_writesManifestAndDeduplicatesFileNames() {
        val notes = listOf(
            Note(
                id = "dup-1",
                title = "Catatan Sama",
                content = "Isi pertama",
                tags = listOf("satu"),
                isPinned = true,
                fileExtension = "txt",
                createdAt = 1000L,
                updatedAt = 2000L
            ),
            Note(
                id = "dup-2",
                title = "Catatan Sama",
                content = "Isi kedua",
                tags = listOf("dua"),
                isPinned = false,
                fileExtension = "txt",
                createdAt = 3000L,
                updatedAt = 4000L
            )
        )

        val baos = ByteArrayOutputStream()
        BulkTransferManager.writeNotesToZipStream(notes, baos)
        val zipBytes = baos.toByteArray()

        // Verify ZIP entries contain manifest + 2 uniquely named text files
        val entryNames = mutableListOf<String>()
        ZipInputStream(zipBytes.inputStream()).use { zin ->
            var entry = zin.nextEntry
            while (entry != null) {
                entryNames.add(entry.name)
                zin.closeEntry()
                entry = zin.nextEntry
            }
        }
        assertTrue(entryNames.contains("cloudpad_backup.json"))
        assertEquals(3, entryNames.size)
        assertEquals(3, entryNames.distinct().size)

        // Restore from ZIP via manifest
        val restored = BulkTransferManager.readNotesFromZipBytes(zipBytes)
        assertEquals(0, restored.skippedCount)
        assertEquals(2, restored.notes.size)
        assertEquals("dup-1", restored.notes[0].id)
        assertEquals("Isi pertama", restored.notes[0].content)
        assertEquals(listOf("satu"), restored.notes[0].tags)
        assertTrue(restored.notes[0].isPinned)
        assertEquals("dup-2", restored.notes[1].id)
        assertEquals("Isi kedua", restored.notes[1].content)
    }

    @Test
    fun readNotesFromZipBytes_withoutManifest_importsTextFilesAndSkipsBinary() {
        val baos = ByteArrayOutputStream()
        ZipOutputStream(baos).use { zout ->
            zout.putNextEntry(ZipEntry("folder/hello.py"))
            zout.write("print('hi')".toByteArray(Charsets.UTF_8))
            zout.closeEntry()

            zout.putNextEntry(ZipEntry("readme.md"))
            zout.write("# Title".toByteArray(Charsets.UTF_8))
            zout.closeEntry()

            zout.putNextEntry(ZipEntry("image.png"))
            zout.write(byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x00, 0x01))
            zout.closeEntry()

            zout.putNextEntry(ZipEntry("__MACOSX/._hello.py"))
            zout.write(byteArrayOf(0x00, 0x05))
            zout.closeEntry()
        }

        val result = BulkTransferManager.readNotesFromZipBytes(baos.toByteArray())
        assertEquals(2, result.notes.size)
        assertEquals(1, result.skippedCount) // image.png skipped, __MACOSX ignored cleanly

        val pyNote = result.notes.first { it.fileExtension == "py" }
        assertEquals("hello", pyNote.title)
        assertEquals("print('hi')", pyNote.content)
        assertTrue(pyNote.tags.contains("impor"))

        val mdNote = result.notes.first { it.fileExtension == "md" }
        assertEquals("readme", mdNote.title)
        assertEquals("# Title", mdNote.content)
    }

    @Test
    fun sanitizeNote_enforcesFirestoreRuleBounds() {
        val dirty = Note(
            id = "invalid/id with spaces!",
            title = "A".repeat(250),
            content = "OK",
            tags = (1..40).map { "tag$it" },
            fileExtension = ".PY!"
        )

        val clean = BulkTransferManager.sanitizeNote(dirty)
        assertNotEquals(dirty.id, clean.id)
        assertTrue(clean.id.matches(Regex("^[a-zA-Z0-9_\\-]+$")))
        assertEquals(200, clean.title.length)
        assertEquals(30, clean.tags.size)
        assertEquals("py", clean.fileExtension)
    }
}
