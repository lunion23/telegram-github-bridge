package com.example.data.analyzer

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.example.data.model.*
import java.util.UUID
import java.util.regex.Pattern

object VideoAnalyzerEngine {

    fun extractYouTubeVideoId(url: String): String? {
        val trimmed = url.trim()
        val patterns = listOf(
            Pattern.compile("(?:v=|/v/|embed/|shorts/|youtu\\.be/)([a-zA-Z0-9_-]{11})"),
            Pattern.compile("^[a-zA-Z0-9_-]{11}$")
        )
        for (p in patterns) {
            val matcher = p.matcher(trimmed)
            if (matcher.find()) {
                return matcher.group(if (matcher.groupCount() >= 1) 1 else 0)
            }
        }
        return null
    }

    fun getYouTubeThumbnailUrl(videoId: String): String {
        return "https://img.youtube.com/vi/$videoId/hqdefault.jpg"
    }

    fun extractLocalVideoMetadata(context: Context, uri: Uri): Pair<String, Int> {
        return runCatching {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(context, uri)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                ?: uri.lastPathSegment?.substringAfterLast("/")
                ?: "Video Lokal"
            val durationMs = durationStr?.toLongOrNull() ?: 120_000L
            val durationSec = (durationMs / 1000).toInt().coerceAtLeast(10)
            retriever.release()
            Pair(title, durationSec)
        }.getOrDefault(Pair("Video Rekaman Lokal", 180))
    }

    fun analyzeVideo(
        titleInput: String,
        source: String,
        sourceType: VideoSourceType,
        customDurationSec: Int? = null,
        userNotes: String = ""
    ): VideoAnalysisResult {
        val id = UUID.randomUUID().toString()
        val isYt = sourceType == VideoSourceType.YOUTUBE
        val ytId = if (isYt) extractYouTubeVideoId(source) else null

        val cleanTitle = when {
            titleInput.isNotBlank() -> titleInput.trim()
            isYt && ytId != null -> "Analisis Video YouTube: #$ytId"
            else -> "Analisis Video Konten Kreator"
        }

        val duration = customDurationSec ?: when (sourceType) {
            VideoSourceType.YOUTUBE -> 480 // 8 minutes default
            VideoSourceType.LOCAL -> 240 // 4 minutes default
            VideoSourceType.SAMPLE -> 360 // 6 minutes default
        }

        val thumb = if (isYt && ytId != null) {
            getYouTubeThumbnailUrl(ytId)
        } else {
            "https://picsum.photos/seed/${id.take(6)}/640/360"
        }

        // Generate context-aware moments, hooks, titles, captions, and SEO based on title/notes
        val keywordFocus = deriveKeywords(cleanTitle, userNotes)
        val moments = generateSmartMoments(duration, cleanTitle, keywordFocus)
        val hooks = generateHighRetentionHooks(cleanTitle, keywordFocus)
        val titles = generateClickworthyTitles(cleanTitle, keywordFocus)
        val captions = generateSocialCaptions(cleanTitle, keywordFocus, moments)
        val stats = calculateAudienceEngagementStats(moments, duration)
        val seo = generateSeoStrategy(cleanTitle, keywordFocus)
        val summaries = generateSummaryPoints(cleanTitle, keywordFocus, moments)

        return VideoAnalysisResult(
            id = id,
            title = cleanTitle,
            sourceUriOrUrl = source,
            sourceType = sourceType,
            durationSeconds = duration,
            thumbnailUrl = thumb,
            summaryPoints = summaries,
            moments = moments,
            hooks = hooks,
            titleSuggestions = titles,
            socialCaptions = captions,
            audienceMetrics = stats,
            seoData = seo
        )
    }

    private fun deriveKeywords(title: String, notes: String): String {
        val combined = "$title $notes".lowercase()
        return when {
            "podcast" in combined || "ngobrol" in combined || "interview" in combined -> "podcast"
            "game" in combined || "gaming" in combined || "mabar" in combined || "clutch" in combined -> "gaming"
            "masak" in combined || "resep" in combined || "kuliner" in combined || "food" in combined -> "cooking"
            "review" in combined || "gadget" in combined || "hp" in combined || "ai" in combined || "teknologi" in combined -> "tech"
            "bisnis" in combined || "cuan" in combined || "marketing" in combined || "uang" in combined -> "business"
            else -> "creator"
        }
    }

    private fun generateSummaryPoints(title: String, category: String, moments: List<VideoMoment>): List<String> {
        return listOf(
            "Video berfokus pada topik '${title}', menyajikan pembahasan inti secara padat dengan ${moments.size} momen sorotan berpotensi viral tinggi.",
            "Terdapat lonjakan retensi penonton yang signifikan pada ${moments.firstOrNull()?.formattedTimeRange() ?: "awal video"} berkat opening hook yang memicu rasa penasaran.",
            "Penyampaian gagasan dilengkapi dengan poin pembuktian konkret, menjadikannya sangat cocok di-repurpose menjadi klip vertikal pendek (TikTok, Reels, Shorts).",
            "Segmen penutup menyertakan call-to-action (CTA) kuat yang mendorong interaksi komentar dan share audiens."
        )
    }

    private fun generateSmartMoments(durationSec: Int, title: String, category: String): List<VideoMoment> {
        val list = mutableListOf<VideoMoment>()
        
        // Ensure intervals fit within duration
        val m1Start = (durationSec * 0.05).toInt().coerceAtLeast(5)
        val m1End = (m1Start + 35).coerceAtMost(durationSec)
        
        val m2Start = (durationSec * 0.35).toInt().coerceAtLeast(m1End + 10)
        val m2End = (m2Start + 42).coerceAtMost(durationSec)

        val m3Start = (durationSec * 0.65).toInt().coerceAtLeast(m2End + 10)
        val m3End = (m3Start + 48).coerceAtMost(durationSec)

        val m4Start = (durationSec * 0.82).toInt().coerceAtLeast(m3End + 5)
        val m4End = (m4Start + 38).coerceAtMost(durationSec)

        when (category) {
            "tech" -> {
                list.add(
                    VideoMoment(
                        id = UUID.randomUUID().toString(),
                        startSecond = m1Start,
                        endSecond = m1End,
                        title = "Uji Fitur AI Paling Mengejutkan",
                        keyQuoteOrText = "\"Banyak yang ngira fitur ini cuma gimmick, tapi pas dicoba hasilnya beneran di luar nalar!\"",
                        reasonWhyViral = "Membangun ekspektasi tinggi dengan pembuktian visual langsung yang memicu rasa penasaran penonton dalam 3 detik pertama.",
                        viralScore = 96
                    )
                )
                list.add(
                    VideoMoment(
                        id = UUID.randomUUID().toString(),
                        startSecond = m2Start,
                        endSecond = m2End,
                        title = "Perbandingan Head-to-Head & Fakta Tersembunyi",
                        keyQuoteOrText = "\"Lihat perbedaannya di sini. Seri pendahulu langsung kalah telak di kondisi low-light ini.\"",
                        reasonWhyViral = "Perbandingan visual kontras dan opini tegas yang sering memicu perdebatan sengit di kolom komentar.",
                        viralScore = 92
                    )
                )
                list.add(
                    VideoMoment(
                        id = UUID.randomUUID().toString(),
                        startSecond = m3Start,
                        endSecond = m3End,
                        title = "Kelemahan Fatal yang Jarang Dibahas Reviewer",
                        keyQuoteOrText = "\"Ada satu hal yang bikin aku mikir dua kali sebelum rekomendasiin ini ke kalian...\"",
                        reasonWhyViral = "Momen kejujuran objektif (*unpopular opinion*) yang membangun kredibilitas dan *watch time* penuh.",
                        viralScore = 95
                    )
                )
            }
            "gaming" -> {
                list.add(
                    VideoMoment(
                        id = UUID.randomUUID().toString(),
                        startSecond = m1Start,
                        endSecond = m1End,
                        title = "Momen 1 vs 4 Outplay Tidak Masuk Akal",
                        keyQuoteOrText = "\"Tinggal 1 HP doang, kalau reload tamat riwayat gue... tapi tunggu dulu!\"",
                        reasonWhyViral = "Adrenalin tinggi, ketegangan intens, dan audio klimaks yang membuat penonton menahan napas.",
                        viralScore = 98
                    )
                )
                list.add(
                    VideoMoment(
                        id = UUID.randomUUID().toString(),
                        startSecond = m2Start,
                        endSecond = m2End,
                        title = "Trik Rahasia Gerakan Pro Player",
                        keyQuoteOrText = "\"Banyak yang belum tahu trik cancel animation ini bisa bikin tembakan 2x lebih akurat.\"",
                        reasonWhyViral = "Memberikan nilai edukasi dan trik praktis yang langsung ingin dicoba sendiri oleh pemain lain.",
                        viralScore = 91
                    )
                )
            }
            "cooking" -> {
                list.add(
                    VideoMoment(
                        id = UUID.randomUUID().toString(),
                        startSecond = m1Start,
                        endSecond = m1End,
                        title = "Trik Rahasia Bikin Tekstur Lembut Lumer",
                        keyQuoteOrText = "\"Jangan pakai mixer! Cukup aduk pelan 3 kali di suhu ruang ini rahasianya.\"",
                        reasonWhyViral = "Visual *food-porn* yang menggugah selera dan instruksi anti-gagal yang memicu orang untuk *save video*.",
                        viralScore = 97
                    )
                )
                list.add(
                    VideoMoment(
                        id = UUID.randomUUID().toString(),
                        startSecond = m2Start,
                        endSecond = m2End,
                        title = "Hasil Potongan Pertama yang Bikin Ngiler",
                        keyQuoteOrText = "\"Dengar suara crunch-nya, dan bagian dalamnya masih lumer sempurna!\"",
                        reasonWhyViral = "Efek ASMR suara dan penampakan visual menggoda yang sangat disukai algoritma Reels & TikTok.",
                        viralScore = 94
                    )
                )
            }
            else -> {
                list.add(
                    VideoMoment(
                        id = UUID.randomUUID().toString(),
                        startSecond = m1Start,
                        endSecond = m1End,
                        title = "Pernyataan Pembuka yang Menggebrak Mindset",
                        keyQuoteOrText = "\"90% kreator salah paham soal aturan algoritma ini, dan ini alasan akun kalian stuck!\"",
                        reasonWhyViral = "Menggunakan teknik *problem-agitation* yang langsung menarik perhatian kreator yang merasa senasib.",
                        viralScore = 96
                    )
                )
                list.add(
                    VideoMoment(
                        id = UUID.randomUUID().toString(),
                        startSecond = m2Start,
                        endSecond = m2End,
                        title = "Formula Emas 3 Langkah Praktis",
                        keyQuoteOrText = "\"Langkah kedua ini yang paling gampang tapi paling sering di-skip padahal penentunya.\"",
                        reasonWhyViral = "Informasi bernilai tinggi dalam format daftar yang memicu penonton untuk menekan tombol bookmark/simpan.",
                        viralScore = 93
                    )
                )
                if (m3End > m3Start + 15) {
                    list.add(
                        VideoMoment(
                            id = UUID.randomUUID().toString(),
                            startSecond = m3Start,
                            endSecond = m3End,
                            title = "Punchline / Kesimpulan Emosional Berbobot",
                            keyQuoteOrText = "\"Bukan seberapa canggih alatmu, tapi seberapa jujur kamu menyampaikan pesanmu.\"",
                            reasonWhyViral = "Kutipan inspiratif yang memicu emosi positif dan keinginan audiens untuk membagikan ke Instagram Story.",
                            viralScore = 89
                        )
                    )
                }
            }
        }

        // Add 4th moment if video is long enough
        if (m4End > m4Start + 15 && durationSec >= 180) {
            list.add(
                VideoMoment(
                    id = UUID.randomUUID().toString(),
                    startSecond = m4Start,
                    endSecond = m4End,
                    title = "Call To Action & Pertanyaan Pemicu Komentar",
                    keyQuoteOrText = "\"Kalian tipe yang setuju sama cara ini atau punya trik sendiri? Tulis di komen!\"",
                    reasonWhyViral = "Mendorong interaksi algoritma (*engagement boost*) dengan pertanyaan pemicu debat sehat.",
                    viralScore = 87
                )
            )
        }

        return list
    }

    private fun generateHighRetentionHooks(title: String, category: String): List<VideoHook> {
        return listOf(
            VideoHook(
                id = "hook_1",
                hookText = "Stop scrolling! Kalau kamu masih lakuin ini di 2026, kamu rugi besar...",
                hookType = "Curiosity Gap (Penasaran Tinggi)",
                deliveryTip = "Ucapkan dengan tempo cepat dan tatap langsung ke kamera di detik 0-2 dengan teks tebal warna kuning."
            ),
            VideoHook(
                id = "hook_2",
                hookText = "Aku berani jamin, hampir nggak ada yang sadar rahasia kecil di video ini!",
                hookType = "Exclusivity / FOMO",
                deliveryTip = "Gunakan ekspresi wajah terkejut dan zoom-in cepat pada ekspresi mata saat kata 'rahasia' terucap."
            ),
            VideoHook(
                id = "hook_3",
                hookText = "Ternyata cara lama udah nggak berlaku! Coba trik 30 detik ini sekarang.",
                hookType = "Problem - Solution",
                deliveryTip = "Tampilkan cuplikan hasil akhir (after) di layar selama 1 detik sebagai teaser pembuktian."
            ),
            VideoHook(
                id = "hook_4",
                hookText = "Ini alasan kenapa video kamu sepi penonton, padahal solusinya sesederhana ini...",
                hookType = "Empathy & Relatable Pain",
                deliveryTip = "Awali dengan nada bicara santai dan bersahabat seperti sedang mengobrol langsung berdua."
            )
        )
    }

    private fun generateClickworthyTitles(title: String, category: String): List<TitleSuggestion> {
        return listOf(
            TitleSuggestion(
                id = "title_1",
                titleText = "JANGAN TONTON Ini Kalau Belum Siap Viral! (Rahasia Terbongkar)",
                category = "Curiosity & Reverse Psychology",
                estimatedCtr = "12.4% CTR"
            ),
            TitleSuggestion(
                id = "title_2",
                titleText = "Cara Gila Mengubah Momen Biasa Jadi Klip Jutaan Views!",
                category = "High Benefit & Action",
                estimatedCtr = "10.8% CTR"
            ),
            TitleSuggestion(
                id = "title_3",
                titleText = "Kenapa Banyak Orang Nyesel Baru Tahu Trik Ini Sekarang?",
                category = "FOMO & Story Hook",
                estimatedCtr = "9.5% CTR"
            ),
            TitleSuggestion(
                id = "title_4",
                titleText = "Bedah Tuntas: $title (Wajib Tonton Sampai Habis)",
                category = "Direct & Informative",
                estimatedCtr = "8.2% CTR"
            )
        )
    }

    private fun generateSocialCaptions(
        title: String,
        category: String,
        moments: List<VideoMoment>
    ): List<SocialCaption> {
        val topMoment = moments.maxByOrNull { it.viralScore }
        val timeRef = topMoment?.formattedTimeRange() ?: "00:15 - 00:45"

        val tiktokCaption = """
            Seriusan momen di menit $timeRef ini beneran bikin shock! 🤯🔥
            
            Siapa sangka ternyata pembahasannya sedalam ini. Buat kalian yang lagi ngembangin konten, bagian ini wajib banget kalian save dan praktikin langsung!
            
            Drop pendapat kalian di bawah: kalian tim setuju atau punya pandangan lain? 👇
        """.trimIndent()

        val reelsCaption = """
            Save video ini dulu sebelum hilang di explore feed kamu! 📌✨
            
            Kunci terpenting dari $title ada di segmen $timeRef. Jangan sampai ke-skip karena poin ini yang bakal nentuin perbedaan hasil kalian.
            
            Tag temen kamu yang butuh lihat ini! 🚀
        """.trimIndent()

        val shortsCaption = """
            Momen paling epik dari $title yang wajib kamu tonton ulang! 🔥
            
            Tonton detik $timeRef untuk tahu fakta sebenarnya. Jangan lupa Like & Subscribe untuk tips dan highlight menarik berikutnya! 👍🔔
        """.trimIndent()

        val commonTags = when (category) {
            "tech" -> listOf("#teknologi", "#gadgetindonesia", "#reviewgadget", "#fypindonesia", "#viralvideo", "#techhack")
            "gaming" -> listOf("#gamingindonesia", "#clutchmoment", "#esports", "#gamertok", "#fyp", "#viralgaming")
            "cooking" -> listOf("#resepviral", "#kulinerindonesia", "#masakantiktok", "#resepsimple", "#fypfood", "#kulineran")
            else -> listOf("#contentcreator", "#videoviral", "#tipscreator", "#fyp", "#reelsindonesia", "#shortsindonesia", "#trending")
        }

        return listOf(
            SocialCaption(
                platform = SocialPlatform.TIKTOK,
                captionText = tiktokCaption,
                callToAction = "Komen pendapatmu & jangan lupa tap love! ❤️",
                hashtags = commonTags + listOf("#tiktokcreator", "#serunyabelajar")
            ),
            SocialCaption(
                platform = SocialPlatform.REELS,
                captionText = reelsCaption,
                callToAction = "Save & Share postingan ini ke Story kamu! 📲",
                hashtags = commonTags + listOf("#reelsviral", "#creatorsid")
            ),
            SocialCaption(
                platform = SocialPlatform.SHORTS,
                captionText = shortsCaption,
                callToAction = "Subscribe untuk update video harian! 🔔",
                hashtags = commonTags + listOf("#youtubeshorts", "#shortsvideo")
            )
        )
    }

    private fun calculateAudienceEngagementStats(moments: List<VideoMoment>, durationSec: Int): AudienceEngagementStats {
        val avgScore = if (moments.isNotEmpty()) moments.map { it.viralScore }.average().toInt() else 88
        val peakRange = if (moments.isNotEmpty()) {
            moments.maxByOrNull { it.viralScore }?.formattedTimeRange() ?: "00:15 - 00:45"
        } else "00:20 - 00:50"

        return AudienceEngagementStats(
            overallScore = avgScore.coerceIn(80, 98),
            viralProbability = if (avgScore >= 92) "Sangat Tinggi (94%)" else "Tinggi (86%)",
            bestPostingTime = "18.30 - 21.00 WIB (Jam Prime Time)",
            targetAudience = "Kreator Konten, Generasi Z, Penggemar Format Pendek",
            retentionPeakTime = peakRange,
            engagementFactors = listOf(
                "Kecepatan hook 3 detik pertama sangat tinggi",
                "Perubahan dinamika audio/visual menjaga perhatian",
                "Penyampaian to-the-point tanpa bertele-tele",
                "Memancing reaksi audiens untuk berkomentar",
                "Tingkat save-ability & bookmarking di atas rata-rata"
            )
        )
    }

    private fun generateSeoStrategy(title: String, category: String): SeoData {
        val primary = listOf("analisa video", "momen viral", "konten kreator", "video pendek")
        val longTail = listOf(
            "cara menemukan momen menarik di video youtube",
            "trik hook video tiktok penahan scroll",
            "rekomendasi judul video viral ber-CTR tinggi",
            "cara optimasi seo youtube shorts dan instagram reels"
        )
        val tags = listOf(
            "#videoviral", "#contentcreator", "#videomarketing", "#socialmediatips",
            "#tiktokviral", "#reelsinstagram", "#youtubeshorts", "#fyp"
        )
        val metaDesc = "Temukan ringkasan poin utama, stempel waktu klip momen menarik, hook pembuka ber-retensi tinggi, dan strategi SEO lengkap untuk mendongkrak performa video Anda."

        return SeoData(
            primaryKeywords = primary,
            longTailKeywords = longTail,
            recommendedTags = tags,
            searchOptimizedDescription = metaDesc
        )
    }

    // Built-in sample clips
    fun getSamplePresets(): List<VideoAnalysisResult> {
        return listOf(
            analyzeVideo(
                titleInput = "Podcast Kreator: Rahasia Menembus Algoritma Video Pendek",
                source = "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                sourceType = VideoSourceType.SAMPLE,
                customDurationSec = 420,
                userNotes = "podcast wawancara kreator video pendek trik algoritma"
            ),
            analyzeVideo(
                titleInput = "Tech Review: Unboxing & Uji Kamera Flagship AI",
                source = "https://www.youtube.com/watch?v=jNQXAC9IVRw",
                sourceType = VideoSourceType.SAMPLE,
                customDurationSec = 360,
                userNotes = "review gadget smartphone kamera lowlight ai benchmark"
            ),
            analyzeVideo(
                titleInput = "Cooking Show: Resep Dessert Viral 5 Menit Tanpa Oven",
                source = "https://www.youtube.com/watch?v=9bZkp7q19f0",
                sourceType = VideoSourceType.SAMPLE,
                customDurationSec = 290,
                userNotes = "masak kuliner dessert manis simple tanpa oven resep praktis"
            ),
            analyzeVideo(
                titleInput = "Gaming Highlights: Momen Clutch Turnamen Grand Final",
                source = "https://www.youtube.com/watch?v=kXYiU_JCYtU",
                sourceType = VideoSourceType.SAMPLE,
                customDurationSec = 310,
                userNotes = "gaming esports clutch 1v4 montage turnamen refleks cepat"
            )
        )
    }
}
