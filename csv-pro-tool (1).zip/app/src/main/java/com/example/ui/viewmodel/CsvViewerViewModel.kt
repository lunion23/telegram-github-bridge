package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ColumnConfigEntity
import com.example.data.model.ConsolidatedCardItem
import com.example.data.model.CsvRowEntity
import com.example.data.model.FilterCriteria
import com.example.data.repository.CsvRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ViewDisplayMode {
    CONSOLIDATED_CARDS,
    SPREADSHEET_TABLE
}

class CsvViewerViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = CsvRepository(application.applicationContext)

    val rowCount: StateFlow<Int> = repository.rowCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val columnConfigs: StateFlow<List<ColumnConfigEntity>> = repository.columnConfigs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val distinctStatuses: StateFlow<List<String>> = repository.distinctStatuses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val distinctCategories: StateFlow<List<String>> = repository.distinctCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _displayMode = MutableStateFlow(ViewDisplayMode.CONSOLIDATED_CARDS)
    val displayMode: StateFlow<ViewDisplayMode> = _displayMode.asStateFlow()

    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _filterCriteria = MutableStateFlow(FilterCriteria())
    val filterCriteria: StateFlow<FilterCriteria> = _filterCriteria.asStateFlow()

    private val _consolidatedGroups = MutableStateFlow<List<ConsolidatedCardItem>>(emptyList())
    val consolidatedGroups: StateFlow<List<ConsolidatedCardItem>> = _consolidatedGroups.asStateFlow()

    private val _spreadsheetRows = MutableStateFlow<List<CsvRowEntity>>(emptyList())
    val spreadsheetRows: StateFlow<List<CsvRowEntity>> = _spreadsheetRows.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _progressMessage = MutableStateFlow<String?>(null)
    val progressMessage: StateFlow<String?> = _progressMessage.asStateFlow()

    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    // Dialog & Sheet States
    private val _showFilterDialog = MutableStateFlow(false)
    val showFilterDialog: StateFlow<Boolean> = _showFilterDialog.asStateFlow()

    private val _showColumnManagerDialog = MutableStateFlow(false)
    val showColumnManagerDialog: StateFlow<Boolean> = _showColumnManagerDialog.asStateFlow()

    private val _showAddRowDialog = MutableStateFlow(false)
    val showAddRowDialog: StateFlow<Boolean> = _showAddRowDialog.asStateFlow()

    private val _editingRow = MutableStateFlow<CsvRowEntity?>(null)
    val editingRow: StateFlow<CsvRowEntity?> = _editingRow.asStateFlow()

    private val _showExportDialog = MutableStateFlow(false)
    val showExportDialog: StateFlow<Boolean> = _showExportDialog.asStateFlow()

    private val _showHelpGuide = MutableStateFlow(false)
    val showHelpGuide: StateFlow<Boolean> = _showHelpGuide.asStateFlow()

    private var filterJob: Job? = null

    init {
        viewModelScope.launch {
            repository.initializeDefaultsIfNeeded()
            refreshData()
        }
    }

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    fun setDisplayMode(mode: ViewDisplayMode) {
        _displayMode.value = mode
    }

    fun toggleDisplayMode() {
        _displayMode.value = if (_displayMode.value == ViewDisplayMode.CONSOLIDATED_CARDS) {
            ViewDisplayMode.SPREADSHEET_TABLE
        } else {
            ViewDisplayMode.CONSOLIDATED_CARDS
        }
    }

    // Search Column 1 (Global Search)
    fun updateSearchQuery(query: String) {
        _filterCriteria.value = _filterCriteria.value.copy(searchQuery = query)
        debounceRefresh()
    }

    // Search Column 2 (Specific Column Selection & Search Query)
    fun updateSearchColumn2Index(colIndex: Int) {
        _filterCriteria.value = _filterCriteria.value.copy(searchColumn2Index = colIndex)
        debounceRefresh()
    }

    fun updateSearchQuery2(query: String) {
        _filterCriteria.value = _filterCriteria.value.copy(searchQuery2 = query)
        debounceRefresh()
    }

    fun clearSearch2() {
        _filterCriteria.value = _filterCriteria.value.copy(searchQuery2 = "")
        debounceRefresh()
    }

    fun setColumnFilter(colIndex: Int, text: String) {
        val updated = _filterCriteria.value.columnFilters.toMutableMap()
        if (text.isBlank()) {
            updated.remove(colIndex)
        } else {
            updated[colIndex] = text
        }
        _filterCriteria.value = _filterCriteria.value.copy(columnFilters = updated)
        refreshData()
    }

    fun setStatusFilter(status: String?) {
        _filterCriteria.value = _filterCriteria.value.copy(statusFilter = status)
        refreshData()
    }

    fun setCategoryFilter(category: String?) {
        _filterCriteria.value = _filterCriteria.value.copy(categoryFilter = category)
        refreshData()
    }

    fun setSortColumn(colIndex: Int) {
        val current = _filterCriteria.value
        val isAsc = if (current.sortColumnIndex == colIndex) !current.isSortAscending else true
        _filterCriteria.value = current.copy(sortColumnIndex = colIndex, isSortAscending = isAsc)
        refreshData()
    }

    fun clearAllFilters() {
        _filterCriteria.value = FilterCriteria()
        refreshData()
    }

    private fun debounceRefresh() {
        filterJob?.cancel()
        filterJob = viewModelScope.launch {
            delay(200)
            refreshData()
        }
    }

    fun refreshData() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val currentFilter = _filterCriteria.value
                val rows = repository.getFilteredRows(currentFilter)
                _spreadsheetRows.value = rows
                _consolidatedGroups.value = repository.getConsolidatedGroups(currentFilter)
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun loadSampleData() {
        viewModelScope.launch {
            _isLoading.value = true
            _progressMessage.value = "Memuat data contoh 10 kolom..."
            try {
                repository.loadSampleData()
                _filterCriteria.value = FilterCriteria()
                refreshData()
                _userMessage.value = "Berhasil memuat 20 baris data contoh!"
            } catch (e: Exception) {
                _userMessage.value = "Gagal memuat data contoh: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
                _progressMessage.value = null
            }
        }
    }

    fun importCsv(uri: Uri) {
        viewModelScope.launch {
            _isLoading.value = true
            _progressMessage.value = "Membaca dan memproses file CSV..."
            try {
                val count = repository.importCsvFromUri(uri) { progress ->
                    _progressMessage.value = "Mengimpor $progress baris..."
                }
                refreshData()
                _userMessage.value = "Berhasil mengimpor $count baris data dari CSV!"
            } catch (e: Exception) {
                _userMessage.value = "Gagal impor CSV: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
                _progressMessage.value = null
            }
        }
    }

    fun exportToCsv(uri: Uri) {
        viewModelScope.launch {
            _isLoading.value = true
            _progressMessage.value = "Mengekspor file CSV..."
            try {
                val success = repository.exportCsv(uri, _filterCriteria.value)
                if (success) {
                    _userMessage.value = "File CSV berhasil diekspor!"
                } else {
                    _userMessage.value = "Gagal mengekspor file CSV."
                }
            } catch (e: Exception) {
                _userMessage.value = "Error: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
                _progressMessage.value = null
            }
        }
    }

    fun exportToExcel(uri: Uri) {
        viewModelScope.launch {
            _isLoading.value = true
            _progressMessage.value = "Menyusun spreadsheet Excel..."
            try {
                val success = repository.exportExcel(uri, _filterCriteria.value)
                if (success) {
                    _userMessage.value = "Spreadsheet Excel berhasil disimpan!"
                } else {
                    _userMessage.value = "Gagal mengekspor Excel."
                }
            } catch (e: Exception) {
                _userMessage.value = "Error: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
                _progressMessage.value = null
            }
        }
    }

    fun exportToPdf(uri: Uri) {
        viewModelScope.launch {
            _isLoading.value = true
            _progressMessage.value = "Membuat dokumen PDF landscape..."
            try {
                val success = repository.exportPdf(uri, _filterCriteria.value)
                if (success) {
                    _userMessage.value = "Dokumen PDF berhasil dibuat!"
                } else {
                    _userMessage.value = "Gagal mengekspor PDF."
                }
            } catch (e: Exception) {
                _userMessage.value = "Error: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
                _progressMessage.value = null
            }
        }
    }

    fun backupDatabase(uri: Uri) {
        viewModelScope.launch {
            _isLoading.value = true
            _progressMessage.value = "Menyimpan cadangan file SQLite DB..."
            try {
                val success = repository.backupDatabaseToUri(uri)
                if (success) {
                    _userMessage.value = "Cadangan Database (.db) berhasil diekspor!"
                } else {
                    _userMessage.value = "Gagal mengekspor file database."
                }
            } catch (e: Exception) {
                _userMessage.value = "Error backup: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
                _progressMessage.value = null
            }
        }
    }

    fun restoreDatabase(uri: Uri) {
        viewModelScope.launch {
            _isLoading.value = true
            _progressMessage.value = "Memulihkan database SQLite..."
            try {
                val success = repository.restoreDatabaseFromUri(uri)
                if (success) {
                    refreshData()
                    _userMessage.value = "Database SQLite berhasil dipulihkan!"
                } else {
                    _userMessage.value = "Gagal memulihkan file database."
                }
            } catch (e: Exception) {
                _userMessage.value = "Error restore: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
                _progressMessage.value = null
            }
        }
    }

    fun addRow(row: CsvRowEntity) {
        viewModelScope.launch {
            repository.insertRow(row)
            refreshData()
            _userMessage.value = "Data baris baru berhasil ditambahkan!"
        }
    }

    fun updateRow(row: CsvRowEntity) {
        viewModelScope.launch {
            repository.updateRow(row)
            refreshData()
            _userMessage.value = "Data berhasil diperbarui!"
        }
    }

    fun deleteRow(id: Long) {
        viewModelScope.launch {
            repository.deleteRow(id)
            refreshData()
            _userMessage.value = "Baris berhasil dihapus."
        }
    }

    fun deleteGroup(recordId: String) {
        viewModelScope.launch {
            repository.deleteGroup(recordId)
            refreshData()
            _userMessage.value = "Grup ID $recordId berhasil dihapus."
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.clearAll()
            refreshData()
            _userMessage.value = "Seluruh data berhasil dikosongkan."
        }
    }

    fun updateColumnConfig(config: ColumnConfigEntity) {
        viewModelScope.launch {
            repository.updateColumnConfig(config)
        }
    }

    fun updateAllColumnConfigs(configs: List<ColumnConfigEntity>) {
        viewModelScope.launch {
            repository.updateColumnConfigs(configs)
        }
    }

    // Sheet/Dialog Controls
    fun openFilterDialog() { _showFilterDialog.value = true }
    fun closeFilterDialog() { _showFilterDialog.value = false }

    fun openColumnManager() { _showColumnManagerDialog.value = true }
    fun closeColumnManager() { _showColumnManagerDialog.value = false }

    fun openAddRowDialog() { _showAddRowDialog.value = true }
    fun closeAddRowDialog() { _showAddRowDialog.value = false }

    fun startEditingRow(row: CsvRowEntity) { _editingRow.value = row }
    fun closeEditingRow() { _editingRow.value = null }

    fun openExportDialog() { _showExportDialog.value = true }
    fun closeExportDialog() { _showExportDialog.value = false }

    fun openHelpGuide() { _showHelpGuide.value = true }
    fun closeHelpGuide() { _showHelpGuide.value = false }

    fun dismissUserMessage() { _userMessage.value = null }
}
