package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.AutoFixHigh
import androidx.compose.material.icons.outlined.BookmarkAdded
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material.icons.outlined.RestartAlt
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.PdfRenderSource
import com.example.model.ShippingLabelData

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LabelDataEditorScreen(
    data: ShippingLabelData,
    onUpdateData: ((ShippingLabelData) -> ShippingLabelData) -> Unit,
    onResetSample: () -> Unit,
    onSaveToHistory: (() -> Unit)? = null,
    onClose: () -> Unit,
    snackbarHostState: SnackbarHostState? = null,
    isUpdatingExistingHistory: Boolean = false,
    renderSource: PdfRenderSource = PdfRenderSource.VECTOR_RECONSTRUCTION,
    onSwitchToVectorMode: (() -> Unit)? = null,
    onSaveAndClose: (() -> Unit)? = null
) {
    BackHandler(onBack = onClose)

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = {
            if (snackbarHostState != null) {
                SnackbarHost(hostState = snackbarHostState)
            }
        },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = stringResource(R.string.editor_title),
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = stringResource(R.string.editor_subtitle),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("editor_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back)
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = onResetSample,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("editor_reset_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.RestartAlt,
                            contentDescription = stringResource(R.string.cd_reset_label_data)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (onSaveToHistory != null) {
                    FilledTonalButton(
                        onClick = {
                            if (onSaveAndClose != null) {
                                onSaveAndClose()
                            } else {
                                onSaveToHistory()
                                onClose()
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("editor_save_history_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.BookmarkAdded,
                            contentDescription = null,
                            modifier = Modifier.padding(end = 6.dp)
                        )
                        Text(
                            text = if (isUpdatingExistingHistory) {
                                stringResource(R.string.action_update_in_history)
                            } else {
                                stringResource(R.string.action_save_to_history)
                            },
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                } else {
                    OutlinedButton(
                        onClick = onResetSample,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("editor_reset_bottom_button")
                    ) {
                        Text(
                            text = stringResource(R.string.action_reset_sample),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Button(
                    onClick = onClose,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("editor_done_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Check,
                        contentDescription = null,
                        modifier = Modifier.padding(end = 6.dp)
                    )
                    Text(
                        text = stringResource(R.string.action_done_editing),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 640.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (renderSource == PdfRenderSource.CAPTURED_DOCUMENT && onSwitchToVectorMode != null) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("editor_camera_mode_banner"),
                        shape = MaterialTheme.shapes.medium,
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                        ),
                        border = BorderStroke(
                            1.dp,
                            MaterialTheme.colorScheme.secondary.copy(alpha = 0.4f)
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.PhotoCamera,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = stringResource(R.string.editor_camera_mode_title),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = stringResource(R.string.editor_camera_mode_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            FilledTonalButton(
                                onClick = onSwitchToVectorMode,
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("editor_switch_to_vector_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.AutoFixHigh,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(stringResource(R.string.action_switch_to_vector_pdf))
                            }
                        }
                    }
                }

                // Section 1: Routing & Barcode
                EditorGroupCard(title = stringResource(R.string.group_routing_barcode)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = data.badgeLeft,
                            onValueChange = { v -> onUpdateData { it.copy(badgeLeft = v) } },
                            label = { Text(stringResource(R.string.field_badge_left)) },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_badge_left")
                        )
                        OutlinedTextField(
                            value = data.badgeRight,
                            onValueChange = { v -> onUpdateData { it.copy(badgeRight = v) } },
                            label = { Text(stringResource(R.string.field_badge_right)) },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_badge_right")
                        )
                    }
                    OutlinedTextField(
                        value = data.routingCode,
                        onValueChange = { v -> onUpdateData { it.copy(routingCode = v) } },
                        label = { Text(stringResource(R.string.field_routing_code)) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_routing_code")
                    )
                    OutlinedTextField(
                        value = data.waybillNumber,
                        onValueChange = { v -> onUpdateData { it.copy(waybillNumber = v) } },
                        label = { Text(stringResource(R.string.field_waybill_number)) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_waybill_number")
                    )
                    OutlinedTextField(
                        value = data.destinationBanner,
                        onValueChange = { v -> onUpdateData { it.copy(destinationBanner = v) } },
                        label = { Text(stringResource(R.string.field_destination_banner)) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_destination_banner")
                    )
                }

                // Section 2: Recipient
                EditorGroupCard(title = stringResource(R.string.group_recipient)) {
                    OutlinedTextField(
                        value = data.recipientName,
                        onValueChange = { v -> onUpdateData { it.copy(recipientName = v) } },
                        label = { Text(stringResource(R.string.field_recipient_name)) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_recipient_name")
                    )
                    OutlinedTextField(
                        value = data.recipientPhone,
                        onValueChange = { v -> onUpdateData { it.copy(recipientPhone = v) } },
                        label = { Text(stringResource(R.string.field_recipient_phone)) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_recipient_phone")
                    )
                    OutlinedTextField(
                        value = data.recipientAddress,
                        onValueChange = { v -> onUpdateData { it.copy(recipientAddress = v) } },
                        label = { Text(stringResource(R.string.field_recipient_address)) },
                        minLines = 2,
                        maxLines = 4,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_recipient_address")
                    )
                }

                // Section 3: Sender
                EditorGroupCard(title = stringResource(R.string.group_sender)) {
                    OutlinedTextField(
                        value = data.senderName,
                        onValueChange = { v -> onUpdateData { it.copy(senderName = v) } },
                        label = { Text(stringResource(R.string.field_sender_name)) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_sender_name")
                    )
                    OutlinedTextField(
                        value = data.senderPhone,
                        onValueChange = { v -> onUpdateData { it.copy(senderPhone = v) } },
                        label = { Text(stringResource(R.string.field_sender_phone)) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_sender_phone")
                    )
                    OutlinedTextField(
                        value = data.senderArea,
                        onValueChange = { v -> onUpdateData { it.copy(senderArea = v) } },
                        label = { Text(stringResource(R.string.field_sender_area)) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_sender_area")
                    )
                }

                // Section 4: Cost & Package Details
                EditorGroupCard(title = stringResource(R.string.group_shipment_details)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = data.shippingFeeAmount,
                            onValueChange = { v -> onUpdateData { it.copy(shippingFeeAmount = v) } },
                            label = { Text(stringResource(R.string.field_shipping_fee)) },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_shipping_fee")
                        )
                        OutlinedTextField(
                            value = data.paymentMethod,
                            onValueChange = { v -> onUpdateData { it.copy(paymentMethod = v) } },
                            label = { Text(stringResource(R.string.field_payment_method)) },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_payment_method")
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = data.weight,
                            onValueChange = { v -> onUpdateData { it.copy(weight = v) } },
                            label = { Text(stringResource(R.string.field_weight)) },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_weight")
                        )
                        OutlinedTextField(
                            value = data.printDate,
                            onValueChange = { v -> onUpdateData { it.copy(printDate = v) } },
                            label = { Text(stringResource(R.string.field_print_date)) },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_print_date")
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = data.orderNumber,
                            onValueChange = { v -> onUpdateData { it.copy(orderNumber = v) } },
                            label = { Text(stringResource(R.string.field_order_number)) },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1.4f)
                                .testTag("input_order_number")
                        )
                        OutlinedTextField(
                            value = data.expCode,
                            onValueChange = { v -> onUpdateData { it.copy(expCode = v) } },
                            label = { Text(stringResource(R.string.field_exp)) },
                            singleLine = true,
                            modifier = Modifier
                                .weight(0.9f)
                                .testTag("input_exp_code")
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = data.quantityText,
                            onValueChange = { v -> onUpdateData { it.copy(quantityText = v) } },
                            label = { Text(stringResource(R.string.field_quantity)) },
                            singleLine = true,
                            modifier = Modifier
                                .weight(0.8f)
                                .testTag("input_quantity")
                        )
                        OutlinedTextField(
                            value = data.itemCategory,
                            onValueChange = { v -> onUpdateData { it.copy(itemCategory = v) } },
                            label = { Text(stringResource(R.string.field_item_category)) },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1.5f)
                                .testTag("input_item_category")
                        )
                    }
                    OutlinedTextField(
                        value = data.notes,
                        onValueChange = { v -> onUpdateData { it.copy(notes = v) } },
                        label = { Text(stringResource(R.string.field_notes)) },
                        maxLines = 2,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_notes")
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun EditorGroupCard(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
            )
            content()
        }
    }
}
