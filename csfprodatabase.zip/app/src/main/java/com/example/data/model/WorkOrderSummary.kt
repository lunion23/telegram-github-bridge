package com.example.data.model

/**
 * Grouped Work Order representation. Aggregates multiple line items belonging to the same WO ID (`name`).
 */
data class WorkOrderSummary(
    val name: String,
    val mobilName: String,
    val trandateFormatted: String,
    val trandateMillis: Long,
    val kmCurrent: Long,
    val keluhan: String,
    val noChassis: String,
    val noMesin: String,
    val itemCount: Int,
    val totalCost: Double,
    val partCount: Int,
    val jasaCount: Int,
    val startTime: String,
    val endTime: String
)

/**
 * Statistics overview for the Executive Dashboard
 */
data class FleetKpiStats(
    val totalWorkOrders: Int = 0,
    val totalLineItems: Int = 0,
    val totalVehicles: Int = 0,
    val totalExpenditure: Double = 0.0,
    val totalPartCost: Double = 0.0,
    val totalJasaCost: Double = 0.0,
    val averageCostPerWo: Double = 0.0
)
