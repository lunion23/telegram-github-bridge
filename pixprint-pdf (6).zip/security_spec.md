# Security Specification — Cetak Resi PDF (Data Manager)

## 1. Data Invariants
1. **Strict Tenant & PII Isolation**: Every saved shipping label document lives at `/users/{userId}/shipping_labels/{labelId}` and contains PII (recipient/sender names, masked/full phone numbers, addresses). Only the authenticated owner (`request.auth.uid == userId` and `data.userId == request.auth.uid`) may create, read (`get`/`list`), update, or delete their own shipping labels.
2. **Mandatory Schema & Size Bounds**: Every `create` and `update` must satisfy `isValidShippingLabel(request.resource.data)`, enforcing exact key allowlists (`hasAll` + `hasOnly`), strict types (`string`, `bool`, `timestamp`), enum validation on `paperPresetName`, non-empty `title`, `waybillNumber`, and `recipientName`, and `.size() <= MAX` limits on every string field.
3. **Immutable Ownership & Creation Timestamp**: `userId` and `createdAt` cannot be modified after creation (`incoming().userId == existing().userId && incoming().createdAt == existing().createdAt`).
4. **Query Alignment**: `allow list` enforces `request.auth.uid == userId && resource.data.userId == request.auth.uid` so unaligned queries without `.whereEqualTo("userId", uid)` fail with `PERMISSION_DENIED`.

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Unauthenticated Read**: `unauthDb.doc("users/alice_123/shipping_labels/doc1").get()` -> Reject.
2. **Unauthenticated Write**: `unauthDb.doc("users/alice_123/shipping_labels/doc1").set(validPayload)` -> Reject.
3. **Cross-User PII Read**: Alice reads `users/bob_456/shipping_labels/doc1` -> Reject.
4. **Cross-User Write/Hijack**: Alice writes to `users/bob_456/shipping_labels/doc1` -> Reject.
5. **Identity Spoofing on Create**: Alice writes to `users/alice_123/shipping_labels/doc1` with `userId: "bob_456"` -> Reject.
6. **Shadow / Ghost Field Injection**: Payload includes `isAdmin: true` or `isVerified: true` -> Reject via `hasOnly`.
7. **Unaligned List Query**: Alice calls `collection("users/alice_123/shipping_labels").get()` without `.where("userId", "==", "alice_123")` -> Reject.
8. **Empty Required Field**: `waybillNumber: ""` or `recipientName: ""` -> Reject.
9. **Oversized String DoW**: `recipientAddress` of 1000 chars (> 500 max) -> Reject.
10. **Invalid Enum Value**: `paperPresetName: "CUSTOM_HACK"` -> Reject.
11. **Immutable Field Mutation**: Updating `createdAt` or `userId` on an existing document -> Reject.
12. **Future Timestamp Spoofing / Wrong Type**: `createdAt` as integer epoch or future timestamp `> request.time` -> Reject.
