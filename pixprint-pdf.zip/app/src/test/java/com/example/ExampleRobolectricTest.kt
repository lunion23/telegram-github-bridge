package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.PaperSizePreset
import com.example.model.PdfRenderSource
import com.example.model.ShippingLabelData
import com.example.pdf.ShippingLabelPdfGenerator
import java.io.ByteArrayOutputStream
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name matches Cetak Resi PDF`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Cetak Resi PDF", appName)
    }

    @Test
    fun `pdf generator writes valid pdf header and non-empty vector content`() {
        val sampleData = ShippingLabelData.defaultFromReferenceImage()
        val output = ByteArrayOutputStream()

        ShippingLabelPdfGenerator.writePdfToStream(
            outputStream = output,
            data = sampleData,
            paperPreset = PaperSizePreset.THERMAL_100X200,
            renderSource = PdfRenderSource.VECTOR_RECONSTRUCTION,
            referenceBitmap = null
        )

        val bytes = output.toByteArray()
        assertTrue("Generated PDF should not be empty", bytes.size > 500)
        val header = String(bytes, 0, 5, Charsets.US_ASCII)
        assertEquals("%PDF-", header)
    }
}
