package com.example.data.repository

import android.content.Context
import android.net.Uri
import com.example.data.database.AppDatabase
import com.example.data.database.CsvDao
import com.example.data.exporter.CsvExporter
import com.example.data.exporter.ExcelExporter
import com.example.data.exporter.PdfExporter
import com.example.data.model.ColumnConfigEntity
import com.example.data.model.ConsolidatedCardItem
import com.example.data.model.CsvRowEntity
import com.example.data.model.FilterCriteria
import com.example.data.model.SampleDataGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.OutputStream

class CsvRepository(private val context: Context) {

    private val db = AppDatabase.getDatabase(context)
    private val dao: CsvDao = db.csvDao()

    val rowCount: Flow<Int> = dao.getRowCount()
    val allRows: Flow<List<CsvRowEntity>> = dao.getAllRows()
    val columnConfigs: Flow<List<ColumnConfigEntity>> = dao.getAllColumnConfigs()
    val distinctStatuses: Flow<List<String>> = dao.getDistinctStatuses()
    val distinctCategories: Flow<List<String>> = dao.getDistinctCategories()

    suspend fun initializeDefaultsIfNeeded() = withContext(Dispatchers.IO) {
        val existingConfigs = dao.getAllColumnConfigsDirect()
        if (existingConfigs.isEmpty()) {
            dao.insertColumnConfigs(ColumnConfigEntity.defaultConfigs())
        }
    }

    suspend fun loadSampleData() = withContext(Dispatchers.IO) {
        dao.clearAllRows()
        val sample = SampleDataGenerator.generate10ColumnDataset()
        dao.insertAll(sample)
    }

    suspend fun getFilteredRows(filter: FilterCriteria): List<CsvRowEntity> = withContext(Dispatchers.IO) {
        val rows = dao.filterAllRows(
            query = filter.searchQuery.trim(),
            status = filter.statusFilter,
            category = filter.categoryFilter
        )

        var result = rows

        // Apply 2nd search column query if provided
        if (filter.searchQuery2.isNotBlank()) {
            val q2 = filter.searchQuery2.trim()
            val colIdx = filter.searchColumn2Index
            result = result.filter { row ->
                row.getCell(colIdx).contains(q2, ignoreCase = true)
            }
        }

        // Apply column-specific filter if any
        if (filter.columnFilters.isNotEmpty()) {
            result = result.filter { row ->
                filter.columnFilters.all { (colIndex, text) ->
                    row.getCell(colIndex).contains(text, ignoreCase = true)
                }
            }
        }

        // Apply sorting
        result = if (filter.isSortAscending) {
            result.sortedBy { it.getCell(filter.sortColumnIndex).lowercase() }
        } else {
            result.sortedByDescending { it.getCell(filter.sortColumnIndex).lowercase() }
        }

        result
    }

    suspend fun getConsolidatedGroups(filter: FilterCriteria): List<ConsolidatedCardItem> = withContext(Dispatchers.IO) {
        val rows = getFilteredRows(filter)
        val groups = rows.groupBy { row ->
            row.recordId.ifEmpty { row.col0 }.ifEmpty { "TANPA-ID" }
        }
        groups.map { (_, groupRows) ->
            ConsolidatedCardItem.fromRows(groupRows)
        }
    }

    suspend fun insertRow(row: CsvRowEntity) = withContext(Dispatchers.IO) {
        dao.insertRow(row)
    }

    suspend fun updateRow(row: CsvRowEntity) = withContext(Dispatchers.IO) {
        dao.updateRow(row)
    }

    suspend fun deleteRow(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteRowById(id)
    }

    suspend fun deleteGroup(recordId: String) = withContext(Dispatchers.IO) {
        dao.deleteByRecordId(recordId)
    }

    suspend fun clearAll() = withContext(Dispatchers.IO) {
        dao.clearAllRows()
    }

    suspend fun updateColumnConfig(config: ColumnConfigEntity) = withContext(Dispatchers.IO) {
        dao.updateColumnConfig(config)
    }

    suspend fun updateColumnConfigs(configs: List<ColumnConfigEntity>) = withContext(Dispatchers.IO) {
        dao.insertColumnConfigs(configs)
    }

    suspend fun importCsvFromUri(uri: Uri, onProgress: (imported: Int) -> Unit = {}): Int = withContext(Dispatchers.IO) {
        val contentResolver = context.contentResolver
        val inputStream = contentResolver.openInputStream(uri) ?: return@withContext 0

        val reader = BufferedReader(InputStreamReader(inputStream))
        var lineIndex = 0
        val batch = mutableListOf<CsvRowEntity>()
        var totalImported = 0

        var firstLine = true
        var detectedHeaders = listOf<String>()

        reader.useLines { lines ->
            for (line in lines) {
                if (line.isBlank()) continue
                val values = parseCsvLine(line)

                if (firstLine) {
                    firstLine = false
                    if (isHeaderLine(values)) {
                        detectedHeaders = values
                        val newConfigs = (0..9).map { idx ->
                            val name = detectedHeaders.getOrNull(idx)?.takeIf { it.isNotBlank() } ?: "Kolom ${idx + 1}"
                            ColumnConfigEntity(idx, name, isVisible = true, displayOrder = idx)
                        }
                        dao.insertColumnConfigs(newConfigs)
                        continue
                    }
                }

                val entity = CsvRowEntity.fromList(values)
                batch.add(entity)
                lineIndex++

                if (batch.size >= 500) {
                    dao.insertAll(batch)
                    totalImported += batch.size
                    onProgress(totalImported)
                    batch.clear()
                }
            }
        }

        if (batch.isNotEmpty()) {
            dao.insertAll(batch)
            totalImported += batch.size
            onProgress(totalImported)
            batch.clear()
        }

        totalImported
    }

    suspend fun backupDatabaseToUri(uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val dbFile = context.getDatabasePath(AppDatabase.DATABASE_NAME)
            if (!dbFile.exists()) return@withContext false

            val outputStream: OutputStream? = context.contentResolver.openOutputStream(uri)
            outputStream?.use { out ->
                FileInputStream(dbFile).use { input ->
                    input.copyTo(out)
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun restoreDatabaseFromUri(uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val dbFile = context.getDatabasePath(AppDatabase.DATABASE_NAME)
            val parent = dbFile.parentFile
            if (parent != null && !parent.exists()) {
                parent.mkdirs()
            }

            db.close()

            val inputStream = context.contentResolver.openInputStream(uri) ?: return@withContext false
            FileOutputStream(dbFile).use { output ->
                inputStream.use { input ->
                    input.copyTo(output)
                }
            }

            File(dbFile.path + "-wal").delete()
            File(dbFile.path + "-shm").delete()

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun exportCsv(uri: Uri, filter: FilterCriteria): Boolean = withContext(Dispatchers.IO) {
        try {
            val rows = getFilteredRows(filter)
            val columns = dao.getAllColumnConfigsDirect()
            val out = context.contentResolver.openOutputStream(uri) ?: return@withContext false
            out.use { CsvExporter.export(it, columns, rows) }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun exportExcel(uri: Uri, filter: FilterCriteria): Boolean = withContext(Dispatchers.IO) {
        try {
            val rows = getFilteredRows(filter)
            val columns = dao.getAllColumnConfigsDirect()
            val out = context.contentResolver.openOutputStream(uri) ?: return@withContext false
            out.use { ExcelExporter.export(it, columns, rows) }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun exportPdf(uri: Uri, filter: FilterCriteria): Boolean = withContext(Dispatchers.IO) {
        try {
            val rows = getFilteredRows(filter)
            val columns = dao.getAllColumnConfigsDirect()
            val out = context.contentResolver.openOutputStream(uri) ?: return@withContext false
            val summary = if (filter.isActive) "Filter Aktif (${rows.size} baris)" else "Semua Data (${rows.size} baris)"
            out.use { PdfExporter.export(it, columns, rows, filterSummary = summary) }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun isHeaderLine(values: List<String>): Boolean {
        val keywords = listOf("id", "no", "faktur", "tanggal", "date", "name", "nama", "customer", "kategori", "category", "produk", "product", "qty", "harga", "price", "total", "status")
        return values.any { v -> keywords.any { k -> v.lowercase().contains(k) } }
    }

    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val sb = java.lang.StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            if (c == '\"') {
                if (inQuotes && i + 1 < line.length && line[i + 1] == '\"') {
                    sb.append('\"')
                    i++
                } else {
                    inQuotes = !inQuotes
                }
            } else if (c == ',' && !inQuotes) {
                result.add(sb.toString().trim())
                sb.setLength(0)
            } else {
                sb.append(c)
            }
            i++
        }
        result.add(sb.toString().trim())
        return result
    }
}
