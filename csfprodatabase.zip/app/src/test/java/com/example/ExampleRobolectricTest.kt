package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.parser.CsvStreamParser
import com.example.data.parser.DateNormalizer
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("datacsv", appName)
    }

    @Test
    fun `test launch MainActivity`() {
        org.robolectric.Robolectric.buildActivity(MainActivity::class.java).setup()
    }

    @Test
    fun `test date normalizer formats correctly`() {
        val res1 = DateNormalizer.parse("12/05/2024")
        assertEquals("2024-05-12", res1.formatted)

        val res2 = DateNormalizer.parse("2024-10-25 14:30:00")
        assertEquals("2024-10-25", res2.formatted)
    }

    @Test
    fun `test csv line parsing with quotes`() {
        val csvLine = "\"WO-001\",\"B 9123 UXT\",\"12/05/2024\",50000,\"Rem getar, muatan penuh\",\"PART\",\"FL-01\",\"Filter Oli\",,10:00,12:00,2,2,185000,\"Engine\",\"CHASSIS123\",\"ENG456\""
        val tokens = CsvStreamParser.parseCsvLine(csvLine)
        assertEquals(17, tokens.size)
        assertEquals("WO-001", tokens[0])
        assertEquals("B 9123 UXT", tokens[1])
        assertEquals("Rem getar, muatan penuh", tokens[4])
    }

    @Test
    fun `test stream batch parsing`() = runTest {
        val csvContent = """
            Name,MobilName,Trandate,KmCurrent,Keluhan,Tipe,Kode,Description,Catatan,StartTime,EndTime,Qty,Total,TotalPrice,ProductClass,NoChassis,NoMesin
            "WO-101","B 1111 AA","15/06/2024",12000,"Ganti Oli","PART","OIL-01","Oli Meditran",,08:00,09:00,4,4,400000,"Pelumas","CHAS1","ENG1"
            "WO-101","B 1111 AA","15/06/2024",12000,"Ganti Oli","JASA","JS-01","Jasa Tune Up",,08:00,09:00,1,1,150000,"Jasa","CHAS1","ENG1"
        """.trimIndent()

        val parsedBatches = mutableListOf<Int>()
        val totalCount = CsvStreamParser.parseStreamInBatches(
            inputStream = ByteArrayInputStream(csvContent.toByteArray(Charsets.UTF_8)),
            chunkSize = 10
        ) { batch, _ ->
            parsedBatches.add(batch.size)
        }

        assertEquals(2L, totalCount)
        assertEquals(1, parsedBatches.size)
        assertEquals(2, parsedBatches[0])
    }

    @Test
    fun `test bundled cilegon asset parses cleanly`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val assetStream = context.assets.open("CILEGONCSV.csv")
        assertNotNull(assetStream)

        var totalItems = 0L
        val count = CsvStreamParser.parseStreamInBatches(
            inputStream = assetStream,
            chunkSize = 20
        ) { batch, _ ->
            totalItems += batch.size
            assertTrue(batch.isNotEmpty())
            assertTrue(batch[0].name.startsWith("WO-CLG"))
        }

        assertTrue("Expected at least 25 items in CILEGONCSV.csv", count >= 25)
    }

    @Test
    fun `test semicolon delimited csv parsing`() {
        val semiLine = "\"WO-SEM-01\";\"A 1234 B\";\"10/01/2024\";10000;\"Rem, kopling, oli\";\"PART\";\"CD-1\";\"Kampas Rem\";\"\";\"08:00\";\"10:00\";2;2;500000;\"Brake\";\"CHAS\";\"ENG\""
        val tokens = CsvStreamParser.parseCsvLine(semiLine, ';')
        assertEquals(17, tokens.size)
        assertEquals("WO-SEM-01", tokens[0])
        assertEquals("A 1234 B", tokens[1])
        assertEquals("Rem, kopling, oli", tokens[4])
    }

    @Test
    fun `test dual keyword filter criteria activation`() {
        val criteria = com.example.data.model.FilterCriteria(
            dualKeyword1 = "HINO",
            dualColumn1 = com.example.data.model.SearchTargetColumn.MOBIL_NAME,
            dualKeyword2 = "REM",
            dualColumn2 = com.example.data.model.SearchTargetColumn.KELUHAN
        )
        assertTrue(criteria.isDualSearchActive)
        assertTrue(criteria.isActive)
        assertEquals("HINO", criteria.dualKeyword1)
        assertEquals(com.example.data.model.SearchTargetColumn.MOBIL_NAME, criteria.dualColumn1)
        assertEquals("REM", criteria.dualKeyword2)
        assertEquals(com.example.data.model.SearchTargetColumn.KELUHAN, criteria.dualColumn2)
    }

    @Test
    fun `test import mode enum options`() {
        val append = com.example.data.model.ImportMode.APPEND
        val replace = com.example.data.model.ImportMode.REPLACE_ALL

        assertTrue(append.title.contains("Append"))
        assertTrue(replace.title.contains("Replace All"))
    }

    @Test
    fun `test print layout options exist`() {
        val compact = com.example.ui.components.PrintLayoutOption.COMPACT_ORDER_KERJA
        val full = com.example.ui.components.PrintLayoutOption.FULL_DETAIL_REPORT

        assertNotNull(compact)
        assertNotNull(full)
    }
}
