package com.example.data.model

data class PartItem(
    val no: Int,
    val noParts: String = "",
    val namaParts: String = "",
    val jenisPengadaan: String = "" // "Stock", "Order", "Modifikasi", "Pending", or ""
) {
    companion object {
        fun defaultList(): List<PartItem> {
            return (1..5).map { PartItem(no = it) }
        }
    }
}
