package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ColumnType {
    TEXT,
    NUMBER,
    CURRENCY,
    DATE
}

@Entity(tableName = "column_configs")
data class ColumnConfigEntity(
    @PrimaryKey
    val colIndex: Int,
    val headerName: String,
    val isVisible: Boolean = true,
    val displayOrder: Int = colIndex,
    val columnType: String = ColumnType.TEXT.name
) {
    companion object {
        fun defaultConfigs(): List<ColumnConfigEntity> {
            return listOf(
                ColumnConfigEntity(0, "No ID / Faktur", isVisible = true, displayOrder = 0, ColumnType.TEXT.name),
                ColumnConfigEntity(1, "Tanggal", isVisible = true, displayOrder = 1, ColumnType.DATE.name),
                ColumnConfigEntity(2, "Pelanggan / Klien", isVisible = true, displayOrder = 2, ColumnType.TEXT.name),
                ColumnConfigEntity(3, "Kategori", isVisible = true, displayOrder = 3, ColumnType.TEXT.name),
                ColumnConfigEntity(4, "Nama Produk / Item", isVisible = true, displayOrder = 4, ColumnType.TEXT.name),
                ColumnConfigEntity(5, "Qty", isVisible = true, displayOrder = 5, ColumnType.NUMBER.name),
                ColumnConfigEntity(6, "Harga Satuan", isVisible = true, displayOrder = 6, ColumnType.NUMBER.name),
                ColumnConfigEntity(7, "Diskon", isVisible = true, displayOrder = 7, ColumnType.NUMBER.name),
                ColumnConfigEntity(8, "Keterangan", isVisible = true, displayOrder = 8, ColumnType.TEXT.name),
                ColumnConfigEntity(9, "Status", isVisible = true, displayOrder = 9, ColumnType.TEXT.name)
            )
        }
    }
}
