package com.example

import com.example.files.LocalFileManager
import org.junit.Assert.assertEquals
import org.junit.Test

class LocalFileManagerTest {

    @Test
    fun splitFileName_extractsTitleAndExtension() {
        val (title, ext) = LocalFileManager.splitFileName("script_ku.py")
        assertEquals("script_ku", title)
        assertEquals("py", ext)
    }

    @Test
    fun splitFileName_handlesMultipleDots() {
        val (title, ext) = LocalFileManager.splitFileName("app.config.json")
        assertEquals("app.config", title)
        assertEquals("json", ext)
    }

    @Test
    fun splitFileName_defaultsToTxtWhenNoExtension() {
        val (title, ext) = LocalFileManager.splitFileName("README")
        assertEquals("README", title)
        assertEquals("txt", ext)
    }

    @Test
    fun splitFileName_normalizesUppercaseExtension() {
        val (title, ext) = LocalFileManager.splitFileName("INDEX.HTML")
        assertEquals("INDEX", title)
        assertEquals("html", ext)
    }
}
