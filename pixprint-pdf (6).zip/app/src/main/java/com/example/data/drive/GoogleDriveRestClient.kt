package com.example.data.drive

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class DriveUnauthorizedException(message: String) : IOException(message)

data class RemoteDriveSyncFile(
    val fileId: String,
    val content: String
)

interface DriveRemoteDataSource {
    suspend fun ensureFolder(
        accessToken: String,
        folderName: String,
        cachedFolderId: String = ""
    ): String

    suspend fun downloadSyncJson(
        accessToken: String,
        folderId: String,
        fileName: String,
        cachedFileId: String = ""
    ): RemoteDriveSyncFile?

    suspend fun uploadSyncJson(
        accessToken: String,
        folderId: String,
        existingFileId: String?,
        fileName: String,
        jsonContent: String
    ): String

    suspend fun uploadPdfFile(
        accessToken: String,
        folderId: String,
        existingFileId: String?,
        fileName: String,
        pdfBytes: ByteArray
    ): String
}

class GoogleDriveRestClient(
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
) : DriveRemoteDataSource {

    override suspend fun ensureFolder(
        accessToken: String,
        folderName: String,
        cachedFolderId: String
    ): String = withContext(Dispatchers.IO) {
        if (cachedFolderId.isNotBlank() && isActiveDriveItem(accessToken, cachedFolderId)) {
            return@withContext cachedFolderId
        }

        val escapedName = escapeDriveQueryLiteral(folderName)
        val query = "mimeType = '$FOLDER_MIME_TYPE' and name = '$escapedName' and trashed = false"
        val existingId = findFirstFileId(accessToken, query)
        if (!existingId.isNullOrBlank()) {
            return@withContext existingId
        }

        val createMetadata = JSONObject().apply {
            put("name", folderName)
            put("mimeType", FOLDER_MIME_TYPE)
        }
        val url = "$DRIVE_FILES_ENDPOINT?fields=id,name"
        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $accessToken")
            .post(createMetadata.toString().toRequestBody(JSON_MEDIA_TYPE))
            .build()

        executeJsonRequest(request).getString("id")
    }

    override suspend fun downloadSyncJson(
        accessToken: String,
        folderId: String,
        fileName: String,
        cachedFileId: String
    ): RemoteDriveSyncFile? = withContext(Dispatchers.IO) {
        val candidateId = if (cachedFileId.isNotBlank() && isActiveDriveItem(accessToken, cachedFileId)) {
            cachedFileId
        } else {
            val escapedFolder = escapeDriveQueryLiteral(folderId)
            val escapedName = escapeDriveQueryLiteral(fileName)
            val query = "'$escapedFolder' in parents and name = '$escapedName' and trashed = false"
            findFirstFileId(accessToken, query)
        }

        if (candidateId.isNullOrBlank()) {
            return@withContext null
        }

        val downloadUrl = "$DRIVE_FILES_ENDPOINT/$candidateId".toHttpUrl().newBuilder()
            .addQueryParameter("alt", "media")
            .build()

        val request = Request.Builder()
            .url(downloadUrl)
            .addHeader("Authorization", "Bearer $accessToken")
            .get()
            .build()

        httpClient.newCall(request).execute().use { response ->
            when {
                response.code == 401 -> throw DriveUnauthorizedException("Sesi Google Drive kedaluwarsa (401)")
                response.code == 404 -> null
                !response.isSuccessful -> {
                    val err = response.body?.string()?.take(240).orEmpty()
                    throw IOException("Gagal mengunduh data Drive (${response.code}): $err")
                }
                else -> {
                    val bodyText = response.body?.string().orEmpty()
                    RemoteDriveSyncFile(fileId = candidateId, content = bodyText)
                }
            }
        }
    }

    override suspend fun uploadSyncJson(
        accessToken: String,
        folderId: String,
        existingFileId: String?,
        fileName: String,
        jsonContent: String
    ): String = withContext(Dispatchers.IO) {
        val payloadBytes = jsonContent.toByteArray(Charsets.UTF_8)
        upsertDriveFile(
            accessToken = accessToken,
            folderId = folderId,
            existingFileId = existingFileId,
            fileName = fileName,
            mimeType = "application/json",
            contentTypeHeader = "application/json; charset=UTF-8",
            contentBytes = payloadBytes
        )
    }

    override suspend fun uploadPdfFile(
        accessToken: String,
        folderId: String,
        existingFileId: String?,
        fileName: String,
        pdfBytes: ByteArray
    ): String = withContext(Dispatchers.IO) {
        upsertDriveFile(
            accessToken = accessToken,
            folderId = folderId,
            existingFileId = existingFileId,
            fileName = fileName,
            mimeType = "application/pdf",
            contentTypeHeader = "application/pdf",
            contentBytes = pdfBytes
        )
    }

    private fun upsertDriveFile(
        accessToken: String,
        folderId: String,
        existingFileId: String?,
        fileName: String,
        mimeType: String,
        contentTypeHeader: String,
        contentBytes: ByteArray
    ): String {
        val resolvedId = if (!existingFileId.isNullOrBlank() && isActiveDriveItem(accessToken, existingFileId)) {
            existingFileId
        } else {
            val escapedFolder = escapeDriveQueryLiteral(folderId)
            val escapedName = escapeDriveQueryLiteral(fileName)
            val query = "'$escapedFolder' in parents and name = '$escapedName' and trashed = false"
            findFirstFileId(accessToken, query)
        }

        if (!resolvedId.isNullOrBlank()) {
            val patchUrl = "$DRIVE_UPLOAD_ENDPOINT/$resolvedId?uploadType=media&fields=id,name"
            val patchRequest = Request.Builder()
                .url(patchUrl)
                .addHeader("Authorization", "Bearer $accessToken")
                .patch(contentBytes.toRequestBody(contentTypeHeader.toMediaType()))
                .build()

            httpClient.newCall(patchRequest).execute().use { response ->
                when {
                    response.code == 401 -> throw DriveUnauthorizedException("Sesi Google Drive kedaluwarsa (401)")
                    response.isSuccessful -> {
                        val raw = response.body?.string().orEmpty()
                        return JSONObject(raw).optString("id", resolvedId)
                    }
                    response.code != 404 -> {
                        val err = response.body?.string()?.take(240).orEmpty()
                        throw IOException("Gagal memperbarui file Drive (${response.code}): $err")
                    }
                }
            }
        }

        val metadata = JSONObject().apply {
            put("name", fileName)
            put("mimeType", mimeType)
            put("parents", JSONArray().put(folderId))
        }
        val multipartBody = buildMultipartRelatedBody(
            metadataJson = metadata.toString(),
            mediaContentType = contentTypeHeader,
            mediaBytes = contentBytes
        )
        val createUrl = "$DRIVE_UPLOAD_ENDPOINT?uploadType=multipart&fields=id,name"
        val createRequest = Request.Builder()
            .url(createUrl)
            .addHeader("Authorization", "Bearer $accessToken")
            .post(multipartBody)
            .build()

        return executeJsonRequest(createRequest).getString("id")
    }

    private fun isActiveDriveItem(accessToken: String, fileId: String): Boolean {
        val url = "$DRIVE_FILES_ENDPOINT/$fileId".toHttpUrl().newBuilder()
            .addQueryParameter("fields", "id,trashed")
            .build()
        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $accessToken")
            .get()
            .build()

        httpClient.newCall(request).execute().use { response ->
            if (response.code == 401) {
                throw DriveUnauthorizedException("Sesi Google Drive kedaluwarsa (401)")
            }
            if (!response.isSuccessful) return false
            val body = response.body?.string().orEmpty()
            val json = runCatching { JSONObject(body) }.getOrNull() ?: return false
            return !json.optBoolean("trashed", false) && json.optString("id").isNotBlank()
        }
    }

    private fun findFirstFileId(accessToken: String, query: String): String? {
        val url = DRIVE_FILES_ENDPOINT.toHttpUrl().newBuilder()
            .addQueryParameter("q", query)
            .addQueryParameter("spaces", "drive")
            .addQueryParameter("fields", "files(id,name,modifiedTime)")
            .addQueryParameter("orderBy", "modifiedTime desc")
            .addQueryParameter("pageSize", "5")
            .build()

        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $accessToken")
            .get()
            .build()

        val json = executeJsonRequest(request)
        val files = json.optJSONArray("files") ?: return null
        if (files.length() == 0) return null
        return files.optJSONObject(0)?.optString("id")?.takeIf { it.isNotBlank() }
    }

    private fun executeJsonRequest(request: Request): JSONObject {
        httpClient.newCall(request).execute().use { response ->
            val rawBody = response.body?.string().orEmpty()
            if (response.code == 401) {
                throw DriveUnauthorizedException("Sesi Google Drive kedaluwarsa (401)")
            }
            if (!response.isSuccessful) {
                throw IOException(
                    "Permintaan Google Drive gagal (${response.code}): ${rawBody.take(240)}"
                )
            }
            return if (rawBody.isBlank()) JSONObject() else JSONObject(rawBody)
        }
    }

    companion object {
        private const val DRIVE_FILES_ENDPOINT = "https://www.googleapis.com/drive/v3/files"
        private const val DRIVE_UPLOAD_ENDPOINT = "https://www.googleapis.com/upload/drive/v3/files"
        private const val FOLDER_MIME_TYPE = "application/vnd.google-apps.folder"
        private val JSON_MEDIA_TYPE = "application/json; charset=UTF-8".toMediaType()

        internal fun escapeDriveQueryLiteral(value: String): String {
            return value
                .replace("\\", "\\\\")
                .replace("'", "\\'")
        }

        internal fun buildMultipartRelatedBody(
            metadataJson: String,
            mediaContentType: String,
            mediaBytes: ByteArray
        ): RequestBody {
            val boundary = "cetak_resi_${UUID.randomUUID().toString().replace("-", "")}"
            val crlf = "\r\n".toByteArray(Charsets.UTF_8)
            val stream = ByteArrayOutputStream(metadataJson.length + mediaBytes.size + 256)

            stream.write("--$boundary\r\n".toByteArray(Charsets.UTF_8))
            stream.write("Content-Type: application/json; charset=UTF-8\r\n\r\n".toByteArray(Charsets.UTF_8))
            stream.write(metadataJson.toByteArray(Charsets.UTF_8))
            stream.write(crlf)

            stream.write("--$boundary\r\n".toByteArray(Charsets.UTF_8))
            stream.write("Content-Type: $mediaContentType\r\n\r\n".toByteArray(Charsets.UTF_8))
            stream.write(mediaBytes)
            stream.write(crlf)

            stream.write("--$boundary--\r\n".toByteArray(Charsets.UTF_8))

            return stream.toByteArray().toRequestBody(
                "multipart/related; boundary=$boundary".toMediaType()
            )
        }
    }
}
