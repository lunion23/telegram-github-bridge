package com.example.data

import com.example.base.FirestoreEmulatorTestBase
import com.example.model.PaperSizePreset
import com.example.model.ShippingLabelData
import com.google.firebase.firestore.FirebaseFirestoreException
import java.util.UUID
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class ShippingLabelRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun createGetPinUpdateAndDeleteLabel_authenticatedOwner_succeeds() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val repository = ShippingLabelRepository(firestore, auth)

        val uniqueWaybill = "JD-${UUID.randomUUID().toString().take(8).uppercase()}"
        val sampleData = ShippingLabelData.defaultFromReferenceImage().copy(
            waybillNumber = uniqueWaybill,
            recipientName = "Andi Pratama"
        )

        val createResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createLabel(
                data = sampleData,
                paperPreset = PaperSizePreset.THERMAL_100X200,
                customTitle = "Paket Batam Andi"
            )
        }
        assertTrue("Create should succeed: ${createResult.exceptionOrNull()}", createResult.isSuccess)
        val createdId = createResult.getOrThrow()
        assertTrue(createdId.isNotBlank())

        // Observe via Flow
        val observedList = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeLabels(aliceUid).first { list -> list.any { it.id == createdId } }
        }
        val fetched = observedList.first { it.id == createdId }
        assertEquals(uniqueWaybill, fetched.waybillNumber)
        assertFalse(fetched.pinned)
        assertNotNull(fetched.createdAt)

        // Pin toggle (Action 1)
        val pinResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.setLabelPinned(createdId, true)
        }
        assertTrue("Pin toggle should succeed: ${pinResult.exceptionOrNull()}", pinResult.isSuccess)

        // Full update (Action 2) preserving createdAt
        val afterPin = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.getLabelById(aliceUid, createdId).getOrThrow()
        }
        assertNotNull(afterPin)
        assertTrue(afterPin!!.pinned)

        val updateResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.updateLabel(afterPin.copy(recipientName = "Andi Pratama Updated"))
        }
        assertTrue("Full update should succeed: ${updateResult.exceptionOrNull()}", updateResult.isSuccess)

        val afterUpdate = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.getLabelById(aliceUid, createdId).getOrThrow()
        }
        assertEquals("Andi Pratama Updated", afterUpdate?.recipientName)

        // Delete
        val deleteResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.deleteLabel(createdId)
        }
        assertTrue("Delete should succeed", deleteResult.isSuccess)
    }

    @Test
    fun getLabelById_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = ShippingLabelRepository(firestore, auth)
        val labelId = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.createLabel(
                data = ShippingLabelData.defaultFromReferenceImage(),
                paperPreset = PaperSizePreset.THERMAL_100X200
            ).getOrThrow()
        }

        // Switch to Bob and attempt to read Alice's PII shipping label
        signInTestUser(BOB_EMAIL)
        val bobRepo = ShippingLabelRepository(firestore, auth)
        val crossReadResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.getLabelById(aliceUid, labelId)
        }
        assertTrue("Cross-user read must fail", crossReadResult.isFailure)
        val fsEx = crossReadResult.exceptionOrNull()?.unwrapFirestoreException()
        assertNotNull("Expected FirebaseFirestoreException", fsEx)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
    }

    @Test
    fun observeLabels_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        auth.signOut()
        val repository = ShippingLabelRepository(firestore, auth)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeLabels(aliceUid).first()
            }
            fail("Expected observeLabels while signed out to throw PERMISSION_DENIED")
        } catch (e: Exception) {
            val fsEx = e.unwrapFirestoreException()
            assertNotNull("Expected wrapped FirebaseFirestoreException, got $e", fsEx)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
        }
    }

    private companion object {
        const val ALICE_EMAIL = "alice@cetakresi.test"
        const val BOB_EMAIL = "bob@cetakresi.test"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
