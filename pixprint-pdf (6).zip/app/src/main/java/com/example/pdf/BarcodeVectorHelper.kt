package com.example.pdf

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.oned.Code128Writer
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import kotlin.math.min

/**
 * Thread-safe vector 1D Code 128 and 2D QR Code renderer for Android [Canvas] and [android.graphics.pdf.PdfDocument].
 */
object BarcodeVectorHelper {

    private fun createBarPaint(): Paint = Paint().apply {
        color = Color.BLACK
        style = Paint.Style.FILL
        isAntiAlias = false
    }

    /**
     * Sanitizes waybill text for Code 128 (printable ASCII 32..126, max 80 chars per ZXing spec)
     * so pasted strings containing invisible Unicode marks (e.g. zero-width spaces) still encode accurately.
     */
    fun sanitizeForCode128(raw: String): String {
        val cleaned = raw.filter { it.code in 32..126 }.trim().take(80)
        return cleaned.ifEmpty { "JD0600216038" }
    }

    /**
     * Draws a crisp 1D Code 128 barcode filling [left]..[right] and [top]..[bottom].
     */
    fun drawCode128(
        canvas: Canvas,
        content: String,
        left: Float,
        top: Float,
        right: Float,
        bottom: Float
    ) {
        if (right <= left || bottom <= top) return
        val barPaint = createBarPaint()
        val safeContent = sanitizeForCode128(content)
        val encoded: BooleanArray = try {
            Code128Writer().encode(safeContent)
        } catch (_: Exception) {
            Code128Writer().encode("JD0600216038")
        }

        val totalModules = encoded.size
        if (totalModules == 0) return

        val availableWidth = right - left
        val moduleWidth = availableWidth / totalModules.toFloat()

        var i = 0
        while (i < totalModules) {
            if (encoded[i]) {
                var runEnd = i + 1
                while (runEnd < totalModules && encoded[runEnd]) {
                    runEnd++
                }
                val barLeft = left + i * moduleWidth
                val barRight = left + runEnd * moduleWidth
                canvas.drawRect(barLeft, top, barRight, bottom, barPaint)
                i = runEnd
            } else {
                i++
            }
        }
    }

    /**
     * Draws a crisp 2D QR Code filling the square [left], [top] with side length [size].
     */
    fun drawQrCode(
        canvas: Canvas,
        content: String,
        left: Float,
        top: Float,
        size: Float
    ) {
        if (size <= 0f) return
        val barPaint = createBarPaint()
        val safeContent = content.trim().ifEmpty { "JD0600216038" }
        val hints = mapOf(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.L,
            EncodeHintType.MARGIN to 0,
            EncodeHintType.CHARACTER_SET to "UTF-8"
        )

        val matrix = try {
            QRCodeWriter().encode(safeContent, BarcodeFormat.QR_CODE, 1, 1, hints)
        } catch (_: Exception) {
            QRCodeWriter().encode("JD0600216038", BarcodeFormat.QR_CODE, 1, 1, hints)
        }

        val matrixW = matrix.width
        val matrixH = matrix.height
        if (matrixW <= 0 || matrixH <= 0) return

        val cellW = size / matrixW.toFloat()
        val cellH = size / matrixH.toFloat()
        val maxRight = left + size
        val maxBottom = top + size

        for (y in 0 until matrixH) {
            val rowTop = top + y * cellH
            val rowBottom = min(maxBottom, top + (y + 1) * cellH + 0.05f)
            var x = 0
            while (x < matrixW) {
                if (matrix.get(x, y)) {
                    var runEnd = x + 1
                    while (runEnd < matrixW && matrix.get(runEnd, y)) {
                        runEnd++
                    }
                    val rectLeft = left + x * cellW
                    val rectRight = min(maxRight, left + runEnd * cellW + 0.05f)
                    canvas.drawRect(rectLeft, rowTop, rectRight, rowBottom, barPaint)
                    x = runEnd
                } else {
                    x++
                }
            }
        }
    }
}
