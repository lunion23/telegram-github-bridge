package com.example.ui.screens

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.model.ReplacementPart
import com.example.model.TechnicalReport
import com.example.ui.components.LabeledCheckbox
import com.example.ui.components.SectionContainer
import com.example.ui.components.StyledInputField
import com.example.ui.theme.IndustrialBlue
import com.example.ui.theme.SafetyAmber
import com.example.viewmodel.ReportViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FormEditScreen(
    viewModel: ReportViewModel,
    modifier: Modifier = Modifier
) {
    val report by viewModel.activeReport.collectAsState()
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }

    // Intercept back button to return to history
    BackHandler {
        viewModel.navigateToHistory()
    }

    // Photo pickers
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let { viewModel.onPhotoSelected(it) }
    }

    // Camera launcher
    var tempCameraUri by remember { mutableStateOf<Uri?>(null) }
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success: Boolean ->
        if (success) {
            tempCameraUri?.let { viewModel.onPhotoSelected(it) }
        }
    }

    fun launchCamera() {
        val imagesDir = File(context.filesDir, "images")
        if (!imagesDir.exists()) imagesDir.mkdirs()
        val tempFile = File(imagesDir, "temp_camera_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            tempFile
        )
        tempCameraUri = uri
        cameraLauncher.launch(uri)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (report.id == 0L) "Buat Laporan Baru" else "Edit Laporan",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = report.reportNumber,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateToHistory() }) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.saveActiveReport(andPreview = false) },
                        modifier = Modifier.testTag("btn_save_draft_top")
                    ) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = "Simpan")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            SurfaceBottomBar(
                onSaveDraft = { viewModel.saveActiveReport(andPreview = false) },
                onPreviewPdf = { viewModel.saveActiveReport(andPreview = true) }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Tab Row for easy organization
            val tabs = listOf("Identitas & Kerusakan", "Analisa & Foto", "Penyebab & Solusi", "Suku Cadang & TTD")
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = IndustrialBlue
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 12.sp,
                                maxLines = 1,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                when (selectedTab) {
                    0 -> {
                        item {
                            Tab1IdentitasDanUnit(
                                report = report,
                                onUpdate = { viewModel.updateActiveReport(it) }
                            )
                        }
                    }
                    1 -> {
                        item {
                            Tab2AnalisaDanFoto(
                                report = report,
                                onUpdate = { viewModel.updateActiveReport(it) },
                                onPickGallery = {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                onPickCamera = { launchCamera() },
                                context = context
                            )
                        }
                    }
                    2 -> {
                        item {
                            Tab3PenyebabDanSolusi(
                                report = report,
                                onUpdate = { viewModel.updateActiveReport(it) }
                            )
                        }
                    }
                    3 -> {
                        item {
                            Tab4PartsDanSignature(
                                report = report,
                                onUpdate = { viewModel.updateActiveReport(it) },
                                onAddPart = { viewModel.addPartItem(it) },
                                onRemovePart = { viewModel.removePartItem(it) },
                                onUpdatePart = { index, part -> viewModel.updatePartItem(index, part) }
                            )
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(80.dp))
                }
            }
        }
    }
}

@Composable
private fun SurfaceBottomBar(
    onSaveDraft: () -> Unit,
    onPreviewPdf: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(
                onClick = onSaveDraft,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("btn_save_draft"),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Simpan Draf")
            }

            Button(
                onClick = onPreviewPdf,
                modifier = Modifier
                    .weight(1.3f)
                    .height(48.dp)
                    .testTag("btn_preview_pdf"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = IndustrialBlue)
            ) {
                Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Pratinjau PDF", fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ================= TAB 1: IDENTITAS PERUSAHAAN & UNIT =================
@Composable
private fun Tab1IdentitasDanUnit(
    report: TechnicalReport,
    onUpdate: (TechnicalReport) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionContainer(title = "Kop & Identitas Laporan", icon = Icons.Default.Description) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StyledInputField(
                    label = "Nama Perusahaan",
                    value = report.companyName,
                    onValueChange = { onUpdate(report.copy(companyName = it)) },
                    modifier = Modifier.weight(1f),
                    tag = "input_company_name"
                )
                StyledInputField(
                    label = "Judul Dokumen",
                    value = report.reportTitle,
                    onValueChange = { onUpdate(report.copy(reportTitle = it)) },
                    modifier = Modifier.weight(1f),
                    tag = "input_report_title"
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StyledInputField(
                    label = "No. Laporan",
                    value = report.reportNumber,
                    onValueChange = { onUpdate(report.copy(reportNumber = it)) },
                    modifier = Modifier.weight(1.2f),
                    tag = "input_report_number"
                )
                StyledInputField(
                    label = "Bengkel",
                    value = report.workshop,
                    onValueChange = { onUpdate(report.copy(workshop = it)) },
                    modifier = Modifier.weight(1f),
                    tag = "input_workshop"
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StyledInputField(
                    label = "Tanggal",
                    value = report.date,
                    onValueChange = { onUpdate(report.copy(date = it)) },
                    modifier = Modifier.weight(1f),
                    tag = "input_date"
                )
                StyledInputField(
                    label = "Nama Alat",
                    value = report.toolName,
                    onValueChange = { onUpdate(report.copy(toolName = it)) },
                    modifier = Modifier.weight(1f),
                    placeholder = "Misal: Ban",
                    tag = "input_tool_name"
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            StyledInputField(
                label = "Komponen",
                value = report.component,
                onValueChange = { onUpdate(report.copy(component = it)) },
                placeholder = "Misal: Underbody",
                tag = "input_component"
            )
        }

        SectionContainer(title = "Data Kendaraan / Armada", icon = Icons.Default.DirectionsBus) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StyledInputField(
                    label = "Pabrik Pembuat",
                    value = report.manufacturer,
                    onValueChange = { onUpdate(report.copy(manufacturer = it)) },
                    modifier = Modifier.weight(1f),
                    placeholder = "HINO",
                    tag = "input_manufacturer"
                )
                StyledInputField(
                    label = "Tipe",
                    value = report.vehicleType,
                    onValueChange = { onUpdate(report.copy(vehicleType = it)) },
                    modifier = Modifier.weight(1f),
                    placeholder = "DUTRO",
                    tag = "input_vehicle_type"
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StyledInputField(
                    label = "Model",
                    value = report.model,
                    onValueChange = { onUpdate(report.copy(model = it)) },
                    modifier = Modifier.weight(1.2f),
                    placeholder = "W04DTPJ-53447",
                    tag = "input_model"
                )
                StyledInputField(
                    label = "Kode Unit",
                    value = report.unitCode,
                    onValueChange = { onUpdate(report.copy(unitCode = it)) },
                    modifier = Modifier.weight(1f),
                    placeholder = "D127",
                    tag = "input_unit_code"
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StyledInputField(
                    label = "Tanggal Rusak",
                    value = report.damageDate,
                    onValueChange = { onUpdate(report.copy(damageDate = it)) },
                    modifier = Modifier.weight(1f),
                    tag = "input_damage_date"
                )
                StyledInputField(
                    label = "Km / Hm",
                    value = report.odometer,
                    onValueChange = { onUpdate(report.copy(odometer = it)) },
                    modifier = Modifier.weight(1f),
                    placeholder = "598916",
                    tag = "input_odometer"
                )
            }
        }
    }
}

// ================= TAB 2: ANALISA, RIWAYAT SERVIS & FOTO =================
@Composable
private fun Tab2AnalisaDanFoto(
    report: TechnicalReport,
    onUpdate: (TechnicalReport) -> Unit,
    onPickGallery: () -> Unit,
    onPickCamera: () -> Unit,
    context: Context
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionContainer(title = "Uraian Kerusakan & Garansi", icon = Icons.Default.Warning) {
            Text("Status Garansi Unit:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FilterChip(
                    selected = report.warrantyStatus == "MASA_GARANSI",
                    onClick = { onUpdate(report.copy(warrantyStatus = "MASA_GARANSI")) },
                    label = { Text("Masa Garansi") }
                )
                FilterChip(
                    selected = report.warrantyStatus == "SETELAH_GARANSI",
                    onClick = { onUpdate(report.copy(warrantyStatus = "SETELAH_GARANSI")) },
                    label = { Text("Setelah Masa Garansi") }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StyledInputField(
                    label = "Status Pelaporan",
                    value = report.status,
                    onValueChange = { onUpdate(report.copy(status = it)) },
                    modifier = Modifier.weight(1f),
                    placeholder = "Storing / Perbaikan Bengkel",
                    tag = "input_status"
                )
                StyledInputField(
                    label = "Kerusakan",
                    value = report.damageDescription,
                    onValueChange = { onUpdate(report.copy(damageDescription = it)) },
                    modifier = Modifier.weight(1.3f),
                    placeholder = "Misal: Ban kempes",
                    tag = "input_damage_desc"
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            StyledInputField(
                label = "Lokasi Kerusakan",
                value = report.damageLocation,
                onValueChange = { onUpdate(report.copy(damageLocation = it)) },
                placeholder = "Misal: Tol tangerang - merak",
                tag = "input_damage_location"
            )

            Spacer(modifier = Modifier.height(10.dp))
            StyledInputField(
                label = "Analisa Kejadian & Kondisi",
                value = report.analysis,
                onValueChange = { onUpdate(report.copy(analysis = it)) },
                singleLine = false,
                maxLines = 4,
                placeholder = "Setelah dilakukan storing oleh team, ditemukan...",
                tag = "input_analysis"
            )
        }

        SectionContainer(title = "Lampiran Foto Kerusakan", icon = Icons.Default.Image) {
            Text(
                text = "Foto ini akan otomatis dicetak pada kolom 'Foto Kerusakan' di lembar PDF.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Photo Preview box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                val photoPath = report.photoPath
                val bitmap = remember(photoPath) {
                    if (photoPath != null) {
                        try {
                            when {
                                photoPath == "sample_damage.jpg" || photoPath.contains("sample_damage") -> {
                                    try {
                                        context.assets.open("sample_damage.jpg").use { input ->
                                            BitmapFactory.decodeStream(input)
                                        }
                                    } catch (_: Exception) {
                                        val f = File(photoPath)
                                        if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
                                    }
                                }
                                photoPath.startsWith("/") -> {
                                    val f = File(photoPath)
                                    if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
                                }
                                else -> {
                                    val f = File(context.filesDir, photoPath)
                                    if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
                                }
                            }
                        } catch (_: Exception) {
                            null
                        }
                    } else null
                }

                if (bitmap != null) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = "Foto Kerusakan",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.Image, contentDescription = null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Belum ada foto kerusakan yang dilampirkan", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onPickCamera,
                    modifier = Modifier.weight(1f).testTag("btn_take_camera_photo")
                ) {
                    Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Kamera")
                }

                OutlinedButton(
                    onClick = onPickGallery,
                    modifier = Modifier.weight(1f).testTag("btn_pick_gallery_photo")
                ) {
                    Icon(imageVector = Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Galeri")
                }

                if (report.photoPath != null) {
                    OutlinedButton(
                        onClick = { onUpdate(report.copy(photoPath = null)) },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.testTag("btn_delete_photo")
                    ) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Hapus Foto", modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        SectionContainer(title = "Riwayat Penggantian & Servis", icon = Icons.Default.History) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StyledInputField(
                    label = "Penggantian Terakhir",
                    value = report.lastReplacement,
                    onValueChange = { onUpdate(report.copy(lastReplacement = it)) },
                    modifier = Modifier.weight(1.2f),
                    placeholder = "9-5-2022 (km.415513)",
                    tag = "input_last_replacement"
                )
                StyledInputField(
                    label = "No. Work Order",
                    value = report.lastReplacementWo,
                    onValueChange = { onUpdate(report.copy(lastReplacementWo = it)) },
                    modifier = Modifier.weight(1f),
                    placeholder = "KLD1-WO-2205-00381",
                    tag = "input_last_replacement_wo"
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StyledInputField(
                    label = "Weekly Terakhir",
                    value = report.lastWeekly,
                    onValueChange = { onUpdate(report.copy(lastWeekly = it)) },
                    modifier = Modifier.weight(1.2f),
                    placeholder = "5-3-2026 (km.598234)",
                    tag = "input_last_weekly"
                )
                StyledInputField(
                    label = "No. Work Order",
                    value = report.lastWeeklyWo,
                    onValueChange = { onUpdate(report.copy(lastWeeklyWo = it)) },
                    modifier = Modifier.weight(1f),
                    placeholder = "CLG1-WO-2603-00225",
                    tag = "input_last_weekly_wo"
                )
            }
        }
    }
}

// ================= TAB 3: PENYEBAB & SOLUSI KERUSAKAN =================
@Composable
private fun Tab3PenyebabDanSolusi(
    report: TechnicalReport,
    onUpdate: (TechnicalReport) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionContainer(title = "Penyebab Kerusakan", icon = Icons.Default.FactCheck) {
            Text(
                text = "Pilih faktor penyebab (√ = YA):",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))

            LabeledCheckbox(
                label = "1. Pemasangan",
                checked = report.causePemasangan,
                onCheckedChange = { onUpdate(report.copy(causePemasangan = it)) },
                modifier = Modifier.fillMaxWidth()
            )
            LabeledCheckbox(
                label = "2. Kwalitas Parts",
                checked = report.causeKwalitasParts,
                onCheckedChange = { onUpdate(report.copy(causeKwalitasParts = it)) },
                modifier = Modifier.fillMaxWidth()
            )
            LabeledCheckbox(
                label = "3. Kesalahan Operasional",
                checked = report.causeKesalahanOperasional,
                onCheckedChange = { onUpdate(report.copy(causeKesalahanOperasional = it)) },
                modifier = Modifier.fillMaxWidth()
            )
            LabeledCheckbox(
                label = "4. Sudah waktunya (Aus / Usia Pakai)",
                checked = report.causeSudahWaktunya,
                onCheckedChange = { onUpdate(report.copy(causeSudahWaktunya = it)) },
                modifier = Modifier.fillMaxWidth()
            )
            LabeledCheckbox(
                label = "5. Lain-lain",
                checked = report.causeLainLain,
                onCheckedChange = { onUpdate(report.copy(causeLainLain = it)) },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))
            StyledInputField(
                label = "Penjelasan Penyebab (Jika YA)",
                value = report.causeExplanation,
                onValueChange = { onUpdate(report.copy(causeExplanation = it)) },
                singleLine = false,
                maxLines = 3,
                placeholder = "Jelaskan detail penyebab kondisi...",
                tag = "input_cause_explanation"
            )
        }

        SectionContainer(title = "Cara Mengatasi Kerusakan", icon = Icons.Default.Build) {
            LabeledCheckbox(
                label = "1. Ganti Part Baru",
                checked = report.solutionGantiPartBaru,
                onCheckedChange = { onUpdate(report.copy(solutionGantiPartBaru = it)) },
                modifier = Modifier.fillMaxWidth()
            )
            LabeledCheckbox(
                label = "2. Pemasangan atau Penyetelan Ulang",
                checked = report.solutionPemasanganUlang,
                onCheckedChange = { onUpdate(report.copy(solutionPemasanganUlang = it)) },
                modifier = Modifier.fillMaxWidth()
            )
            LabeledCheckbox(
                label = "3. Modifikasi",
                checked = report.solutionModifikasi,
                onCheckedChange = { onUpdate(report.copy(solutionModifikasi = it)) },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))
            StyledInputField(
                label = "Tindakan Perbaikan",
                value = report.solutionActionText,
                onValueChange = { onUpdate(report.copy(solutionActionText = it)) },
                placeholder = "Misal: Ganti ban stip",
                tag = "input_solution_action"
            )
        }

        SectionContainer(title = "Tertunda Karena & Usulan Pelapor", icon = Icons.Default.Lightbulb) {
            StyledInputField(
                label = "Tertunda Karena (Bila Ada)",
                value = report.delayedReason,
                onValueChange = { onUpdate(report.copy(delayedReason = it)) },
                placeholder = "Misal: Menunggu pengiriman suku cadang",
                tag = "input_delayed_reason"
            )

            Spacer(modifier = Modifier.height(10.dp))
            StyledInputField(
                label = "Usulan Pelapor",
                value = report.reporterSuggestion,
                onValueChange = { onUpdate(report.copy(reporterSuggestion = it)) },
                singleLine = false,
                maxLines = 3,
                placeholder = "Usulan pencegahan agar tidak terulang...",
                tag = "input_reporter_suggestion"
            )
        }
    }
}

// ================= TAB 4: SUKU CADANG & TANDA TANGAN =================
@Composable
private fun Tab4PartsDanSignature(
    report: TechnicalReport,
    onUpdate: (TechnicalReport) -> Unit,
    onAddPart: (ReplacementPart) -> Unit,
    onRemovePart: (Int) -> Unit,
    onUpdatePart: (Int, ReplacementPart) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionContainer(title = "Parts Yang Harus Diganti (Maks. 5 baris)", icon = Icons.Default.ContentPaste) {
            if (report.parts.isEmpty()) {
                Text(
                    text = "Belum ada suku cadang yang dicatat.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                report.parts.forEachIndexed { index, part ->
                    PartItemRow(
                        index = index,
                        part = part,
                        onUpdate = { onUpdatePart(index, it) },
                        onDelete = { onRemovePart(index) }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }

            if (report.parts.size < 5) {
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedButton(
                    onClick = {
                        onAddPart(
                            ReplacementPart(
                                partNumber = "",
                                partName = "",
                                procurementType = "Stock"
                            )
                        )
                    },
                    modifier = Modifier.fillMaxWidth().testTag("btn_add_part_row")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Tambah Baris Suku Cadang (${report.parts.size}/5)")
                }
            }
        }

        SectionContainer(title = "Pengesahan & Tanda Tangan", icon = Icons.Default.Person) {
            Text("Mengetahui :", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StyledInputField(
                    label = "Pihak Mengetahui 1",
                    value = report.knownBy1,
                    onValueChange = { onUpdate(report.copy(knownBy1 = it)) },
                    modifier = Modifier.weight(1f),
                    placeholder = "Misal: Kepala Bengkel",
                    tag = "input_known_by_1"
                )
                StyledInputField(
                    label = "Pihak Mengetahui 2",
                    value = report.knownBy2,
                    onValueChange = { onUpdate(report.copy(knownBy2 = it)) },
                    modifier = Modifier.weight(1f),
                    placeholder = "Misal: Ka. Operasional",
                    tag = "input_known_by_2"
                )
            }

            Spacer(modifier = Modifier.height(14.dp))
            Text("Dilaporkan Oleh :", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StyledInputField(
                    label = "Nama Pelapor",
                    value = report.reporterName,
                    onValueChange = { onUpdate(report.copy(reporterName = it)) },
                    modifier = Modifier.weight(1.2f),
                    placeholder = "Yudi Indrawan",
                    tag = "input_reporter_name"
                )
                StyledInputField(
                    label = "Jabatan Pelapor",
                    value = report.reporterTitle,
                    onValueChange = { onUpdate(report.copy(reporterTitle = it)) },
                    modifier = Modifier.weight(1f),
                    placeholder = "Wa.Ka.Bengkel",
                    tag = "input_reporter_title"
                )
            }
        }
    }
}

@Composable
private fun PartItemRow(
    index: Int,
    part: ReplacementPart,
    onUpdate: (ReplacementPart) -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Baris #${index + 1}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = IndustrialBlue
                )
                IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Hapus", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StyledInputField(
                    label = "No Parts",
                    value = part.partNumber,
                    onValueChange = { onUpdate(part.copy(partNumber = it)) },
                    modifier = Modifier.weight(1f),
                    tag = "input_part_no_$index"
                )
                StyledInputField(
                    label = "Nama Parts",
                    value = part.partName,
                    onValueChange = { onUpdate(part.copy(partName = it)) },
                    modifier = Modifier.weight(1.5f),
                    tag = "input_part_name_$index"
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text("Pengadaan Part:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val types = listOf("Stock", "Order", "Modifikasi", "Pending")
                types.forEach { t ->
                    FilterChip(
                        selected = part.procurementType.equals(t, ignoreCase = true),
                        onClick = { onUpdate(part.copy(procurementType = t)) },
                        label = { Text(t, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = IndustrialBlue,
                            selectedLabelColor = androidx.compose.ui.graphics.Color.White
                        )
                    )
                }
            }
        }
    }
}
