package com.example.util

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.Locale

/**
 * Data class yang merepresentasikan informasi metadata video.
 */
data class VideoMetadata(
    val uri: Uri,
    val title: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val sizeBytes: Long,
    val mimeType: String? = "video/mp4"
) {
    val durationSeconds: Double
        get() = durationMs / 1000.0

    val formattedDuration: String
        get() = MediaUtils.formatSeconds(durationSeconds)
}

/**
 * Utilitas untuk ekstraksi metadata video, formatting waktu,
 * dan penyediaan fallback trimming native berbasis MediaMuxer.
 */
object MediaUtils {

    private const val TAG = "MediaUtils"

    /**
     * Memformat detik menjadi string HH:MM:SS atau MM:SS.mmm
     */
    fun formatSeconds(seconds: Double, includeMillis: Boolean = false): String {
        val totalSec = seconds.coerceAtLeast(0.0)
        val hours = (totalSec / 3600).toInt()
        val minutes = ((totalSec % 3600) / 60).toInt()
        val secs = (totalSec % 60).toInt()
        val millis = ((totalSec - totalSec.toInt()) * 100).toInt()

        return when {
            hours > 0 -> {
                if (includeMillis) {
                    String.format(Locale.US, "%02d:%02d:%02d.%02d", hours, minutes, secs, millis)
                } else {
                    String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, secs)
                }
            }
            else -> {
                if (includeMillis) {
                    String.format(Locale.US, "%02d:%02d.%02d", minutes, secs, millis)
                } else {
                    String.format(Locale.US, "%02d:%02d", minutes, secs)
                }
            }
        }
    }

    /**
     * Ekstraksi metadata video (durasi, resolusi, nama) menggunakan MediaMetadataRetriever.
     */
    suspend fun extractVideoMetadata(context: Context, videoUri: Uri): VideoMetadata? =
        withContext(Dispatchers.IO) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, videoUri)
                val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                val durationMs = durationStr?.toLongOrNull() ?: 0L

                val widthStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                val heightStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                val width = widthStr?.toIntOrNull() ?: 0
                val height = heightStr?.toIntOrNull() ?: 0

                val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                    ?: videoUri.lastPathSegment
                    ?: "video.mp4"

                var sizeBytes = 0L
                try {
                    context.contentResolver.openFileDescriptor(videoUri, "r")?.use { pfd ->
                        sizeBytes = pfd.statSize
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Gagal mendapatkan ukuran file: ${e.message}")
                }

                VideoMetadata(
                    uri = videoUri,
                    title = title,
                    durationMs = durationMs,
                    width = width,
                    height = height,
                    sizeBytes = sizeBytes
                )
            } catch (e: Exception) {
                Log.e(TAG, "Gagal mengekstrak metadata video: ${e.message}", e)
                null
            } finally {
                try {
                    retriever.release()
                } catch (e: Exception) {
                    // Ignore release errors
                }
            }
        }

    /**
     * Menyalin konten Uri ke file lokal sementara di direktori cache.
     * Diperlukan karena FFmpeg binary membutuhkan path file lokal filesystem.
     */
    suspend fun copyUriToLocalCache(context: Context, sourceUri: Uri, destFileName: String): Result<File> =
        withContext(Dispatchers.IO) {
            try {
                val destFile = File(context.cacheDir, destFileName)
                context.contentResolver.openInputStream(sourceUri)?.use { input ->
                    FileOutputStream(destFile).use { output ->
                        input.copyTo(output)
                    }
                } ?: return@withContext Result.failure(Exception("Tidak dapat membuka InputStream dari Uri: $sourceUri"))

                Result.success(destFile)
            } catch (e: Exception) {
                Log.e(TAG, "Gagal menyalin Uri ke cache: ${e.message}", e)
                Result.failure(e)
            }
        }

    /**
     * Mesin pemotong video native berbasis MediaExtractor dan MediaMuxer.
     * Bekerja seperti stream copy (-c copy) pada FFmpeg tanpa re-encoding,
     * digunakan secara otomatis sebagai fallback berkinerja tinggi jika sistem
     * Android menolak eksekusi biner langsung dari data app (SELinux W^X).
     */
    suspend fun trimVideoNativeStreamCopy(
        sourceFile: File,
        destFile: File,
        startMs: Long,
        endMs: Long,
        onProgress: suspend (progressPercent: Int, currentTimeSec: Double) -> Unit,
        onLog: suspend (line: String) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null

        try {
            extractor.setDataSource(sourceFile.absolutePath)
            val trackCount = extractor.trackCount
            muxer = MediaMuxer(destFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            val indexMap = HashMap<Int, Int>(trackCount)
            val bufferSize = 1024 * 1024
            val buffer = ByteBuffer.allocate(bufferSize)

            for (i in 0 until trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                    extractor.selectTrack(i)
                    val dstIndex = muxer.addTrack(format)
                    indexMap[i] = dstIndex
                }
            }

            muxer.start()

            val startUs = startMs * 1000L
            val endUs = endMs * 1000L
            val targetDurationSec = (endMs - startMs).toDouble() / 1000.0

            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

            val bufferInfo = MediaCodec.BufferInfo()
            var lastReportedSec = 0.0

            onLog("Memulai pemotongan video (Stream Copy mode: ${sourceFile.name} -> ${destFile.name})")

            while (true) {
                val trackIndex = extractor.sampleTrackIndex
                if (trackIndex < 0) break

                val dstIndex = indexMap[trackIndex]
                if (dstIndex != null) {
                    bufferInfo.size = extractor.readSampleData(buffer, 0)
                    if (bufferInfo.size < 0) {
                        bufferInfo.size = 0
                        break
                    }

                    bufferInfo.presentationTimeUs = extractor.sampleTime
                    if (bufferInfo.presentationTimeUs > endUs) {
                        break
                    }

                    if (bufferInfo.presentationTimeUs >= startUs) {
                        bufferInfo.flags = extractor.sampleFlags
                        bufferInfo.offset = 0
                        muxer.writeSampleData(dstIndex, buffer, bufferInfo)

                        val currentSec = (bufferInfo.presentationTimeUs - startUs).toDouble() / 1_000_000.0
                        val diff = currentSec - lastReportedSec
                        if (diff >= 0.25 || currentSec >= targetDurationSec) {
                            lastReportedSec = currentSec
                            val percent = ((currentSec / targetDurationSec) * 100).toInt().coerceIn(0, 100)
                            val logLine = "frame=mux time=${formatSeconds(currentSec, true)} target=${formatSeconds(targetDurationSec)}"
                            onLog(logLine)
                            onProgress(percent, currentSec)
                        }
                    }
                }

                extractor.advance()
            }

            onLog("Proses muxing selesai. Menyimpan file: ${destFile.absolutePath}")
            Result.success(destFile)
        } catch (e: Exception) {
            Log.e(TAG, "Gagal melakukan trim video native: ${e.message}", e)
            Result.failure(e)
        } finally {
            try {
                muxer?.stop()
                muxer?.release()
            } catch (e: Exception) {
                // Ignore
            }
            try {
                extractor.release()
            } catch (e: Exception) {
                // Ignore
            }
        }
    }

    /**
     * Menyimpan file video hasil potongan ke Galeri publik Android (folder Movies/VideoTrimmer)
     * sehingga pengguna dapat langsung melihatnya di aplikasi Galeri / File Manager bawaan HP.
     */
    suspend fun saveVideoToPublicGallery(context: Context, videoFile: File): Result<Uri> =
        withContext(Dispatchers.IO) {
            try {
                val resolver = context.contentResolver
                val contentValues = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, videoFile.name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VideoTrimmer")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                }

                val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues)
                    ?: return@withContext Result.failure(Exception("Gagal membuat entri MediaStore"))

                resolver.openOutputStream(uri)?.use { outputStream ->
                    FileInputStream(videoFile).use { inputStream ->
                        inputStream.copyTo(outputStream)
                    }
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    contentValues.clear()
                    contentValues.put(MediaStore.Video.Media.IS_PENDING, 0)
                    resolver.update(uri, contentValues, null, null)
                }

                Result.success(uri)
            } catch (e: Exception) {
                Log.e(TAG, "Gagal menyimpan video ke galeri: ${e.message}", e)
                Result.failure(e)
            }
        }
}
