package com.example.data.model

enum class VideoSourceType {
    LOCAL,
    YOUTUBE,
    SAMPLE
}

enum class SocialPlatform(val displayName: String, val iconName: String) {
    TIKTOK("TikTok", "tiktok"),
    REELS("Instagram Reels", "reels"),
    SHORTS("YouTube Shorts", "shorts")
}

data class VideoMoment(
    val id: String,
    val startSecond: Int,
    val endSecond: Int,
    val title: String,
    val keyQuoteOrText: String,
    val reasonWhyViral: String,
    val viralScore: Int // 1-100
) {
    val durationSeconds: Int get() = (endSecond - startSecond).coerceAtLeast(1)
    
    fun formattedStartTime(): String = formatTime(startSecond)
    fun formattedEndTime(): String = formatTime(endSecond)
    fun formattedTimeRange(): String = "${formattedStartTime()} - ${formattedEndTime()}"

    companion object {
        fun formatTime(seconds: Int): String {
            val m = seconds / 60
            val s = seconds % 60
            return "%02d:%02d".format(m, s)
        }
    }
}

data class VideoHook(
    val id: String,
    val hookText: String,
    val hookType: String, // e.g., "Curiosity Gap", "Shock Value", "Relatable", "Story Hook"
    val deliveryTip: String
)

data class TitleSuggestion(
    val id: String,
    val titleText: String,
    val category: String, // e.g., "Curiosity Trigger", "Action/How-To", "High CTR"
    val estimatedCtr: String
)

data class SocialCaption(
    val platform: SocialPlatform,
    val captionText: String,
    val callToAction: String,
    val hashtags: List<String>
)

data class AudienceEngagementStats(
    val overallScore: Int, // 1-100
    val viralProbability: String, // e.g., "Sangat Tinggi (88%)"
    val bestPostingTime: String, // e.g., "19.00 - 21.00 WIB"
    val targetAudience: String, // e.g., "Gen Z, Kreator Pemula, Tech Enthusiasts"
    val retentionPeakTime: String, // e.g., "Detik 15 - 45"
    val engagementFactors: List<String>
)

data class SeoData(
    val primaryKeywords: List<String>,
    val longTailKeywords: List<String>,
    val recommendedTags: List<String>,
    val searchOptimizedDescription: String
)

data class VideoAnalysisResult(
    val id: String,
    val title: String,
    val sourceUriOrUrl: String,
    val sourceType: VideoSourceType,
    val durationSeconds: Int,
    val thumbnailUrl: String,
    val summaryPoints: List<String>,
    val moments: List<VideoMoment>,
    val hooks: List<VideoHook>,
    val titleSuggestions: List<TitleSuggestion>,
    val socialCaptions: List<SocialCaption>,
    val audienceMetrics: AudienceEngagementStats,
    val seoData: SeoData,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun formattedDuration(): String = VideoMoment.formatTime(durationSeconds)
}
