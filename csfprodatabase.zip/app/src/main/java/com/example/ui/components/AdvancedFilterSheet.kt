package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FilterCriteria

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdvancedFilterSheet(
    criteria: FilterCriteria,
    onApply: (mobil: String, chassis: String, keluhan: String, startDate: Long?, endDate: Long?) -> Unit,
    onClear: () -> Unit,
    onDismiss: () -> Unit,
    sheetState: SheetState,
    modifier: Modifier = Modifier
) {
    var mobilInput by remember { mutableStateOf(criteria.specificMobil) }
    var chassisInput by remember { mutableStateOf(criteria.specificChassis) }
    var keluhanInput by remember { mutableStateOf(criteria.specificKeluhan) }

    val scrollState = rememberScrollState()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .verticalScroll(scrollState)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.FilterList,
                        contentDescription = "Filter",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Filter Kustom Spesifik",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Tutup")
                }
            }

            Text(
                text = "Penyaringan presisi per kolom untuk mempercepat investigasi armada",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Specific Mobil / Plate
            OutlinedTextField(
                value = mobilInput,
                onValueChange = { mobilInput = it },
                label = { Text("Filter Plat / Armada (MobilName)") },
                placeholder = { Text("contoh: B 9281 UXT, HINO, TRONTON") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("filter_mobil_input"),
                singleLine = true,
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Specific Chassis
            OutlinedTextField(
                value = chassisInput,
                onValueChange = { chassisInput = it },
                label = { Text("Nomor Rangka (NoChassis)") },
                placeholder = { Text("contoh: MHM12345...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("filter_chassis_input"),
                singleLine = true,
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Specific Keluhan
            OutlinedTextField(
                value = keluhanInput,
                onValueChange = { keluhanInput = it },
                label = { Text("Keluhan / Permasalahan") },
                placeholder = { Text("contoh: rem, bocor, gardan, per daun") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("filter_keluhan_input"),
                singleLine = true,
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        mobilInput = ""
                        chassisInput = ""
                        keluhanInput = ""
                        onClear()
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Reset Filter")
                }

                Button(
                    onClick = {
                        onApply(
                            mobilInput,
                            chassisInput,
                            keluhanInput,
                            criteria.startDateMillis,
                            criteria.endDateMillis
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("apply_advanced_filter_button")
                ) {
                    Text("Terapkan")
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
