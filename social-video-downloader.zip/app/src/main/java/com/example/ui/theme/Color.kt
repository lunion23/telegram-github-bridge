package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand accents
val IndigoPrimary = Color(0xFF6366F1)
val IndigoPrimaryLight = Color(0xFF818CF8)
val CyanSecondary = Color(0xFF06B6D4)
val CyanSecondaryLight = Color(0xFF22D3EE)
val PinkTertiary = Color(0xFFF43F5E)

// Dark Theme backgrounds & surfaces
val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1F2937)
val DarkOutline = Color(0xFF374151)

// Light Theme surfaces
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOutline = Color(0xFFCBD5E1)

// Platform Branding colors
val TikTokColor = Color(0xFF00F2FE)
val InstagramColor = Color(0xFFE1306C)
val YouTubeColor = Color(0xFFFF0000)
val TwitterColor = Color(0xFF1DA1F2)
val FacebookColor = Color(0xFF1877F2)
