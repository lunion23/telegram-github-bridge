package com.example.data.parser

import com.example.data.model.ImportProgress
import com.example.data.model.WorkOrderItem
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader

object CsvStreamParser {

    private const val DEFAULT_CHUNK_SIZE = 2500 // 1,000 - 5,000 optimal batch size for SQLite

    /**
     * Reads CSV line-by-line using a streaming buffer.
     * Never loads the entire file into RAM, guaranteeing 0 Out-Of-Memory errors even on files with millions of rows.
     */
    suspend fun parseStreamInBatches(
        inputStream: InputStream,
        totalBytesEstimate: Long = 0L,
        chunkSize: Int = DEFAULT_CHUNK_SIZE,
        onBatchReady: suspend (batch: List<WorkOrderItem>, progress: ImportProgress) -> Unit
    ): Long = withContext(Dispatchers.IO) {
        val reader = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8), 32 * 1024)
        var totalRowsProcessed = 0L
        var batchNumber = 0
        val startTime = System.currentTimeMillis()

        try {
            val headerLine = reader.readLine() ?: return@withContext 0L
            val delimiter = if (headerLine.count { it == ';' } > headerLine.count { it == ',' }) ';' else ','
            val headers = parseCsvLine(headerLine, delimiter).map { it.trim().lowercase() }

            // Column index map based on CSV schema
            val idxName = headers.indexOfFirst { it == "name" || it.contains("id wo") || it.contains("no wo") }
            val idxMobil = headers.indexOfFirst { it == "mobilname" || it.contains("mobil") || it.contains("nopol") }
            val idxTrandate = headers.indexOfFirst { it == "trandate" || it.contains("tanggal") || it.contains("date") }
            val idxKm = headers.indexOfFirst { it == "kmcurrent" || it.contains("km") || it.contains("odometer") }
            val idxKeluhan = headers.indexOfFirst { it == "keluhan" || it.contains("keluhan") || it.contains("masalah") }
            val idxTipe = headers.indexOfFirst { it == "tipe" || it.contains("tipe") || it.contains("type") }
            val idxKode = headers.indexOfFirst { it == "kode" || it.contains("kode") || it.contains("code") }
            val idxDesc = headers.indexOfFirst { it == "description" || it.contains("deskripsi") || it.contains("pekerjaan") }
            val idxCatatan = headers.indexOfFirst { it == "catatan" || it.contains("catatan") || it.contains("note") }
            val idxStartTime = headers.indexOfFirst { it == "starttime" || it.contains("start") }
            val idxEndTime = headers.indexOfFirst { it == "endtime" || it.contains("end") }
            val idxQty = headers.indexOfFirst { it == "qty" || it.contains("jumlah") }
            val idxTotal = headers.indexOfFirst { it == "total" }
            val idxTotalPrice = headers.indexOfFirst { it == "totalprice" || it.contains("harga") || it.contains("biaya") }
            val idxProductClass = headers.indexOfFirst { it == "productclass" || it.contains("class") || it.contains("kategori") }
            val idxNoChassis = headers.indexOfFirst { it == "nochassis" || it.contains("chassis") || it.contains("rangka") }
            val idxNoMesin = headers.indexOfFirst { it == "nomesin" || it.contains("mesin") || it.contains("engine") }

            val currentBatchList = ArrayList<WorkOrderItem>(chunkSize)
            var line: String? = reader.readLine()

            val estimatedTotalRows = if (totalBytesEstimate > 0) (totalBytesEstimate / 180L).coerceAtLeast(100L) else 0L

            while (line != null) {
                if (!currentCoroutineContext().isActive) {
                    throw CancellationException("Import dibatalkan oleh pengguna.")
                }

                if (line.isNotBlank()) {
                    val tokens = parseCsvLine(line, delimiter)
                    val item = buildWorkOrderItem(
                        tokens = tokens,
                        idxName = idxName,
                        idxMobil = idxMobil,
                        idxTrandate = idxTrandate,
                        idxKm = idxKm,
                        idxKeluhan = idxKeluhan,
                        idxTipe = idxTipe,
                        idxKode = idxKode,
                        idxDesc = idxDesc,
                        idxCatatan = idxCatatan,
                        idxStartTime = idxStartTime,
                        idxEndTime = idxEndTime,
                        idxQty = idxQty,
                        idxTotal = idxTotal,
                        idxTotalPrice = idxTotalPrice,
                        idxProductClass = idxProductClass,
                        idxNoChassis = idxNoChassis,
                        idxNoMesin = idxNoMesin
                    )
                    currentBatchList.add(item)
                    totalRowsProcessed++

                    if (currentBatchList.size >= chunkSize) {
                        batchNumber++
                        val elapsedSecs = (System.currentTimeMillis() - startTime) / 1000.0
                        val speed = if (elapsedSecs > 0) totalRowsProcessed / elapsedSecs else 0.0
                        val percent = if (estimatedTotalRows > 0) {
                            ((totalRowsProcessed.toDouble() / estimatedTotalRows.toDouble()) * 100).toInt().coerceIn(0, 99)
                        } else 0

                        val progress = ImportProgress(
                            isImporting = true,
                            processedRows = totalRowsProcessed,
                            totalEstimatedRows = estimatedTotalRows,
                            percentage = percent,
                            currentSpeedRowsPerSec = speed,
                            currentBatch = batchNumber,
                            statusText = "Menyimpan transaksi batch #$batchNumber (${currentBatchList.size} baris)..."
                        )

                        onBatchReady(currentBatchList.toList(), progress)
                        currentBatchList.clear()
                    }
                }

                line = reader.readLine()
            }

            // Flush remaining items
            if (currentBatchList.isNotEmpty()) {
                batchNumber++
                val elapsedSecs = (System.currentTimeMillis() - startTime) / 1000.0
                val speed = if (elapsedSecs > 0) totalRowsProcessed / elapsedSecs else 0.0

                val progress = ImportProgress(
                    isImporting = true,
                    processedRows = totalRowsProcessed,
                    totalEstimatedRows = totalRowsProcessed,
                    percentage = 100,
                    currentSpeedRowsPerSec = speed,
                    currentBatch = batchNumber,
                    statusText = "Menyimpan sisa batch akhir (${currentBatchList.size} baris)..."
                )
                onBatchReady(currentBatchList.toList(), progress)
                currentBatchList.clear()
            }

        } finally {
            try {
                reader.close()
            } catch (_: Exception) {}
        }

        return@withContext totalRowsProcessed
    }

    private fun buildWorkOrderItem(
        tokens: List<String>,
        idxName: Int,
        idxMobil: Int,
        idxTrandate: Int,
        idxKm: Int,
        idxKeluhan: Int,
        idxTipe: Int,
        idxKode: Int,
        idxDesc: Int,
        idxCatatan: Int,
        idxStartTime: Int,
        idxEndTime: Int,
        idxQty: Int,
        idxTotal: Int,
        idxTotalPrice: Int,
        idxProductClass: Int,
        idxNoChassis: Int,
        idxNoMesin: Int
    ): WorkOrderItem {
        fun getVal(idx: Int): String = if (idx in tokens.indices) tokens[idx].trim() else ""

        val rawName = getVal(if (idxName >= 0) idxName else 0)
        val rawMobil = getVal(if (idxMobil >= 0) idxMobil else 1)
        val rawDate = getVal(if (idxTrandate >= 0) idxTrandate else 2)
        val normalizedDate = DateNormalizer.parse(rawDate)

        val rawKm = getVal(if (idxKm >= 0) idxKm else 3).replace(".", "").replace(",", "").toLongOrNull() ?: 0L
        val rawKeluhan = getVal(if (idxKeluhan >= 0) idxKeluhan else 4)
        val rawTipe = getVal(if (idxTipe >= 0) idxTipe else 5).ifBlank { "Part" }
        val rawKode = getVal(if (idxKode >= 0) idxKode else 6)
        val rawDesc = getVal(if (idxDesc >= 0) idxDesc else 7)
        val rawCatatan = getVal(if (idxCatatan >= 0) idxCatatan else 8)
        val rawStartTime = getVal(if (idxStartTime >= 0) idxStartTime else 9)
        val rawEndTime = getVal(if (idxEndTime >= 0) idxEndTime else 10)
        val rawQty = getVal(if (idxQty >= 0) idxQty else 11).replace(",", ".").toDoubleOrNull() ?: 1.0
        val rawTotal = getVal(if (idxTotal >= 0) idxTotal else 12).replace(",", ".").toDoubleOrNull() ?: rawQty
        val rawTotalPrice = getVal(if (idxTotalPrice >= 0) idxTotalPrice else 13)
            .replace("Rp", "")
            .replace(".", "")
            .replace(",", ".")
            .trim()
            .toDoubleOrNull() ?: 0.0
        val rawProductClass = getVal(if (idxProductClass >= 0) idxProductClass else 14).ifBlank { "General" }
        val rawChassis = getVal(if (idxNoChassis >= 0) idxNoChassis else 15)
        val rawMesin = getVal(if (idxNoMesin >= 0) idxNoMesin else 16)

        return WorkOrderItem(
            name = if (rawName.isNotBlank()) rawName else "WO-UNKNOWN",
            mobilName = if (rawMobil.isNotBlank()) rawMobil else "Armada Tidak Dikenal",
            trandate = rawDate,
            trandateMillis = normalizedDate.millis,
            trandateFormatted = normalizedDate.formatted,
            kmCurrent = rawKm,
            keluhan = rawKeluhan,
            tipe = rawTipe,
            kode = rawKode,
            description = rawDesc,
            catatan = rawCatatan,
            startTime = rawStartTime,
            endTime = rawEndTime,
            qty = rawQty,
            total = rawTotal,
            totalPrice = rawTotalPrice,
            productClass = rawProductClass,
            noChassis = rawChassis,
            noMesin = rawMesin
        )
    }

    /**
     * Parses a single CSV line supporting RFC 4180 quotes, commas/semicolons, and escaped quotes.
     */
    fun parseCsvLine(line: String, explicitDelimiter: Char? = null): List<String> {
        val delim = explicitDelimiter ?: if (line.count { it == ';' } > line.count { it == ',' }) ';' else ','
        val result = mutableListOf<String>()
        val cur = StringBuilder()
        var inQuotes = false
        var i = 0

        while (i < line.length) {
            val c = line[i]
            when {
                c == '\"' -> {
                    if (inQuotes && i + 1 < line.length && line[i + 1] == '\"') {
                        cur.append('\"')
                        i++ // Skip escaped quote
                    } else {
                        inQuotes = !inQuotes
                    }
                }
                c == delim && !inQuotes -> {
                    result.add(cur.toString())
                    cur.clear()
                }
                else -> {
                    cur.append(c)
                }
            }
            i++
        }
        result.add(cur.toString())
        return result
    }
}
