package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PrintFormatMode
import com.example.data.model.ReceiptData
import com.example.util.BarcodeGenerator

/**
 * Smart dynamic receipt view that renders Option 1, Option 2, or Option 3 based on selected format.
 */
@Composable
fun DynamicReceiptView(
    receipt: ReceiptData,
    modifier: Modifier = Modifier
) {
    when (receipt.selectedFormat) {
        PrintFormatMode.MAIN_LABEL -> ShippingLabelView(receipt = receipt, modifier = modifier)
        PrintFormatMode.SENDER_COPY -> SenderCopyLabelView(receipt = receipt, modifier = modifier, withSideMargins = true)
        PrintFormatMode.COMBO_ALL -> ComboShippingLabelView(receipt = receipt, modifier = modifier)
    }
}

/**
 * OPSI 1: Struk / Label Pengiriman Utama (Format Asli).
 */
@Composable
fun ShippingLabelView(
    receipt: ReceiptData,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("shipping_label_card"),
        shape = RoundedCornerShape(4.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
                .height(IntrinsicSize.Min)
        ) {
            VerticalSideTextColumn(resiCode = receipt.resiCode, isLeft = true, repeatCount = 4)

            MainLabelContent(receipt = receipt, modifier = Modifier.weight(1f))

            VerticalSideTextColumn(resiCode = receipt.resiCode, isLeft = false, repeatCount = 4)
        }
    }
}

/**
 * OPSI 2: Lembar Pengirim Saja (Sesuai Gambar 1).
 */
@Composable
fun SenderCopyLabelView(
    receipt: ReceiptData,
    modifier: Modifier = Modifier,
    withSideMargins: Boolean = true
) {
    val barcodeBitmap = remember(receipt.resiCode) {
        BarcodeGenerator.generateBarcode128(receipt.resiCode, width = 600, height = 110)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("sender_copy_card"),
        shape = RoundedCornerShape(4.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
                .height(IntrinsicSize.Min)
        ) {
            if (withSideMargins) {
                VerticalSideTextColumn(resiCode = receipt.resiCode, isLeft = true, repeatCount = 2)
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .border(1.5.dp, Color.Black)
                    .background(Color.White)
            ) {
                // Top Barcode
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp, bottom = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (barcodeBitmap != null) {
                        Image(
                            bitmap = barcodeBitmap.asImageBitmap(),
                            contentDescription = "Barcode ${receipt.resiCode}",
                            modifier = Modifier
                                .fillMaxWidth(0.92f)
                                .height(46.dp),
                            contentScale = ContentScale.FillBounds
                        )
                    }
                    Text(
                        text = receipt.resiCode,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = Color.Black
                    )
                }

                HorizontalDivider(thickness = 1.dp, color = Color.Black)

                // Sender & Recipient Section
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Pengirim: ${receipt.senderName}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.5.sp,
                            color = Color.Black,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = receipt.getDisplaySenderPhone(),
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.5.sp,
                            color = Color.Black
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Penerima: ${receipt.recipientName}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.5.sp,
                            color = Color.Black,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = receipt.getDisplayRecipientPhone(),
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.5.sp,
                            color = Color.Black
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = receipt.recipientAddress,
                        fontSize = 9.sp,
                        lineHeight = 12.sp,
                        color = Color.Black
                    )
                }

                HorizontalDivider(thickness = 1.dp, color = Color.Black)

                // Split Details Table (Left: TOTAL BIAYA & Badge, Right: Qty, Barang, Notes, Cetak, Exp, Legal)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Min)
                ) {
                    // Left Column: Total Biaya + Lembar Pengirim
                    Column(
                        modifier = Modifier
                            .weight(1.3f)
                            .fillMaxHeight(),
                        verticalArrangement = Arrangement.SpaceBetween,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "TOTAL BIAYA",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.Black,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = receipt.getFormattedFee(),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.Black
                            )
                            Text(
                                text = "Sudah Termasuk PPN",
                                fontSize = 7.sp,
                                color = Color.DarkGray
                            )
                        }

                        // Black Badge: Lembar Pengirim
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Black)
                                .padding(vertical = 5.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Lembar Pengirim",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }

                    VerticalDivider(thickness = 1.dp, color = Color.Black)

                    // Right Column: Qty, Barang, Notes, Cetak, Exp, Legal
                    Column(
                        modifier = Modifier
                            .weight(2.3f)
                            .fillMaxHeight()
                    ) {
                        // Row 1: Qty & Barang
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(IntrinsicSize.Min)
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "Qty ${receipt.itemQty}",
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                            VerticalDivider(thickness = 1.dp, color = Color.Black)
                            Box(
                                modifier = Modifier
                                    .weight(1.8f)
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "BARANG ${receipt.itemName}",
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black,
                                    maxLines = 1
                                )
                            }
                        }

                        HorizontalDivider(thickness = 1.dp, color = Color.Black)

                        // Row 2: Notes
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "Notes: ${receipt.notes}",
                                fontSize = 8.5.sp,
                                color = Color.Black,
                                maxLines = 1
                            )
                        }

                        HorizontalDivider(thickness = 1.dp, color = Color.Black)

                        // Row 3: Cetak & Exp
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(IntrinsicSize.Min)
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "Cetak ${receipt.printDate}",
                                    fontSize = 8.sp,
                                    color = Color.Black
                                )
                            }
                            VerticalDivider(thickness = 1.dp, color = Color.Black)
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "Exp ${receipt.expDate}",
                                    fontSize = 8.sp,
                                    color = Color.Black
                                )
                            }
                        }

                        HorizontalDivider(thickness = 1.dp, color = Color.Black)

                        // Footer Legal
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Syarat dan ketentuan pengiriman dilihat pada website www.jet.co.id",
                                fontSize = 6.2.sp,
                                color = Color.DarkGray,
                                maxLines = 1
                            )
                            Text(
                                text = "PT GLOBAL JET EXPRESS, 0735697740 041 000\nLANDMARK PLUIT TOWER BLOK B1, LANTAI 8, 9A,",
                                fontSize = 6.2.sp,
                                lineHeight = 8.sp,
                                color = Color.Black
                            )
                        }
                    }
                }
            }

            if (withSideMargins) {
                VerticalSideTextColumn(resiCode = receipt.resiCode, isLeft = false, repeatCount = 2)
            }
        }
    }
}

/**
 * OPSI 3: Gabungan Lengkap 2-in-1 (Sesuai Gambar 2).
 * Bagian atas adalah Label Paket Utama, bagian bawah adalah Lembar Pengirim.
 */
@Composable
fun ComboShippingLabelView(
    receipt: ReceiptData,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("combo_shipping_label_card"),
        shape = RoundedCornerShape(4.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
                .height(IntrinsicSize.Min)
        ) {
            // Side Vertical Resi Text (extended for the entire height, 6 repeats)
            VerticalSideTextColumn(resiCode = receipt.resiCode, isLeft = true, repeatCount = 6)

            Column(
                modifier = Modifier
                    .weight(1f)
                    .border(1.5.dp, Color.Black)
                    .background(Color.White)
            ) {
                // Section 1: Main Shipping Label
                MainLabelContent(receipt = receipt, modifier = Modifier.fillMaxWidth())

                // Perforation Divider
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .background(Color(0xFFF1F5F9)),
                    contentAlignment = Alignment.Center
                ) {
                    HorizontalDivider(
                        modifier = Modifier.fillMaxWidth(),
                        thickness = 1.dp,
                        color = Color.Black
                    )
                }

                // Section 2: Lembar Pengirim (lower part)
                SenderCopyContentOnly(receipt = receipt, modifier = Modifier.fillMaxWidth())
            }

            // Side Vertical Resi Text (right)
            VerticalSideTextColumn(resiCode = receipt.resiCode, isLeft = false, repeatCount = 6)
        }
    }
}

/**
 * Inner component for Main Label (used in Option 1 & 3).
 */
@Composable
private fun MainLabelContent(
    receipt: ReceiptData,
    modifier: Modifier = Modifier
) {
    val barcodeBitmap = remember(receipt.resiCode) {
        BarcodeGenerator.generateBarcode128(receipt.resiCode, width = 600, height = 130)
    }
    val qrBitmap = remember(receipt.resiCode) {
        BarcodeGenerator.generateQrCode(receipt.resiCode, size = 200)
    }

    Column(
        modifier = modifier
            .background(Color.White)
    ) {
        // Top Routing Code and Badges
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = receipt.routingCode,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = Color.Black,
                fontFamily = FontFamily.SansSerif,
                letterSpacing = 0.5.sp,
                modifier = Modifier.weight(1f)
            )

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                BlackBadge(text = receipt.badge1)
                BlackBadge(text = receipt.badge2)
            }
        }

        HorizontalDivider(thickness = 1.dp, color = Color.Black)

        // Barcode Section
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp, bottom = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (barcodeBitmap != null) {
                Image(
                    bitmap = barcodeBitmap.asImageBitmap(),
                    contentDescription = "Barcode ${receipt.resiCode}",
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .height(52.dp)
                        .testTag("resi_barcode_image"),
                    contentScale = ContentScale.FillBounds
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = receipt.resiCode,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black,
                fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Center,
                modifier = Modifier.testTag("resi_code_text")
            )
        }

        // Drop Point Black Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black)
                .padding(vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = receipt.dropPoint.uppercase(),
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                letterSpacing = 0.5.sp,
                textAlign = TextAlign.Center
            )
        }

        // Recipient Section
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 5.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Penerima: ${receipt.recipientName}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.5.sp,
                    color = Color.Black,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = receipt.getDisplayRecipientPhone(),
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.5.sp,
                    color = Color.Black
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = receipt.recipientAddress,
                fontSize = 9.sp,
                lineHeight = 12.sp,
                color = Color.Black,
                fontWeight = FontWeight.Normal
            )
        }

        HorizontalDivider(thickness = 1.dp, color = Color.Black)

        // Sender Section
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 5.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Pengirim: ${receipt.senderName}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.5.sp,
                    color = Color.Black,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = receipt.getDisplaySenderPhone(),
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.5.sp,
                    color = Color.Black
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = receipt.senderAddress,
                fontSize = 9.sp,
                lineHeight = 12.sp,
                color = Color.Black,
                fontWeight = FontWeight.Normal
            )
        }

        HorizontalDivider(thickness = 1.dp, color = Color.Black)

        // Shipping Details Table
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(IntrinsicSize.Min)
            ) {
                // Col 1: Biaya Pengiriman
                Column(
                    modifier = Modifier
                        .weight(1.3f)
                        .fillMaxHeight(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black)
                            .padding(vertical = 1.5.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "BIAYA PENGIRIMAN",
                            color = Color.White,
                            fontSize = 7.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = receipt.getFormattedFee(),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                    Text(
                        text = "Sudah Termasuk PPH",
                        fontSize = 6.5.sp,
                        color = Color.DarkGray
                    )
                }

                VerticalDivider(thickness = 1.dp, color = Color.Black)

                // Col 2: Tunai
                Box(
                    modifier = Modifier
                        .weight(0.9f)
                        .fillMaxHeight(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = receipt.paymentType,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }

                VerticalDivider(thickness = 1.dp, color = Color.Black)

                // Col 3: Weight
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "• ${receipt.weightKg}",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }

                VerticalDivider(thickness = 1.dp, color = Color.Black)

                // Col 4: Print Date
                Box(
                    modifier = Modifier
                        .weight(1.2f)
                        .fillMaxHeight(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Cetak ${receipt.printDate}",
                        fontSize = 8.5.sp,
                        color = Color.Black
                    )
                }
            }

            HorizontalDivider(thickness = 1.dp, color = Color.Black)

            // Row 2: Order No & Exp
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(IntrinsicSize.Min)
            ) {
                Box(
                    modifier = Modifier
                        .weight(3.2f)
                        .padding(horizontal = 6.dp, vertical = 3.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(
                        text = "Order No. ${receipt.orderNo}",
                        fontSize = 8.sp,
                        color = Color.Black
                    )
                }

                VerticalDivider(thickness = 1.dp, color = Color.Black)

                Box(
                    modifier = Modifier
                        .weight(1.2f)
                        .padding(horizontal = 4.dp, vertical = 3.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(
                        text = "Exp: ${receipt.expNote}",
                        fontSize = 8.sp,
                        color = Color.Black
                    )
                }
            }

            HorizontalDivider(thickness = 1.dp, color = Color.Black)

            // Row 3: Notes
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 3.dp)
            ) {
                Text(
                    text = "Notes: ${receipt.notes}",
                    fontSize = 8.5.sp,
                    color = Color.Black
                )
            }
        }

        HorizontalDivider(thickness = 1.dp, color = Color.Black)

        // Footer Section
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Syarat dan ketentuan pengiriman dilihat pada website",
                    fontSize = 6.8.sp,
                    color = Color.DarkGray
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = receipt.footerCompany,
                    fontSize = 6.8.sp,
                    lineHeight = 9.sp,
                    fontWeight = FontWeight.Normal,
                    color = Color.Black
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            if (qrBitmap != null) {
                Image(
                    bitmap = qrBitmap.asImageBitmap(),
                    contentDescription = "QR Code Resi",
                    modifier = Modifier
                        .size(64.dp)
                        .testTag("resi_qr_image"),
                    contentScale = ContentScale.Fit
                )
            }
        }
    }
}

/**
 * Inner component for Sender Copy content without card wrapper (for Option 3).
 */
@Composable
private fun SenderCopyContentOnly(
    receipt: ReceiptData,
    modifier: Modifier = Modifier
) {
    val barcodeBitmap = remember(receipt.resiCode) {
        BarcodeGenerator.generateBarcode128(receipt.resiCode, width = 600, height = 110)
    }

    Column(modifier = modifier.background(Color.White)) {
        // Barcode
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp, bottom = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (barcodeBitmap != null) {
                Image(
                    bitmap = barcodeBitmap.asImageBitmap(),
                    contentDescription = "Barcode ${receipt.resiCode}",
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .height(46.dp),
                    contentScale = ContentScale.FillBounds
                )
            }
            Text(
                text = receipt.resiCode,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = Color.Black
            )
        }

        HorizontalDivider(thickness = 1.dp, color = Color.Black)

        // Sender & Recipient
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 5.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Pengirim: ${receipt.senderName}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.5.sp,
                    color = Color.Black,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = receipt.getDisplaySenderPhone(),
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.5.sp,
                    color = Color.Black
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Penerima: ${receipt.recipientName}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.5.sp,
                    color = Color.Black,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = receipt.getDisplayRecipientPhone(),
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.5.sp,
                    color = Color.Black
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = receipt.recipientAddress,
                fontSize = 9.sp,
                lineHeight = 12.sp,
                color = Color.Black
            )
        }

        HorizontalDivider(thickness = 1.dp, color = Color.Black)

        // Table
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(IntrinsicSize.Min)
        ) {
            // Left: Total Biaya + Lembar Pengirim
            Column(
                modifier = Modifier
                    .weight(1.3f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "TOTAL BIAYA",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.Black,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = receipt.getFormattedFee(),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.Black
                    )
                    Text(
                        text = "Sudah Termasuk PPN",
                        fontSize = 7.sp,
                        color = Color.DarkGray
                    )
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black)
                        .padding(vertical = 5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Lembar Pengirim",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            VerticalDivider(thickness = 1.dp, color = Color.Black)

            // Right: Qty, Barang, Notes, Cetak, Exp, Legal
            Column(
                modifier = Modifier
                    .weight(2.3f)
                    .fillMaxHeight()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Min)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "Qty ${receipt.itemQty}",
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }
                    VerticalDivider(thickness = 1.dp, color = Color.Black)
                    Box(
                        modifier = Modifier
                            .weight(1.8f)
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "BARANG ${receipt.itemName}",
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black,
                            maxLines = 1
                        )
                    }
                }

                HorizontalDivider(thickness = 1.dp, color = Color.Black)

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "Notes: ${receipt.notes}",
                        fontSize = 8.5.sp,
                        color = Color.Black,
                        maxLines = 1
                    )
                }

                HorizontalDivider(thickness = 1.dp, color = Color.Black)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Min)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "Cetak ${receipt.printDate}",
                            fontSize = 8.sp,
                            color = Color.Black
                        )
                    }
                    VerticalDivider(thickness = 1.dp, color = Color.Black)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "Exp ${receipt.expDate}",
                            fontSize = 8.sp,
                            color = Color.Black
                        )
                    }
                }

                HorizontalDivider(thickness = 1.dp, color = Color.Black)

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "Syarat dan ketentuan pengiriman dilihat pada website www.jet.co.id",
                        fontSize = 6.2.sp,
                        color = Color.DarkGray,
                        maxLines = 1
                    )
                    Text(
                        text = "PT GLOBAL JET EXPRESS, 0735697740 041 000\nLANDMARK PLUIT TOWER BLOK B1, LANTAI 8, 9A,",
                        fontSize = 6.2.sp,
                        lineHeight = 8.sp,
                        color = Color.Black
                    )
                }
            }
        }
    }
}

@Composable
private fun VerticalSideTextColumn(
    resiCode: String,
    isLeft: Boolean,
    repeatCount: Int = 4
) {
    Column(
        modifier = Modifier
            .width(20.dp)
            .fillMaxHeight(),
        verticalArrangement = Arrangement.SpaceAround,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val rotationAngle = if (isLeft) -90f else 90f
        repeat(repeatCount) {
            Text(
                text = resiCode,
                fontSize = 7.5.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = Color.DarkGray,
                modifier = Modifier.rotate(rotationAngle),
                maxLines = 1,
                softWrap = false
            )
        }
    }
}

@Composable
private fun BlackBadge(text: String) {
    Box(
        modifier = Modifier
            .background(Color.Black, shape = RoundedCornerShape(2.dp))
            .padding(horizontal = 10.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color.White,
            fontWeight = FontWeight.Black,
            fontSize = 13.sp,
            fontFamily = FontFamily.SansSerif
        )
    }
}
