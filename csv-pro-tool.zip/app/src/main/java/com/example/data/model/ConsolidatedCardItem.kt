package com.example.data.model

data class ConsolidatedCardItem(
    val recordId: String,
    val primaryDate: String,
    val customerOrEntity: String,
    val category: String,
    val totalItemsCount: Int,
    val status: String,
    val rows: List<CsvRowEntity> = emptyList(),
    val isRowsLoaded: Boolean = false
) {
    companion object {
        fun fromRows(rowsForId: List<CsvRowEntity>): ConsolidatedCardItem {
            val first = rowsForId.firstOrNull()
            val recId = first?.recordId?.ifEmpty { first.col0 } ?: "TANPA-ID"
            val date = first?.col1?.ifEmpty { "-" } ?: "-"
            val customer = first?.col2?.ifEmpty { "-" } ?: "-"
            val category = first?.col3?.ifEmpty { "-" } ?: "-"
            val status = first?.col9?.ifEmpty { "Selesai" } ?: "Selesai"

            return ConsolidatedCardItem(
                recordId = recId,
                primaryDate = date,
                customerOrEntity = customer,
                category = category,
                totalItemsCount = rowsForId.size,
                status = status,
                rows = rowsForId,
                isRowsLoaded = true
            )
        }
    }
}
