package com.example.pdf

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.content.FileProvider
import com.example.R
import com.example.data.GeneratedPdfFileItem
import com.example.model.PaperSizePreset
import com.example.model.PdfRenderSource
import com.example.model.ShippingLabelData
import com.example.pdf.ShippingLabelPdfGenerator.findActivity
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Manages locally generated `.pdf` documents in `filesDir/pdfs` and `cacheDir/pdfs`
 * so users can inspect, re-print, share, or clean up already created PDF files in Data Manager.
 */
class LocalPdfArchiveManager(context: Context) {

    private val appContext = context.applicationContext
    private val printScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private fun archiveDirectory(): File {
        val dir = File(appContext.filesDir, "pdfs")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    private fun cachePdfDirectory(): File = File(appContext.cacheDir, "pdfs")

    suspend fun listGeneratedPdfs(): List<GeneratedPdfFileItem> = withContext(Dispatchers.IO) {
        val seenPaths = HashSet<String>()
        val collected = mutableListOf<GeneratedPdfFileItem>()

        listOf(archiveDirectory(), cachePdfDirectory()).forEach { dir ->
            if (dir.exists() && dir.isDirectory) {
                dir.listFiles { file ->
                    file.isFile && file.extension.equals("pdf", ignoreCase = true) && file.length() > 0L
                }?.forEach { pdf ->
                    val canonical = runCatching { pdf.canonicalPath }.getOrDefault(pdf.absolutePath)
                    if (seenPaths.add(canonical)) {
                        collected.add(
                            GeneratedPdfFileItem(
                                file = pdf,
                                name = pdf.name,
                                sizeBytes = pdf.length(),
                                lastModifiedMillis = pdf.lastModified()
                            )
                        )
                    }
                }
            }
        }

        collected.sortedByDescending { it.lastModifiedMillis }
    }

    suspend fun archiveLabelPdf(
        data: ShippingLabelData,
        paperPreset: PaperSizePreset,
        renderSource: PdfRenderSource,
        referenceBitmap: Bitmap?,
        capturedBitmap: Bitmap? = null
    ): File = withContext(Dispatchers.IO) {
        val dir = archiveDirectory()
        val timestampSuffix = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val basePrefix = if (renderSource == PdfRenderSource.CAPTURED_DOCUMENT) {
            "Scan_Dokumen"
        } else {
            val sanitizedWaybill = data.waybillNumber
                .replace(Regex("[^A-Za-z0-9_-]"), "_")
                .take(40)
                .ifBlank { "Resi" }
            "Resi_$sanitizedWaybill"
        }
        val outFile = File(dir, "${basePrefix}_${timestampSuffix}.pdf")
        FileOutputStream(outFile).use { fos ->
            ShippingLabelPdfGenerator.writePdfToStream(
                outputStream = fos,
                data = data,
                paperPreset = paperPreset,
                renderSource = renderSource,
                referenceBitmap = referenceBitmap,
                capturedBitmap = capturedBitmap
            )
        }
        outFile
    }

    suspend fun deletePdfFile(file: File): Boolean = withContext(Dispatchers.IO) {
        runCatching { file.exists() && file.delete() }.getOrDefault(false)
    }

    suspend fun clearAllPdfFiles(): Int = withContext(Dispatchers.IO) {
        var deletedCount = 0
        listOf(archiveDirectory(), cachePdfDirectory()).forEach { dir ->
            dir.listFiles { f -> f.isFile && f.extension.equals("pdf", ignoreCase = true) }
                ?.forEach { pdf ->
                    if (runCatching { pdf.delete() }.getOrDefault(false)) {
                        deletedCount++
                    }
                }
        }
        deletedCount
    }

    fun shareExistingPdfFile(activityContext: Context, pdfFile: File) {
        val authority = "${activityContext.packageName}.fileprovider"
        val contentUri = FileProvider.getUriForFile(activityContext, authority, pdfFile)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, contentUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(
            shareIntent,
            activityContext.getString(R.string.share_chooser_title)
        )
        val activity = activityContext.findActivity()
        if (activity != null) {
            activity.startActivity(chooser)
        } else {
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activityContext.startActivity(chooser)
        }
    }

    fun printExistingPdfFile(activityContext: Context, pdfFile: File) {
        val activity = activityContext.findActivity()
            ?: throw IllegalStateException("Activity context diperlukan untuk PrintManager")
        val printManager = activity.getSystemService(Context.PRINT_SERVICE) as PrintManager
        val jobName = pdfFile.nameWithoutExtension.take(48).ifBlank { "Dokumen_PDF" }
        val attributes = PrintAttributes.Builder()
            .setMediaSize(PrintAttributes.MediaSize.ISO_A4.asPortrait())
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .build()
        printManager.print(
            jobName,
            ExistingPdfFilePrintAdapter(pdfFile = pdfFile, ioScope = printScope),
            attributes
        )
    }
}

private class ExistingPdfFilePrintAdapter(
    private val pdfFile: File,
    private val ioScope: CoroutineScope
) : PrintDocumentAdapter() {

    override fun onLayout(
        oldAttributes: PrintAttributes?,
        newAttributes: PrintAttributes,
        cancellationSignal: CancellationSignal?,
        callback: LayoutResultCallback,
        extras: Bundle?
    ) {
        if (cancellationSignal?.isCanceled == true) {
            callback.onLayoutCancelled()
            return
        }
        val info = PrintDocumentInfo.Builder(pdfFile.name)
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
            .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
            .build()
        callback.onLayoutFinished(info, oldAttributes != newAttributes)
    }

    override fun onWrite(
        pages: Array<out PageRange>?,
        destination: ParcelFileDescriptor,
        cancellationSignal: CancellationSignal?,
        callback: WriteResultCallback
    ) {
        val job = ioScope.launch {
            ParcelFileDescriptor.AutoCloseOutputStream(destination).use { output ->
                try {
                    if (cancellationSignal?.isCanceled == true) {
                        callback.onWriteCancelled()
                        return@launch
                    }
                    FileInputStream(pdfFile).use { input ->
                        input.copyTo(output)
                    }
                    output.flush()
                    callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    if (cancellationSignal?.isCanceled == true) {
                        callback.onWriteCancelled()
                    } else {
                        callback.onWriteFailed(e.localizedMessage ?: "Gagal membaca file PDF")
                    }
                }
            }
        }
        cancellationSignal?.setOnCancelListener { job.cancel() }
    }
}
