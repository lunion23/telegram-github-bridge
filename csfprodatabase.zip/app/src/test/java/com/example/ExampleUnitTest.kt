package com.example

import com.example.data.export.WorkOrderPdfGenerator
import com.example.data.model.WorkOrderItem
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    private fun createDummyItem(tipe: String, description: String, catatan: String = ""): WorkOrderItem {
        return WorkOrderItem(
            id = 1,
            name = "WO-CLG-2024-001",
            mobilName = "B 9451 UXT",
            trandate = "2024-05-01",
            trandateMillis = 1714521600000L,
            trandateFormatted = "2024-05-01",
            kmCurrent = 150000,
            keluhan = "Rem bunyi",
            tipe = tipe,
            kode = "PRD-001",
            description = description,
            catatan = catatan,
            startTime = "08:00",
            endTime = "10:00",
            qty = 1.0,
            total = 1.0,
            totalPrice = 50000.0,
            productClass = "Maintenance",
            noChassis = "CHASSIS123",
            noMesin = "ENGINE123"
        )
    }

    @Test
    fun testExtractTwoMechanicsFromSeparateRows() {
        val items = listOf(
            createDummyItem(tipe = "MEKANIK", description = "AZIZ"),
            createDummyItem(tipe = "PART", description = "KAMPAS REM"),
            createDummyItem(tipe = "MEKANIK", description = "BUDI")
        )

        val mechanics = WorkOrderPdfGenerator.extractDistinctMechanics(items)
        assertEquals(listOf("AZIZ", "BUDI"), mechanics)
    }

    @Test
    fun testExtractTwoMechanicsFromSingleRowSlash() {
        val items = listOf(
            createDummyItem(tipe = "MEKANIK", description = "AZIZ / BAMBANG")
        )

        val mechanics = WorkOrderPdfGenerator.extractDistinctMechanics(items)
        assertEquals(listOf("AZIZ", "BAMBANG"), mechanics)
    }

    @Test
    fun testExtractMechanicsWithPrefixAndDeduplication() {
        val items = listOf(
            createDummyItem(tipe = "MEKANIK", description = "Mekanik: AZIZ"),
            createDummyItem(tipe = "TEKNISI", description = "aziz")
        )

        val mechanics = WorkOrderPdfGenerator.extractDistinctMechanics(items)
        assertEquals(listOf("AZIZ"), mechanics)
    }
}
