package com.example.util

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.content.FileProvider
import com.example.data.model.ReceiptData
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

object PdfReceiptGenerator {

    private const val PDF_WIDTH = 420
    private const val PDF_HEIGHT = 650

    /**
     * Generates a PDF file from receipt data.
     */
    fun generatePdfFile(context: Context, receipt: ReceiptData): File {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(PDF_WIDTH, PDF_HEIGHT, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        drawReceiptOnCanvas(canvas, receipt, PDF_WIDTH.toFloat(), PDF_HEIGHT.toFloat())

        pdfDocument.finishPage(page)

        val outputDir = File(context.cacheDir, "receipt_pdfs").apply { mkdirs() }
        val sanitizedResi = receipt.resiCode.replace("[^a-zA-Z0-9]".toRegex(), "_")
        val outputFile = File(outputDir, "Struk_${sanitizedResi}.pdf")

        FileOutputStream(outputFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
        return outputFile
    }

    /**
     * Renders a PDF file into a preview Bitmap using PdfRenderer.
     */
    fun renderPdfToBitmap(pdfFile: File): Bitmap? {
        if (!pdfFile.exists()) return null
        return try {
            val fileDescriptor = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
            val renderer = PdfRenderer(fileDescriptor)
            if (renderer.pageCount == 0) {
                renderer.close()
                fileDescriptor.close()
                return null
            }
            val page = renderer.openPage(0)
            val scale = 2.0f // High-res preview
            val bitmap = Bitmap.createBitmap(
                (page.width * scale).toInt(),
                (page.height * scale).toInt(),
                Bitmap.Config.ARGB_8888
            )
            bitmap.eraseColor(Color.WHITE)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            page.close()
            renderer.close()
            fileDescriptor.close()
            bitmap
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Unwraps context to obtain the enclosing Activity.
     */
    fun findActivity(context: Context): Activity? {
        var ctx = context
        while (ctx is ContextWrapper) {
            if (ctx is Activity) return ctx
            ctx = ctx.baseContext
        }
        return null
    }

    /**
     * Launches the system PrintManager to print the PDF.
     */
    fun printPdf(context: Context, pdfFile: File, jobName: String = "Cetak Struk"): Boolean {
        val activity = findActivity(context) ?: return false
        val printManager = activity.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return false
        val printAdapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder("$jobName.pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build()
                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                var input: FileInputStream? = null
                var output: FileOutputStream? = null
                try {
                    input = FileInputStream(pdfFile)
                    output = FileOutputStream(destination?.fileDescriptor)
                    val buf = ByteArray(1024)
                    var bytesRead: Int
                    while (input.read(buf).also { bytesRead = it } > 0) {
                        if (cancellationSignal?.isCanceled == true) {
                            callback?.onWriteCancelled()
                            return
                        }
                        output.write(buf, 0, bytesRead)
                    }
                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                } finally {
                    try { input?.close() } catch (_: IOException) {}
                    try { output?.close() } catch (_: IOException) {}
                }
            }
        }

        val attributes = PrintAttributes.Builder()
            .setMediaSize(PrintAttributes.MediaSize.ISO_A6)
            .setResolution(PrintAttributes.Resolution("thermal", "Thermal", 300, 300))
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .build()

        printManager.print(jobName, printAdapter, attributes)
        return true
    }

    /**
     * Shares the generated PDF file using standard Android Intent.
     */
    fun sharePdf(context: Context, pdfFile: File) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.provider",
                pdfFile
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Struk Resi ${pdfFile.name}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, "Bagikan Struk PDF")
            if (context !is Activity) {
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Draws the exact shipping label layout on any Canvas (used for PDF and Thermal Bitmap Rasterizer).
     */
    fun drawReceiptOnCanvas(
        canvas: Canvas,
        receipt: ReceiptData,
        width: Float,
        height: Float
    ) {
        // Background
        val bgPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, width, height, bgPaint)

        val borderPaint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }

        val fillBlackPaint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        val textPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }

        val boldTextPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }

        val whiteBoldPaint = Paint().apply {
            color = Color.WHITE
            isAntiAlias = true
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }

        val margin = 8f
        val leftBorder = 26f
        val rightBorder = width - 26f
        val topBorder = 12f
        val bottomBorder = height - 12f

        // Draw outer bounding box for content
        canvas.drawRect(leftBorder, topBorder, rightBorder, bottomBorder, borderPaint)

        // Draw vertical side texts (repeating Resi code on left and right)
        val sidePaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 7.5f
            isAntiAlias = true
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }

        // Left vertical text (4 times)
        val segmentHeight = (bottomBorder - topBorder) / 4f
        for (i in 0 until 4) {
            val yPos = topBorder + (i * segmentHeight) + (segmentHeight * 0.7f)
            canvas.save()
            canvas.rotate(-90f, 14f, yPos)
            canvas.drawText(receipt.resiCode, 14f - 24f, yPos, sidePaint)
            canvas.restore()
        }

        // Right vertical text (4 times)
        for (i in 0 until 4) {
            val yPos = topBorder + (i * segmentHeight) + (segmentHeight * 0.7f)
            canvas.save()
            canvas.rotate(90f, width - 14f, yPos)
            canvas.drawText(receipt.resiCode, width - 14f - 24f, yPos, sidePaint)
            canvas.restore()
        }

        // Top Badges [NP] [EZ]
        val badgeWidth = 44f
        val badgeHeight = 22f
        val badge2Left = rightBorder - badgeWidth - 4f
        val badge1Left = badge2Left - badgeWidth - 4f
        val badgeTop = topBorder + 4f

        canvas.drawRect(badge1Left, badgeTop, badge1Left + badgeWidth, badgeTop + badgeHeight, fillBlackPaint)
        canvas.drawRect(badge2Left, badgeTop, badge2Left + badgeWidth, badgeTop + badgeHeight, fillBlackPaint)

        whiteBoldPaint.textSize = 13f
        whiteBoldPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.badge1, badge1Left + (badgeWidth / 2), badgeTop + 16f, whiteBoldPaint)
        canvas.drawText(receipt.badge2, badge2Left + (badgeWidth / 2), badgeTop + 16f, whiteBoldPaint)

        // Big Routing Code (e.g. 350-4BDO88-16A)
        boldTextPaint.textSize = 23f
        boldTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText(receipt.routingCode, leftBorder + 8f, badgeTop + 20f, boldTextPaint)

        // Divider under routing code
        var currentY = badgeTop + badgeHeight + 6f
        canvas.drawLine(leftBorder, currentY, rightBorder, currentY, borderPaint)

        // 1D Barcode of Resi Code
        currentY += 4f
        val barcodeBitmap = BarcodeGenerator.generateBarcode128(receipt.resiCode, width = 500, height = 90)
        val barcodeRect = RectF(leftBorder + 18f, currentY, rightBorder - 18f, currentY + 54f)
        if (barcodeBitmap != null) {
            canvas.drawBitmap(barcodeBitmap, null, barcodeRect, null)
        }

        // Resi code text under barcode
        currentY += 58f
        boldTextPaint.textSize = 12f
        boldTextPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.resiCode, (leftBorder + rightBorder) / 2f, currentY + 10f, boldTextPaint)

        // Full width black drop point banner
        currentY += 15f
        canvas.drawRect(leftBorder, currentY, rightBorder, currentY + 22f, fillBlackPaint)
        whiteBoldPaint.textSize = 11.5f
        whiteBoldPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.dropPoint, (leftBorder + rightBorder) / 2f, currentY + 16f, whiteBoldPaint)
        currentY += 22f

        // Recipient Section
        currentY += 12f
        boldTextPaint.textSize = 10f
        boldTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Penerima: ${receipt.recipientName}", leftBorder + 6f, currentY, boldTextPaint)

        boldTextPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(receipt.getDisplayRecipientPhone(), rightBorder - 6f, currentY, boldTextPaint)

        // Recipient Address (multiline)
        currentY += 4f
        textPaint.textSize = 8.5f
        textPaint.textAlign = Paint.Align.LEFT
        currentY = drawMultilineText(
            canvas,
            receipt.recipientAddress,
            leftBorder + 6f,
            currentY + 10f,
            rightBorder - leftBorder - 12f,
            textPaint,
            lineSpacing = 11f,
            maxLines = 4
        )

        // Divider
        currentY += 6f
        canvas.drawLine(leftBorder, currentY, rightBorder, currentY, borderPaint)

        // Sender Section
        currentY += 12f
        boldTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Pengirim: ${receipt.senderName}", leftBorder + 6f, currentY, boldTextPaint)

        boldTextPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(receipt.getDisplaySenderPhone(), rightBorder - 6f, currentY, boldTextPaint)

        // Sender Address
        currentY += 4f
        currentY = drawMultilineText(
            canvas,
            receipt.senderAddress,
            leftBorder + 6f,
            currentY + 10f,
            rightBorder - leftBorder - 12f,
            textPaint,
            lineSpacing = 11f,
            maxLines = 3
        )

        // Divider
        currentY += 6f
        canvas.drawLine(leftBorder, currentY, rightBorder, currentY, borderPaint)

        // Shipping Details Table
        val tableTop = currentY
        val col1Width = 84f
        val col2Width = 60f
        val col3Width = 75f
        val col4Left = leftBorder + col1Width + col2Width + col3Width

        val row1Height = 32f
        val row2Height = 20f
        val row3Height = 18f
        val tableHeight = row1Height + row2Height + row3Height

        // Row 1 divider
        canvas.drawLine(leftBorder, tableTop + row1Height, rightBorder, tableTop + row1Height, borderPaint)
        // Row 2 divider
        canvas.drawLine(leftBorder, tableTop + row1Height + row2Height, rightBorder, tableTop + row1Height + row2Height, borderPaint)
        // Row 3 divider
        canvas.drawLine(leftBorder, tableTop + tableHeight, rightBorder, tableTop + tableHeight, borderPaint)

        // Vertical column dividers in Row 1 & 2
        val col1Right = leftBorder + col1Width
        val col2Right = col1Right + col2Width
        val col3Right = col2Right + col3Width

        // Col 1 vertical line full table height
        canvas.drawLine(col1Right, tableTop, col1Right, tableTop + row1Height + row2Height, borderPaint)
        // Col 2 vertical line in Row 1
        canvas.drawLine(col2Right, tableTop, col2Right, tableTop + row1Height, borderPaint)
        // Col 3 vertical line in Row 1 & Row 2
        canvas.drawLine(col3Right, tableTop, col3Right, tableTop + row1Height + row2Height, borderPaint)

        // Col 1 Content: Black header "BIAYA PENGIRIMAN", bold IDR 7,200, small note
        val c1HeaderHeight = 11f
        canvas.drawRect(leftBorder, tableTop, col1Right, tableTop + c1HeaderHeight, fillBlackPaint)
        whiteBoldPaint.textSize = 6.8f
        whiteBoldPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("BIAYA PENGIRIMAN", leftBorder + (col1Width / 2f), tableTop + 8.5f, whiteBoldPaint)

        boldTextPaint.textSize = 10.5f
        boldTextPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.getFormattedFee(), leftBorder + (col1Width / 2f), tableTop + 21f, boldTextPaint)

        textPaint.textSize = 6.2f
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("Sudah Termasuk PPH", leftBorder + (col1Width / 2f), tableTop + 29f, textPaint)

        // Col 2: Payment Type
        boldTextPaint.textSize = 9.5f
        boldTextPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.paymentType, col1Right + (col2Width / 2f), tableTop + 18f, boldTextPaint)

        // Col 3: Weight
        boldTextPaint.textSize = 9.5f
        canvas.drawText("• ${receipt.weightKg}", col2Right + (col3Width / 2f), tableTop + 18f, boldTextPaint)

        // Col 4: Print Date
        textPaint.textSize = 8f
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("Cetak ${receipt.printDate}", col3Right + ((rightBorder - col3Right) / 2f), tableTop + 18f, textPaint)

        // Row 2: Order No (spanning col 2 and 3)
        textPaint.textSize = 7.5f
        textPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Order No. ${receipt.orderNo}", col1Right + 5f, tableTop + row1Height + 14f, textPaint)

        // Exp in Col 4
        canvas.drawText("Exp: ${receipt.expNote}", col3Right + 5f, tableTop + row1Height + 14f, textPaint)

        // Row 3: Notes (full width)
        textPaint.textSize = 7.8f
        canvas.drawText("Notes: ${receipt.notes}", leftBorder + 6f, tableTop + row1Height + row2Height + 13f, textPaint)

        // Footer Section
        currentY = tableTop + tableHeight + 8f

        // QR Code on right
        val qrSize = 68f
        val qrLeft = rightBorder - qrSize - 4f
        val qrTop = currentY
        val qrBitmap = BarcodeGenerator.generateQrCode(receipt.resiCode, size = 180)
        if (qrBitmap != null) {
            canvas.drawBitmap(qrBitmap, null, RectF(qrLeft, qrTop, qrLeft + qrSize, qrTop + qrSize), null)
        }

        // Left Footer Text
        textPaint.textSize = 6.5f
        textPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Syarat dan ketentuan pengiriman dilihat pada website", leftBorder + 6f, currentY + 8f, textPaint)

        val lines = receipt.footerCompany.split("\n")
        var footerY = currentY + 18f
        for (line in lines) {
            canvas.drawText(line.trim(), leftBorder + 6f, footerY, textPaint)
            footerY += 9f
        }
    }

    private fun drawMultilineText(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        maxWidth: Float,
        paint: Paint,
        lineSpacing: Float,
        maxLines: Int
    ): Float {
        val words = text.split(" ")
        var currentLine = StringBuilder()
        var currentY = y
        var lineCount = 0

        for (word in words) {
            val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
            val width = paint.measureText(testLine)
            if (width > maxWidth && currentLine.isNotEmpty()) {
                canvas.drawText(currentLine.toString(), x, currentY, paint)
                currentLine = StringBuilder(word)
                currentY += lineSpacing
                lineCount++
                if (lineCount >= maxLines - 1) break
            } else {
                currentLine = StringBuilder(testLine)
            }
        }
        if (currentLine.isNotEmpty()) {
            canvas.drawText(currentLine.toString(), x, currentY, paint)
            currentY += lineSpacing
        }
        return currentY
    }
}
