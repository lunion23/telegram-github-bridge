package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = StudioCyan,
    onPrimary = Color.Black,
    primaryContainer = StudioCyanDim.copy(alpha = 0.2f),
    onPrimaryContainer = StudioCyan,
    secondary = StudioViolet,
    onSecondary = Color.White,
    secondaryContainer = StudioVioletDark.copy(alpha = 0.25f),
    onSecondaryContainer = Color.White,
    background = DarkBackground,
    onBackground = LightTextPrimary,
    surface = DarkSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = LightTextSecondary,
    outline = DarkBorder,
    error = ErrorRed,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = StudioViolet,
    onPrimary = Color.White,
    secondary = StudioCyanDim,
    onSecondary = Color.Black,
    background = Color(0xFFF7F9FC),
    onBackground = Color(0xFF13171F),
    surface = Color.White,
    onSurface = Color(0xFF13171F),
    surfaceVariant = Color(0xFFE9EEF5),
    onSurfaceVariant = Color(0xFF475263),
    outline = Color(0xFFD0D7E2),
    error = ErrorRed,
    onError = Color.White
)

@Composable
fun VideoTrimmerTheme(
    darkTheme: Boolean = true, // Mengutamakan dark theme untuk editing video
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
