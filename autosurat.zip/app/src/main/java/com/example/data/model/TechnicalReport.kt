package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "technical_reports")
data class TechnicalReport(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val companyName: String = "Hiba Group",
    val companyLogoUri: String? = null,
    val noLaporan: String = "1/LT-CLG/III/2026",
    val bengkel: String = "Cilegon",
    val tanggalLaporan: String = "12-Mar-26",
    val pabrikPembuat: String = "HINO",
    val model: String = "W04DTPJ-53447",
    val tipe: String = "DUTRO",
    val kode: String = "D127",
    val tanggalRusak: String = "12-Mar-26",
    val kmHm: String = "598916",
    val namaAlat: String = "Ban",
    val komponen: String = "Underbody",
    
    // Uraian Kerusakan
    val isMasaGaransi: Boolean = false, // false = Setelah Masa Garansi
    val tanggalKejadian: String = "12 Maret 2026",
    val statusArmada: String = "Storing",
    val kerusakan: String = "Ban kempes",
    val lokasi: String = "Tol tangerang - merak",
    val analisa: String = "Setelah di lakukan storing oleh team cikupa di temukan ban depan kiri kempes",
    
    // Kesimpulan riwayat
    val kesimpulanPenggantianTerakhir: String = "9-5-2022 (km.415513)",
    val noWoPenggantianTerakhir: String = "KLD1-WO-2205-00381",
    val weeklyTerakhir: String = "5-3-2026 (km.598234)",
    val noWoWeeklyTerakhir: String = "CLG1-WO-2603-00225",
    
    // Foto Kerusakan (Comma-separated local file URIs or paths)
    val fotoKerusakanPaths: String = "",
    
    // Penyebab Kerusakan Checklist
    val penyebabPemasangan: Boolean = false,
    val penyebabKwalitasParts: Boolean = false,
    val penyebabKesalahanOperasional: Boolean = false,
    val penyebabSudahWaktunya: Boolean = true,
    val penyebabLainLain: Boolean = false,
    val penyebabPenjelasan: String = "",
    
    // Cara Mengatasi Kerusakan
    val caraGantiPartBaru: Boolean = false,
    val caraPenyetelanUlang: Boolean = true,
    val caraModifikasi: Boolean = false,
    val caraDeskripsi: String = "Ganti ban stip",
    
    // Usulan
    val tertundaKarena: String = "",
    val usulanPelapor: String = "Segera akan di lakukan program pengecekan atau penggantian terkait part tersebut terhadap RK8J supaya tidak terjadi kejadian serupa",
    
    // Spare Parts (JSON string of 5 items)
    val partsJson: String = "",
    
    // Pengesahan / Tanda Tangan
    val mengetahui1Nama: String = "",
    val mengetahui1Jabatan: String = "",
    val mengetahui1SignaturePath: String? = null,
    
    val mengetahui2Nama: String = "",
    val mengetahui2Jabatan: String = "",
    val mengetahui2SignaturePath: String? = null,
    
    val pelaporNama: String = "Yudi Indrawan",
    val pelaporJabatan: String = "Wa.Ka.Bengkel",
    val pelaporSignaturePath: String? = null,
    
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun getPhotoList(): List<String> {
        if (fotoKerusakanPaths.isBlank()) return emptyList()
        return fotoKerusakanPaths.split("|||").filter { it.isNotBlank() }
    }
}
