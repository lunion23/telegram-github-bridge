package com.example.data.local

import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.room.withTransaction
import com.example.data.model.ImportMode
import com.example.data.model.ImportProgress
import com.example.data.model.WorkOrderItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DatabaseBackupManager {

    private const val DB_FILE_NAME = "fleet_work_orders.db"

    /**
     * Checkpoints WAL journal so all committed writes are merged into the main .db file.
     */
    private fun checkpointWal(context: Context) {
        try {
            val db = WorkOrderDatabase.getInstance(context)
            if (db.isOpen) {
                val cursor = db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)")
                cursor.moveToFirst()
                cursor.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Exports the SQLite database (.db) to a user-selected SAF destination Uri.
     */
    suspend fun exportDatabaseToUri(
        context: Context,
        destinationUri: Uri
    ): Result<Long> = withContext(Dispatchers.IO) {
        try {
            checkpointWal(context)
            val dbFile = context.getDatabasePath(DB_FILE_NAME)
            if (!dbFile.exists() || dbFile.length() == 0L) {
                return@withContext Result.failure(IllegalStateException("File database belum memiliki data untuk diekspor."))
            }

            var bytesCopied = 0L
            FileInputStream(dbFile).use { fis ->
                context.contentResolver.openOutputStream(destinationUri)?.use { fos ->
                    bytesCopied = fis.copyTo(fos)
                } ?: return@withContext Result.failure(IllegalStateException("Tidak dapat membuka tujuan penyimpanan file."))
            }

            Result.success(bytesCopied)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Exports SQLite database (.db) to app cache and triggers Android Share sheet.
     */
    suspend fun exportDatabaseAndShare(
        context: Context
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            checkpointWal(context)
            val dbFile = context.getDatabasePath(DB_FILE_NAME)
            if (!dbFile.exists() || dbFile.length() == 0L) {
                return@withContext Result.failure(IllegalStateException("File database belum memiliki data untuk dibagikan."))
            }

            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
            val backupFile = File(exportDir, "datacsv_backup_$timeStamp.db")

            FileInputStream(dbFile).use { fis ->
                FileOutputStream(backupFile).use { fos ->
                    fis.copyTo(fos)
                }
            }

            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                backupFile
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/x-sqlite3"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Backup Database DataCSV ($timeStamp)")
                putExtra(Intent.EXTRA_TEXT, "File cadangan SQLite database DataCSV: ${backupFile.name}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(shareIntent, "Bagikan / Simpan File Database (.db)").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)

            Result.success(backupFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Imports an external SQLite database (.db), validates table 'work_order_items',
     * and restores rows into the application Room database using the specified ImportMode (Append or Replace All).
     */
    suspend fun importDatabaseFromUri(
        context: Context,
        sourceUri: Uri,
        mode: ImportMode = ImportMode.REPLACE_ALL,
        onProgress: suspend (ImportProgress) -> Unit
    ): Result<Int> = withContext(Dispatchers.IO) {
        var tempFile: File? = null
        var tempDb: SQLiteDatabase? = null
        try {
            onProgress(
                ImportProgress(
                    isImporting = true,
                    processedRows = 0L,
                    totalEstimatedRows = 0L,
                    percentage = 5,
                    statusText = "Menyalin file database ke penyimpanan sementara..."
                )
            )

            val tempDir = File(context.cacheDir, "temp_db_import").apply { mkdirs() }
            tempFile = File(tempDir, "import_${System.currentTimeMillis()}.db")

            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext Result.failure(IllegalStateException("Tidak dapat membaca file database dari Uri."))

            onProgress(
                ImportProgress(
                    isImporting = true,
                    processedRows = 0L,
                    totalEstimatedRows = 0L,
                    percentage = 15,
                    statusText = "Memverifikasi struktur tabel SQLite database..."
                )
            )

            tempDb = SQLiteDatabase.openDatabase(tempFile.path, null, SQLiteDatabase.OPEN_READONLY)

            // Validate table existence
            val checkCursor = tempDb.rawQuery(
                "SELECT count(*) FROM sqlite_master WHERE type='table' AND name='work_order_items'",
                null
            )
            val tableExists = checkCursor.use {
                it.moveToFirst() && it.getInt(0) > 0
            }

            if (!tableExists) {
                return@withContext Result.failure(
                    IllegalArgumentException("File yang dipilih bukan database Work Order yang valid (tabel 'work_order_items' tidak ditemukan).")
                )
            }

            // Count total rows to restore
            val countCursor = tempDb.rawQuery("SELECT count(*) FROM work_order_items", null)
            val totalRowsInDb = countCursor.use {
                if (it.moveToFirst()) it.getInt(0) else 0
            }

            if (totalRowsInDb == 0) {
                return@withContext Result.failure(
                    IllegalArgumentException("Database yang dipilih kosong (0 baris data).")
                )
            }

            val roomDb = WorkOrderDatabase.getInstance(context)
            val dao = roomDb.workOrderDao()

            // If Replace All, clear existing database records first
            if (mode == ImportMode.REPLACE_ALL) {
                onProgress(
                    ImportProgress(
                        isImporting = true,
                        processedRows = 0L,
                        totalEstimatedRows = totalRowsInDb.toLong(),
                        percentage = 20,
                        statusText = "Mengosongkan database lama untuk penggantian bersih..."
                    )
                )
                roomDb.withTransaction {
                    dao.clearAll()
                }
            }

            // Read cursor in batches and insert into live Room DB
            val queryCursor = tempDb.rawQuery("SELECT * FROM work_order_items ORDER BY id ASC", null)
            var totalRestored = 0
            val batchSize = 2500
            val currentBatch = ArrayList<WorkOrderItem>(batchSize)

            queryCursor.use { cursor ->
                while (cursor.moveToNext()) {
                    val item = parseWorkOrderItemFromCursor(cursor)
                    currentBatch.add(item)
                    totalRestored++

                    if (currentBatch.size >= batchSize) {
                        val toInsert = ArrayList(currentBatch)
                        currentBatch.clear()
                        roomDb.withTransaction {
                            dao.insertBatch(toInsert)
                        }

                        val pct = ((totalRestored.toDouble() / totalRowsInDb.toDouble()) * 75).toInt() + 20
                        val actionDesc = if (mode == ImportMode.APPEND) "Menambahkan" else "Memulihkan"
                        onProgress(
                            ImportProgress(
                                isImporting = true,
                                processedRows = totalRestored.toLong(),
                                totalEstimatedRows = totalRowsInDb.toLong(),
                                percentage = pct.coerceIn(20, 95),
                                statusText = "$actionDesc data: $totalRestored / $totalRowsInDb baris..."
                            )
                        )
                    }
                }

                // Insert any remaining items
                if (currentBatch.isNotEmpty()) {
                    val toInsert = ArrayList(currentBatch)
                    currentBatch.clear()
                    roomDb.withTransaction {
                        dao.insertBatch(toInsert)
                    }
                }
            }

            val finalDesc = if (mode == ImportMode.APPEND)
                "Berhasil menambahkan $totalRestored baris data baru ke database!"
            else
                "Database berhasil diganti & dipulihkan ($totalRestored baris data)!"

            onProgress(
                ImportProgress(
                    isImporting = true,
                    processedRows = totalRestored.toLong(),
                    totalEstimatedRows = totalRowsInDb.toLong(),
                    percentage = 100,
                    statusText = finalDesc
                )
            )

            Result.success(totalRestored)
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            try {
                tempDb?.close()
            } catch (_: Exception) {}
            try {
                tempFile?.delete()
            } catch (_: Exception) {}
        }
    }

    private fun parseWorkOrderItemFromCursor(c: Cursor): WorkOrderItem {
        return WorkOrderItem(
            id = 0, // Auto-generate clean primary key in destination DB (prevents ID collisions during Append)
            name = getColString(c, "name"),
            mobilName = getColString(c, "mobilName"),
            trandate = getColString(c, "trandate"),
            trandateMillis = getColLong(c, "trandateMillis", System.currentTimeMillis()),
            trandateFormatted = getColString(c, "trandateFormatted"),
            kmCurrent = getColLong(c, "kmCurrent", 0L),
            keluhan = getColString(c, "keluhan"),
            tipe = getColString(c, "tipe"),
            kode = getColString(c, "kode"),
            description = getColString(c, "description"),
            catatan = getColString(c, "catatan"),
            startTime = getColString(c, "startTime"),
            endTime = getColString(c, "endTime"),
            qty = getColDouble(c, "qty", 1.0),
            total = getColDouble(c, "total", 1.0),
            totalPrice = getColDouble(c, "totalPrice", 0.0),
            productClass = getColString(c, "productClass"),
            noChassis = getColString(c, "noChassis"),
            noMesin = getColString(c, "noMesin")
        )
    }

    private fun getColString(c: Cursor, name: String, default: String = ""): String {
        val idx = c.getColumnIndex(name)
        return if (idx >= 0 && !c.isNull(idx)) c.getString(idx) else default
    }

    private fun getColLong(c: Cursor, name: String, default: Long = 0L): Long {
        val idx = c.getColumnIndex(name)
        return if (idx >= 0 && !c.isNull(idx)) c.getLong(idx) else default
    }

    private fun getColDouble(c: Cursor, name: String, default: Double = 0.0): Double {
        val idx = c.getColumnIndex(name)
        return if (idx >= 0 && !c.isNull(idx)) c.getDouble(idx) else default
    }
}
