package com.example.data.local

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlin.math.max
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Durable local storage manager for camera-captured or gallery-imported document images.
 * Saves compressed high-clarity JPEGs inside `filesDir/captured_docs/` so captured documents
 * survive app restarts and can be reloaded from [com.example.model.LabelHistoryItem].
 */
object CapturedDocumentStorage {

    private const val CAPTURED_DIR_NAME = "captured_docs"
    private const val MAX_STORED_DIMENSION_PX = 2200
    private const val JPEG_QUALITY = 92

    suspend fun saveCapturedBitmap(
        context: Context,
        bitmap: Bitmap,
        fileId: String = UUID.randomUUID().toString()
    ): String = withContext(Dispatchers.IO) {
        saveCapturedBitmapBlocking(context, bitmap, fileId)
    }

    fun saveCapturedBitmapBlocking(
        context: Context,
        bitmap: Bitmap,
        fileId: String = UUID.randomUUID().toString()
    ): String {
        val dir = File(context.filesDir, CAPTURED_DIR_NAME)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        val cleanId = fileId.replace(Regex("[^A-Za-z0-9_-]"), "").ifBlank {
            UUID.randomUUID().toString().replace("-", "")
        }
        val targetFile = File(dir, "doc_${cleanId}.jpg")
        val normalizedBitmap = downscaleIfOversized(bitmap, MAX_STORED_DIMENSION_PX)
        FileOutputStream(targetFile).use { fos ->
            normalizedBitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, fos)
            fos.flush()
        }
        return targetFile.absolutePath
    }

    suspend fun loadCapturedBitmap(path: String): Bitmap? = withContext(Dispatchers.IO) {
        loadCapturedBitmapBlocking(path)
    }

    fun loadCapturedBitmapBlocking(path: String): Bitmap? {
        val trimmed = path.trim()
        if (trimmed.isEmpty()) return null
        val file = File(trimmed)
        if (!file.exists() || !file.isFile || file.length() <= 0L) return null
        return runCatching {
            BitmapFactory.decodeFile(file.absolutePath)
        }.getOrNull()
    }

    suspend fun decodeUriBitmap(
        context: Context,
        uri: Uri,
        maxDimensionPx: Int = MAX_STORED_DIMENSION_PX
    ): Bitmap? = withContext(Dispatchers.IO) {
        runCatching {
            val boundsOptions = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, boundsOptions)
            }
            val rawW = boundsOptions.outWidth
            val rawH = boundsOptions.outHeight
            if (rawW <= 0 || rawH <= 0) return@runCatching null

            var sampleSize = 1
            while (max(rawW / sampleSize, rawH / sampleSize) > maxDimensionPx * 2) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val decoded = context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOptions)
            } ?: return@runCatching null

            downscaleIfOversized(decoded, maxDimensionPx)
        }.getOrNull()
    }

    suspend fun deleteCapturedFile(path: String) = withContext(Dispatchers.IO) {
        deleteCapturedFileBlocking(path)
    }

    fun deleteCapturedFileBlocking(path: String) {
        val trimmed = path.trim()
        if (trimmed.isEmpty()) return
        runCatching {
            val file = File(trimmed)
            if (file.exists() && file.isFile && file.parentFile?.name == CAPTURED_DIR_NAME) {
                file.delete()
            }
        }
    }

    internal fun downscaleIfOversized(bitmap: Bitmap, maxDimensionPx: Int): Bitmap {
        val maxSide = max(bitmap.width, bitmap.height)
        if (maxSide <= maxDimensionPx || maxSide <= 0) return bitmap
        val ratio = maxDimensionPx.toFloat() / maxSide.toFloat()
        val targetW = (bitmap.width * ratio).roundToInt().coerceAtLeast(1)
        val targetH = (bitmap.height * ratio).roundToInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
    }
}
