# MomentSnap AI - Analisis Momen Video Menarik & Konten Viral

MomentSnap AI adalah aplikasi Android cerdas berbasis Jetpack Compose dan Material 3 untuk kreator konten dan editor video. Aplikasi ini menganalisis video panjang dari penyimpanan lokal maupun tautan YouTube secara otomatis untuk menemukan momen-momen paling menarik, memberikan stempel waktu pemotongan (*trimming timestamps*), kalimat pembuka penarik perhatian (*hooks*), rekomendasi judul viral, deskripsi media sosial multi-platform (TikTok, Instagram Reels, YouTube Shorts), estimasi metrik keterlibatan audiens (*audience engagement*), serta rekomendasi tagar dan strategi SEO.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> Keputusan utama yang telah dikonfirmasi pada tahap klarifikasi:
> - **Fokus Konten Multi-Platform**: Menghasilkan variasi deskripsi dan tagar yang disesuaikan untuk TikTok, Instagram Reels, dan YouTube Shorts sekaligus.
> - **Pemutar Video Interaktif Terintegrasi**: Pemutar video bawaan di dalam aplikasi yang memungkinkan pengguna mengetuk stempel waktu (*timestamp*) untuk langsung melompat (*seek*) ke momen klip menarik secara presisi.
> - **Analisa Cerdas All-in-One**: Menampilkan seluruh data penting sekaligus dalam tab dan kartu interaktif (ringkasan poin utama, klip momen, hook viral, judul atraktif, deskripsi medsos, estimasi engagement, dan SEO).

- **Pilihan Sumber Video**: Mendukung pemilihan video lokal dari galeri perangkat (melalui Android Photo/Video Picker), input URL video YouTube (dengan thumbnail & ekstraksi metadata otomatis), serta opsi video sampel bawaan untuk pengujian instan.
- **Penyimpanan Riwayat Analisa**: Menggunakan Room Database lokal agar semua video yang telah dianalisis, daftar momen tersimpan, dan naskah klip dapat diakses kembali secara offline tanpa membebani kuota.
- **Mesin Analisis Cerdas**: Menggunakan integrasi AI terstruktur untuk menganalisis konteks video/transkrip dan mengekstrak segmen klip dengan skor potensi viral yang tinggi.

---

### 1. Overview & Core Concept

- **Apa yang Dilakukan Aplikasi**:
  1. Menerima input video dari galeri lokal perangkat atau tautan video YouTube.
  2. Menganalisis konten video dan menghasilkan ringkasan poin-poin utama otomatis.
  3. Mengidentifikasi segmen momen menarik lengkap dengan waktu mulai & selesai (*timestamp trimming: in/out*), alasan kenapa momen tersebut menarik, dan teks subtitle ringkas.
  4. Menghasilkan ide *video hook* (3 detik pertama) dengan berbagai gaya (pertanyaan penasaran, kontroversial, punchline emosional, edukatif).
  5. Menghasilkan draf deskripsi konten siap pakai yang disesuaikan untuk TikTok, Reels, dan Shorts.
  6. Menghitung estimasi statistik keterlibatan audiens (*predicted engagement score, viral potential, audience retention peak*) dan rekomendasi tagar relevan.
  7. Menyarankan variasi judul video berkinerja tinggi (*click-worthy, storytelling, benefit-driven*).
  8. Menyusun data SEO lengkap: kata kunci utama (*primary keywords*), tag pencarian, dan rekomendasi optimasi algoritma.

- **Target Pengguna**: Kreator konten video, editor video pendek (*short-form editors*), podcaster, *social media managers*, dan pembuat konten edukasi/hiburan yang ingin mengubah video panjang menjadi klip viral secara efisien.
- **Nilai Utama**: Memangkas waktu menonton dan mencatat momen secara manual dari berjam-jam menjadi beberapa detik, dilengkapi dengan semua aset teks dan metadata yang siap disalin (*one-tap copy*).

---

### 2. User Experience & Visual Design

#### Alur Pengguna Utama (Key User Flows)

```
┌─────────────────┐       ┌──────────────────────┐       ┌─────────────────────┐
│ 1. Input Sumber │ ----> │ 2. Pemrosesan Cerdas │ ----> │ 3. Dashboard Hasil  │
│  - File Lokal   │       │  - Analisis AI       │       │  - Pemutar Video    │
│  - Link YouTube │       │  - Deteksi Momen     │       │  - Timestamp Klip   │
│  - Klip Contoh  │       │  - Ekstraksi SEO     │       │  - Hooks & Judul    │
└─────────────────┘       └──────────────────────┘       └──────────┬──────────┘
                                                                    │
                                                                    ▼
                                                         ┌─────────────────────┐
                                                         │ 4. Aksi & Ekspor    │
                                                         │  - Lompat ke Waktu  │
                                                         │  - Salin Teks/Tagar │
                                                         │  - Simpan Riwayat   │
                                                         └─────────────────────┘
```

1. **Layar Beranda & Input**:
   - Tab pemilihan sumber: *Link YouTube*, *Video Lokal*, atau *Sampel Cepat*.
   - Tombol "Analisa Momen Menarik" dengan animasi pemrosesan modern.
   - Daftar riwayat video yang pernah dianalisis sebelumnya.

2. **Layar Detail & Studio Analisa**:
   - **Pemutar Video Interaktif di Bagian Atas**: Memutar video lokal secara langsung atau menampilkan pratinjau pemutar YouTube, dengan kontrol playback dan indikator timestamp dinamis.
   - **Kartu Ringkasan Cepat**: Durasi total, jumlah momen menarik yang terdeteksi, dan skor rata-rata potensi viral.
   - **Tab Navigasi Hasil Analisa**:
     - **Tab 1: Momen & Trimming**: Daftar kartu momen menarik dengan cap waktu `[00:15 - 00:45]`, tombol "Lompat ke Video", teks poin penting klip, dan tombol salin timestamp/skrip.
     - **Tab 2: Hook & Judul**: Koleksi kalimat pembuka (*hooks*) dengan kategori (Curiosity, Shock, Story) dan rekomendasi judul video terbaik.
     - **Tab 3: Deskripsi & Medsos**: Naskah deskripsi siap posting untuk TikTok, Instagram Reels, dan YouTube Shorts lengkap dengan call-to-action (CTA).
     - **Tab 4: SEO & Statistik**: Skor potensi keterlibatan penonton, grafik proyeksi retensi, tagar terpopuler (*hashtags*), dan kata kunci SEO yang relevan.

#### Identitas Visual & Tema

- **Arah Estetika**: *Studio Dark Creator Theme* — tampilan modern, futuristik, dan profesional bernuansa ruang kerja video editor kelas atas.
- **Palet Warna**:
  - Latar Belakang Utama: *Deep Obsidian Slate* (`#0D1117`) dan *Card Dark Surface* (`#161B22`).
  - Aksen Utama: *Electric Cyan* (`#00E5FF`) untuk aksi primer dan stempel waktu aktif.
  - Aksen Sekunder: *Neon Violet / Amethyst* (`#8B5CF6`) untuk highlight potensi viral dan tagar.
  - Aksen Sukses/Metrik: *Emerald Green* (`#10B981`) untuk skor keterlibatan tinggi.
- **Tipografi**: Hirarki tipografi modern dengan ukuran yang nyaman dibaca, penekanan teks tebal pada stempel waktu dan hook pembuka.
- **Umpan Balik & Interaktivitas**: Tombol salin satu-ketukan (*one-tap copy*) dengan snackbar instan "Tersalin ke papan klip!", animasi transisi tab yang halus, dan kartu momen yang bereaksi saat ditekan.

---

### 3. Key Product Decisions & Trade-Offs

- **Pemutar Video**:
  - *Keputusan*: Mengintegrasikan pemutar video berbasis Android Jetpack untuk file lokal (dengan kontrol seek waktu akurat) dan dukungan pratinjau YouTube intent / embed WebView untuk tautan YouTube.
  - *Alasan*: Pengguna dapat langsung memverifikasi apakah momen yang disarankan benar-benar pas tanpa harus membuka aplikasi pemutar video eksternal.
- **Format Penyajian Data Multi-Platform**:
  - *Keputusan*: Memisahkan tab atau tombol pemilih platform (TikTok, IG Reels, YT Shorts) sehingga pengguna tidak perlu repot mengedit ulang format caption atau tagar.
  - *Alasan*: Setiap platform memiliki gaya teks, batasan karakter, dan karakteristik audiens yang berbeda.
- **Penyimpanan Lokal (Room Database)**:
  - *Keputusan*: Menggunakan Room Database untuk menyimpan riwayat analisis, bookmark momen favorit, dan catatan pribadi pengguna secara offline.
  - *Alasan*: Cepat, hemat data internet, dan memastikan hasil analisis berharga pengguna tetap tersimpan dengan aman di perangkat.

---

### 4. Technical Architecture & Data Strategy

#### Diagram Arsitektur & Komponen

```
┌────────────────────────────────────────────────────────────────────────┐
│                          Jetpack Compose UI                            │
│  ┌───────────────────────┐  ┌────────────────────────────────────────┐ │
│  │     VideoPlayerView   │  │           AnalysisDashboardScreen      │ │
│  │ (Exo/VideoView/Embed) │  │  ┌───────────┐ ┌──────────┐ ┌─────────┐│ │
│  └───────────▲───────────┘  │  │Momen & Trim│ │Hooks/Judul│ │SEO/Stats││ │
│              │ (Seek Event) │  └───────────┘ └──────────┘ └─────────┘│ │
│              │              └────────────────────▲───────────────────┘ │
└──────────────┼───────────────────────────────────┼─────────────────────┘
               │                                   │ StateFlow (UI State)
┌──────────────┴───────────────────────────────────┴─────────────────────┐
│                          VideoAnalyzerViewModel                        │
│  - inputUrl / localUri         - activeTab                             │
│  - isAnalyzing (Loading)       - currentPlaybackPosition               │
│  - analysisResult              - savedHistoryList                      │
└──────────────▲───────────────────────────────────▲─────────────────────┘
               │                                   │
┌──────────────┴───────────────────┐ ┌─────────────┴─────────────────────┐
│       VideoAnalysisRepository     │ │         Room Database Engine      │
│  - analyzeVideo(source)          │ │  - VideoAnalysisDao               │
│  - extractMoments(metadata)      │ │  - SavedAnalysisEntity            │
│  - generateHooksAndSeo(...)      │ │  - VideoMomentEntity              │
└──────────────────────────────────┘ └───────────────────────────────────┘
```

#### Struktur Data Model Utama

```kotlin
data class VideoAnalysisResult(
    val id: String,
    val title: String,
    val sourceUrlOrPath: String,
    val isYoutube: Boolean,
    val durationSeconds: Int,
    val summaryPoints: List<String>,
    val moments: List<VideoMoment>,
    val hooks: List<VideoHook>,
    val titleSuggestions: List<TitleSuggestion>,
    val socialCaptions: Map<SocialPlatform, SocialCaption>,
    val audienceMetrics: AudienceEngagementStats,
    val seoMetadata: SeoData
)

data class VideoMoment(
    val id: String,
    val startSecond: Int,
    val endSecond: Int,
    val title: String,
    val keyQuoteOrText: String,
    val reasonWhyViral: String,
    val viralScore: Int // 1 - 100
)

data class VideoHook(
    val hookText: String,
    val hookType: String, // e.g., "Curiosity Gap", "Shock Value", "Problem-Solution"
    val deliveryTip: String
)

data class SocialCaption(
    val platform: SocialPlatform, // TIKTOK, REELS, SHORTS
    val captionText: String,
    val callToAction: String,
    val hashtags: List<String>
)

data class AudienceEngagementStats(
    val overallScore: Int,
    val viralProbability: String,
    val bestPostingTime: String,
    val targetAudience: String,
    val projectedRetentionRate: String
)

data class SeoData(
    val primaryKeywords: List<String>,
    val longTailKeywords: List<String>,
    val recommendedTags: List<String>,
    val searchOptimizedDescription: String
)
```

---

### Verifikasi & Rencana Pengerjaan
1. **Konfigurasi Project & Metadata**: Update `metadata.json` dan `strings.xml` menjadi nama aplikasi yang representatif ("MomentSnap AI").
2. **Setup Domain & Data Layer**: Buat Entity Room, DAO, Repository, dan Service Analisis Cerdas (dengan ekstraktor YouTube & video parser).
3. **Komponen Pemutar & Interaktif**: Bangun komponen pemutar video lokal dan pratinjau yang mendukung lompat waktu (*timestamp seek*) instan.
4. **Komponen UI Studio Analisa**: Bangun tab momen pemotongan, generator hook, saran judul, deskripsi media sosial, metrik engagement, dan SEO lengkap dengan fitur salin cepat.
5. **Kompilasi & Pengujian**: Jalankan `compile_applet` untuk memastikan semua dependensi dan kode Kotlin terkompilasi dengan sempurna tanpa error.
