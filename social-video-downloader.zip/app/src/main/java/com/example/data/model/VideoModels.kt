package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ExtractRequest(
    @Json(name = "url") val url: String
)

@JsonClass(generateAdapter = true)
data class VideoFormatOption(
    @Json(name = "format_id") val formatId: String,
    @Json(name = "resolution") val resolution: String,
    @Json(name = "extension") val extension: String,
    @Json(name = "download_url") val downloadUrl: String,
    @Json(name = "filesize_formatted") val filesizeFormatted: String? = null,
    @Json(name = "is_audio_only") val isAudioOnly: Boolean = false
)

@JsonClass(generateAdapter = true)
data class VideoInfoResponse(
    @Json(name = "title") val title: String,
    @Json(name = "author") val author: String? = "Unknown",
    @Json(name = "thumbnail") val thumbnail: String? = null,
    @Json(name = "duration") val duration: String? = null,
    @Json(name = "platform") val platform: String? = "Social Media",
    @Json(name = "webpage_url") val webpageUrl: String? = null,
    @Json(name = "formats") val formats: List<VideoFormatOption> = emptyList()
)

@JsonClass(generateAdapter = true)
data class HealthResponse(
    @Json(name = "status") val status: String,
    @Json(name = "message") val message: String? = null
)

data class DownloadHistoryItem(
    val id: Long,
    val title: String,
    val platform: String,
    val fileName: String,
    val timestamp: Long = System.currentTimeMillis()
)
