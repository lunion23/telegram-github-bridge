package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.ShippingLabelScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.ShippingLabelViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                AppContent()
            }
        }
    }
}

@Composable
fun AppContent() {
    val shippingViewModel: ShippingLabelViewModel = viewModel(
        factory = ShippingLabelViewModel.factory()
    )

    ShippingLabelScreen(
        viewModel = shippingViewModel
    )
}
