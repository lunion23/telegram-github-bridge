package com.example.data.model

/**
 * Columns available for targeted keyword searches in Work Order records.
 */
enum class SearchTargetColumn(
    val displayName: String,
    val shortName: String,
    val dbColumn: String?
) {
    ALL(
        displayName = "Semua Kolom",
        shortName = "Semua",
        dbColumn = null
    ),
    MOBIL_NAME(
        displayName = "Plat / Armada (Mobil)",
        shortName = "Armada/Plat",
        dbColumn = "mobilName"
    ),
    KELUHAN(
        displayName = "Keluhan / Masalah",
        shortName = "Keluhan",
        dbColumn = "keluhan"
    ),
    DESCRIPTION(
        displayName = "Deskripsi Pekerjaan / Part",
        shortName = "Deskripsi",
        dbColumn = "description"
    ),
    NAME(
        displayName = "No / ID Work Order",
        shortName = "No WO",
        dbColumn = "name"
    ),
    NO_CHASSIS(
        displayName = "Nomor Rangka (Chassis)",
        shortName = "Chassis",
        dbColumn = "noChassis"
    ),
    NO_MESIN(
        displayName = "Nomor Mesin",
        shortName = "Mesin",
        dbColumn = "noMesin"
    ),
    KODE(
        displayName = "Kode Barang / Part",
        shortName = "Kode Part",
        dbColumn = "kode"
    ),
    TIPE(
        displayName = "Tipe Pekerjaan (PART/JASA/OLI)",
        shortName = "Tipe",
        dbColumn = "tipe"
    ),
    PRODUCT_CLASS(
        displayName = "Kategori / Kelas Produk",
        shortName = "Kategori",
        dbColumn = "productClass"
    ),
    CATATAN(
        displayName = "Catatan Tambahan",
        shortName = "Catatan",
        dbColumn = "catatan"
    )
}
