package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import android.widget.Toast
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.export.PdfExporter
import com.example.ui.components.CameraCaptureDialog
import com.example.ui.components.DamagePhotoSourceDialog
import java.io.File
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.PartItem
import com.example.data.model.WarrantyStatus
import com.example.ui.components.AppTextField
import com.example.ui.components.CheckboxWithNoteItem
import com.example.ui.components.PartItemEditorCard
import com.example.ui.components.SectionContainer
import com.example.ui.components.WizardStepIndicator
import com.example.ui.viewmodel.ReportViewModel

@Composable
fun FormWizardScreen(
    viewModel: ReportViewModel,
    onNavigateToPreview: () -> Unit,
    modifier: Modifier = Modifier
) {
    val report by viewModel.currentReport.collectAsState()
    val currentStep by viewModel.currentStep.collectAsState()
    val context = LocalContext.current

    var showPhotoSourceDialog by remember { mutableStateOf(false) }
    var showCameraCaptureDialog by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.setDamagePhotoUri(uri.toString())
            Toast.makeText(context, "Foto kerusakan dipilih!", Toast.LENGTH_SHORT).show()
        }
    }

    val stepTitles = listOf("Unit", "Kerusakan", "Penyebab", "Parts & TTD")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Quick Action & Template Selector Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                // Template Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Format Template:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = report.activeTemplate == 1,
                            onClick = { viewModel.setTemplate(1) },
                            label = { Text("Opsi 1 (Standar)", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.testTag("chip_template_1")
                        )
                        FilterChip(
                            selected = report.activeTemplate == 2,
                            onClick = { viewModel.setTemplate(2) },
                            label = { Text("Opsi 2 (Sesuai Gambar)", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFFDBEAFE),
                                selectedLabelColor = Color(0xFF1E3A8A)
                            ),
                            modifier = Modifier.testTag("chip_template_2")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Auto-fill & Quick Prin Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilledTonalButton(
                        onClick = { viewModel.fillSampleData(template = 2) },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = Color(0xFFEFF6FF),
                            contentColor = Color(0xFF1E3A8A)
                        ),
                        modifier = Modifier
                            .weight(1.3f)
                            .testTag("btn_autofill_opsi_2")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FlashOn,
                            contentDescription = null,
                            tint = Color(0xFF2563EB),
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "Contoh Opsi 2 (Gambar)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    FilledTonalButton(
                        onClick = { viewModel.fillSampleData(template = 1) },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        modifier = Modifier
                            .weight(1.1f)
                            .testTag("btn_autofill_opsi_1")
                    ) {
                        Text(
                            text = "Contoh Opsi 1",
                            fontSize = 11.sp
                        )
                    }

                    OutlinedButton(
                        onClick = { viewModel.resetToBlank() },
                        modifier = Modifier.testTag("btn_reset")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                WizardStepIndicator(
                    currentStep = currentStep,
                    steps = stepTitles,
                    onStepClick = { viewModel.setStep(it) }
                )
            }
        }

        // Step Content inside scrollable column
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            when (currentStep) {
                0 -> {
                    // STEP 1: Header Dokumen & Info Unit
                    item {
                        SectionContainer(
                            title = "1. Header Dokumen",
                            icon = Icons.Default.Description
                        ) {
                            if (report.activeTemplate == 2) {
                                AppTextField(
                                    value = report.companyName,
                                    onValueChange = { viewModel.updateReport { r -> r.copy(companyName = it) } },
                                    label = "Nama Perusahaan / Header",
                                    placeholder = "Contoh: Hiba Group",
                                    testTag = "input_company"
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                            }
                            AppTextField(
                                value = report.title,
                                onValueChange = { viewModel.updateReport { r -> r.copy(title = it) } },
                                label = "Judul Dokumen",
                                testTag = "input_judul"
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                AppTextField(
                                    value = report.reportNumber,
                                    onValueChange = { viewModel.updateReport { r -> r.copy(reportNumber = it) } },
                                    label = "No. Laporan",
                                    placeholder = if (report.activeTemplate == 2) "1/LT-CLG/III/2026" else "2/LP/CLG/6/2026",
                                    modifier = Modifier.weight(1.2f),
                                    testTag = "input_no_laporan"
                                )
                                AppTextField(
                                    value = report.workshop,
                                    onValueChange = { viewModel.updateReport { r -> r.copy(workshop = it) } },
                                    label = "Bengkel",
                                    placeholder = "Contoh: Cilegon",
                                    modifier = Modifier.weight(1f),
                                    testTag = "input_bengkel"
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            AppTextField(
                                value = report.reportDate,
                                onValueChange = { viewModel.updateReport { r -> r.copy(reportDate = it) } },
                                label = "Tanggal Laporan",
                                placeholder = "12-Mar-26 atau YYYY-MM-DD",
                                testTag = "input_tanggal_laporan"
                            )
                        }
                    }

                    item {
                        SectionContainer(
                            title = "2. Informasi Unit / Alat",
                            icon = Icons.Default.Build
                        ) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                AppTextField(
                                    value = report.manufacturer,
                                    onValueChange = { viewModel.updateReport { r -> r.copy(manufacturer = it) } },
                                    label = "Pabrik Pembuat",
                                    placeholder = "Contoh: HINO",
                                    modifier = Modifier.weight(1f),
                                    testTag = "input_pabrik"
                                )
                                AppTextField(
                                    value = report.unitType,
                                    onValueChange = { viewModel.updateReport { r -> r.copy(unitType = it) } },
                                    label = "Tipe",
                                    placeholder = if (report.activeTemplate == 2) "DUTRO" else "J08EUFR",
                                    modifier = Modifier.weight(1f),
                                    testTag = "input_tipe"
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                AppTextField(
                                    value = report.model,
                                    onValueChange = { viewModel.updateReport { r -> r.copy(model = it) } },
                                    label = "Model",
                                    placeholder = if (report.activeTemplate == 2) "W04DTPJ-53447" else "RK8J",
                                    modifier = Modifier.weight(1f),
                                    testTag = "input_model"
                                )
                                AppTextField(
                                    value = report.unitCode,
                                    onValueChange = { viewModel.updateReport { r -> r.copy(unitCode = it) } },
                                    label = "Kode Unit",
                                    placeholder = if (report.activeTemplate == 2) "D127" else "GLX357",
                                    modifier = Modifier.weight(1f),
                                    testTag = "input_kode_unit"
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                AppTextField(
                                    value = report.toolName,
                                    onValueChange = { viewModel.updateReport { r -> r.copy(toolName = it) } },
                                    label = "Nama Alat",
                                    placeholder = "Contoh: Ban",
                                    modifier = Modifier.weight(1f),
                                    testTag = "input_nama_alat"
                                )
                                AppTextField(
                                    value = report.damageDate,
                                    onValueChange = { viewModel.updateReport { r -> r.copy(damageDate = it) } },
                                    label = "Tanggal Rusak",
                                    placeholder = "12-Mar-26",
                                    modifier = Modifier.weight(1f),
                                    testTag = "input_tanggal_rusak"
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                AppTextField(
                                    value = report.mileageKmHm,
                                    onValueChange = { viewModel.updateReport { r -> r.copy(mileageKmHm = it) } },
                                    label = "KM / HM",
                                    placeholder = if (report.activeTemplate == 2) "598916" else "139333",
                                    modifier = Modifier.weight(1f),
                                    testTag = "input_km_hm"
                                )
                                AppTextField(
                                    value = report.component,
                                    onValueChange = { viewModel.updateReport { r -> r.copy(component = it) } },
                                    label = "Komponen",
                                    placeholder = "Contoh: Underbody",
                                    modifier = Modifier.weight(1f),
                                    testTag = "input_komponen"
                                )
                            }
                        }
                    }

                    item {
                        SectionContainer(
                            title = "3. Status Garansi",
                            icon = Icons.Default.CheckCircle
                        ) {
                            Text(
                                "Pilih status garansi unit:",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                val isIn = report.warrantyStatus == WarrantyStatus.IN_WARRANTY
                                val isAfter = report.warrantyStatus == WarrantyStatus.AFTER_WARRANTY

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isIn) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    modifier = Modifier
                                        .weight(1f)
                                        .border(
                                            width = if (isIn) 1.5.dp else 0.5.dp,
                                            color = if (isIn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .clickable { viewModel.updateReport { r -> r.copy(warrantyStatus = WarrantyStatus.IN_WARRANTY) } }
                                        .padding(8.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        RadioButton(
                                            selected = isIn,
                                            onClick = { viewModel.updateReport { r -> r.copy(warrantyStatus = WarrantyStatus.IN_WARRANTY) } },
                                            colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.primary)
                                        )
                                        Text("Masa Garansi", fontSize = 13.sp, fontWeight = if (isIn) FontWeight.Bold else FontWeight.Normal)
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isAfter) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    modifier = Modifier
                                        .weight(1.1f)
                                        .border(
                                            width = if (isAfter) 1.5.dp else 0.5.dp,
                                            color = if (isAfter) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .clickable { viewModel.updateReport { r -> r.copy(warrantyStatus = WarrantyStatus.AFTER_WARRANTY) } }
                                        .padding(8.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        RadioButton(
                                            selected = isAfter,
                                            onClick = { viewModel.updateReport { r -> r.copy(warrantyStatus = WarrantyStatus.AFTER_WARRANTY) } },
                                            colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.primary)
                                        )
                                        Text("Setelah Masa Garansi", fontSize = 13.sp, fontWeight = if (isAfter) FontWeight.Bold else FontWeight.Normal)
                                    }
                                }
                            }
                        }
                    }
                }

                1 -> {
                    // STEP 2: Detail Kerusakan, Lokasi & Foto
                    item {
                        SectionContainer(
                            title = "4. Detail Kerusakan & Foto Kerusakan",
                            icon = Icons.Default.Warning
                        ) {
                            // Foto Kerusakan Picker
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Foto Kerusakan (Tampil di Desain 2):",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.titleSmall
                                        )
                                        FilledTonalButton(
                                            onClick = { showPhotoSourceDialog = true },
                                            modifier = Modifier.testTag("btn_pilih_foto")
                                        ) {
                                            Icon(imageVector = Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(if (report.damagePhotoUri.isNotBlank()) "Ubah Foto" else "+ Foto", fontSize = 11.sp)
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    // Thumbnail preview using Coil
                                    val imageModel: Any? = remember(report.damagePhotoUri) {
                                        when {
                                            report.damagePhotoUri.isBlank() -> null
                                            report.damagePhotoUri == "sample" -> R.drawable.sample_damaged_tire
                                            report.damagePhotoUri.startsWith("content://") || report.damagePhotoUri.startsWith("file://") -> Uri.parse(report.damagePhotoUri)
                                            else -> File(report.damagePhotoUri).takeIf { it.exists() } ?: Uri.parse(report.damagePhotoUri)
                                        }
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(width = 86.dp, height = 96.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                                                .background(if (imageModel != null) Color.White else MaterialTheme.colorScheme.surfaceVariant)
                                                .clickable { showPhotoSourceDialog = true },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (imageModel != null) {
                                                AsyncImage(
                                                    model = ImageRequest.Builder(context)
                                                        .data(imageModel)
                                                        .crossfade(true)
                                                        .build(),
                                                    contentDescription = "Foto Kerusakan",
                                                    modifier = Modifier.fillMaxSize(),
                                                    contentScale = ContentScale.Crop
                                                )
                                            } else {
                                                Column(
                                                    horizontalAlignment = Alignment.CenterHorizontally,
                                                    verticalArrangement = Arrangement.Center,
                                                    modifier = Modifier.padding(4.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.AddPhotoAlternate,
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                                        modifier = Modifier.size(24.dp)
                                                    )
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    Text(
                                                        text = "Polos",
                                                        fontSize = 10.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                                        fontWeight = FontWeight.Medium
                                                    )
                                                }
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = when {
                                                    report.damagePhotoUri == "sample" -> "Foto sampel ban rusak terpasang"
                                                    report.damagePhotoUri.isNotBlank() -> "Foto kamera/galeri kustom terlampir"
                                                    else -> "Tampilan polos bersih (tanpa foto)"
                                                },
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = if (report.damagePhotoUri.isNotBlank()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                OutlinedButton(
                                                    onClick = { showPhotoSourceDialog = true },
                                                    modifier = Modifier.height(28.dp)
                                                ) {
                                                    Text("Pilih Sumber", fontSize = 10.sp)
                                                }
                                                if (report.damagePhotoUri.isNotBlank()) {
                                                    OutlinedButton(
                                                        onClick = { viewModel.setDamagePhotoUri("") },
                                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                                        modifier = Modifier.height(28.dp)
                                                    ) {
                                                        Icon(imageVector = Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(12.dp))
                                                        Spacer(modifier = Modifier.width(2.dp))
                                                        Text("Kosongkan", fontSize = 10.sp)
                                                    }
                                                } else {
                                                    OutlinedButton(
                                                        onClick = { viewModel.setDamagePhotoUri("sample") },
                                                        modifier = Modifier.height(28.dp)
                                                    ) {
                                                        Text("Isi Sampel", fontSize = 10.sp)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                AppTextField(
                                    value = report.damageDetail,
                                    onValueChange = { viewModel.updateReport { r -> r.copy(damageDetail = it) } },
                                    label = "Kerusakan",
                                    placeholder = if (report.activeTemplate == 2) "Ban kempes" else "Ban belakang pecah",
                                    modifier = Modifier.weight(1f),
                                    testTag = "input_detail_kerusakan"
                                )
                                AppTextField(
                                    value = report.location,
                                    onValueChange = { viewModel.updateReport { r -> r.copy(location = it) } },
                                    label = "Lokasi",
                                    placeholder = if (report.activeTemplate == 2) "Tol tangerang - merak" else "Tol Cinere",
                                    modifier = Modifier.weight(1f),
                                    testTag = "input_lokasi"
                                )
                            }

                            if (report.activeTemplate == 2) {
                                Spacer(modifier = Modifier.height(10.dp))
                                AppTextField(
                                    value = report.storingStatus,
                                    onValueChange = { viewModel.updateReport { r -> r.copy(storingStatus = it) } },
                                    label = "Status",
                                    placeholder = "Contoh: Storing",
                                    testTag = "input_storing_status"
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                AppTextField(
                                    value = report.analysisNotes,
                                    onValueChange = { viewModel.updateReport { r -> r.copy(analysisNotes = it) } },
                                    label = "Analisa Kejadian",
                                    placeholder = "Setelah di lakukan storing oleh team cikupa di temukan ban depan kiri kempes",
                                    singleLine = false,
                                    maxLines = 3,
                                    testTag = "input_analisa"
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                AppTextField(
                                    value = report.conclusionNotes,
                                    onValueChange = { viewModel.updateReport { r -> r.copy(conclusionNotes = it) } },
                                    label = "Kesimpulan",
                                    placeholder = "Kosongkan atau isi kesimpulan teknis",
                                    testTag = "input_kesimpulan"
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AppTextField(
                                        value = report.lastReplacement,
                                        onValueChange = { viewModel.updateReport { r -> r.copy(lastReplacement = it) } },
                                        label = "Penggantian Terakhir",
                                        placeholder = "9-5-2022 (km.415513)",
                                        modifier = Modifier.weight(1.2f)
                                    )
                                    AppTextField(
                                        value = report.lastReplacementWo,
                                        onValueChange = { viewModel.updateReport { r -> r.copy(lastReplacementWo = it) } },
                                        label = "No. Work Order",
                                        placeholder = "KLD1-WO-2205-00381",
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AppTextField(
                                        value = report.lastWeeklyCheck,
                                        onValueChange = { viewModel.updateReport { r -> r.copy(lastWeeklyCheck = it) } },
                                        label = "Weekly Terakhir",
                                        placeholder = "5-3-2026 (km.598234)",
                                        modifier = Modifier.weight(1.2f)
                                    )
                                    AppTextField(
                                        value = report.lastWeeklyCheckWo,
                                        onValueChange = { viewModel.updateReport { r -> r.copy(lastWeeklyCheckWo = it) } },
                                        label = "No. Work Order",
                                        placeholder = "CLG1-WO-2603-00225",
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            } else {
                                Spacer(modifier = Modifier.height(10.dp))
                                AppTextField(
                                    value = report.workshopHistory,
                                    onValueChange = { viewModel.updateReport { r -> r.copy(workshopHistory = it) } },
                                    label = "History Bengkel",
                                    placeholder = "Inspeksi terakhir tanggal 18 Juni 2026",
                                    singleLine = false,
                                    maxLines = 3,
                                    testTag = "input_history_bengkel"
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                AppTextField(
                                    value = report.tireHistory,
                                    onValueChange = { viewModel.updateReport { r -> r.copy(tireHistory = it) } },
                                    label = "History Ban / Komponen",
                                    placeholder = "Pengecekan ban terakhir tanggal 18 Juni 2026",
                                    singleLine = false,
                                    maxLines = 3,
                                    testTag = "input_history_ban"
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            AppTextField(
                                value = report.attachments,
                                onValueChange = { viewModel.updateReport { r -> r.copy(attachments = it) } },
                                label = "Lampiran",
                                placeholder = "Foto Kerusakan terlampir",
                                testTag = "input_lampiran"
                            )
                        }
                    }
                }

                2 -> {
                    // STEP 3: Penyebab, Tindakan & Usulan
                    item {
                        SectionContainer(
                            title = "5. Penyebab Kerusakan (√ = YA, X = TIDAK)",
                            icon = Icons.Default.Assignment
                        ) {
                            Text(
                                "Centang faktor penyebab dan beri penjelasan:",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            CheckboxWithNoteItem(
                                checked = report.causeInstallation,
                                onCheckedChange = { viewModel.updateReport { r -> r.copy(causeInstallation = it) } },
                                title = "1. Pemasangan",
                                notes = report.causeInstallationNotes,
                                onNotesChange = { viewModel.updateReport { r -> r.copy(causeInstallationNotes = it) } },
                                notePlaceholder = "Penjelasan pemasangan..."
                            )

                            CheckboxWithNoteItem(
                                checked = report.causeQuality,
                                onCheckedChange = { viewModel.updateReport { r -> r.copy(causeQuality = it) } },
                                title = "2. Kwalitas Parts",
                                notes = report.causeQualityNotes,
                                onNotesChange = { viewModel.updateReport { r -> r.copy(causeQualityNotes = it) } },
                                notePlaceholder = "Penjelasan kualitas part..."
                            )

                            CheckboxWithNoteItem(
                                checked = report.causeOperational,
                                onCheckedChange = { viewModel.updateReport { r -> r.copy(causeOperational = it) } },
                                title = "3. Kesalahan Operasional",
                                notes = report.causeOperationalNotes,
                                onNotesChange = { viewModel.updateReport { r -> r.copy(causeOperationalNotes = it) } },
                                notePlaceholder = "Penjelasan operasional..."
                            )

                            CheckboxWithNoteItem(
                                checked = report.causeTimeExpired,
                                onCheckedChange = { viewModel.updateReport { r -> r.copy(causeTimeExpired = it) } },
                                title = "4. Sudah waktunya",
                                notes = report.causeTimeExpiredNotes,
                                onNotesChange = { viewModel.updateReport { r -> r.copy(causeTimeExpiredNotes = it) } },
                                notePlaceholder = "Penjelasan sudah waktunya..."
                            )

                            CheckboxWithNoteItem(
                                checked = report.causeOthers,
                                onCheckedChange = { viewModel.updateReport { r -> r.copy(causeOthers = it) } },
                                title = "5. Lain-lain",
                                notes = report.causeOthersNotes,
                                onNotesChange = { viewModel.updateReport { r -> r.copy(causeOthersNotes = it) } },
                                notePlaceholder = "Penjelasan lain-lain..."
                            )
                        }
                    }

                    item {
                        SectionContainer(
                            title = "6. Cara Mengatasi Kerusakan",
                            icon = Icons.Default.Build
                        ) {
                            CheckboxWithNoteItem(
                                checked = report.solutionReplacePart,
                                onCheckedChange = { viewModel.updateReport { r -> r.copy(solutionReplacePart = it) } },
                                title = "1. Ganti Part Baru",
                                notes = report.solutionReplacePartNotes,
                                onNotesChange = { viewModel.updateReport { r -> r.copy(solutionReplacePartNotes = it) } },
                                notePlaceholder = "Keterangan ganti part..."
                            )

                            CheckboxWithNoteItem(
                                checked = report.solutionReinstallAdjust,
                                onCheckedChange = { viewModel.updateReport { r -> r.copy(solutionReinstallAdjust = it) } },
                                title = "2. Pemasangan atau Penyetelan Ulang",
                                notes = report.solutionReinstallAdjustNotes,
                                onNotesChange = { viewModel.updateReport { r -> r.copy(solutionReinstallAdjustNotes = it) } },
                                notePlaceholder = "Contoh: Ganti ban stip"
                            )

                            CheckboxWithNoteItem(
                                checked = report.solutionModification,
                                onCheckedChange = { viewModel.updateReport { r -> r.copy(solutionModification = it) } },
                                title = "3. Modifikasi",
                                notes = report.solutionModificationNotes,
                                onNotesChange = { viewModel.updateReport { r -> r.copy(solutionModificationNotes = it) } },
                                notePlaceholder = "Keterangan modifikasi..."
                            )
                        }
                    }

                    if (report.activeTemplate == 2) {
                        item {
                            SectionContainer(
                                title = "7. Tertunda Karena & Usulan Pelapor",
                                icon = Icons.Default.Assignment
                            ) {
                                AppTextField(
                                    value = report.pendingReason,
                                    onValueChange = { viewModel.updateReport { r -> r.copy(pendingReason = it) } },
                                    label = "Tertunda Karena",
                                    placeholder = "Kosongkan atau isi alasan keterlambatan/pending",
                                    singleLine = false,
                                    maxLines = 3,
                                    testTag = "input_tertunda_karena"
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                AppTextField(
                                    value = report.reporterProposal,
                                    onValueChange = { viewModel.updateReport { r -> r.copy(reporterProposal = it) } },
                                    label = "Usulan Pelapor",
                                    placeholder = "Segera akan di lakukan program pengecekan atau penggantian terkait part tersebut...",
                                    singleLine = false,
                                    maxLines = 4,
                                    testTag = "input_usulan_pelapor"
                                )
                            }
                        }
                    }
                }

                3 -> {
                    // STEP 4: Tabel Parts & Penandatangan
                    item {
                        SectionContainer(
                            title = "8. Parts yang Harus Diganti",
                            icon = Icons.Default.Build,
                            trailing = {
                                Button(
                                    onClick = { viewModel.addPart(PartItem()) },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                    modifier = Modifier.testTag("btn_tambah_part")
                                ) {
                                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Tambah Part", fontSize = 12.sp)
                                }
                            }
                        ) {
                            if (report.partsList.isEmpty()) {
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 12.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(16.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            "Belum ada suku cadang (parts) yang ditambahkan.",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        OutlinedButton(onClick = { viewModel.addPart(PartItem()) }) {
                                            Icon(imageVector = Icons.Default.Add, contentDescription = null)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Tambah Part Pertama")
                                        }
                                    }
                                }
                            } else {
                                report.partsList.forEachIndexed { index, part ->
                                    PartItemEditorCard(
                                        index = index,
                                        item = part,
                                        onItemChange = { updated -> viewModel.updatePart(index, updated) },
                                        onDelete = { viewModel.removePart(index) }
                                    )
                                }
                            }
                        }
                    }

                    item {
                        SectionContainer(
                            title = "9. Bagian Penandatangan",
                            icon = Icons.Default.Person
                        ) {
                            if (report.activeTemplate == 2) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            "Mengetahui:",
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary,
                                            style = MaterialTheme.typography.titleSmall
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            AppTextField(
                                                value = report.knownBy1,
                                                onValueChange = { viewModel.updateReport { r -> r.copy(knownBy1 = it) } },
                                                label = "Saksi 1",
                                                placeholder = "(...............................)",
                                                modifier = Modifier.weight(1f)
                                            )
                                            AppTextField(
                                                value = report.knownBy2,
                                                onValueChange = { viewModel.updateReport { r -> r.copy(knownBy2 = it) } },
                                                label = "Saksi 2",
                                                placeholder = "SUHERMAN",
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                            }

                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        "Dilaporkan Oleh:",
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        AppTextField(
                                            value = report.reportedByName,
                                            onValueChange = { viewModel.updateReport { r -> r.copy(reportedByName = it) } },
                                            label = "Nama Pelapor",
                                            placeholder = if (report.activeTemplate == 2) "Yudi Indrawan" else "Ahmad Supriyadi",
                                            modifier = Modifier.weight(1f),
                                            testTag = "input_nama_pelapor"
                                        )
                                        AppTextField(
                                            value = report.reportedByTitle,
                                            onValueChange = { viewModel.updateReport { r -> r.copy(reportedByTitle = it) } },
                                            label = "Jabatan Pelapor",
                                            placeholder = if (report.activeTemplate == 2) "Wa.Ka.Bengkel" else "Mekanik / Foreman",
                                            modifier = Modifier.weight(1f),
                                            testTag = "input_jabatan_pelapor"
                                        )
                                    }
                                }
                            }

                            if (report.activeTemplate == 1) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            "Disetujui Oleh:",
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary,
                                            style = MaterialTheme.typography.titleSmall
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            AppTextField(
                                                value = report.approvedByName,
                                                onValueChange = { viewModel.updateReport { r -> r.copy(approvedByName = it) } },
                                                label = "Nama Pejabat",
                                                placeholder = "Yudi Indrawan",
                                                modifier = Modifier.weight(1f),
                                                testTag = "input_nama_disetujui"
                                            )
                                            AppTextField(
                                                value = report.approvedByTitle,
                                                onValueChange = { viewModel.updateReport { r -> r.copy(approvedByTitle = it) } },
                                                label = "Jabatan",
                                                placeholder = "WA.KA. Bengkel",
                                                modifier = Modifier.weight(1f),
                                                testTag = "input_jabatan_disetujui"
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            AppTextField(
                                value = report.signDate,
                                onValueChange = { viewModel.updateReport { r -> r.copy(signDate = it) } },
                                label = "Tanggal Tanda Tangan",
                                placeholder = "12-Mar-26",
                                testTag = "input_tanggal_ttd"
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        // Bottom Wizard Navigation Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (currentStep > 0) {
                    OutlinedButton(
                        onClick = { viewModel.previousStep() },
                        modifier = Modifier.testTag("btn_step_prev")
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Sebelumnya")
                    }
                } else {
                    Spacer(modifier = Modifier.width(1.dp))
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (currentStep == 3) {
                        Button(
                            onClick = {
                                try {
                                    PdfExporter.printReport(context, report, templateOption = 2)
                                    Toast.makeText(context, "Membuka printer untuk Opsi 2 (Sesuai Gambar)...", Toast.LENGTH_SHORT).show()
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Gagal print: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                            modifier = Modifier.testTag("btn_prin_langsung_opsi2")
                        ) {
                            Icon(imageVector = Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Prin (Opsi 2)")
                        }
                    }

                    Button(
                        onClick = onNavigateToPreview,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        modifier = Modifier.testTag("btn_ke_pratinjau")
                    ) {
                        Icon(imageVector = Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Pratinjau")
                    }

                    if (currentStep < 3) {
                        Button(
                            onClick = { viewModel.nextStep() },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.testTag("btn_step_next")
                        ) {
                            Text("Lanjut")
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    } else {
                        Button(
                            onClick = onNavigateToPreview,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.testTag("btn_selesai_form")
                        ) {
                            Text("Selesai")
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }

    // Dialog Pemilihan Sumber Foto (Kamera CameraX, Galeri, Sampel, Kosongkan)
    DamagePhotoSourceDialog(
        isOpen = showPhotoSourceDialog,
        onDismiss = { showPhotoSourceDialog = false },
        onLaunchCamera = { showCameraCaptureDialog = true },
        onLaunchGallery = {
            photoPickerLauncher.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
            )
        },
        onSelectSample = {
            viewModel.setDamagePhotoUri("sample")
            Toast.makeText(context, "Foto contoh ban kerusakan dimuat!", Toast.LENGTH_SHORT).show()
        },
        onClearPhoto = {
            viewModel.setDamagePhotoUri("")
            Toast.makeText(context, "Foto dikosongkan (tampilan polos)", Toast.LENGTH_SHORT).show()
        },
        hasPhoto = report.damagePhotoUri.isNotBlank()
    )

    // Dialog Pengambilan Foto Kamera CameraX
    CameraCaptureDialog(
        isOpen = showCameraCaptureDialog,
        onDismiss = { showCameraCaptureDialog = false },
        onPhotoCaptured = { savedUri ->
            viewModel.setDamagePhotoUri(savedUri)
            Toast.makeText(context, "Foto kerusakan berhasil disimpan ke dokumen!", Toast.LENGTH_SHORT).show()
        }
    )
}
