package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ColumnVisibilityState
import com.example.data.model.WorkOrderColumn
import com.example.data.model.WorkOrderItem
import java.text.NumberFormat
import java.util.Locale

@Composable
fun WorkOrderTableView(
    items: List<WorkOrderItem>,
    visibilityState: ColumnVisibilityState,
    isLoading: Boolean,
    onLoadMore: () -> Unit,
    onRowClick: ((String) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val horizontalScrollState = rememberScrollState()
    val verticalListState = rememberLazyListState()

    val visibleCols = remember(visibilityState) {
        WorkOrderColumn.values().filter { visibilityState.isVisible(it) }
    }

    val idrFormat = remember {
        NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply {
            maximumFractionDigits = 0
        }
    }
    val intFormat = remember { NumberFormat.getIntegerInstance(Locale("id", "ID")) }

    // Detect when reaching near end of list to trigger infinite scroll pagination
    val shouldLoadMore by remember {
        derivedStateOf {
            val totalItems = verticalListState.layoutInfo.totalItemsCount
            val lastVisibleIndex = verticalListState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            totalItems > 0 && lastVisibleIndex >= totalItems - 5
        }
    }

    LaunchedEffect(shouldLoadMore) {
        if (shouldLoadMore && !isLoading) {
            onLoadMore()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("work_order_table_view")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .horizontalScroll(horizontalScrollState)
        ) {
            // Sticky Table Header
            Row(
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
                    .padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Row Number column
                Box(
                    modifier = Modifier
                        .width(44.dp)
                        .padding(horizontal = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "#",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                visibleCols.forEach { col ->
                    Box(
                        modifier = Modifier
                            .width(col.minWidthDp.dp)
                            .padding(horizontal = 8.dp),
                        contentAlignment = if (col == WorkOrderColumn.TOTAL_PRICE || col == WorkOrderColumn.QTY || col == WorkOrderColumn.KM_CURRENT)
                            Alignment.CenterEnd else Alignment.CenterStart
                    ) {
                        Text(
                            text = col.displayName,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Table Rows
            LazyColumn(
                state = verticalListState,
                modifier = Modifier.weight(1f)
            ) {
                itemsIndexed(items) { index, item ->
                    val isEven = index % 2 == 0
                    val rowBg = if (isEven) MaterialTheme.colorScheme.surface
                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)

                    Row(
                        modifier = Modifier
                            .background(rowBg)
                            .then(
                                if (onRowClick != null) Modifier.clickable { onRowClick(item.name) }
                                else Modifier
                            )
                            .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Row index
                        Box(
                            modifier = Modifier
                                .width(44.dp)
                                .padding(horizontal = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${index + 1}",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        visibleCols.forEach { col ->
                            Box(
                                modifier = Modifier
                                    .width(col.minWidthDp.dp)
                                    .padding(horizontal = 8.dp),
                                contentAlignment = if (col == WorkOrderColumn.TOTAL_PRICE || col == WorkOrderColumn.QTY || col == WorkOrderColumn.KM_CURRENT)
                                    Alignment.CenterEnd else Alignment.CenterStart
                            ) {
                                renderTableCell(col, item, idrFormat, intFormat)
                            }
                        }
                    }
                }

                if (isLoading) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(strokeWidth = 2.dp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun renderTableCell(
    column: WorkOrderColumn,
    item: WorkOrderItem,
    idrFormat: NumberFormat,
    intFormat: NumberFormat
) {
    when (column) {
        WorkOrderColumn.NAME -> {
            Text(
                text = item.name,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        WorkOrderColumn.MOBIL_NAME -> {
            Text(
                text = item.mobilName,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        WorkOrderColumn.TRANDATE -> {
            Text(
                text = item.trandateFormatted,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        WorkOrderColumn.KM_CURRENT -> {
            Text(
                text = if (item.kmCurrent > 0) "${intFormat.format(item.kmCurrent)} KM" else "-",
                fontSize = 11.sp,
                textAlign = TextAlign.End
            )
        }
        WorkOrderColumn.KELUHAN -> {
            Text(
                text = item.keluhan.ifBlank { "-" },
                fontSize = 11.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
        WorkOrderColumn.TIPE -> {
            val isPart = item.tipe.lowercase().contains("part")
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (isPart) Color(0xFFE0F2FE) else Color(0xFFFEF3C7))
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Text(
                    text = item.tipe.uppercase(),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isPart) Color(0xFF0369A1) else Color(0xFFB45309)
                )
            }
        }
        WorkOrderColumn.KODE -> {
            Text(
                text = item.kode.ifBlank { "-" },
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }
        WorkOrderColumn.DESCRIPTION -> {
            Text(
                text = item.description,
                fontSize = 11.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
        WorkOrderColumn.CATATAN -> {
            Text(
                text = item.catatan.ifBlank { "-" },
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        WorkOrderColumn.START_TIME -> {
            Text(text = item.startTime.ifBlank { "-" }, fontSize = 11.sp)
        }
        WorkOrderColumn.END_TIME -> {
            Text(text = item.endTime.ifBlank { "-" }, fontSize = 11.sp)
        }
        WorkOrderColumn.QTY -> {
            Text(text = item.qty.toString(), fontSize = 11.sp, textAlign = TextAlign.End)
        }
        WorkOrderColumn.TOTAL -> {
            Text(text = item.total.toString(), fontSize = 11.sp, textAlign = TextAlign.End)
        }
        WorkOrderColumn.TOTAL_PRICE -> {
            Text(
                text = idrFormat.format(item.totalPrice),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.tertiary,
                textAlign = TextAlign.End
            )
        }
        WorkOrderColumn.PRODUCT_CLASS -> {
            Text(text = item.productClass.ifBlank { "-" }, fontSize = 11.sp)
        }
        WorkOrderColumn.NO_CHASSIS -> {
            Text(text = item.noChassis.ifBlank { "-" }, fontSize = 10.sp)
        }
        WorkOrderColumn.NO_MESIN -> {
            Text(text = item.noMesin.ifBlank { "-" }, fontSize = 10.sp)
        }
    }
}
