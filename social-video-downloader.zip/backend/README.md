# Panduan Backend: Social Video Downloader (Python FastAPI + yt-dlp)

Panduan lengkap untuk menjalankan server backend ekstraktor video di komputer lokal / VPS Anda.

---

## 1. Prasyarat Sistem
- **Python 3.9+** (Disarankan Python 3.10 atau 3.11).
- **FFmpeg** (Sangat disarankan terinstal di komputer agar `yt-dlp` bisa memproses penggabungan stream video & audio dengan sempurna).
  - **Windows**: `winget install Gyan.FFmpeg` atau unduh dari ffmpeg.org
  - **macOS**: `brew install ffmpeg`
  - **Ubuntu/Debian**: `sudo apt update && sudo apt install -y ffmpeg`

---

## 2. Langkah Instalasi & Menjalankan Server

Buka Terminal / Command Prompt di folder `backend/`:

### Langkah A: Buat & Aktifkan Virtual Environment (venv)
```bash
# Pindah ke direktori backend
cd backend

# Buat virtual environment
python -m venv venv

# Aktifkan virtual environment:
# Di Windows:
venv\Scripts\activate

# Di macOS / Linux:
source venv/bin/activate
```

### Langkah B: Install Dependensi
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### Langkah C: Jalankan Server FastAPI
```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

Jika berhasil, Anda akan melihat output:
```
INFO:     Uvicorn running on http://0.0.0.0:8000 (Press CTRL+C to quit)
INFO:     Started reloader process
INFO:     Application startup complete.
```

---

## 3. Cara Menguji API Secara Mandiri

### Opsi 1: Melalui Swagger UI (Interaktif di Browser)
Buka browser dan akses:
**`http://localhost:8000/docs`**

Anda dapat langsung mencoba endpoint `POST /api/extract` dengan input JSON:
```json
{
  "url": "https://www.tiktok.com/@example/video/123456789"
}
```

### Opsi 2: Menggunakan cURL di Terminal
```bash
curl -X POST "http://localhost:8000/api/extract" \
     -H "Content-Type: application/json" \
     -d "{\"url\": \"https://www.tiktok.com/@username/video/123456789\"}"
```

---

## 4. Cara Menghubungkan Aplikasi Android ke Backend

### Skenario A: Menjalankan di Android Studio Emulator (AVD)
- Komputer Anda bertindak sebagai server di `localhost:8000`.
- Android Emulator memiliki alias loopback khusus ke komputer host yaitu:
  👉 **`http://10.0.2.2:8000/`**
- Ini sudah menjadi nilai default di aplikasi Android! Cukup buka aplikasi, dan server akan langsung terhubung.

### Skenario B: Menjalankan di HP Fisik Android (Real Device)
1. Pastikan HP Android dan Komputer Anda terhubung ke **jaringan Wi-Fi yang sama**.
2. Cari IP lokal komputer Anda:
   - **Windows**: Jalankan `ipconfig` di CMD (cari *IPv4 Address*, contoh: `192.168.1.50`).
   - **macOS / Linux**: Jalankan `ifconfig` atau `ip a` (contoh: `192.168.1.50`).
3. Di aplikasi Android, klik ikon **Pengaturan (Server Settings)** di kanan atas.
4. Masukkan URL:
   👉 **`http://192.168.1.50:8000/`** (ganti dengan IP komputer Anda).
5. Klik **Tes Koneksi (Ping)** untuk memverifikasi sampai muncul status hijau "Server Online".
