package com.example.ui.screens

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.BluetoothDisabled
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.ExpressNavy
import com.example.ui.theme.ExpressRed
import com.example.ui.viewmodel.ReceiptViewModel
import com.example.util.PrinterStatus
import kotlinx.coroutines.launch

@Composable
fun BluetoothPrinterScreen(
    viewModel: ReceiptViewModel,
    modifier: Modifier = Modifier
) {
    val printerStatus by viewModel.printerStatus.collectAsState()
    val is80mm by viewModel.is80mm.collectAsState()
    val isPrinting by viewModel.isPrinting.collectAsState()
    val printMessage by viewModel.printMessage.collectAsState()
    val currentReceipt by viewModel.currentReceipt.collectAsState()

    var pairedDevices by remember { mutableStateOf<List<BluetoothDevice>>(emptyList()) }
    var hasPermission by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val granted = results.values.all { it }
        hasPermission = granted
        if (granted) {
            pairedDevices = viewModel.getPairedBluetoothDevices()
        }
    }

    fun checkAndRequestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN
                )
            )
        } else {
            hasPermission = true
            pairedDevices = viewModel.getPairedBluetoothDevices()
        }
    }

    LaunchedEffect(Unit) {
        checkAndRequestPermissions()
    }

    LaunchedEffect(printMessage) {
        printMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearPrintMessage()
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Printer Thermal Bluetooth",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Cetak resi langsung di lapangan (ESC/POS)",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }

                    IconButton(onClick = {
                        checkAndRequestPermissions()
                        pairedDevices = viewModel.getPairedBluetoothDevices()
                    }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh Perangkat")
                    }
                }
            }

            // Connection Status Banner
            item {
                ElevatedCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.elevatedCardColors(
                        containerColor = when (printerStatus) {
                            is PrinterStatus.Connected -> Color(0xFFECFDF5)
                            is PrinterStatus.Connecting -> Color(0xFFEFF6FF)
                            is PrinterStatus.Error -> Color(0xFFFEF2F2)
                            else -> MaterialTheme.colorScheme.surface
                        }
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(
                                    when (printerStatus) {
                                        is PrinterStatus.Connected -> AccentGreen.copy(alpha = 0.2f)
                                        is PrinterStatus.Connecting -> ExpressNavy.copy(alpha = 0.1f)
                                        is PrinterStatus.Error -> ExpressRed.copy(alpha = 0.2f)
                                        else -> Color.LightGray.copy(alpha = 0.3f)
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (printerStatus) {
                                    is PrinterStatus.Connected -> Icons.Default.BluetoothConnected
                                    is PrinterStatus.Connecting -> Icons.Default.Bluetooth
                                    is PrinterStatus.Error -> Icons.Default.Error
                                    else -> Icons.Default.BluetoothDisabled
                                },
                                contentDescription = null,
                                tint = when (printerStatus) {
                                    is PrinterStatus.Connected -> AccentGreen
                                    is PrinterStatus.Connecting -> ExpressNavy
                                    is PrinterStatus.Error -> ExpressRed
                                    else -> Color.Gray
                                },
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            when (val status = printerStatus) {
                                is PrinterStatus.Connected -> {
                                    Text(
                                        text = "Terhubung: ${status.deviceName}",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF065F46)
                                    )
                                    Text(
                                        text = status.address,
                                        fontSize = 11.sp,
                                        color = Color(0xFF047857)
                                    )
                                }
                                is PrinterStatus.Connecting -> {
                                    Text(
                                        text = "Menghubungkan ke printer...",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = ExpressNavy
                                    )
                                    Text(
                                        text = "Membuat koneksi SPP Bluetooth",
                                        fontSize = 11.sp,
                                        color = Color.DarkGray
                                    )
                                }
                                is PrinterStatus.Error -> {
                                    Text(
                                        text = "Koneksi Terputus / Gagal",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = ExpressRed
                                    )
                                    Text(
                                        text = status.message,
                                        fontSize = 11.sp,
                                        color = Color.DarkGray
                                    )
                                }
                                is PrinterStatus.Disconnected -> {
                                    Text(
                                        text = "Printer Belum Terhubung",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Pilih salah satu printer di bawah untuk menghubungkan",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                            }
                        }

                        if (printerStatus is PrinterStatus.Connected) {
                            OutlinedButton(
                                onClick = { viewModel.disconnectPrinter() },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("Putus", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            // Print Operations Bar
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Pengaturan Kertas & Cetak",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        // Paper width chips
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Lebar Kertas:",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            FilterChip(
                                selected = !is80mm,
                                onClick = { viewModel.setPaperWidth80mm(false) },
                                label = { Text("58 mm (Standar Mini)") }
                            )
                            FilterChip(
                                selected = is80mm,
                                onClick = { viewModel.setPaperWidth80mm(true) },
                                label = { Text("80 mm (Lebar)") }
                            )
                        }

                        HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))

                        // Print Actions
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.printTestReceipt() },
                                modifier = Modifier.weight(1f),
                                enabled = printerStatus is PrinterStatus.Connected && !isPrinting,
                                colors = ButtonDefaults.buttonColors(containerColor = ExpressNavy),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Test Print", fontSize = 12.sp)
                            }

                            Button(
                                onClick = { viewModel.printCurrentReceiptBluetooth() },
                                modifier = Modifier
                                    .weight(1.5f)
                                    .testTag("print_receipt_bluetooth_btn"),
                                enabled = printerStatus is PrinterStatus.Connected && !isPrinting,
                                colors = ButtonDefaults.buttonColors(containerColor = ExpressRed),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                if (isPrinting) {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                } else {
                                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                }
                                Text("Cetak Resi Sekarang", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        if (printerStatus !is PrinterStatus.Connected) {
                            Text(
                                text = "Tips: Sambungkan Bluetooth thermal printer Anda di menu Bluetooth HP terlebih dahulu, lalu pilih perangkat di daftar bawah.",
                                fontSize = 11.sp,
                                color = Color.Gray,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }

            // Current Receipt Preview Info
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Resi yang akan dicetak:",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            Text(
                                text = currentReceipt.resiCode,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                color = ExpressRed
                            )
                            Text(
                                text = "${currentReceipt.recipientName} • ${currentReceipt.getFormattedFee()}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Box(
                            modifier = Modifier
                                .background(Color.Black, RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = currentReceipt.routingCode,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Paired Devices List Section
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Perangkat Bluetooth Tersanding (${pairedDevices.size})",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            }

            if (pairedDevices.isEmpty()) {
                item {
                    ElevatedCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bluetooth,
                                contentDescription = null,
                                modifier = Modifier.size(40.dp),
                                tint = Color.LightGray
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Tidak Ada Printer Bluetooth Tersanding",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Silakan pasangkan (pair) printer Bluetooth thermal Anda di Pengaturan Bluetooth HP terlebih dahulu.",
                                fontSize = 12.sp,
                                color = Color.Gray,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(onClick = {
                                checkAndRequestPermissions()
                                pairedDevices = viewModel.getPairedBluetoothDevices()
                            }) {
                                Text("Pindai Ulang")
                            }
                        }
                    }
                }
            } else {
                items(pairedDevices) { device ->
                    DeviceItemCard(
                        device = device,
                        isConnected = (printerStatus as? PrinterStatus.Connected)?.address == device.address,
                        onConnect = { viewModel.connectPrinter(device) }
                    )
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 80.dp)
        )
    }
}

@Composable
private fun DeviceItemCard(
    device: BluetoothDevice,
    isConnected: Boolean,
    onConnect: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onConnect() }
            .testTag("bluetooth_device_${device.address.replace(":", "_")}"),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = if (isConnected) Color(0xFFF0FDF4) else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(if (isConnected) AccentGreen.copy(alpha = 0.2f) else Color.LightGray.copy(alpha = 0.3f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Print,
                    contentDescription = null,
                    tint = if (isConnected) AccentGreen else ExpressNavy,
                    modifier = Modifier.size(20.dp)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = device.name ?: "Unknown Device",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = device.address,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
            }

            if (isConnected) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = AccentGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Text("Terhubung", color = AccentGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            } else {
                OutlinedButton(
                    onClick = onConnect,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text("Sambung", fontSize = 12.sp)
                }
            }
        }
    }
}
