# Panduan Menjalankan Backend di Termux (Android)

Anda bisa menjalankan server backend **FastAPI + yt-dlp** langsung di dalam HP Android Anda menggunakan **Termux** tanpa memerlukan laptop atau komputer!

Dengan skenario ini:
- **Termux** bertindak sebagai server lokal di background (`http://127.0.0.1:8000`).
- **Aplikasi Android** ini terhubung langsung ke Termux di HP yang sama.

---

## 1. Persiapan di Termux

Buka aplikasi **Termux** di HP Anda, lalu ketik perintah berikut satu per satu:

### Langkah A: Update Repositori & Install Paket Dasar
```bash
pkg update && pkg upgrade -y
pkg install python ffmpeg git -y
```

### Langkah B: Pasang Library Python
```bash
pip install --upgrade pip
pip install fastapi "uvicorn[standard]" yt-dlp pydantic requests
```

---

## 2. Meletakkan File `main.py` di Termux

Anda memiliki 2 cara:

### Cara 1: Buat langsung file `main.py` di Termux
Jalankan:
```bash
nano main.py
```
Lalu tempel (paste) seluruh kode dari file `backend/main.py`, lalu tekan **CTRL + O** (Enter) untuk menyimpan dan **CTRL + X** untuk keluar.

### Cara 2: Akses Folder Penyimpanan HP
Jika Anda sudah menyalin file `main.py` ke folder Download HP Anda:
```bash
termux-setup-storage
cd /sdcard/Download
```

---

## 3. Jalankan Server di Termux

Ketik perintah ini di Termux:
```bash
python -m uvicorn main:app --host 127.0.0.1 --port 8000
```

Jika berhasil, Termux akan menampilkan:
```
INFO:     Uvicorn running on http://127.0.0.1:8000 (Press CTRL+C to quit)
INFO:     Application startup complete.
```

> **Tips:** Agar server tidak dimatikan oleh sistem Android saat aplikasi berjalan di background, tarik notifikasi Termux ke bawah lalu pilih **"Acquire Wakelock"**.

---

## 4. Hubungkan Aplikasi Android ke Termux

1. Buka aplikasi **Social Video Downloader** di HP Anda.
2. Klik ikon **Pengaturan (Server Settings)** di pojok kanan atas.
3. Klik tombol preset **"Termux"** (otomatis mengisi `http://127.0.0.1:8000/`).
4. Klik **Uji Koneksi** (status akan berubah menjadi hijau **Backend Online**).
5. Klik **Simpan**.

Sekarang Anda bisa paste link video TikTok/IG/YouTube dan langsung mengunduh video sepuasnya tanpa laptop!
