package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.VideoAnalysisResult
import com.example.data.model.VideoMoment
import com.example.ui.components.*
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioEmerald

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalysisDetailScreen(
    analysis: VideoAnalysisResult,
    targetSeekSecond: Int?,
    activeTab: Int,
    onTabSelected: (Int) -> Unit,
    onSeekTo: (Int) -> Unit,
    onResetSeek: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Android back handler to return to Home screen
    BackHandler {
        onBack()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = analysis.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${analysis.sourceType.name} • ${analysis.formattedDuration()} • ${analysis.moments.size} Momen Klip",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("back_to_home_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Kembali ke Beranda"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            val shareText = buildString {
                                appendLine("🎬 *Hasil Analisis Momen Video - MomentSnap AI*")
                                appendLine("Video: ${analysis.title}")
                                appendLine("Durasi: ${analysis.formattedDuration()}")
                                appendLine("\n📌 *Momen Klip & Trimming:*")
                                analysis.moments.forEach { m ->
                                    appendLine("• [${m.formattedTimeRange()}] ${m.title} (${m.viralScore}% viral)")
                                }
                                appendLine("\n🔥 *Top Hook (3 Detik Pertama):*")
                                analysis.hooks.firstOrNull()?.let {
                                    appendLine("\"${it.hookText}\" (${it.hookType})")
                                }
                                appendLine("\n✨ *Rekomendasi Judul Terbaik:*")
                                analysis.titleSuggestions.take(2).forEach {
                                    appendLine("• ${it.titleText}")
                                }
                                appendLine("\n🏷️ *Tagar Relevan:*")
                                appendLine(analysis.seoData.recommendedTags.take(8).joinToString(" "))
                            }
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "Analisis Video - ${analysis.title}")
                                putExtra(Intent.EXTRA_TEXT, shareText)
                            }
                            context.startActivity(Intent.createChooser(intent, "Bagikan Hasil Analisa"))
                        },
                        modifier = Modifier.testTag("share_analysis_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Bagikan Hasil"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 48.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Interactive Video Player & Timeline
            item {
                VideoPlayerSection(
                    analysis = analysis,
                    targetSeekSecond = targetSeekSecond,
                    onResetSeek = onResetSeek,
                    onMomentSelected = { moment ->
                        onSeekTo(moment.startSecond)
                    }
                )
            }

            // Summary Card (Rangkuman Poin Utama Otomatis)
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("summary_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Summarize,
                                    contentDescription = null,
                                    tint = StudioCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Rangkuman Poin Utama Otomatis",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = StudioEmerald.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "AI Generated",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = StudioEmerald,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            analysis.summaryPoints.forEach { point ->
                                Row(
                                    verticalAlignment = Alignment.Top,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircleOutline,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier
                                            .size(16.dp)
                                            .padding(top = 2.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = point,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        lineHeight = 18.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Tabs for Analysis Categories
            item {
                ScrollableTabRow(
                    selectedTabIndex = activeTab,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.primary,
                    edgePadding = 0.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .testTag("detail_category_tab_row")
                ) {
                    val tabs = listOf(
                        Pair("Momen & Trim", Icons.Default.ContentCut),
                        Pair("Hooks & Judul", Icons.Default.Bolt),
                        Pair("Deskripsi Medsos", Icons.Default.Share),
                        Pair("Statistik & SEO", Icons.Default.TrendingUp)
                    )
                    tabs.forEachIndexed { index, (label, icon) ->
                        Tab(
                            selected = activeTab == index,
                            onClick = { onTabSelected(index) },
                            text = {
                                Text(
                                    text = label,
                                    fontWeight = if (activeTab == index) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 12.sp
                                )
                            },
                            icon = {
                                Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        )
                    }
                }
            }

            // Tab Content
            when (activeTab) {
                0 -> {
                    // Momen & Trimming
                    items(analysis.moments, key = { it.id }) { moment ->
                        MomentCard(
                            moment = moment,
                            onSeekTo = onSeekTo
                        )
                    }
                }
                1 -> {
                    // Hooks & Titles
                    item {
                        HooksAndTitlesSection(
                            hooks = analysis.hooks,
                            titles = analysis.titleSuggestions
                        )
                    }
                }
                2 -> {
                    // Social Captions
                    item {
                        SocialCaptionsSection(
                            captions = analysis.socialCaptions
                        )
                    }
                }
                3 -> {
                    // Statistics & SEO
                    item {
                        SeoAndStatsSection(
                            audienceMetrics = analysis.audienceMetrics,
                            seoData = analysis.seoData
                        )
                    }
                }
            }
        }
    }
}
