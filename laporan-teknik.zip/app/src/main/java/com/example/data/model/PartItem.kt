package com.example.data.model

data class PartItem(
    val partNumber: String = "",
    val partName: String = "",
    val procurementType: String = "Stock", // Stock, Order, Modifikasi
    val notes: String = ""
)
