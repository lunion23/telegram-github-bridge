# CloudPad - Cloud-Synced Notepad & Code Notebook

A modern, responsive Android notepad application designed for quick note-taking, markdown writing, and code snippets, featuring real-time multi-device cloud synchronization with Google Sign-In, offline guest mode, and flexible multi-format file export (.txt, .json, .html, .js, .py, and custom extensions).

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The following product decisions were confirmed during the planning clarification interview:
> - **Guest Mode & Cloud Sync**: Notes are accessible immediately offline in guest mode (stored locally via Room) with seamless one-tap Google Sign-In to activate real-time Firebase Firestore cloud synchronization across all devices.
> - **Editor Style**: Rich markdown and code editor supporting syntax highlighting for code fences (JSON, HTML, JS, Python, Markdown), formatting shortcut bar, and live preview toggle.
> - **Multi-Format Export**: One-tap quick presets to export notes as `.txt`, `.json`, `.html`, `.js`, `.py`, as well as custom user-specified extensions and Android system share sheet integration.

---

### 1. Overview & Core Concept

- **What It Does**: CloudPad delivers a fluid, distraction-free writing and coding experience. Users can create, organize, pin, tag, and search notes. Notes can be stored locally in guest mode or synced continuously in real-time across devices whenever signed in with Google.
- **Target Audience**: Developers, technical writers, students, and power users who need a fast, versatile notepad capable of handling both everyday notes and syntax-highlighted code snippets with quick export options.
- **Key Value**: Eliminates lock-in and sync delays: instant offline responsiveness with automatic real-time cloud backup, conflict-resilient editing, and unrestricted file exporting.

---

### 2. User Experience & Visual Design

#### Key User Flows
1. **First Launch & Guest Mode**:
   - App opens immediately into the Notes Dashboard with a welcoming empty/sample note and clear status indicator ("Guest Mode - Stored on device").
   - A subtle top app bar banner offers "Sync with Google" with a one-tap sign-in button.
2. **Writing & Editing**:
   - Tapping the Floating Action Button (`+`) opens the Editor screen with zero delay.
   - Header with Title input, tags chip row, and live word/character counters.
   - Formatter bar above keyboard: Headings (`H1`-`H3`), Bold (`**`), Italic (`*`), Code snippet (```), Checklist (`- [ ]`), Bullet list (`-`), and Link.
   - Toggle between **Edit Mode**, **Split/Live View**, and **Markdown Preview**.
3. **Multi-Format Export**:
   - Note options menu (`⋮`) -> "Export Note".
   - Clean bottom sheet dialog with quick preset chips:
     - 📄 **Plain Text (`.txt`)**
     - 📦 **Structured JSON (`.json`)** with metadata and timestamp
     - 🌐 **Web Page (`.html`)** rendered with clean styling
     - ⚡ **JavaScript (`.js`)** / 🐍 **Python (`.py`)** with boilerplate headers
     - 🏷️ **Custom Extension** input dialog (e.g., `.md`, `.yaml`, `.csv`, `.sh`)
   - Action triggers Android Storage Access Framework (`ActivityResultContracts.CreateDocument`) to save directly to device storage, plus a "Share to App" button for Android system share sheet.
4. **Cloud Sync & Account Management**:
   - User taps "Sign in with Google" via Credential Manager.
   - Existing guest notes are automatically preserved and linked to the user account.
   - Real-time changes replicate instantly across open devices via Firestore snapshot listeners.
   - Offline indicators gracefully notify users when changes are queued locally.

#### Visual Identity & Theme
- **Aesthetic Direction**: *Nordic Modern Minimalist* — crisp, high-contrast, distraction-free canvas with warm slate/charcoal surfaces, electric cyan accent for code and links, and subtle tonal borders.
- **Color Palette (M3 Semantic Tokens)**:
  - `primary`: Deep Cyan / Teal `#00838F` (Light) / Vibrant Cyan `#4DD0E1` (Dark)
  - `surface`: Crisp off-white `#F8F9FA` (Light) / Elevated Charcoal `#181A1F` (Dark)
  - `surfaceContainer`: Soft pearl `#EFF2F5` (Light) / Card midnight `#21252B` (Dark)
  - `codeSurface`: Slate tint `#282C34` with syntax tokens (amber strings, purple keywords, green comments)
- **Typography & Hierarchy**:
  - Headings: Bold modern geometric sans (Title Large / Headline Medium).
  - Body: Readable sans (15sp - 16sp) with generous 1.5 line height.
  - Code & Snippets: Monospace font with subtle background pill and rounded corners.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Dual Local-First + Firebase Firestore Sync Engine**
  - *Chosen Approach*: Notes are persisted in Room database locally for instantaneous offline startup. When authenticated with Google, a background synchronization layer seamlessly pairs local records with the user's private Firestore collection (`/users/{uid}/notes`).
  - *Why*: Ensures zero latency when opening the app or typing, works 100% offline without network blocks, while providing real-time multi-device collaboration and cloud backup.
  - *Alternatives Considered*: Direct Firestore-only access (would block or fail in guest mode or offline).
- **Decision 2: Native Android Document Creation (SAF) for Export**
  - *Chosen Approach*: Use `ActivityResultContracts.CreateDocument` combined with `Intent.ACTION_SEND`.
  - *Why*: Google Play policy compliant, requires zero dangerous external storage permissions, and allows users to pick any folder (Downloads, Drive, SD card).
- **Decision 3: Zero Anonymous Auth Invariant**
  - *Chosen Approach*: Strict adherence to security standards using Jetpack Credential Manager for Google Sign-In with visible button; guest mode stays completely on-device without pseudo-anonymous Firebase auth.

---

### 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────┐
│                       CloudPad App                          │
├─────────────────────────────────────────────────────────────┤
│  Presentation Layer (Jetpack Compose M3)                    │
│  ┌───────────────────────┐   ┌───────────────────────────┐  │
│  │ NoteListScreen        │   │ NoteEditorScreen          │  │
│  │ - Search & Tag Filter │   │ - Syntax / Markdown Field │  │
│  │ - Sync Status Badge   │   │ - Quick Formatting Bar    │  │
│  │ - Note Card Grid/List │   │ - Live Preview & Stats    │  │
│  └───────────┬───────────┘   └─────────────┬─────────────┘  │
│              │                             │                │
│  ┌───────────▼─────────────────────────────▼─────────────┐  │
│  │ NoteViewModel & AuthViewModel                         │  │
│  │ - Reactive StateFlow UI State                         │  │
│  │ - Export generation (TXT, JSON, HTML, JS, PY, Custom) │  │
│  └───────────────────────────┬───────────────────────────┘  │
│                              │                              │
│  Domain & Repository Layer   │                              │
│  ┌───────────────────────────▼───────────────────────────┐  │
│  │ SyncNoteRepository                                    │  │
│  │ - Coordinates Local Room + Remote Firestore           │  │
│  └─────────────┬───────────────────────────┬─────────────┘  │
│                │                           │                │
│  ┌─────────────▼────────────┐ ┌────────────▼──────────────┐ │
│  │ Local: Room Database     │ │ Remote: Firebase Firestore│ │
│  │ - Offline cache          │ │ - users/{uid}/notes       │ │
│  │ - NoteEntity             │ │ - Real-time snapshots     │ │
│  └──────────────────────────┘ └───────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

#### Core Data Entities

```kotlin
// Note Model
data class Note(
    val id: String = UUID.randomUUID().toString(),
    val userId: String = "",
    val title: String = "",
    val content: String = "",
    val tags: List<String> = emptyList(),
    val isPinned: Boolean = false,
    val fileExtension: String = "txt", // txt, md, json, html, js, py
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isSynced: Boolean = false
)
```

#### Interactive Components & Export Matrix
| Format | Extension | Content Transformation |
| :--- | :--- | :--- |
| **Plain Text** | `.txt` | Raw content string |
| **JSON** | `.json` | Serialized note object with title, tags, timestamps |
| **HTML** | `.html` | Full HTML5 wrapper document with CSS typography |
| **JavaScript** | `.js` | JS comment header + code content |
| **Python** | `.py` | Python docstring header + code content |
| **Custom** | User defined | Raw content with custom filename & extension |

---

### Implementation Phases & Verification Steps
1. **Backend & Rules Setup**: Provision Firebase Auth & Firestore using `set_up_firebase`, write `firebase-blueprint.json`, `firestore.rules`, and test with emulators.
2. **Local Room & Repository**: Implement Room database, DAO, and `SyncNoteRepository` handling offline caching and cloud sync.
3. **UI Components & Theme**: Modern Compose theme, Note card grid, full-fidelity Markdown/Code editor with syntax highlighting and formatting bar.
4. **Export Engine**: SAF document writer and Share intent generator for all file formats.
5. **Compilation & End-to-End Build Verification**: Full Gradle build and runtime check.
