package com.example.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import com.example.data.model.PartItem
import com.example.data.model.TechnicalReport
import com.example.data.repository.ReportRepository
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

object PdfEngineGenerator {

    // High resolution A4 standard dimensions at ~150 DPI
    const val PAGE_WIDTH = 1240
    const val PAGE_HEIGHT = 1754

    fun generatePdf(context: Context, report: TechnicalReport): File {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        drawReportDocument(context, canvas, report)

        pdfDocument.finishPage(page)

        val outputDir = File(context.cacheDir, "generated_pdfs")
        if (!outputDir.exists()) outputDir.mkdirs()

        val safeName = report.noLaporan.replace("[^a-zA-Z0-9.-]".toRegex(), "_")
        val file = File(outputDir, "Laporan_Teknik_${safeName}.pdf")
        val outputStream = FileOutputStream(file)
        pdfDocument.writeTo(outputStream)
        outputStream.flush()
        outputStream.close()
        pdfDocument.close()

        return file
    }

    fun renderPageToBitmap(context: Context, report: TechnicalReport): Bitmap {
        val bitmap = Bitmap.createBitmap(PAGE_WIDTH, PAGE_HEIGHT, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawReportDocument(context, canvas, report)
        return bitmap
    }

    private fun drawReportDocument(context: Context, canvas: Canvas, report: TechnicalReport) {
        // Background white
        canvas.drawColor(Color.WHITE)

        val borderPaint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 2.5f
            isAntiAlias = true
        }

        val thinBorderPaint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 1.2f
            isAntiAlias = true
        }

        val textPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = 21f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }

        val boldTextPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val titlePaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = 34f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val leftMargin = 38f
        val rightMargin = 1202f
        val topMargin = 38f
        val bottomMargin = 1716f
        val docWidth = rightMargin - leftMargin

        // 1. Draw Outer Boundary Box
        canvas.drawRect(leftMargin, topMargin, rightMargin, bottomMargin, borderPaint)

        // -------------------------------------------------------------
        // SECTION 1: HEADER (Y: 38 to 175)
        // -------------------------------------------------------------
        val headerBottom = 175f
        val rightColX = 890f // Start of right mini-table (No.Laporan, Bengkel, Tanggal)

        // Horizontal line under header
        canvas.drawLine(leftMargin, headerBottom, rightMargin, headerBottom, borderPaint)
        // Vertical divider for right mini table
        canvas.drawLine(rightColX, topMargin, rightColX, headerBottom, borderPaint)

        // Left Header: Logo & Title
        drawHeaderLogoAndTitle(context, canvas, report, leftMargin + 16f, topMargin + 10f, rightColX - leftMargin - 32f, headerBottom - topMargin, titlePaint, boldTextPaint)

        // Right Mini Table: 3 rows (No.Laporan, Bengkel, Tanggal)
        val miniRowH = (headerBottom - topMargin) / 3f
        val rightLabelW = 150f
        val miniColValX = rightColX + rightLabelW

        // Row dividers inside mini table
        canvas.drawLine(rightColX, topMargin + miniRowH, rightMargin, topMargin + miniRowH, thinBorderPaint)
        canvas.drawLine(rightColX, topMargin + miniRowH * 2, rightMargin, topMargin + miniRowH * 2, thinBorderPaint)
        // Vertical line between label and value
        canvas.drawLine(miniColValX, topMargin, miniColValX, headerBottom, thinBorderPaint)

        // Mini table text
        drawTextCell(canvas, "No.Laporan", rightColX + 8f, topMargin + 32f, boldTextPaint)
        drawTextCell(canvas, report.noLaporan, miniColValX + 8f, topMargin + 32f, boldTextPaint)

        drawTextCell(canvas, "Bengkel", rightColX + 8f, topMargin + miniRowH + 32f, boldTextPaint)
        drawTextCell(canvas, report.bengkel, miniColValX + 8f, topMargin + miniRowH + 32f, boldTextPaint)

        drawTextCell(canvas, "Tanggal", rightColX + 8f, topMargin + miniRowH * 2 + 32f, boldTextPaint)
        drawTextCell(canvas, report.tanggalLaporan, miniColValX + 8f, topMargin + miniRowH * 2 + 32f, boldTextPaint)

        // -------------------------------------------------------------
        // SECTION 2: VEHICLE SPECS & NAMA ALAT (Y: 175 to 265)
        // -------------------------------------------------------------
        val specsBottom = 265f
        val specsRowH = (specsBottom - headerBottom) / 2f
        canvas.drawLine(leftMargin, headerBottom + specsRowH, rightMargin, headerBottom + specsRowH, thinBorderPaint)
        canvas.drawLine(leftMargin, specsBottom, rightMargin, specsBottom, borderPaint)

        // Columns for specs: Pabrik Pembuat | Tipe | Nama Alat
        val col1W = 210f
        val col2W = 320f
        val col3W = 110f
        val col4W = 250f // Tipe value
        val col5W = 150f // Nama Alat / Komponen label
        // X coordinates
        val c1X = leftMargin
        val c2X = c1X + col1W
        val c3X = c2X + col2W
        val c4X = c3X + col3W
        val c5X = rightColX
        val c6X = c5X + rightLabelW

        // Vertical dividers for vehicle specs
        canvas.drawLine(c2X, headerBottom, c2X, specsBottom, thinBorderPaint)
        canvas.drawLine(c3X, headerBottom, c3X, specsBottom, thinBorderPaint)
        canvas.drawLine(c4X, headerBottom, c4X, specsBottom, thinBorderPaint)
        canvas.drawLine(c5X, headerBottom, c5X, specsBottom, borderPaint)
        canvas.drawLine(c6X, headerBottom, c6X, specsBottom, thinBorderPaint)

        // Row 1:
        drawTextCell(canvas, "Pabrik Pembuat", c1X + 8f, headerBottom + 30f, boldTextPaint)
        drawTextCell(canvas, report.pabrikPembuat, c2X + 8f, headerBottom + 30f, textPaint)
        drawTextCell(canvas, "Tipe", c3X + 8f, headerBottom + 30f, boldTextPaint)
        drawTextCell(canvas, report.tipe, c4X + 8f, headerBottom + 30f, textPaint)
        drawTextCell(canvas, "Nama Alat", c5X + 8f, headerBottom + 30f, boldTextPaint)
        drawTextCell(canvas, report.namaAlat, c6X + 8f, headerBottom + 30f, textPaint)

        // Row 2:
        val r2Y = headerBottom + specsRowH
        drawTextCell(canvas, "Model", c1X + 8f, r2Y + 30f, boldTextPaint)
        drawTextCell(canvas, report.model, c2X + 8f, r2Y + 30f, textPaint)
        drawTextCell(canvas, "Kode", c3X + 8f, r2Y + 30f, boldTextPaint)
        drawTextCell(canvas, report.kode, c4X + 8f, r2Y + 30f, textPaint)
        drawTextCell(canvas, "Komponen", c5X + 8f, r2Y + 30f, boldTextPaint)
        drawTextCell(canvas, report.komponen, c6X + 8f, r2Y + 30f, textPaint)

        // -------------------------------------------------------------
        // SECTION 3: TANGGAL RUSAK & KM/HM (Y: 265 to 305)
        // -------------------------------------------------------------
        val subRowBottom = 305f
        canvas.drawLine(leftMargin, subRowBottom, rightMargin, subRowBottom, thinBorderPaint)

        canvas.drawLine(c2X, specsBottom, c2X, subRowBottom, thinBorderPaint)
        canvas.drawLine(c3X, specsBottom, c3X, subRowBottom, thinBorderPaint)
        canvas.drawLine(c4X, specsBottom, c4X, subRowBottom, thinBorderPaint)
        canvas.drawLine(c5X, specsBottom, c5X, subRowBottom, borderPaint)

        drawTextCell(canvas, "Tanggal Rusak", c1X + 8f, specsBottom + 28f, boldTextPaint)
        drawTextCell(canvas, report.tanggalRusak, c2X + 8f, specsBottom + 28f, textPaint)
        drawTextCell(canvas, "Km / Hm", c3X + 8f, specsBottom + 28f, boldTextPaint)
        drawTextCell(canvas, report.kmHm, c4X + 8f, specsBottom + 28f, textPaint)
        drawTextCell(canvas, "Foto Kerusakan :", c5X + 8f, specsBottom + 28f, boldTextPaint)

        // -------------------------------------------------------------
        // SECTION 4: URAIAN KERUSAKAN & ADAPTIVE FOTO KERUSAKAN
        // (Y: 305 to 680)
        // -------------------------------------------------------------
        val damageSectionBottom = 680f
        // Vertical line dividing Uraian Kerusakan (left) and Foto Kerusakan (right)
        val photoBoxLeft = 770f
        canvas.drawLine(photoBoxLeft, subRowBottom, photoBoxLeft, damageSectionBottom, borderPaint)
        canvas.drawLine(leftMargin, damageSectionBottom, rightMargin, damageSectionBottom, borderPaint)

        // Uraian Kerusakan Header bar
        val uraianHeaderBottom = subRowBottom + 40f
        canvas.drawLine(leftMargin, uraianHeaderBottom, photoBoxLeft, uraianHeaderBottom, thinBorderPaint)

        val uraianLabelW = 210f
        canvas.drawLine(leftMargin + uraianLabelW, subRowBottom, leftMargin + uraianLabelW, uraianHeaderBottom, thinBorderPaint)

        drawTextCell(canvas, "Uraian Kerusakan", leftMargin + 8f, subRowBottom + 28f, boldTextPaint)

        // Checkboxes: Masa Garansi vs Setelah Masa Garansi
        val cbMasaGaransi = report.isMasaGaransi
        drawCheckbox(canvas, leftMargin + uraianLabelW + 20f, subRowBottom + 12f, 20f, cbMasaGaransi)
        drawTextCell(canvas, "Masa Garansi", leftMargin + uraianLabelW + 48f, subRowBottom + 28f, textPaint)

        drawCheckbox(canvas, leftMargin + uraianLabelW + 240f, subRowBottom + 12f, 20f, !cbMasaGaransi)
        drawTextCell(canvas, "Setelah Masa Garansi", leftMargin + uraianLabelW + 268f, subRowBottom + 28f, textPaint)

        // Inside Uraian Kerusakan Content Area
        var curY = uraianHeaderBottom + 30f

        // Tanggal & Status
        drawTextCell(canvas, "Tanggal    :  ${report.tanggalKejadian}", leftMargin + 12f, curY, textPaint)
        drawTextCell(canvas, "Status  :  ${report.statusArmada}", leftMargin + 380f, curY, textPaint)

        curY += 34f
        // Kerusakan & Lokasi
        drawTextCell(canvas, "Kerusakan :  ${report.kerusakan}", leftMargin + 12f, curY, textPaint)
        drawTextCell(canvas, "Lokasi  :  ${report.lokasi}", leftMargin + 380f, curY, textPaint)

        curY += 36f
        // Analisa
        drawTextCell(canvas, "Analisa     :", leftMargin + 12f, curY, boldTextPaint)
        curY += 26f
        drawWrappedText(canvas, report.analisa, leftMargin + 12f, curY, photoBoxLeft - leftMargin - 24f, textPaint, 26f)

        curY += 70f
        // Kesimpulan
        drawTextCell(canvas, "Kesimpulan :  Penggantian terakhir  :  ${report.kesimpulanPenggantianTerakhir}", leftMargin + 12f, curY, textPaint)
        curY += 28f
        drawTextCell(canvas, "                    No. Work Order        :  ${report.noWoPenggantianTerakhir}", leftMargin + 12f, curY, textPaint)
        curY += 28f
        drawTextCell(canvas, "                    Weekly terakhir       :  ${report.weeklyTerakhir}", leftMargin + 12f, curY, textPaint)
        curY += 28f
        drawTextCell(canvas, "                    No. Work Order        :  ${report.noWoWeeklyTerakhir}", leftMargin + 12f, curY, textPaint)

        // Draw Adaptive Photo Box on Right (photoBoxLeft to rightMargin, subRowBottom to damageSectionBottom)
        val photoRect = RectF(photoBoxLeft, subRowBottom, rightMargin, damageSectionBottom)
        drawAdaptivePhotoGrid(context, canvas, report.getPhotoList(), photoRect)

        // -------------------------------------------------------------
        // SECTION 5: PENYEBAB KERUSAKAN (Y: 680 to 860)
        // -------------------------------------------------------------
        val penyebabBottom = 860f
        canvas.drawLine(leftMargin, penyebabBottom, rightMargin, penyebabBottom, borderPaint)

        val penyebabHeaderBottom = 680f + 36f
        canvas.drawLine(leftMargin, penyebabHeaderBottom, rightMargin, penyebabHeaderBottom, thinBorderPaint)

        val penyebabColMid = 550f
        canvas.drawLine(penyebabColMid, 680f, penyebabColMid, penyebabBottom, borderPaint)

        // Header
        drawTextCell(canvas, "Penyebab Kerusakan  :   √ = YA   X = TIDAK", leftMargin + 12f, 680f + 26f, boldTextPaint)
        drawTextCell(canvas, "....................jika YA, tolong jelaskan!", penyebabColMid + 12f, 680f + 26f, textPaint)

        // 5 Rows of Checklist on Left
        val pRowH = (penyebabBottom - penyebabHeaderBottom) / 5f
        val cbX = penyebabColMid - 70f

        val items = listOf(
            Pair("1. Pemasangan", report.penyebabPemasangan),
            Pair("2. Kwalitas Parts", report.penyebabKwalitasParts),
            Pair("3. Kesalahan Operasional", report.penyebabKesalahanOperasional),
            Pair("4. Sudah waktunya", report.penyebabSudahWaktunya),
            Pair("5. Lain-lain", report.penyebabLainLain)
        )

        for (i in 0 until 5) {
            val rY = penyebabHeaderBottom + i * pRowH
            canvas.drawLine(leftMargin, rY + pRowH, penyebabColMid, rY + pRowH, thinBorderPaint)
            // Vertical line for checkbox column
            canvas.drawLine(cbX - 10f, rY, cbX - 10f, rY + pRowH, thinBorderPaint)

            drawTextCell(canvas, items[i].first, leftMargin + 12f, rY + 24f, textPaint)
            drawCheckboxWithTickCross(canvas, cbX + 8f, rY + 6f, 22f, items[i].second)
        }
        // Vertical line bounding checkbox
        canvas.drawLine(cbX - 10f, penyebabHeaderBottom, cbX - 10f, penyebabBottom, thinBorderPaint)

        // Right side: explanation text
        if (report.penyebabPenjelasan.isNotBlank()) {
            drawWrappedText(canvas, report.penyebabPenjelasan, penyebabColMid + 16f, penyebabHeaderBottom + 30f, rightMargin - penyebabColMid - 32f, textPaint, 26f)
        }

        // -------------------------------------------------------------
        // SECTION 6: CARA MENGATASI KERUSAKAN (Y: 860 to 990)
        // -------------------------------------------------------------
        val caraBottom = 990f
        canvas.drawLine(leftMargin, caraBottom, rightMargin, caraBottom, borderPaint)

        val caraHeaderBottom = 860f + 36f
        canvas.drawLine(leftMargin, caraHeaderBottom, rightMargin, caraHeaderBottom, thinBorderPaint)
        drawTextCentered(canvas, "Cara mengatasi kerusakan :", leftMargin, rightMargin, 860f + 26f, boldTextPaint)

        // Left checklist (3 items), Right description
        val caraColMid = 550f
        canvas.drawLine(caraColMid, caraHeaderBottom, caraColMid, caraBottom, borderPaint)

        val cRowH = (caraBottom - caraHeaderBottom) / 3f
        val caraItems = listOf(
            Pair("1.Ganti Part Baru", report.caraGantiPartBaru),
            Pair("2.Pemasangan atau Penyetelan Ulang", report.caraPenyetelanUlang),
            Pair("3.Modifikasi", report.caraModifikasi)
        )

        for (i in 0 until 3) {
            val rY = caraHeaderBottom + i * cRowH
            canvas.drawLine(leftMargin, rY + cRowH, caraColMid, rY + cRowH, thinBorderPaint)
            canvas.drawLine(cbX - 10f, rY, cbX - 10f, rY + cRowH, thinBorderPaint)

            drawTextCell(canvas, caraItems[i].first, leftMargin + 12f, rY + 26f, textPaint)
            drawCheckboxWithTickCross(canvas, cbX + 8f, rY + 6f, 22f, caraItems[i].second)
        }
        canvas.drawLine(cbX - 10f, caraHeaderBottom, cbX - 10f, caraBottom, thinBorderPaint)

        // Right side: caraDeskripsi (e.g. "Ganti ban stip")
        drawTextCentered(canvas, report.caraDeskripsi, caraColMid, rightMargin, caraHeaderBottom + 55f, boldTextPaint)

        // -------------------------------------------------------------
        // SECTION 7: TERTUNDA KARENA & USULAN PELAPOR (Y: 990 to 1150)
        // -------------------------------------------------------------
        val usulanBottom = 1150f
        canvas.drawLine(leftMargin, usulanBottom, rightMargin, usulanBottom, borderPaint)

        val usulanHeaderBottom = 990f + 36f
        canvas.drawLine(leftMargin, usulanHeaderBottom, rightMargin, usulanHeaderBottom, thinBorderPaint)

        val halfMidX = leftMargin + docWidth * 0.45f
        canvas.drawLine(halfMidX, 990f, halfMidX, usulanBottom, borderPaint)

        drawTextCentered(canvas, "Tertunda Karena", leftMargin, halfMidX, 990f + 26f, boldTextPaint)
        drawTextCentered(canvas, "Usulan Pelapor", halfMidX, rightMargin, 990f + 26f, boldTextPaint)

        if (report.tertundaKarena.isNotBlank()) {
            drawWrappedText(canvas, report.tertundaKarena, leftMargin + 16f, usulanHeaderBottom + 30f, halfMidX - leftMargin - 32f, textPaint, 26f)
        }
        if (report.usulanPelapor.isNotBlank()) {
            drawWrappedText(canvas, report.usulanPelapor, halfMidX + 16f, usulanHeaderBottom + 30f, rightMargin - halfMidX - 32f, textPaint, 26f)
        }

        // -------------------------------------------------------------
        // SECTION 8: PARTS YANG HARUS DIGANTI (Y: 1150 to 1390)
        // -------------------------------------------------------------
        val partsBottom = 1390f
        canvas.drawLine(leftMargin, partsBottom, rightMargin, partsBottom, borderPaint)

        val partsHeader1Bottom = 1150f + 36f
        canvas.drawLine(leftMargin, partsHeader1Bottom, rightMargin, partsHeader1Bottom, thinBorderPaint)
        drawTextCell(canvas, "Parts yang harus diganti  :", leftMargin + 12f, 1150f + 26f, boldTextPaint)

        // Table headers (2 levels)
        val partsHeader2Bottom = partsHeader1Bottom + 45f
        canvas.drawLine(leftMargin, partsHeader2Bottom, rightMargin, partsHeader2Bottom, thinBorderPaint)

        val pColNo = leftMargin + 50f
        val pColPartNo = pColNo + 180f
        val pColPartName = pColPartNo + 320f
        // Remaining width divided for 4 columns: Stock | Order | Modifikasi | Pending
        val subW = (rightMargin - pColPartName) / 4f
        val pColStock = pColPartName + subW
        val pColOrder = pColStock + subW
        val pColModif = pColOrder + subW

        // Vertical lines for headers
        canvas.drawLine(pColNo, partsHeader1Bottom, pColNo, partsBottom, thinBorderPaint)
        canvas.drawLine(pColPartNo, partsHeader1Bottom, pColPartNo, partsBottom, thinBorderPaint)
        canvas.drawLine(pColPartName, partsHeader1Bottom, pColPartName, partsBottom, borderPaint)

        drawTextCentered(canvas, "No", leftMargin, pColNo, partsHeader1Bottom + 30f, boldTextPaint)
        drawTextCentered(canvas, "No Parts", pColNo, pColPartNo, partsHeader1Bottom + 30f, boldTextPaint)
        drawTextCentered(canvas, "Nama Parts", pColPartNo, pColPartName, partsHeader1Bottom + 30f, boldTextPaint)

        // Super header: "Jenis Pengadaan Part" spanning all 4 columns
        drawTextCentered(canvas, "Jenis Pengadaan Part", pColPartName, rightMargin, partsHeader1Bottom + 22f, boldTextPaint)

        // Subheader line separating "Jenis Pengadaan Part" from "Stock | Order | Modifikasi | Pending"
        val partsSubHeaderY = partsHeader1Bottom + 26f
        canvas.drawLine(pColPartName, partsSubHeaderY, rightMargin, partsSubHeaderY, thinBorderPaint)

        canvas.drawLine(pColStock, partsSubHeaderY, pColStock, partsBottom, thinBorderPaint)
        canvas.drawLine(pColOrder, partsSubHeaderY, pColOrder, partsBottom, thinBorderPaint)
        canvas.drawLine(pColModif, partsSubHeaderY, pColModif, partsBottom, thinBorderPaint)

        drawTextCentered(canvas, "Stock", pColPartName, pColStock, partsHeader2Bottom - 6f, textPaint)
        drawTextCentered(canvas, "Order", pColStock, pColOrder, partsHeader2Bottom - 6f, textPaint)
        drawTextCentered(canvas, "Modifikasi", pColOrder, pColModif, partsHeader2Bottom - 6f, textPaint)
        drawTextCentered(canvas, "Pending", pColModif, rightMargin, partsHeader2Bottom - 6f, textPaint)

        // 5 Data Rows
        val partsList = ReportRepository.jsonToParts(report.partsJson)
        val pRowHeight = (partsBottom - partsHeader2Bottom) / 5f

        for (i in 0 until 5) {
            val rowY = partsHeader2Bottom + i * pRowHeight
            canvas.drawLine(leftMargin, rowY + pRowHeight, rightMargin, rowY + pRowHeight, thinBorderPaint)

            val part = partsList.getOrNull(i) ?: PartItem(no = i + 1)
            drawTextCentered(canvas, "${i + 1}", leftMargin, pColNo, rowY + 26f, textPaint)
            drawTextCell(canvas, part.noParts, pColNo + 8f, rowY + 26f, textPaint)
            drawTextCell(canvas, part.namaParts, pColPartNo + 8f, rowY + 26f, textPaint)

            // Draw checkmark in appropriate column
            when (part.jenisPengadaan.trim().lowercase()) {
                "stock" -> drawTextCentered(canvas, "✓", pColPartName, pColStock, rowY + 26f, boldTextPaint)
                "order" -> drawTextCentered(canvas, "✓", pColStock, pColOrder, rowY + 26f, boldTextPaint)
                "modifikasi" -> drawTextCentered(canvas, "✓", pColOrder, pColModif, rowY + 26f, boldTextPaint)
                "pending" -> drawTextCentered(canvas, "✓", pColModif, rightMargin, rowY + 26f, boldTextPaint)
            }
        }

        // -------------------------------------------------------------
        // SECTION 9: TANDA TANGAN & PENGESAHAN (Y: 1390 to 1716)
        // -------------------------------------------------------------
        val signHeaderBottom = 1390f + 36f
        canvas.drawLine(leftMargin, signHeaderBottom, rightMargin, signHeaderBottom, thinBorderPaint)

        val signColMid = leftMargin + docWidth * 0.65f
        canvas.drawLine(signColMid, 1390f, signColMid, bottomMargin, borderPaint)

        // Headers
        drawTextCentered(canvas, "Mengetahui,", leftMargin, signColMid, 1390f + 26f, boldTextPaint)
        drawTextCentered(canvas, "Dilaporkan Oleh:", signColMid, rightMargin, 1390f + 26f, boldTextPaint)

        // Mengetahui Column (Split into 2 signatories)
        val menW = (signColMid - leftMargin) / 2f
        val men1X = leftMargin
        val men2X = men1X + menW

        val dottedLineY = bottomMargin - 45f

        // Dotted sign line 1
        val line1Start = men1X + 40f
        val line1End = men1X + menW - 40f
        drawDottedLineWithParentheses(canvas, line1Start, line1End, dottedLineY, textPaint)
        if (report.mengetahui1Nama.isNotBlank()) {
            drawTextCentered(canvas, report.mengetahui1Nama, line1Start, line1End, dottedLineY - 10f, textPaint)
        }
        report.mengetahui1SignaturePath?.let { path ->
            drawSignatureBitmap(canvas, path, line1Start + 10f, dottedLineY - 140f, line1End - line1Start - 20f, 130f)
        }

        // Dotted sign line 2
        val line2Start = men2X + 40f
        val line2End = men2X + menW - 40f
        drawDottedLineWithParentheses(canvas, line2Start, line2End, dottedLineY, textPaint)
        if (report.mengetahui2Nama.isNotBlank()) {
            drawTextCentered(canvas, report.mengetahui2Nama, line2Start, line2End, dottedLineY - 10f, textPaint)
        }
        report.mengetahui2SignaturePath?.let { path ->
            drawSignatureBitmap(canvas, path, line2Start + 10f, dottedLineY - 140f, line2End - line2Start - 20f, 130f)
        }

        // Dilaporkan Oleh Column (Right)
        val pelRow1 = signHeaderBottom + 32f
        val pelRow2 = pelRow1 + 32f
        drawTextCell(canvas, "Nama     :  ${report.pelaporNama}", signColMid + 16f, pelRow1, boldTextPaint)
        drawTextCell(canvas, "Jabatan  :  ${report.pelaporJabatan}", signColMid + 16f, pelRow2, boldTextPaint)

        // Dotted sign line for Dilaporkan Oleh
        val pelLineStart = signColMid + 80f
        val pelLineEnd = rightMargin - 40f
        drawDottedLineWithParentheses(canvas, pelLineStart, pelLineEnd, dottedLineY, textPaint)

        report.pelaporSignaturePath?.let { path ->
            drawSignatureBitmap(canvas, path, pelLineStart + 15f, dottedLineY - 140f, pelLineEnd - pelLineStart - 30f, 130f)
        }
    }

    private fun drawHeaderLogoAndTitle(
        context: Context,
        canvas: Canvas,
        report: TechnicalReport,
        x: Float,
        y: Float,
        w: Float,
        h: Float,
        titlePaint: Paint,
        boldPaint: Paint
    ) {
        // Draw company logo if provided, or default circle emblem
        val logoSize = 64f
        val logoTop = y + (h - logoSize) / 2f
        var logoDrawn = false

        if (!report.companyLogoUri.isNullOrBlank()) {
            try {
                val uri = Uri.parse(report.companyLogoUri)
                val inputStream = context.contentResolver.openInputStream(uri)
                val bmp = BitmapFactory.decodeStream(inputStream)
                inputStream?.close()
                if (bmp != null) {
                    val dst = RectF(x, logoTop, x + logoSize, logoTop + logoSize)
                    canvas.drawBitmap(bmp, null, dst, null)
                    logoDrawn = true
                }
            } catch (e: Exception) {
                logoDrawn = false
            }
        }

        if (!logoDrawn) {
            // Draw neat corporate emblem (twin circle leaves/sphere)
            val emblemPaint = Paint().apply {
                color = Color.DKGRAY
                isAntiAlias = true
                style = Paint.Style.FILL
            }
            val cx = x + 32f
            val cy = y + h / 2f
            canvas.drawCircle(cx - 10f, cy, 22f, emblemPaint)
            emblemPaint.color = Color.GRAY
            canvas.drawCircle(cx + 10f, cy, 22f, emblemPaint)
            emblemPaint.color = Color.WHITE
            canvas.drawCircle(cx, cy, 14f, emblemPaint)
        }

        val textStartX = x + logoSize + 20f
        // Draw Company Name
        val compPaint = Paint(boldPaint).apply {
            textSize = 28f
            color = Color.BLACK
        }
        canvas.drawText(report.companyName, textStartX, y + h / 2f + 8f, compPaint)

        // Draw Prominent Underlined Title "LAPORAN TEKNIK"
        val title = "LAPORAN TEKNIK"
        val titleW = titlePaint.measureText(title)
        val titleX = x + (w - titleW) / 2f + 80f
        val titleY = y + h / 2f + 10f
        canvas.drawText(title, titleX, titleY, titlePaint)

        // Underline under LAPORAN TEKNIK
        val underPaint = Paint().apply {
            color = Color.BLACK
            strokeWidth = 3f
        }
        canvas.drawLine(titleX, titleY + 6f, titleX + titleW, titleY + 6f, underPaint)
    }

    /**
     * Adaptive Photo Grid Drawer:
     * Guarantees 100% full coverage of the bounding box without blank gaps,
     * fulfilling user's exact specification:
     * - 1 image: fills 100% of bounding box
     * - 2 images: 2 side-by-side columns (50% / 50%) filling the box completely
     * - 3 images: 1 top wide photo (100% W x 50% H) + 2 bottom photos (50% W x 50% H)
     * - 4 images: 2x2 grid filling 100% of the box
     */
    private fun drawAdaptivePhotoGrid(context: Context, canvas: Canvas, photoPaths: List<String>, rect: RectF) {
        if (photoPaths.isEmpty()) {
            // Draw empty placeholder text subtly
            val phPaint = Paint().apply {
                color = Color.LTGRAY
                textSize = 20f
                isAntiAlias = true
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("Belum ada foto kerusakan", rect.centerX(), rect.centerY(), phPaint)
            return
        }

        val count = photoPaths.size
        val rects = mutableListOf<RectF>()

        when {
            count == 1 -> {
                // 1 full photo
                rects.add(RectF(rect.left, rect.top, rect.right, rect.bottom))
            }
            count == 2 -> {
                // 2 side-by-side photos filling the whole box
                val midX = rect.left + rect.width() / 2f
                rects.add(RectF(rect.left, rect.top, midX, rect.bottom))
                rects.add(RectF(midX, rect.top, rect.right, rect.bottom))
            }
            count == 3 -> {
                // 1 top wide photo + 2 bottom side-by-side photos
                val midY = rect.top + rect.height() / 2f
                val midX = rect.left + rect.width() / 2f
                rects.add(RectF(rect.left, rect.top, rect.right, midY))
                rects.add(RectF(rect.left, midY, midX, rect.bottom))
                rects.add(RectF(midX, midY, rect.right, rect.bottom))
            }
            else -> {
                // 4 or more: 2x2 grid filling completely
                val midX = rect.left + rect.width() / 2f
                val midY = rect.top + rect.height() / 2f
                rects.add(RectF(rect.left, rect.top, midX, midY))
                rects.add(RectF(midX, rect.top, rect.right, midY))
                rects.add(RectF(rect.left, midY, midX, rect.bottom))
                rects.add(RectF(midX, midY, rect.right, rect.bottom))
            }
        }

        val dividerPaint = Paint().apply {
            color = Color.BLACK
            strokeWidth = 1.5f
            style = Paint.Style.STROKE
        }

        for (i in 0 until min(photoPaths.size, rects.size)) {
            val path = photoPaths[i]
            val targetRect = rects[i]
            val bmp = loadSampledBitmap(context, path, targetRect.width().toInt(), targetRect.height().toInt())
            if (bmp != null) {
                drawCenterCropBitmap(canvas, bmp, targetRect)
            }
            // Draw border around each photo segment
            canvas.drawRect(targetRect, dividerPaint)
        }
    }

    /**
     * CenterCrop image drawing: fills the entire target rectangle without letterboxing or empty space
     */
    private fun drawCenterCropBitmap(canvas: Canvas, bitmap: Bitmap, target: RectF) {
        val srcW = bitmap.width.toFloat()
        val srcH = bitmap.height.toFloat()
        val dstW = target.width()
        val dstH = target.height()

        val srcAspect = srcW / srcH
        val dstAspect = dstW / dstH

        val srcRect: Rect
        if (srcAspect > dstAspect) {
            // Source is wider than target: crop left & right
            val cropW = (srcH * dstAspect).toInt()
            val startX = ((srcW - cropW) / 2f).toInt()
            srcRect = Rect(startX, 0, startX + cropW, srcH.toInt())
        } else {
            // Source is taller than target: crop top & bottom
            val cropH = (srcW / dstAspect).toInt()
            val startY = ((srcH - cropH) / 2f).toInt()
            srcRect = Rect(0, startY, srcW.toInt(), startY + cropH)
        }

        canvas.drawBitmap(bitmap, srcRect, target, null)
    }

    private fun loadSampledBitmap(context: Context, pathOrUri: String, reqW: Int, reqH: Int): Bitmap? {
        return try {
            val uri = Uri.parse(pathOrUri)
            val inputStream = if (uri.scheme == "content" || uri.scheme == "file") {
                context.contentResolver.openInputStream(uri)
            } else {
                File(pathOrUri).inputStream()
            }

            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            BitmapFactory.decodeStream(inputStream, null, options)
            inputStream?.close()

            options.inSampleSize = calculateInSampleSize(options, max(100, reqW), max(100, reqH))
            options.inJustDecodeBounds = false

            val stream2 = if (uri.scheme == "content" || uri.scheme == "file") {
                context.contentResolver.openInputStream(uri)
            } else {
                File(pathOrUri).inputStream()
            }
            val bmp = BitmapFactory.decodeStream(stream2, null, options)
            stream2?.close()
            bmp
        } catch (e: Exception) {
            null
        }
    }

    private fun calculateInSampleSize(options: BitmapFactory.Options, reqWidth: Int, reqHeight: Int): Int {
        val height = options.outHeight
        val width = options.outWidth
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight = height / 2
            val halfWidth = width / 2
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    private fun drawSignatureBitmap(canvas: Canvas, pathOrUri: String, x: Float, y: Float, w: Float, h: Float) {
        try {
            val file = File(pathOrUri)
            val bmp = if (file.exists()) {
                BitmapFactory.decodeFile(file.absolutePath)
            } else {
                null
            }
            if (bmp != null) {
                val dst = RectF(x, y, x + w, y + h)
                val paint = Paint().apply { isFilterBitmap = true }
                canvas.drawBitmap(bmp, null, dst, paint)
            }
        } catch (e: Exception) {
            // Ignore
        }
    }

    private fun drawCheckbox(canvas: Canvas, x: Float, y: Float, size: Float, checked: Boolean) {
        val boxPaint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 1.8f
            isAntiAlias = true
        }
        canvas.drawRect(x, y, x + size, y + size, boxPaint)
        if (checked) {
            val checkPaint = Paint().apply {
                color = Color.BLACK
                isAntiAlias = true
                textSize = size * 0.95f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("✓", x + size / 2f, y + size * 0.85f, checkPaint)
        }
    }

    private fun drawCheckboxWithTickCross(canvas: Canvas, x: Float, y: Float, size: Float, state: Boolean) {
        val boxPaint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 1.8f
            isAntiAlias = true
        }
        canvas.drawRect(x, y, x + size, y + size, boxPaint)
        if (state) {
            val checkPaint = Paint().apply {
                color = Color.BLACK
                isAntiAlias = true
                textSize = size * 0.95f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("✓", x + size / 2f, y + size * 0.85f, checkPaint)
        }
    }

    private fun drawTextCell(canvas: Canvas, text: String, x: Float, y: Float, paint: Paint) {
        canvas.drawText(text, x, y, paint)
    }

    private fun drawTextCentered(canvas: Canvas, text: String, startX: Float, endX: Float, y: Float, paint: Paint) {
        val prevAlign = paint.textAlign
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText(text, startX + (endX - startX) / 2f, y, paint)
        paint.textAlign = prevAlign
    }

    private fun drawDottedLineWithParentheses(canvas: Canvas, startX: Float, endX: Float, y: Float, paint: Paint) {
        canvas.drawText("(..........................................)", startX, y, paint)
    }

    private fun drawWrappedText(canvas: Canvas, text: String, x: Float, startY: Float, maxWidth: Float, paint: Paint, lineSpacing: Float) {
        val words = text.split(" ")
        var currentLine = ""
        var currentY = startY

        for (word in words) {
            val candidate = if (currentLine.isEmpty()) word else "$currentLine $word"
            if (paint.measureText(candidate) <= maxWidth) {
                currentLine = candidate
            } else {
                if (currentLine.isNotEmpty()) {
                    canvas.drawText(currentLine, x, currentY, paint)
                    currentY += lineSpacing
                }
                currentLine = word
            }
        }
        if (currentLine.isNotEmpty()) {
            canvas.drawText(currentLine, x, currentY, paint)
        }
    }
}
