package com.example.data.repository

import androidx.room.withTransaction
import androidx.sqlite.db.SimpleSQLiteQuery
import com.example.data.local.WorkOrderDao
import com.example.data.local.WorkOrderDatabase
import com.example.data.model.FilterCriteria
import com.example.data.model.FleetKpiStats
import com.example.data.model.ImportMode
import com.example.data.model.ImportProgress
import com.example.data.model.SearchTargetColumn
import com.example.data.model.WorkOrderItem
import com.example.data.model.WorkOrderSummary
import com.example.data.parser.CsvStreamParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.InputStream

class WorkOrderRepository(
    private val database: WorkOrderDatabase,
    private val dao: WorkOrderDao
) {

    val distinctTypes: Flow<List<String>> = dao.getDistinctTypes()
    val distinctProductClasses: Flow<List<String>> = dao.getDistinctProductClasses()
    val totalItemCountFlow: Flow<Int> = dao.getItemCountFlow()

    /**
     * Executes stream-based parsing and batch database transaction insertion.
     * Uses withTransaction to commit 1,000 - 5,000 rows per atomic transaction.
     * Supports flexible ImportMode: APPEND (keep current) or REPLACE_ALL (clear then insert).
     */
    suspend fun importCsvStream(
        inputStream: InputStream,
        totalBytesEstimate: Long = 0L,
        chunkSize: Int = 2500,
        mode: ImportMode = ImportMode.APPEND,
        onProgress: suspend (ImportProgress) -> Unit
    ): Long = withContext(Dispatchers.IO) {
        if (mode == ImportMode.REPLACE_ALL) {
            database.withTransaction {
                dao.clearAll()
            }
        }
        val totalInserted = CsvStreamParser.parseStreamInBatches(
            inputStream = inputStream,
            totalBytesEstimate = totalBytesEstimate,
            chunkSize = chunkSize
        ) { batchChunk, progress ->
            database.withTransaction {
                dao.insertBatch(batchChunk)
            }
            onProgress(progress)
        }
        return@withContext totalInserted
    }

    suspend fun importXlsxStream(
        inputStream: InputStream,
        totalBytesEstimate: Long = 0L,
        chunkSize: Int = 2500,
        mode: ImportMode = ImportMode.APPEND,
        onProgress: suspend (ImportProgress) -> Unit
    ): Long = withContext(Dispatchers.IO) {
        if (mode == ImportMode.REPLACE_ALL) {
            database.withTransaction {
                dao.clearAll()
            }
        }
        val totalInserted = com.example.data.parser.XlsxStreamParser.parseXlsxStreamInBatches(
            inputStream = inputStream,
            totalBytesEstimate = totalBytesEstimate,
            chunkSize = chunkSize
        ) { batchChunk, progress ->
            database.withTransaction {
                dao.insertBatch(batchChunk)
            }
            onProgress(progress)
        }
        return@withContext totalInserted
    }

    suspend fun clearAllData() = withContext(Dispatchers.IO) {
        dao.clearAll()
    }

    suspend fun getWorkOrderItems(woName: String): List<WorkOrderItem> = withContext(Dispatchers.IO) {
        dao.getItemsForWorkOrder(woName)
    }

    /**
     * High-speed dynamic query for Grouped Work Orders matching FilterCriteria.
     */
    suspend fun getTotalItemCount(): Int = withContext(Dispatchers.IO) {
        dao.getItemCount()
    }

    suspend fun getGroupedWorkOrders(
        criteria: FilterCriteria,
        limit: Int = 100,
        offset: Int = 0
    ): List<WorkOrderSummary> = withContext(Dispatchers.IO) {
        val (whereClause, args) = buildWhereClause(criteria)
        val sortOrder = if (criteria.sortDateAscending) "ASC" else "DESC"

        val sql = """
            SELECT
                COALESCE(name, '') AS name,
                COALESCE(mobilName, '') AS mobilName,
                COALESCE(trandateFormatted, '') AS trandateFormatted,
                COALESCE(trandateMillis, 0) AS trandateMillis,
                COALESCE(MAX(kmCurrent), 0) AS kmCurrent,
                COALESCE(keluhan, '') AS keluhan,
                COALESCE(noChassis, '') AS noChassis,
                COALESCE(noMesin, '') AS noMesin,
                COUNT(*) AS itemCount,
                COALESCE(SUM(totalPrice), 0.0) AS totalCost,
                SUM(CASE WHEN LOWER(tipe) LIKE '%part%' THEN 1 ELSE 0 END) AS partCount,
                SUM(CASE WHEN LOWER(tipe) LIKE '%jasa%' THEN 1 ELSE 0 END) AS jasaCount,
                COALESCE(MIN(startTime), '') AS startTime,
                COALESCE(MAX(endTime), '') AS endTime
            FROM work_order_items
            $whereClause
            GROUP BY name
            ORDER BY trandateMillis $sortOrder, name $sortOrder
            LIMIT $limit OFFSET $offset
        """.trimIndent()

        val query = SimpleSQLiteQuery(sql, args.toTypedArray())
        dao.getGroupedWorkOrdersRaw(query)
    }

    /**
     * High-speed dynamic query for raw line items (Table View) matching FilterCriteria.
     */
    suspend fun getItemsForTable(
        criteria: FilterCriteria,
        limit: Int = 150,
        offset: Int = 0
    ): List<WorkOrderItem> = withContext(Dispatchers.IO) {
        val (whereClause, args) = buildWhereClause(criteria)
        val sortOrder = if (criteria.sortDateAscending) "ASC" else "DESC"

        val sql = """
            SELECT * FROM work_order_items
            $whereClause
            ORDER BY trandateMillis $sortOrder, id $sortOrder
            LIMIT $limit OFFSET $offset
        """.trimIndent()

        val query = SimpleSQLiteQuery(sql, args.toTypedArray())
        dao.getItemsRaw(query)
    }

    /**
     * Counts filtered items for table pagination calculation.
     */
    suspend fun countFilteredItems(criteria: FilterCriteria): Int = withContext(Dispatchers.IO) {
        val (whereClause, args) = buildWhereClause(criteria)
        val sql = "SELECT COUNT(*) FROM work_order_items $whereClause"
        dao.countFilteredItemsRaw(SimpleSQLiteQuery(sql, args.toTypedArray()))
    }

    /**
     * Computes real-time fleet KPI statistics.
     */
    suspend fun getFleetKpiStats(): FleetKpiStats = withContext(Dispatchers.IO) {
        val totalWo = dao.getDistinctWoCount()
        val totalItems = dao.getItemCount()
        val totalVehicles = dao.getDistinctVehicleCount()
        val totalExp = dao.getTotalExpenditure()
        val partExp = dao.getTotalPartExpenditure()
        val jasaExp = dao.getTotalJasaExpenditure()
        val avgWo = if (totalWo > 0) totalExp / totalWo else 0.0

        FleetKpiStats(
            totalWorkOrders = totalWo,
            totalLineItems = totalItems,
            totalVehicles = totalVehicles,
            totalExpenditure = totalExp,
            totalPartCost = partExp,
            totalJasaCost = jasaExp,
            averageCostPerWo = avgWo
        )
    }

    private fun buildWhereClause(criteria: FilterCriteria): Pair<String, List<Any>> {
        val conditions = mutableListOf<String>()
        val args = mutableListOf<Any>()

        // 1. Dual Keyword Search with different/targeted columns simultaneously
        if (criteria.dualKeyword1.isNotBlank()) {
            appendTargetedColumnCondition(criteria.dualKeyword1, criteria.dualColumn1, conditions, args)
        }
        if (criteria.dualKeyword2.isNotBlank()) {
            appendTargetedColumnCondition(criteria.dualKeyword2, criteria.dualColumn2, conditions, args)
        }

        // 2. Global Search (handles both single phrase and multiple space/comma separated tokens across columns)
        if (criteria.searchQuery.isNotBlank()) {
            val tokens = criteria.searchQuery.trim().split(Regex("[,+]|\\s+")).filter { it.isNotBlank() }
            if (tokens.isNotEmpty()) {
                for (token in tokens) {
                    val q = "%$token%"
                    conditions.add(
                        """(
                            name LIKE ? OR 
                            mobilName LIKE ? OR 
                            keluhan LIKE ? OR 
                            description LIKE ? OR 
                            catatan LIKE ? OR 
                            noChassis LIKE ? OR 
                            noMesin LIKE ? OR 
                            kode LIKE ? OR
                            tipe LIKE ? OR
                            productClass LIKE ?
                        )""".trimIndent()
                    )
                    for (i in 0 until 10) {
                        args.add(q)
                    }
                }
            }
        }

        // 3. Tipe chips multi-select
        if (criteria.selectedTypes.isNotEmpty()) {
            val placeholders = criteria.selectedTypes.joinToString(",") { "?" }
            conditions.add("tipe IN ($placeholders)")
            args.addAll(criteria.selectedTypes)
        }

        // 4. ProductClass chips multi-select
        if (criteria.selectedProductClasses.isNotEmpty()) {
            val placeholders = criteria.selectedProductClasses.joinToString(",") { "?" }
            conditions.add("productClass IN ($placeholders)")
            args.addAll(criteria.selectedProductClasses)
        }

        // 5. Date range filter
        if (criteria.startDateMillis != null) {
            conditions.add("trandateMillis >= ?")
            args.add(criteria.startDateMillis)
        }
        if (criteria.endDateMillis != null) {
            conditions.add("trandateMillis <= ?")
            args.add(criteria.endDateMillis)
        }

        // 6. Specific Column Filters from Advanced Filter Sheet
        if (criteria.specificMobil.isNotBlank()) {
            conditions.add("mobilName LIKE ?")
            args.add("%${criteria.specificMobil.trim()}%")
        }
        if (criteria.specificChassis.isNotBlank()) {
            conditions.add("noChassis LIKE ?")
            args.add("%${criteria.specificChassis.trim()}%")
        }
        if (criteria.specificKeluhan.isNotBlank()) {
            conditions.add("keluhan LIKE ?")
            args.add("%${criteria.specificKeluhan.trim()}%")
        }

        val clause = if (conditions.isEmpty()) "" else "WHERE " + conditions.joinToString(" AND ")
        return Pair(clause, args)
    }

    private fun appendTargetedColumnCondition(
        keyword: String,
        targetColumn: SearchTargetColumn,
        conditions: MutableList<String>,
        args: MutableList<Any>
    ) {
        val trimmed = keyword.trim()
        if (trimmed.isBlank()) return
        val q = "%$trimmed%"
        if (targetColumn == SearchTargetColumn.ALL || targetColumn.dbColumn == null) {
            conditions.add(
                """(
                    name LIKE ? OR 
                    mobilName LIKE ? OR 
                    keluhan LIKE ? OR 
                    description LIKE ? OR 
                    catatan LIKE ? OR 
                    noChassis LIKE ? OR 
                    noMesin LIKE ? OR 
                    kode LIKE ? OR
                    tipe LIKE ? OR
                    productClass LIKE ?
                )""".trimIndent()
            )
            for (i in 0 until 10) {
                args.add(q)
            }
        } else {
            conditions.add("${targetColumn.dbColumn} LIKE ?")
            args.add(q)
        }
    }
}
