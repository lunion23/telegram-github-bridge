package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.model.PaperSizePreset
import com.example.model.PdfRenderSource
import com.example.model.PreviewDisplayMode
import com.example.model.ShippingLabelData
import com.example.pdf.ShippingLabelPdfGenerator
import com.example.pdf.ShippingLabelPdfGenerator.findActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ShippingLabelUiState(
    val labelData: ShippingLabelData = ShippingLabelData.defaultFromReferenceImage(),
    val paperPreset: PaperSizePreset = PaperSizePreset.THERMAL_100X200,
    val renderSource: PdfRenderSource = PdfRenderSource.VECTOR_RECONSTRUCTION,
    val previewDisplayMode: PreviewDisplayMode = PreviewDisplayMode.GENERATED_PDF,
    val previewBitmap: Bitmap? = null,
    val comparisonLabelBitmap: Bitmap? = null,
    val referenceBitmap: Bitmap? = null,
    val capturedDocumentBitmap: Bitmap? = null,
    val isEditorOpen: Boolean = false,
    val isCameraOpen: Boolean = false,
    val isZoomDialogOpen: Boolean = false,
    val isGeneratingPdf: Boolean = false,
    val snackbarMessage: String? = null
)

class ShippingLabelViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(ShippingLabelUiState())
    val uiState: StateFlow<ShippingLabelUiState> = _uiState.asStateFlow()

    private var previewRenderJob: Job? = null

    init {
        viewModelScope.launch {
            val refBitmap = withContext(Dispatchers.IO) {
                ShippingLabelPdfGenerator.loadReferenceBitmap(getApplication())
            }
            _uiState.update { it.copy(referenceBitmap = refBitmap) }
            refreshPreviewBitmap(debounceMs = 0L)
        }
    }

    fun updateLabelData(transform: (ShippingLabelData) -> ShippingLabelData) {
        _uiState.update { state ->
            state.copy(
                labelData = transform(state.labelData),
                renderSource = PdfRenderSource.VECTOR_RECONSTRUCTION
            )
        }
        refreshPreviewBitmap(debounceMs = 120L)
    }

    fun resetToSampleData() {
        val app = getApplication<Application>()
        _uiState.update { state ->
            state.copy(
                labelData = ShippingLabelData.defaultFromReferenceImage(),
                renderSource = PdfRenderSource.VECTOR_RECONSTRUCTION,
                snackbarMessage = app.getString(R.string.msg_data_reset)
            )
        }
        refreshPreviewBitmap(debounceMs = 0L)
    }

    fun selectPaperPreset(preset: PaperSizePreset) {
        _uiState.update { it.copy(paperPreset = preset) }
        refreshPreviewBitmap(debounceMs = 0L)
    }

    fun selectRenderSource(source: PdfRenderSource) {
        if (source == PdfRenderSource.CAPTURED_DOCUMENT && _uiState.value.capturedDocumentBitmap == null) {
            setCameraOpen(true)
            return
        }
        _uiState.update { it.copy(renderSource = source) }
        refreshPreviewBitmap(debounceMs = 0L)
    }

    fun selectPreviewDisplayMode(mode: PreviewDisplayMode) {
        _uiState.update { it.copy(previewDisplayMode = mode) }
    }

    fun setEditorOpen(open: Boolean) {
        _uiState.update { it.copy(isEditorOpen = open) }
        if (!open) {
            refreshPreviewBitmap(debounceMs = 0L)
        }
    }

    fun setCameraOpen(open: Boolean) {
        _uiState.update { it.copy(isCameraOpen = open) }
    }

    fun onDocumentCaptured(bitmap: Bitmap) {
        val app = getApplication<Application>()
        // Default to A4 if user was on default preset and photographed a wider document, or keep current preset
        val aspect = bitmap.width.toFloat() / bitmap.height.toFloat().coerceAtLeast(1f)
        val recommendedPreset = if (aspect > 0.62f && _uiState.value.paperPreset == PaperSizePreset.THERMAL_100X200) {
            PaperSizePreset.A4_ACTUAL_SIZE
        } else {
            _uiState.value.paperPreset
        }

        _uiState.update { state ->
            state.copy(
                capturedDocumentBitmap = bitmap,
                renderSource = PdfRenderSource.CAPTURED_DOCUMENT,
                previewDisplayMode = PreviewDisplayMode.GENERATED_PDF,
                paperPreset = recommendedPreset,
                isCameraOpen = false,
                snackbarMessage = app.getString(R.string.msg_captured_applied)
            )
        }
        refreshPreviewBitmap(debounceMs = 0L)
    }

    fun onCameraError(reason: String) {
        val app = getApplication<Application>()
        _uiState.update {
            it.copy(snackbarMessage = app.getString(R.string.msg_capture_failed, reason))
        }
    }

    fun setZoomDialogOpen(open: Boolean) {
        _uiState.update { it.copy(isZoomDialogOpen = open) }
    }

    fun clearSnackbarMessage() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    private fun refreshPreviewBitmap(debounceMs: Long) {
        previewRenderJob?.cancel()
        previewRenderJob = viewModelScope.launch {
            if (debounceMs > 0L) {
                delay(debounceMs)
            }
            val snapshot = _uiState.value
            val (pageBitmap, label1to2Bitmap) = withContext(Dispatchers.Default) {
                ensureActive()
                val pageBmp = ShippingLabelPdfGenerator.renderPreviewBitmap(
                    data = snapshot.labelData,
                    paperPreset = snapshot.paperPreset,
                    renderSource = snapshot.renderSource,
                    referenceBitmap = snapshot.referenceBitmap,
                    capturedBitmap = snapshot.capturedDocumentBitmap,
                    targetWidthPx = 944
                )
                ensureActive()
                val compareBmp = if (
                    snapshot.paperPreset == PaperSizePreset.THERMAL_100X200 &&
                    snapshot.renderSource == PdfRenderSource.VECTOR_RECONSTRUCTION
                ) {
                    pageBmp
                } else {
                    ShippingLabelPdfGenerator.renderPreviewBitmap(
                        data = snapshot.labelData,
                        paperPreset = PaperSizePreset.THERMAL_100X200,
                        renderSource = PdfRenderSource.VECTOR_RECONSTRUCTION,
                        referenceBitmap = snapshot.referenceBitmap,
                        capturedBitmap = snapshot.capturedDocumentBitmap,
                        targetWidthPx = 629
                    )
                }
                pageBmp to compareBmp
            }
            _uiState.update {
                it.copy(
                    previewBitmap = pageBitmap,
                    comparisonLabelBitmap = label1to2Bitmap
                )
            }
        }
    }

    fun printPdf(activityContext: Context) {
        val state = _uiState.value
        try {
            val sanitizedWaybill = state.labelData.waybillNumber
                .replace(Regex("[^A-Za-z0-9_-]"), "_")
                .take(48)
                .ifBlank { "Resi" }
            val jobName = if (state.renderSource == PdfRenderSource.CAPTURED_DOCUMENT) {
                "Dokumen_Scan"
            } else {
                activityContext.getString(R.string.print_job_name, sanitizedWaybill)
            }
            ShippingLabelPdfGenerator.launchSystemPrint(
                context = activityContext,
                jobName = jobName,
                data = state.labelData,
                paperPreset = state.paperPreset,
                renderSource = state.renderSource,
                referenceBitmap = state.referenceBitmap,
                capturedBitmap = state.capturedDocumentBitmap
            )
        } catch (e: Exception) {
            _uiState.update {
                it.copy(
                    snackbarMessage = activityContext.getString(
                        R.string.msg_print_error,
                        e.localizedMessage ?: "Error"
                    )
                )
            }
        }
    }

    fun savePdfToUri(context: Context, destinationUri: Uri, displayFileName: String) {
        val state = _uiState.value
        _uiState.update { it.copy(isGeneratingPdf = true) }
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val out = context.contentResolver.openOutputStream(destinationUri)
                        ?: throw IllegalStateException("OutputStream null")
                    out.use { stream ->
                        ShippingLabelPdfGenerator.writePdfToStream(
                            outputStream = stream,
                            data = state.labelData,
                            paperPreset = state.paperPreset,
                            renderSource = state.renderSource,
                            referenceBitmap = state.referenceBitmap,
                            capturedBitmap = state.capturedDocumentBitmap
                        )
                    }
                }
            }
            _uiState.update { current ->
                current.copy(
                    isGeneratingPdf = false,
                    snackbarMessage = result.fold(
                        onSuccess = {
                            context.getString(R.string.msg_pdf_saved_success, displayFileName)
                        },
                        onFailure = { err ->
                            context.getString(
                                R.string.msg_pdf_save_error,
                                err.localizedMessage ?: "Error"
                            )
                        }
                    )
                )
            }
        }
    }

    fun sharePdf(activityContext: Context) {
        val state = _uiState.value
        _uiState.update { it.copy(isGeneratingPdf = true) }
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    ShippingLabelPdfGenerator.generateCachePdfFile(
                        context = activityContext,
                        data = state.labelData,
                        paperPreset = state.paperPreset,
                        renderSource = state.renderSource,
                        referenceBitmap = state.referenceBitmap,
                        capturedBitmap = state.capturedDocumentBitmap
                    )
                }
            }
            _uiState.update { it.copy(isGeneratingPdf = false) }
            result.onSuccess { pdfFile ->
                try {
                    val authority = "${activityContext.packageName}.fileprovider"
                    val contentUri = FileProvider.getUriForFile(activityContext, authority, pdfFile)
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/pdf"
                        putExtra(Intent.EXTRA_STREAM, contentUri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    val chooser = Intent.createChooser(
                        shareIntent,
                        activityContext.getString(R.string.share_chooser_title)
                    )
                    val activity = activityContext.findActivity()
                    if (activity != null) {
                        activity.startActivity(chooser)
                    } else {
                        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        activityContext.startActivity(chooser)
                    }
                } catch (e: Exception) {
                    _uiState.update {
                        it.copy(
                            snackbarMessage = activityContext.getString(
                                R.string.msg_share_error,
                                e.localizedMessage ?: "Error"
                            )
                        )
                    }
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        snackbarMessage = activityContext.getString(
                            R.string.msg_share_error,
                            err.localizedMessage ?: "Error"
                        )
                    )
                }
            }
        }
    }
}
