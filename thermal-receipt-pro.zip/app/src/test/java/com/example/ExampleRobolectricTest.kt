package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.ReceiptData
import com.example.util.BarcodeGenerator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Struk Express", appName)
    }

    @Test
    fun `test barcode generation for resi`() {
        val resi = "JD0597328904561"
        val barcodeBitmap = BarcodeGenerator.generateBarcode128(resi)
        assertNotNull(barcodeBitmap)
        assertTrue(barcodeBitmap!!.width > 0)
        assertTrue(barcodeBitmap.height > 0)

        val qrBitmap = BarcodeGenerator.generateQrCode(resi)
        assertNotNull(qrBitmap)
        assertTrue(qrBitmap!!.width > 0)
    }

    @Test
    fun `test receipt formatting`() {
        val receipt = ReceiptData(
            resiCode = "JD0597328904561",
            recipientPhone = "081234563149",
            shippingFee = 7200,
            maskPhone = true
        )
        assertEquals("IDR 7.200", receipt.getFormattedFee())
        assertEquals("*******3149", receipt.getDisplayRecipientPhone())
    }
}
