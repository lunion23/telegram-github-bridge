package com.example.export

import android.content.Context
import android.net.Uri
import com.example.data.model.Note
import com.example.files.LocalFileManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

enum class BulkExportFormat {
    JSON_BACKUP,
    ZIP_ARCHIVE
}

data class BulkImportResult(
    val notes: List<Note>,
    val skippedCount: Int = 0
)

object BulkTransferManager {

    private const val BACKUP_APP_NAME = "CloudPad"
    private const val BACKUP_FORMAT_VERSION = 1
    private const val ZIP_MANIFEST_NAME = "cloudpad_backup.json"
    private const val MAX_ARCHIVE_BYTES = 15_000_000L
    private const val MAX_SINGLE_NOTE_BYTES = 900_000

    private val VALID_ID_REGEX = Regex("^[a-zA-Z0-9_\\-]+$")

    fun getDefaultExportFileName(format: BulkExportFormat): String {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return when (format) {
            BulkExportFormat.JSON_BACKUP -> "cloudpad_backup_$stamp.json"
            BulkExportFormat.ZIP_ARCHIVE -> "cloudpad_notes_$stamp.zip"
        }
    }

    fun getMimeType(format: BulkExportFormat): String {
        return when (format) {
            BulkExportFormat.JSON_BACKUP -> "application/json"
            BulkExportFormat.ZIP_ARCHIVE -> "application/zip"
        }
    }

    suspend fun exportAllNotesToUri(
        context: Context,
        notes: List<Note>,
        uri: Uri,
        format: BulkExportFormat
    ): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val outputStream = context.contentResolver.openOutputStream(uri, "wt")
                ?: context.contentResolver.openOutputStream(uri)
                ?: return@withContext Result.failure(
                    IllegalStateException("Tidak dapat membuka file tujuan untuk menulis.")
                )

            outputStream.use { stream ->
                when (format) {
                    BulkExportFormat.JSON_BACKUP -> {
                        val json = serializeNotesToBackupJson(notes)
                        stream.write(json.toByteArray(Charsets.UTF_8))
                    }
                    BulkExportFormat.ZIP_ARCHIVE -> {
                        writeNotesToZipStream(notes, stream)
                    }
                }
                stream.flush()
            }
            Result.success(notes.size)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun importNotesFromUri(context: Context, uri: Uri): Result<BulkImportResult> =
        withContext(Dispatchers.IO) {
            try {
                val fileName = LocalFileManager.resolveFileName(context, uri)
                val inputStream = context.contentResolver.openInputStream(uri)
                    ?: return@withContext Result.failure(
                        IllegalStateException("Tidak dapat membaca file yang dipilih.")
                    )

                val bytes = inputStream.use { readLimitedBytes(it, MAX_ARCHIVE_BYTES) }
                    ?: return@withContext Result.failure(
                        IllegalArgumentException("Ukuran file terlalu besar (maksimal 15 MB).")
                    )

                if (isZipBytes(bytes) || fileName.lowercase(Locale.ROOT).endsWith(".zip")) {
                    val zipResult = readNotesFromZipBytes(bytes)
                    return@withContext if (zipResult.notes.isEmpty() && zipResult.skippedCount == 0) {
                        Result.failure(IllegalArgumentException("Arsip ZIP kosong atau tidak berisi file teks."))
                    } else {
                        Result.success(zipResult)
                    }
                }

                // Check for binary NUL bytes
                val sampleSize = minOf(bytes.size, 4096)
                for (i in 0 until sampleSize) {
                    if (bytes[i].toInt() == 0) {
                        return@withContext Result.failure(
                            IllegalArgumentException("File biner tidak didukung untuk impor catatan.")
                        )
                    }
                }

                val textContent = bytes.toString(Charsets.UTF_8)
                val (_, ext) = LocalFileManager.splitFileName(fileName)

                if (ext == "json" || textContent.trimStart().startsWith("{") || textContent.trimStart().startsWith("[")) {
                    val parsedNotes = tryParseNotesFromJson(textContent)
                    if (parsedNotes != null && parsedNotes.isNotEmpty()) {
                        return@withContext Result.success(BulkImportResult(notes = parsedNotes))
                    }
                }

                // Fallback: single local text/code file
                val opened = LocalFileManager.readNoteFromUri(context, uri).getOrThrow()
                Result.success(BulkImportResult(notes = listOf(sanitizeNote(opened.note))))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun importMultipleUris(context: Context, uris: List<Uri>): Result<BulkImportResult> =
        withContext(Dispatchers.IO) {
            val collectedNotes = mutableListOf<Note>()
            var skipped = 0

            for (uri in uris) {
                val result = importNotesFromUri(context, uri)
                result.onSuccess { res ->
                    collectedNotes.addAll(res.notes)
                    skipped += res.skippedCount
                }.onFailure {
                    skipped++
                }
            }

            if (collectedNotes.isEmpty()) {
                Result.failure(IllegalArgumentException("Tidak ada catatan valid yang berhasil diimpor."))
            } else {
                Result.success(BulkImportResult(notes = collectedNotes, skippedCount = skipped))
            }
        }

    fun serializeNotesToBackupJson(notes: List<Note>, exportedAt: Long = System.currentTimeMillis()): String {
        val sb = StringBuilder()
        sb.append("{\n")
        sb.append("  \"app\": \"").append(escapeJson(BACKUP_APP_NAME)).append("\",\n")
        sb.append("  \"formatVersion\": ").append(BACKUP_FORMAT_VERSION).append(",\n")
        sb.append("  \"exportedAt\": ").append(exportedAt).append(",\n")
        sb.append("  \"noteCount\": ").append(notes.size).append(",\n")
        sb.append("  \"notes\": [")
        if (notes.isNotEmpty()) {
            sb.append("\n")
            notes.forEachIndexed { index, note ->
                sb.append("    {\n")
                sb.append("      \"id\": \"").append(escapeJson(note.id)).append("\",\n")
                sb.append("      \"title\": \"").append(escapeJson(note.title)).append("\",\n")
                sb.append("      \"content\": \"").append(escapeJson(note.content)).append("\",\n")
                sb.append("      \"tags\": [")
                note.tags.forEachIndexed { tagIdx, tag ->
                    sb.append("\"").append(escapeJson(tag)).append("\"")
                    if (tagIdx < note.tags.lastIndex) sb.append(", ")
                }
                sb.append("],\n")
                sb.append("      \"isPinned\": ").append(note.isPinned).append(",\n")
                sb.append("      \"fileExtension\": \"").append(escapeJson(note.fileExtension)).append("\",\n")
                sb.append("      \"createdAt\": ").append(note.createdAt).append(",\n")
                sb.append("      \"updatedAt\": ").append(note.updatedAt).append("\n")
                sb.append("    }")
                if (index < notes.lastIndex) sb.append(",")
                sb.append("\n")
            }
            sb.append("  ")
        }
        sb.append("]\n")
        sb.append("}")
        return sb.toString()
    }

    fun writeNotesToZipStream(notes: List<Note>, outputStream: OutputStream) {
        val zipOut = ZipOutputStream(outputStream)
        val usedNames = mutableSetOf(ZIP_MANIFEST_NAME)

        // 1. Write full metadata manifest so restoring from ZIP preserves tags, pin, IDs
        val manifestBytes = serializeNotesToBackupJson(notes).toByteArray(Charsets.UTF_8)
        zipOut.putNextEntry(ZipEntry(ZIP_MANIFEST_NAME))
        zipOut.write(manifestBytes)
        zipOut.closeEntry()

        // 2. Write each note as a standalone human-readable file
        notes.forEachIndexed { idx, note ->
            val baseName = ExportManager.getDefaultFileName(note, note.fileExtension)
            var candidateName = baseName
            var counter = 1
            while (!usedNames.add(candidateName.lowercase(Locale.ROOT))) {
                val dotIndex = baseName.lastIndexOf('.')
                candidateName = if (dotIndex > 0) {
                    "${baseName.substring(0, dotIndex)}_$counter${baseName.substring(dotIndex)}"
                } else {
                    "${baseName}_${counter}_${idx}"
                }
                counter++
            }

            val contentBytes = note.content.toByteArray(Charsets.UTF_8)
            zipOut.putNextEntry(ZipEntry(candidateName))
            zipOut.write(contentBytes)
            zipOut.closeEntry()
        }
        zipOut.finish()
    }

    fun readNotesFromZipBytes(zipBytes: ByteArray): BulkImportResult {
        val zipIn = ZipInputStream(ByteArrayInputStream(zipBytes))
        var manifestNotes: List<Note>? = null
        val fallbackNotes = mutableListOf<Note>()
        var skipped = 0
        var totalReadBytes = 0L

        zipIn.use { zin ->
            var entry = zin.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) {
                    val entryName = entry.name.substringAfterLast('/')
                    // Skip hidden Mac/system metadata files
                    if (entryName.isBlank() || entryName.startsWith("._") || entry.name.contains("__MACOSX")) {
                        zin.closeEntry()
                        entry = zin.nextEntry
                        continue
                    }

                    val remainingBudget = MAX_ARCHIVE_BYTES - totalReadBytes
                    val entryBytes = readLimitedBytes(zin, minOf(remainingBudget, MAX_ARCHIVE_BYTES))
                    if (entryBytes == null) {
                        skipped++
                        break
                    }
                    totalReadBytes += entryBytes.size

                    if (entryName.equals(ZIP_MANIFEST_NAME, ignoreCase = true)) {
                        val manifestText = entryBytes.toString(Charsets.UTF_8)
                        val parsed = tryParseNotesFromJson(manifestText)
                        if (!parsed.isNullOrEmpty()) {
                            manifestNotes = parsed
                        }
                    } else if (entryBytes.size <= MAX_SINGLE_NOTE_BYTES && !looksBinary(entryBytes)) {
                        val (title, ext) = LocalFileManager.splitFileName(entryName)
                        val content = entryBytes.toString(Charsets.UTF_8)
                        fallbackNotes.add(
                            sanitizeNote(
                                Note(
                                    title = title,
                                    content = content,
                                    tags = listOf("impor", ext),
                                    fileExtension = ext
                                )
                            )
                        )
                    } else {
                        skipped++
                    }
                }
                zin.closeEntry()
                entry = zin.nextEntry
            }
        }

        val finalNotes = manifestNotes ?: fallbackNotes
        return BulkImportResult(notes = finalNotes, skippedCount = if (manifestNotes != null) 0 else skipped)
    }

    fun tryParseNotesFromJson(jsonText: String): List<Note>? {
        return try {
            val parsed = SimpleJsonParser(jsonText).parseValue()
            when (parsed) {
                is Map<*, *> -> {
                    val notesList = parsed["notes"] as? List<*>
                    if (notesList != null) {
                        val items = notesList.mapNotNull { item ->
                            (item as? Map<*, *>)?.let { mapToNote(it) }
                        }
                        items.ifEmpty { emptyList() }
                    } else if (parsed.containsKey("title") && parsed.containsKey("content")) {
                        // Single exported CloudPad JSON note
                        listOf(mapToNote(parsed))
                    } else {
                        null
                    }
                }
                is List<*> -> {
                    val items = parsed.mapNotNull { item ->
                        (item as? Map<*, *>)?.let { mapToNote(it) }
                    }
                    items.ifEmpty { null }
                }
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun mapToNote(map: Map<*, *>): Note {
        val rawId = (map["id"] as? String).orEmpty()
        val title = (map["title"] as? String).orEmpty()
        val content = (map["content"] as? String).orEmpty()
        val tagsRaw = (map["tags"] as? List<*>)?.mapNotNull { it as? String } ?: emptyList()
        val isPinned = (map["isPinned"] as? Boolean) ?: false
        val fileExt = (map["fileExtension"] as? String)?.ifBlank { "txt" } ?: "txt"
        val now = System.currentTimeMillis()
        val createdAt = (map["createdAt"] as? Number)?.toLong() ?: now
        val updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: now

        return sanitizeNote(
            Note(
                id = rawId,
                title = title,
                content = content,
                tags = tagsRaw,
                isPinned = isPinned,
                fileExtension = fileExt,
                createdAt = createdAt,
                updatedAt = updatedAt
            )
        )
    }

    fun sanitizeNote(note: Note): Note {
        val validId = if (note.id.isNotBlank() && note.id.length <= 128 && VALID_ID_REGEX.matches(note.id)) {
            note.id
        } else {
            UUID.randomUUID().toString()
        }
        val safeTitle = note.title.take(200)
        val safeContent = note.content.take(MAX_SINGLE_NOTE_BYTES)
        val safeTags = note.tags
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
            .take(30)
        val safeExt = note.fileExtension
            .trim()
            .removePrefix(".")
            .lowercase(Locale.ROOT)
            .replace("[^a-z0-9]".toRegex(), "")
            .take(32)
            .ifBlank { "txt" }

        return note.copy(
            id = validId,
            title = safeTitle,
            content = safeContent,
            tags = safeTags,
            fileExtension = safeExt
        )
    }

    private fun isZipBytes(bytes: ByteArray): Boolean {
        return bytes.size >= 4 &&
            bytes[0] == 0x50.toByte() &&
            bytes[1] == 0x4B.toByte() &&
            bytes[2] == 0x03.toByte() &&
            bytes[3] == 0x04.toByte()
    }

    private fun looksBinary(bytes: ByteArray): Boolean {
        val sampleSize = minOf(bytes.size, 4096)
        for (i in 0 until sampleSize) {
            if (bytes[i].toInt() == 0) return true
        }
        return false
    }

    private fun readLimitedBytes(input: InputStream, maxBytes: Long): ByteArray? {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var total = 0L
        while (true) {
            val read = input.read(buf)
            if (read == -1) break
            total += read
            if (total > maxBytes) return null
            out.write(buf, 0, read)
        }
        return out.toByteArray()
    }

    private fun escapeJson(value: String): String {
        val sb = StringBuilder(value.length + 16)
        for (ch in value) {
            when (ch) {
                '\\' -> sb.append("\\\\")
                '"' -> sb.append("\\\"")
                '\b' -> sb.append("\\b")
                '\u000C' -> sb.append("\\f")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> {
                    if (ch.code < 0x20) {
                        sb.append(String.format(Locale.US, "\\u%04x", ch.code))
                    } else {
                        sb.append(ch)
                    }
                }
            }
        }
        return sb.toString()
    }
}

private class SimpleJsonParser(private val input: String) {
    private var pos = 0

    fun parseValue(): Any? {
        skipWhitespace()
        if (pos >= input.length) throw IllegalArgumentException("Unexpected end of JSON")
        return when (val ch = input[pos]) {
            '{' -> parseObject()
            '[' -> parseArray()
            '"' -> parseString()
            't', 'f' -> parseBoolean()
            'n' -> parseNull()
            '-', in '0'..'9' -> parseNumber()
            else -> throw IllegalArgumentException("Unexpected char '$ch' at $pos")
        }
    }

    private fun parseObject(): Map<String, Any?> {
        val map = LinkedHashMap<String, Any?>()
        pos++ // '{'
        skipWhitespace()
        if (peek() == '}') {
            pos++
            return map
        }
        while (pos < input.length) {
            skipWhitespace()
            val key = parseString()
            skipWhitespace()
            if (peek() != ':') throw IllegalArgumentException("Expected ':' at $pos")
            pos++
            val value = parseValue()
            map[key] = value
            skipWhitespace()
            when (peek()) {
                ',' -> pos++
                '}' -> {
                    pos++
                    return map
                }
                else -> throw IllegalArgumentException("Expected ',' or '}' at $pos")
            }
        }
        throw IllegalArgumentException("Unterminated JSON object")
    }

    private fun parseArray(): List<Any?> {
        val list = ArrayList<Any?>()
        pos++ // '['
        skipWhitespace()
        if (peek() == ']') {
            pos++
            return list
        }
        while (pos < input.length) {
            val value = parseValue()
            list.add(value)
            skipWhitespace()
            when (peek()) {
                ',' -> pos++
                ']' -> {
                    pos++
                    return list
                }
                else -> throw IllegalArgumentException("Expected ',' or ']' at $pos")
            }
        }
        throw IllegalArgumentException("Unterminated JSON array")
    }

    private fun parseString(): String {
        if (peek() != '"') throw IllegalArgumentException("Expected '\"' at $pos")
        pos++
        val sb = StringBuilder()
        while (pos < input.length) {
            val ch = input[pos++]
            when (ch) {
                '"' -> return sb.toString()
                '\\' -> {
                    if (pos >= input.length) throw IllegalArgumentException("Unterminated escape")
                    when (val esc = input[pos++]) {
                        '"' -> sb.append('"')
                        '\\' -> sb.append('\\')
                        '/' -> sb.append('/')
                        'b' -> sb.append('\b')
                        'f' -> sb.append('\u000C')
                        'n' -> sb.append('\n')
                        'r' -> sb.append('\r')
                        't' -> sb.append('\t')
                        'u' -> {
                            if (pos + 4 > input.length) throw IllegalArgumentException("Invalid unicode escape")
                            val hex = input.substring(pos, pos + 4)
                            sb.append(hex.toInt(16).toChar())
                            pos += 4
                        }
                        else -> sb.append(esc)
                    }
                }
                else -> sb.append(ch)
            }
        }
        throw IllegalArgumentException("Unterminated JSON string")
    }

    private fun parseBoolean(): Boolean {
        return if (input.startsWith("true", pos)) {
            pos += 4
            true
        } else if (input.startsWith("false", pos)) {
            pos += 5
            false
        } else {
            throw IllegalArgumentException("Invalid boolean at $pos")
        }
    }

    private fun parseNull(): Any? {
        if (input.startsWith("null", pos)) {
            pos += 4
            return null
        }
        throw IllegalArgumentException("Invalid null at $pos")
    }

    private fun parseNumber(): Number {
        val start = pos
        if (input[pos] == '-') pos++
        while (pos < input.length && input[pos].isDigit()) pos++
        var isFloat = false
        if (pos < input.length && input[pos] == '.') {
            isFloat = true
            pos++
            while (pos < input.length && input[pos].isDigit()) pos++
        }
        if (pos < input.length && (input[pos] == 'e' || input[pos] == 'E')) {
            isFloat = true
            pos++
            if (pos < input.length && (input[pos] == '+' || input[pos] == '-')) pos++
            while (pos < input.length && input[pos].isDigit()) pos++
        }
        val numStr = input.substring(start, pos)
        return if (isFloat) numStr.toDouble() else numStr.toLong()
    }

    private fun skipWhitespace() {
        while (pos < input.length && input[pos].isWhitespace()) {
            pos++
        }
    }

    private fun peek(): Char? = if (pos < input.length) input[pos] else null
}
