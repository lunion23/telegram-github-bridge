package com.example.data.exporter

import com.example.data.model.ColumnConfigEntity
import com.example.data.model.ColumnType
import com.example.data.model.CsvRowEntity
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets

object ExcelExporter {

    fun export(
        outputStream: OutputStream,
        columns: List<ColumnConfigEntity>,
        rows: List<CsvRowEntity>,
        sheetName: String = "Data Filter"
    ) {
        val writer = OutputStreamWriter(outputStream, StandardCharsets.UTF_8)
        val visibleCols = columns.filter { it.isVisible }.sortedBy { it.displayOrder }

        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        sb.append("<?mso-application progid=\"Excel.Sheet\"?>\n")
        sb.append("<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\"\n")
        sb.append(" xmlns:o=\"urn:schemas-microsoft-com:office:office\"\n")
        sb.append(" xmlns:x=\"urn:schemas-microsoft-com:office:excel\"\n")
        sb.append(" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\"\n")
        sb.append(" xmlns:html=\"http://www.w3.org/TR/REC-html40\">\n")

        sb.append(" <Styles>\n")
        sb.append("  <Style ss:ID=\"Default\" ss:Name=\"Normal\">\n")
        sb.append("   <Alignment ss:Vertical=\"Center\"/>\n")
        sb.append("   <Font ss:FontName=\"Segoe UI\" ss:Size=\"10\" ss:Color=\"#0F172A\"/>\n")
        sb.append("  </Style>\n")

        sb.append("  <Style ss:ID=\"HeaderStyle\">\n")
        sb.append("   <Alignment ss:Horizontal=\"Center\" ss:Vertical=\"Center\" ss:WrapText=\"1\"/>\n")
        sb.append("   <Borders>\n")
        sb.append("    <Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#334155\"/>\n")
        sb.append("    <Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#334155\"/>\n")
        sb.append("   </Borders>\n")
        sb.append("   <Font ss:FontName=\"Segoe UI\" ss:Size=\"10\" ss:Bold=\"1\" ss:Color=\"#FFFFFF\"/>\n")
        sb.append("   <Interior ss:Color=\"#0F172A\" ss:Pattern=\"Solid\"/>\n")
        sb.append("  </Style>\n")

        sb.append("  <Style ss:ID=\"EvenRow\">\n")
        sb.append("   <Interior ss:Color=\"#F8FAFC\" ss:Pattern=\"Solid\"/>\n")
        sb.append("  </Style>\n")

        sb.append("  <Style ss:ID=\"NumberStyle\">\n")
        sb.append("   <Alignment ss:Horizontal=\"Right\" ss:Vertical=\"Center\"/>\n")
        sb.append("   <NumberFormat ss:Format=\"#,##0\"/>\n")
        sb.append("  </Style>\n")

        sb.append("  <Style ss:ID=\"CurrencyStyle\">\n")
        sb.append("   <Alignment ss:Horizontal=\"Right\" ss:Vertical=\"Center\"/>\n")
        sb.append("   <NumberFormat ss:Format=\"&quot;Rp &quot;#,##0\"/>\n")
        sb.append("  </Style>\n")

        sb.append(" </Styles>\n")

        sb.append(" <Worksheet ss:Name=\"").append(escapeXml(sheetName)).append("\">\n")
        sb.append("  <Table ss:ExpandedColumnCount=\"").append(visibleCols.size)
            .append("\" ss:ExpandedRowCount=\"").append(rows.size + 1).append("\">\n")

        for (col in visibleCols) {
            val width = when (col.colIndex) {
                0 -> 110
                1 -> 90
                2 -> 160
                3 -> 110
                4 -> 180
                5 -> 60
                6 -> 120
                7 -> 70
                8 -> 130
                9 -> 100
                else -> 120
            }
            sb.append("   <Column ss:Width=\"").append(width).append("\"/>\n")
        }

        sb.append("   <Row ss:Height=\"24\" ss:StyleID=\"HeaderStyle\">\n")
        for (col in visibleCols) {
            sb.append("    <Cell><Data ss:Type=\"String\">")
                .append(escapeXml(itOrEmpty(col.headerName)))
                .append("</Data></Cell>\n")
        }
        sb.append("   </Row>\n")

        rows.forEachIndexed { index, row ->
            val isEven = index % 2 == 1
            val rowStyle = if (isEven) " ss:StyleID=\"EvenRow\"" else ""
            sb.append("   <Row ss:Height=\"20\"").append(rowStyle).append(">\n")

            for (col in visibleCols) {
                val rawVal = row.getCell(col.colIndex)
                val type = col.columnType

                if (type == ColumnType.NUMBER.name || type == ColumnType.CURRENCY.name) {
                    val cleanNumber = rawVal.replace(".", "").replace(",", ".").replace("Rp", "").trim()
                    val num = cleanNumber.toDoubleOrNull()
                    if (num != null) {
                        val style = if (type == ColumnType.CURRENCY.name) " ss:StyleID=\"CurrencyStyle\"" else " ss:StyleID=\"NumberStyle\""
                        sb.append("    <Cell").append(style).append("><Data ss:Type=\"Number\">")
                            .append(cleanNumber).append("</Data></Cell>\n")
                    } else {
                        sb.append("    <Cell><Data ss:Type=\"String\">")
                            .append(escapeXml(rawVal)).append("</Data></Cell>\n")
                    }
                } else {
                    sb.append("    <Cell><Data ss:Type=\"String\">")
                        .append(escapeXml(rawVal)).append("</Data></Cell>\n")
                }
            }
            sb.append("   </Row>\n")
        }

        sb.append("  </Table>\n")
        sb.append(" </Worksheet>\n")
        sb.append("</Workbook>\n")

        writer.write(sb.toString())
        writer.flush()
    }

    private fun escapeXml(text: String): String {
        return text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }

    private fun itOrEmpty(text: String?): String = text ?: ""
}
