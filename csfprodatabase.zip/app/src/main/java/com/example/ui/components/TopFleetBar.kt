package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.ManageSearch
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material.icons.filled.ViewColumn
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.ViewDisplayMode
import java.text.NumberFormat
import java.util.Locale

/**
 * Header & Kontrol Utama (Top Fleet Bar) - Versi Ringkas & Ramping (Compact Fleet Bar).
 * Dimensi tetap stabil dan TIDAK memanjang saat filter aktif:
 * - Baris 1: Identitas Ringkas ("DataCSV"), Counter Data Baris / Status Filter terintegrasi, dan Tombol Navigasi
 * - Baris 2: Bilah Pencarian Cepat 40dp dengan Tombol "2 Kolom" Terintegrasi
 */
@Composable
fun TopFleetBar(
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    totalRowCount: Int,
    currentViewMode: ViewDisplayMode,
    onToggleViewMode: () -> Unit,
    onOpenImportMenu: () -> Unit,
    onExportClick: () -> Unit,
    onOpenColumnSettings: () -> Unit,
    onOpenAdvancedFilter: () -> Unit,
    onOpenDualSearch: () -> Unit,
    isDualSearchActive: Boolean,
    hasActiveFilters: Boolean,
    onClearAllData: () -> Unit,
    onImportDatabase: () -> Unit = {},
    onExportDatabase: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var moreMenuExpanded by remember { mutableStateOf(false) }

    val formattedCount = remember(totalRowCount) {
        try {
            NumberFormat.getNumberInstance(Locale("id", "ID")).format(totalRowCount)
        } catch (_: Exception) {
            totalRowCount.toString()
        }
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        shadowElevation = 2.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 4.dp)
        ) {
            // ========================================================
            // BARIS 1: IDENTITAS RINGKAS, COUNTER & KONTROL CEPAT
            // Ketinggian terkunci (36dp) agar tidak melar/memanjang saat filter aktif
            // ========================================================
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(36.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Kiri: Logo + Judul Ringkas + Counter Badge Terintegrasi
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .clip(RoundedCornerShape(7.dp))
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.DirectionsCar,
                            contentDescription = "Fleet Icon",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(7.dp))

                    Text(
                        text = "DataCSV",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    // Counter Data Pill Ringkas (Lebar stabil & tidak berubah-ubah saat filter aktif)
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (hasActiveFilters)
                            MaterialTheme.colorScheme.secondaryContainer
                        else if (totalRowCount > 0)
                            MaterialTheme.colorScheme.primaryContainer
                        else
                            MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.testTag("counter_data_badge")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(5.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (hasActiveFilters) Color(0xFFE65100)
                                        else if (totalRowCount > 0) Color(0xFF2E7D32)
                                        else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                    )
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "$formattedCount Baris",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (hasActiveFilters)
                                    MaterialTheme.colorScheme.onSecondaryContainer
                                else if (totalRowCount > 0)
                                    MaterialTheme.colorScheme.onPrimaryContainer
                                else
                                    MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(4.dp))

                // Kanan: Tombol Aksi Ramping & Efisien
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    // 1. Tombol Import CSV / Excel
                    IconButton(
                        onClick = onOpenImportMenu,
                        modifier = Modifier
                            .size(34.dp)
                            .testTag("import_csv_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FileUpload,
                            contentDescription = "Import Data CSV",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(19.dp)
                        )
                    }

                    // 2. Toggle Tampilan (Kartu vs Tabel Grid)
                    IconButton(
                        onClick = onToggleViewMode,
                        modifier = Modifier
                            .size(34.dp)
                            .testTag("toggle_view_mode_button")
                    ) {
                        Icon(
                            imageVector = if (currentViewMode == ViewDisplayMode.CARDS_GROUPED)
                                Icons.Default.TableChart else Icons.Default.ViewAgenda,
                            contentDescription = "Ganti Tampilan",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(19.dp)
                        )
                    }

                    // 3. Filter Kustom dengan Indikator Titik Aktif Terintegrasi (Tanpa BadgedBox yang memanjangkan tinggi)
                    Box(contentAlignment = Alignment.TopEnd) {
                        IconButton(
                            onClick = onOpenAdvancedFilter,
                            modifier = Modifier
                                .size(34.dp)
                                .testTag("advanced_filter_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.FilterList,
                                contentDescription = "Filter Kustom",
                                tint = if (hasActiveFilters) MaterialTheme.colorScheme.secondary
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(19.dp)
                            )
                        }
                        if (hasActiveFilters) {
                            Box(
                                modifier = Modifier
                                    .padding(top = 5.dp, end = 5.dp)
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.secondary)
                            )
                        }
                    }

                    // 4. Menu Navigasi Lainnya
                    Box {
                        IconButton(
                            onClick = { moreMenuExpanded = true },
                            modifier = Modifier
                                .size(34.dp)
                                .testTag("more_options_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "Menu Navigasi Lainnya",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(19.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = moreMenuExpanded,
                            onDismissRequest = { moreMenuExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Menu Import Data CSV / Excel...") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.FileUpload,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                onClick = {
                                    moreMenuExpanded = false
                                    onOpenImportMenu()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Import Database SQLite (.db)...") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Storage,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                onClick = {
                                    moreMenuExpanded = false
                                    onImportDatabase()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Export / Backup Database (.db)") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Storage,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                onClick = {
                                    moreMenuExpanded = false
                                    onExportDatabase()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Export Data Terfilter (CSV)") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.FileDownload,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                onClick = {
                                    moreMenuExpanded = false
                                    onExportClick()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Pencarian 2 Kata Kunci (Beda Kolom)") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.ManageSearch,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                onClick = {
                                    moreMenuExpanded = false
                                    onOpenDualSearch()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Pengaturan Kolom Tabel") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.ViewColumn,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                onClick = {
                                    moreMenuExpanded = false
                                    onOpenColumnSettings()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Kosongkan Semua Data", color = MaterialTheme.colorScheme.error) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.DeleteSweep,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                onClick = {
                                    moreMenuExpanded = false
                                    onClearAllData()
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // ========================================================
            // BARIS 2: BILAH PENCARIAN RAMPING DENGAN TOMBOL 2 KOLOM
            // Ketinggian tetap 40dp
            // ========================================================
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Cari",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Box(modifier = Modifier.weight(1f)) {
                        if (searchQuery.isEmpty()) {
                            Text(
                                text = "Cari multi-kata (contoh: HINO REM)...",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                maxLines = 1
                            )
                        }
                        BasicTextField(
                            value = searchQuery,
                            onValueChange = onSearchQueryChange,
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodyMedium.copy(
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            ),
                            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("global_search_input")
                        )
                    }

                    if (searchQuery.isNotEmpty()) {
                        IconButton(
                            onClick = { onSearchQueryChange("") },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Hapus Pencarian",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                    }

                    // Tombol Ringkas 2 Kolom (Terintegrasi di dalam bar pencarian)
                    Surface(
                        shape = RoundedCornerShape(7.dp),
                        color = if (isDualSearchActive)
                            MaterialTheme.colorScheme.primaryContainer
                        else
                            MaterialTheme.colorScheme.surface,
                        border = BorderStroke(
                            1.dp,
                            if (isDualSearchActive) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outlineVariant
                        ),
                        modifier = Modifier
                            .clip(RoundedCornerShape(7.dp))
                            .clickable { onOpenDualSearch() }
                            .testTag("open_dual_search_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ManageSearch,
                                contentDescription = "Pencarian 2 Kolom",
                                tint = if (isDualSearchActive) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "2 Kolom",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDualSearchActive) MaterialTheme.colorScheme.onPrimaryContainer
                                else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
