package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Entity representing an individual line-item from the Cilegon Work Order dataset.
 * Indexed on key query columns to ensure instantaneous (<1s) lookups even with millions of rows.
 */
@Entity(
    tableName = "work_order_items",
    indices = [
        Index(value = ["name"]),
        Index(value = ["mobilName"]),
        Index(value = ["trandateMillis"]),
        Index(value = ["noChassis"]),
        Index(value = ["tipe"]),
        Index(value = ["productClass"])
    ]
)
data class WorkOrderItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,              // ID Work Order (e.g., WO-CLG-2024-001)
    val mobilName: String,         // Plat / Nama Armada (e.g., B 9451 UXT - Hino 500)
    val trandate: String,          // Original Raw Date String
    val trandateMillis: Long,      // Normalized Timestamp for high-speed range indexing & sorting
    val trandateFormatted: String,   // Normalized standard date string (yyyy-MM-dd)
    val kmCurrent: Long,           // Odometer KM
    val keluhan: String,           // Complaint / Issue
    val tipe: String,              // Tipe (Part, Jasa, Oli, etc.)
    val kode: String,              // Item/Part Code
    val description: String,       // Job/Part description
    val catatan: String,           // Additional notes
    val startTime: String,         // Start Time
    val endTime: String,           // End Time
    val qty: Double,               // Quantity
    val total: Double,             // Total units
    val totalPrice: Double,        // Total price (IDR)
    val productClass: String,      // Product category/class
    val noChassis: String,         // Chassis/VIN number
    val noMesin: String            // Engine number
)
