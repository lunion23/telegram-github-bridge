package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.Note

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey
    val id: String,
    val userId: String,
    val title: String,
    val content: String,
    val tagsCsv: String,
    val isPinned: Boolean,
    val fileExtension: String,
    val createdAt: Long,
    val updatedAt: Long,
    val isSynced: Boolean
) {
    fun toDomain(): Note {
        val tagsList = if (tagsCsv.isBlank()) {
            emptyList()
        } else {
            tagsCsv.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        }
        return Note(
            id = id,
            userId = userId,
            title = title,
            content = content,
            tags = tagsList,
            isPinned = isPinned,
            fileExtension = fileExtension,
            createdAt = createdAt,
            updatedAt = updatedAt,
            isSynced = isSynced
        )
    }

    companion object {
        fun fromDomain(note: Note): NoteEntity {
            return NoteEntity(
                id = note.id,
                userId = note.userId,
                title = note.title,
                content = note.content,
                tagsCsv = note.tags.joinToString(","),
                isPinned = note.isPinned,
                fileExtension = note.fileExtension,
                createdAt = note.createdAt,
                updatedAt = note.updatedAt,
                isSynced = note.isSynced
            )
        }
    }
}
