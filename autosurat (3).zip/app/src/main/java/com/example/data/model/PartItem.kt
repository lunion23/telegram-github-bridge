package com.example.data.model

data class PartItem(
    val no: Int,
    val noParts: String = "",
    val namaParts: String = "",
    val stock: String = "",
    val order: String = "",
    val modifikasi: String = "",
    val pending: String = ""
) {
    companion object {
        fun defaultList(): List<PartItem> {
            return (1..5).map { PartItem(no = it) }
        }
    }
}
