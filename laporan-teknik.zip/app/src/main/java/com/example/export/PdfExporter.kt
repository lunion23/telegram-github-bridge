package com.example.export

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.content.FileProvider
import com.example.R
import com.example.data.model.TechnicalReport
import com.example.data.model.WarrantyStatus
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object PdfExporter {

    private const val PAGE_WIDTH = 595 // A4 standard width in points
    private const val PAGE_HEIGHT = 842 // A4 standard height in points
    private const val MARGIN = 20f

    fun generatePdf(context: Context, report: TechnicalReport, templateOption: Int = report.activeTemplate): File {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        if (templateOption == 2) {
            drawDocumentHibaGroup(context, canvas, report)
        } else {
            drawDocumentStandard(canvas, report)
        }

        pdfDocument.finishPage(page)

        val outputDir = File(context.cacheDir, "reports")
        if (!outputDir.exists()) outputDir.mkdirs()

        val prefix = if (templateOption == 2) "Laporan_Teknik_HibaGroup" else "Laporan_Teknik_Standar"
        val cleanReportNo = report.reportNumber.replace("/", "_").replace(" ", "_").ifBlank { "report_${System.currentTimeMillis()}" }
        val pdfFile = File(outputDir, "${prefix}_${cleanReportNo}.pdf")
        val outputStream = FileOutputStream(pdfFile)
        pdfDocument.writeTo(outputStream)
        outputStream.flush()
        outputStream.close()
        pdfDocument.close()

        return pdfFile
    }

    fun generatePdfOption1(context: Context, report: TechnicalReport): File {
        return generatePdf(context, report, templateOption = 1)
    }

    fun generatePdfOption2(context: Context, report: TechnicalReport): File {
        return generatePdf(context, report, templateOption = 2)
    }

    fun printReport(context: Context, report: TechnicalReport, templateOption: Int = report.activeTemplate) {
        val file = generatePdf(context, report, templateOption)
        val jobName = if (templateOption == 2) "Laporan_Teknik_Opsi2_HibaGroup" else "Laporan_Teknik_Opsi1_Standar"
        printPdf(context, file, jobName)
    }

    fun printReportOption1(context: Context, report: TechnicalReport) {
        printReport(context, report, templateOption = 1)
    }

    fun printReportOption2(context: Context, report: TechnicalReport) {
        printReport(context, report, templateOption = 2)
    }

    // =========================================================================
    // DESAIN 2: FORMAT HIBA GROUP (SESUAI GAMBAR)
    // =========================================================================
    private fun drawDocumentHibaGroup(context: Context, canvas: Canvas, report: TechnicalReport) {
        // Background
        val bgPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, PAGE_WIDTH.toFloat(), PAGE_HEIGHT.toFloat(), bgPaint)

        // Double Outer Border
        val borderThick = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 1.8f
        }
        val borderThin = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
        }
        canvas.drawRect(MARGIN - 4, MARGIN - 4, PAGE_WIDTH - MARGIN + 4, PAGE_HEIGHT - MARGIN + 4, borderThick)
        canvas.drawRect(MARGIN - 1.5f, MARGIN - 1.5f, PAGE_WIDTH - MARGIN + 1.5f, PAGE_HEIGHT - MARGIN + 1.5f, borderThin)

        val contentWidth = PAGE_WIDTH - (MARGIN * 2)
        var curY = MARGIN

        val fontText = Paint().apply {
            color = Color.BLACK
            textSize = 8.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }
        val fontBold = Paint().apply {
            color = Color.BLACK
            textSize = 8.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        // -------------------------------------------------------------
        // HEADER ROW: [Logo Hiba Group + LAPORAN TEKNIK] | [No.Laporan, Bengkel, Tanggal Table]
        // -------------------------------------------------------------
        val headerHeight = 38f
        val rightTableWidth = 160f
        val leftHeaderWidth = contentWidth - rightTableWidth

        canvas.drawRect(MARGIN, curY, MARGIN + contentWidth, curY + headerHeight, borderThin)
        canvas.drawLine(MARGIN + leftHeaderWidth, curY, MARGIN + leftHeaderWidth, curY + headerHeight, borderThin)

        // Draw Hiba Group Logo (Oval symbol + text)
        val logoPaint = Paint().apply {
            color = Color.rgb(100, 116, 139)
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val logoCenterY = curY + 18f
        canvas.drawCircle(MARGIN + 16f, logoCenterY, 8f, logoPaint)
        val logoHolePaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawCircle(MARGIN + 16f, logoCenterY, 3.5f, logoHolePaint)

        val hibaPaint = Paint().apply {
            color = Color.rgb(51, 65, 85)
            textSize = 12f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText(report.companyName.ifBlank { "Hiba Group" }, MARGIN + 30f, logoCenterY + 4f, hibaPaint)

        // LAPORAN TEKNIK Title (Bold & Underlined)
        val titlePaint = Paint().apply {
            color = Color.BLACK
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isUnderlineText = true
        }
        canvas.drawText(report.title.ifBlank { "LAPORAN TEKNIK" }, MARGIN + 115f, logoCenterY + 5f, titlePaint)

        // Right side meta table (3 rows)
        val rowH = headerHeight / 3f
        canvas.drawLine(MARGIN + leftHeaderWidth, curY + rowH, MARGIN + contentWidth, curY + rowH, borderThin)
        canvas.drawLine(MARGIN + leftHeaderWidth, curY + (rowH * 2), MARGIN + contentWidth, curY + (rowH * 2), borderThin)
        val colDivX = MARGIN + leftHeaderWidth + 65f
        canvas.drawLine(colDivX, curY, colDivX, curY + headerHeight, borderThin)

        canvas.drawText("No.Laporan", MARGIN + leftHeaderWidth + 4f, curY + 9f, fontBold)
        canvas.drawText(report.reportNumber.ifBlank { "1/LT-CLG/III/2026" }, colDivX + 4f, curY + 9f, fontText)

        canvas.drawText("Bengkel", MARGIN + leftHeaderWidth + 4f, curY + rowH + 9f, fontBold)
        canvas.drawText(report.workshop.ifBlank { "Cilegon" }, colDivX + 4f, curY + rowH + 9f, fontText)

        canvas.drawText("Tanggal", MARGIN + leftHeaderWidth + 4f, curY + (rowH * 2) + 9f, fontBold)
        canvas.drawText(report.reportDate.ifBlank { "12-Mar-26" }, colDivX + 4f, curY + (rowH * 2) + 9f, fontText)

        curY += headerHeight

        // -------------------------------------------------------------
        // INFORMASI UNIT / ALAT TABLE (3 rows)
        // -------------------------------------------------------------
        val unitRowH = 14f
        val unitTotalH = unitRowH * 3
        canvas.drawRect(MARGIN, curY, MARGIN + contentWidth, curY + unitTotalH, borderThin)
        canvas.drawLine(MARGIN, curY + unitRowH, MARGIN + contentWidth, curY + unitRowH, borderThin)
        canvas.drawLine(MARGIN, curY + (unitRowH * 2), MARGIN + contentWidth, curY + (unitRowH * 2), borderThin)

        // Row 1: Pabrik Pembuat | HINO | Tipe | DUTRO
        val col1W = 85f
        val col2W = 160f
        val col3W = 85f
        val x1 = MARGIN + col1W
        val x2 = x1 + col2W
        val x3 = x2 + col3W

        canvas.drawLine(x1, curY, x1, curY + unitTotalH, borderThin)
        canvas.drawLine(x2, curY, x2, curY + unitTotalH, borderThin)
        canvas.drawLine(x3, curY, x3, curY + unitTotalH, borderThin)

        canvas.drawText("Pabrik Pembuat", MARGIN + 4f, curY + 10f, fontBold)
        canvas.drawText(report.manufacturer.ifBlank { "HINO" }, x1 + 4f, curY + 10f, fontBold)
        canvas.drawText("Tipe", x2 + 4f, curY + 10f, fontBold)
        canvas.drawText(report.unitType.ifBlank { "DUTRO" }, x3 + 4f, curY + 10f, fontBold)

        // Row 2: Model | W04DTPJ-53447 | Kode | D127 | Nama Alat | Ban
        val r2Y = curY + unitRowH
        val subColX1 = x2 - 50f
        val subColX2 = x3 + 55f
        canvas.drawLine(x2 - 50f, r2Y, x2 - 50f, r2Y + unitRowH, borderThin)
        canvas.drawLine(x3 + 55f, r2Y, x3 + 55f, r2Y + unitRowH, borderThin)

        canvas.drawText("Model", MARGIN + 4f, r2Y + 10f, fontBold)
        canvas.drawText(report.model.ifBlank { "W04DTPJ-53447" }, x1 + 4f, r2Y + 10f, fontBold)
        canvas.drawText("Kode", x2 + 4f, r2Y + 10f, fontBold)
        canvas.drawText(report.unitCode.ifBlank { "D127" }, x3 + 4f, r2Y + 10f, fontBold)
        canvas.drawText("Nama Alat", x3 + 59f, r2Y + 10f, fontBold)
        val nameAlatValX = x3 + 55f + 65f
        canvas.drawLine(nameAlatValX, r2Y, nameAlatValX, r2Y + unitRowH, borderThin)
        canvas.drawText(report.toolName.ifBlank { "Ban" }, nameAlatValX + 4f, r2Y + 10f, fontBold)

        // Row 3: Tanggal Rusak | 12-Mar-26 | Km / Hm | 598916 | Komponen | Underbody
        val r3Y = curY + (unitRowH * 2)
        canvas.drawLine(x3 + 55f, r3Y, x3 + 55f, r3Y + unitRowH, borderThin)
        canvas.drawLine(nameAlatValX, r3Y, nameAlatValX, r3Y + unitRowH, borderThin)

        canvas.drawText("Tanggal Rusak", MARGIN + 4f, r3Y + 10f, fontBold)
        canvas.drawText(report.damageDate.ifBlank { "12-Mar-26" }, x1 + 4f, r3Y + 10f, fontBold)
        canvas.drawText("Km / Hm", x2 + 4f, r3Y + 10f, fontBold)
        canvas.drawText(report.mileageKmHm.ifBlank { "598916" }, x3 + 4f, r3Y + 10f, fontBold)
        canvas.drawText("Komponen", x3 + 59f, r3Y + 10f, fontBold)
        canvas.drawText(report.component.ifBlank { "Underbody" }, nameAlatValX + 4f, r3Y + 10f, fontBold)

        curY += unitTotalH

        // -------------------------------------------------------------
        // SECTION: URAIAN KERUSAKAN & FOTO KERUSAKAN
        // -------------------------------------------------------------
        val photoColWidth = 195f
        val uraianColWidth = contentWidth - photoColWidth
        val photoSectionHeight = 185f

        // Section Title Bar
        val secTitleH = 15f
        canvas.drawRect(MARGIN, curY, MARGIN + contentWidth, curY + secTitleH, borderThin)
        canvas.drawLine(MARGIN + uraianColWidth, curY, MARGIN + uraianColWidth, curY + secTitleH, borderThin)

        canvas.drawText("Uraian Kerusakan", MARGIN + 4f, curY + 11f, fontBold)
        val isMasaGaransi = report.warrantyStatus == WarrantyStatus.IN_WARRANTY
        val isSetelahGaransi = report.warrantyStatus == WarrantyStatus.AFTER_WARRANTY

        drawSquareCheckbox(canvas, MARGIN + 105f, curY + 2f, isMasaGaransi)
        canvas.drawText("Masa Garansi", MARGIN + 118f, curY + 11f, fontBold)

        drawSquareCheckbox(canvas, MARGIN + 195f, curY + 2f, isSetelahGaransi)
        canvas.drawText("Setelah Masa Garansi", MARGIN + 208f, curY + 11f, fontBold)

        canvas.drawText("Foto Kerusakan :", MARGIN + uraianColWidth + 6f, curY + 11f, fontBold)
        curY += secTitleH

        // Body: Left Content vs Right Photo
        canvas.drawRect(MARGIN, curY, MARGIN + contentWidth, curY + photoSectionHeight, borderThin)
        canvas.drawLine(MARGIN + uraianColWidth, curY, MARGIN + uraianColWidth, curY + photoSectionHeight, borderThin)

        // Draw Left Content Lines
        var leftY = curY + 11f
        canvas.drawText("Tanggal   : ${report.reportDate.ifBlank { "12 Maret 2026" }}", MARGIN + 4f, leftY, fontBold)
        canvas.drawText("Status : ${report.storingStatus.ifBlank { "Storing" }}", MARGIN + 160f, leftY, fontBold)
        leftY += 13f

        canvas.drawText("Kerusakan : ${report.damageDetail.ifBlank { "Ban kempes" }}", MARGIN + 4f, leftY, fontBold)
        canvas.drawText("Lokasi : ${report.location.ifBlank { "Tol tangerang - merak" }}", MARGIN + 160f, leftY, fontBold)
        leftY += 15f

        canvas.drawText("Analisa    :", MARGIN + 4f, leftY, fontBold)
        leftY += 12f
        val analysisText = report.analysisNotes.ifBlank {
            "Setelah di lakukan storing oleh team cikupa di temukan ban depan kiri kempes"
        }
        drawWrappedText(canvas, analysisText, MARGIN + 4f, leftY, uraianColWidth - 10f, fontBold, 11f)
        leftY += 28f

        canvas.drawText("Kesimpulan :", MARGIN + 4f, leftY, fontBold)
        if (report.conclusionNotes.isNotBlank()) {
            canvas.drawText(report.conclusionNotes, MARGIN + 70f, leftY, fontText)
        }
        leftY += 16f

        // Table lines in left lower area
        canvas.drawLine(MARGIN, leftY - 4f, MARGIN + uraianColWidth, leftY - 4f, borderThin)
        canvas.drawText("Penggantian terakhir : ${report.lastReplacement.ifBlank { "9-5-2022 (km.415513)" }}", MARGIN + 4f, leftY + 7f, fontBold)
        leftY += 14f
        canvas.drawLine(MARGIN, leftY - 4f, MARGIN + uraianColWidth, leftY - 4f, borderThin)
        canvas.drawText("No. Work Order          : ${report.lastReplacementWo.ifBlank { "KLD1-WO-2205-00381" }}", MARGIN + 4f, leftY + 7f, fontBold)
        leftY += 14f
        canvas.drawLine(MARGIN, leftY - 4f, MARGIN + uraianColWidth, leftY - 4f, borderThin)
        canvas.drawText("Weekly terakhir          : ${report.lastWeeklyCheck.ifBlank { "5-3-2026 (km.598234)" }}", MARGIN + 4f, leftY + 7f, fontBold)
        leftY += 14f
        canvas.drawLine(MARGIN, leftY - 4f, MARGIN + uraianColWidth, leftY - 4f, borderThin)
        canvas.drawText("No. Work Order          : ${report.lastWeeklyCheckWo.ifBlank { "CLG1-WO-2603-00225" }}", MARGIN + 4f, leftY + 7f, fontBold)

        // Draw Right Photo Box
        val photoBitmap = loadReportBitmap(context, report)
        val pBox = RectF(
            MARGIN + uraianColWidth + 6f,
            curY + 6f,
            MARGIN + contentWidth - 6f,
            curY + photoSectionHeight - 6f
        )
        if (photoBitmap != null) {
            canvas.drawBitmap(photoBitmap, null, pBox, null)
        } else {
            // Tampilan polos kosong bersih
            val whitePaint = Paint().apply {
                color = Color.WHITE
                style = Paint.Style.FILL
            }
            canvas.drawRect(pBox, whitePaint)
        }
        canvas.drawRect(pBox, borderThin)

        curY += photoSectionHeight

        // -------------------------------------------------------------
        // SECTION: PENYEBAB KERUSAKAN
        // -------------------------------------------------------------
        val penyebabH = 14f
        canvas.drawRect(MARGIN, curY, MARGIN + contentWidth, curY + penyebabH, borderThin)
        val penyebabDividerX = MARGIN + 215f
        canvas.drawLine(penyebabDividerX, curY, penyebabDividerX, curY + penyebabH, borderThin)

        canvas.drawText("Penyebab Kerusakan :  √ = YA   X = TIDAK", MARGIN + 4f, curY + 10.5f, fontBold)
        canvas.drawText(".......................jika YA, tolong jelaskan!", penyebabDividerX + 6f, curY + 10.5f, fontBold)
        curY += penyebabH

        val causeRows = listOf(
            Triple("1. Pemasangan", report.causeInstallation, report.causeInstallationNotes),
            Triple("2. Kwalitas Parts", report.causeQuality, report.causeQualityNotes),
            Triple("3. Kesalahan Operasional", report.causeOperational, report.causeOperationalNotes),
            Triple("4. Sudah waktunya", report.causeTimeExpired, report.causeTimeExpiredNotes),
            Triple("5. Lain-lain", report.causeOthers, report.causeOthersNotes)
        )

        val causeRowH = 12.5f
        val causeTotalH = causeRowH * 5
        canvas.drawRect(MARGIN, curY, MARGIN + contentWidth, curY + causeTotalH, borderThin)
        canvas.drawLine(penyebabDividerX, curY, penyebabDividerX, curY + causeTotalH, borderThin)

        causeRows.forEachIndexed { i, (label, checked, notes) ->
            val cY = curY + (i * causeRowH)
            if (i > 0) canvas.drawLine(MARGIN, cY, MARGIN + contentWidth, cY, borderThin)
            canvas.drawText(label, MARGIN + 4f, cY + 9.5f, fontBold)
            drawSquareCheckbox(canvas, penyebabDividerX - 25f, cY + 1.5f, checked)
            if (notes.isNotBlank()) {
                canvas.drawText(notes, penyebabDividerX + 6f, cY + 9.5f, fontText)
            }
        }
        curY += causeTotalH

        // -------------------------------------------------------------
        // SECTION: CARA MENGATASI KERUSAKAN
        // -------------------------------------------------------------
        val caraH = 13f
        canvas.drawRect(MARGIN, curY, MARGIN + contentWidth, curY + caraH, borderThin)
        val caraCenterPaint = Paint().apply {
            color = Color.BLACK
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("Cara mengatasi kerusakan :", MARGIN + (contentWidth / 2f), curY + 9.5f, caraCenterPaint)
        curY += caraH

        val caraContentH = 36f
        canvas.drawRect(MARGIN, curY, MARGIN + contentWidth, curY + caraContentH, borderThin)
        val caraDividerX = MARGIN + 215f
        canvas.drawLine(caraDividerX, curY, caraDividerX, curY + caraContentH, borderThin)

        val cRowH = 12f
        canvas.drawLine(MARGIN, curY + cRowH, caraDividerX, curY + cRowH, borderThin)
        canvas.drawLine(MARGIN, curY + (cRowH * 2), caraDividerX, curY + (cRowH * 2), borderThin)

        // Options
        canvas.drawText("1.Ganti Part Baru", MARGIN + 4f, curY + 9f, fontBold)
        drawSquareCheckbox(canvas, caraDividerX - 25f, curY + 1.5f, report.solutionReplacePart)

        canvas.drawText("2.Pemasangan atau Penyetelan Ulang", MARGIN + 4f, curY + cRowH + 9f, fontBold)
        drawSquareCheckbox(canvas, caraDividerX - 25f, curY + cRowH + 1.5f, report.solutionReinstallAdjust)

        canvas.drawText("3.Modifikasi", MARGIN + 4f, curY + (cRowH * 2) + 9f, fontBold)
        drawSquareCheckbox(canvas, caraDividerX - 25f, curY + (cRowH * 2) + 1.5f, report.solutionModification)

        // Right merged text (e.g. Ganti ban stip)
        val noteCara = when {
            report.solutionReinstallAdjustNotes.isNotBlank() -> report.solutionReinstallAdjustNotes
            report.solutionReplacePartNotes.isNotBlank() -> report.solutionReplacePartNotes
            else -> "Ganti ban stip"
        }
        val rightCaraCenterPaint = Paint().apply {
            color = Color.BLACK
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val rightCaraCenterX = caraDividerX + ((MARGIN + contentWidth - caraDividerX) / 2f)
        canvas.drawText(noteCara, rightCaraCenterX, curY + 20f, rightCaraCenterPaint)

        curY += caraContentH

        // -------------------------------------------------------------
        // SECTION: TERTUNDA KARENA & USULAN PELAPOR
        // -------------------------------------------------------------
        val proposalTitleH = 14f
        canvas.drawRect(MARGIN, curY, MARGIN + contentWidth, curY + proposalTitleH, borderThin)
        canvas.drawLine(caraDividerX, curY, caraDividerX, curY + proposalTitleH, borderThin)

        val centerBold = Paint().apply {
            color = Color.BLACK
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("Tertunda Karena", MARGIN + (caraDividerX - MARGIN) / 2f, curY + 10f, centerBold)
        canvas.drawText("Usulan Pelapor", rightCaraCenterX, curY + 10f, centerBold)
        curY += proposalTitleH

        val proposalContentH = 40f
        canvas.drawRect(MARGIN, curY, MARGIN + contentWidth, curY + proposalContentH, borderThin)
        canvas.drawLine(caraDividerX, curY, caraDividerX, curY + proposalContentH, borderThin)

        if (report.pendingReason.isNotBlank()) {
            drawWrappedText(canvas, report.pendingReason, MARGIN + 4f, curY + 12f, (caraDividerX - MARGIN) - 8f, fontText, 10f)
        }

        val proposalText = report.reporterProposal.ifBlank {
            "Segera akan di lakukan program pengecekan atau penggantian terkait part tersebut terhadap RK8J supaya tidak terjadi kejadian serupa"
        }
        drawWrappedTextCenter(canvas, proposalText, rightCaraCenterX, curY + 14f, (contentWidth - 215f) - 16f, fontBold, 11f)

        curY += proposalContentH

        // -------------------------------------------------------------
        // SECTION: PARTS YANG HARUS DIGANTI
        // -------------------------------------------------------------
        val partsTitleH = 13f
        canvas.drawRect(MARGIN, curY, MARGIN + contentWidth, curY + partsTitleH, borderThin)
        canvas.drawText("Parts yang harus diganti :", MARGIN + 4f, curY + 9.5f, fontBold)
        curY += partsTitleH

        // Table Header
        val thH = 14f
        val colNoW = 24f
        val colPartNoW = 90f
        val colPartNameW = 150f
        val colProcurementW = contentWidth - colNoW - colPartNoW - colPartNameW
        val subProcW = colProcurementW / 4f

        canvas.drawRect(MARGIN, curY, MARGIN + contentWidth, curY + (thH * 2), borderThin)
        // Vertical lines for th
        canvas.drawLine(MARGIN + colNoW, curY, MARGIN + colNoW, curY + (thH * 2), borderThin)
        canvas.drawLine(MARGIN + colNoW + colPartNoW, curY, MARGIN + colNoW + colPartNoW, curY + (thH * 2), borderThin)
        val procStartX = MARGIN + colNoW + colPartNoW + colPartNameW
        canvas.drawLine(procStartX, curY, procStartX, curY + (thH * 2), borderThin)

        // Spanning header for Jenis Pengadaan Part
        canvas.drawLine(procStartX, curY + thH, MARGIN + contentWidth, curY + thH, borderThin)
        for (k in 1..3) {
            canvas.drawLine(procStartX + (k * subProcW), curY + thH, procStartX + (k * subProcW), curY + (thH * 2), borderThin)
        }

        canvas.drawText("No", MARGIN + 6f, curY + 18f, fontBold)
        canvas.drawText("No Parts", MARGIN + colNoW + 15f, curY + 18f, fontBold)
        canvas.drawText("Nama Parts", MARGIN + colNoW + colPartNoW + 35f, curY + 18f, fontBold)

        canvas.drawText("Jenis Pengadaan Part", procStartX + (colProcurementW / 2f), curY + 10f, centerBold)
        canvas.drawText("Stock", procStartX + (subProcW * 0.5f), curY + thH + 10f, centerBold)
        canvas.drawText("Order", procStartX + (subProcW * 1.5f), curY + thH + 10f, centerBold)
        canvas.drawText("Modifikasi", procStartX + (subProcW * 2.5f), curY + thH + 10f, centerBold)
        canvas.drawText("Pending", procStartX + (subProcW * 3.5f), curY + thH + 10f, centerBold)

        curY += (thH * 2)

        // 5 Parts Rows
        val partRowH = 12.5f
        for (p in 0 until 5) {
            val rY = curY + (p * partRowH)
            canvas.drawLine(MARGIN, rY + partRowH, MARGIN + contentWidth, rY + partRowH, borderThin)

            canvas.drawText("${p + 1}", MARGIN + 8f, rY + 9.5f, fontText)

            if (p < report.partsList.size && report.partsList[p].partName.isNotBlank()) {
                val item = report.partsList[p]
                canvas.drawText(item.partNumber, MARGIN + colNoW + 4f, rY + 9.5f, fontText)
                canvas.drawText(item.partName, MARGIN + colNoW + colPartNoW + 4f, rY + 9.5f, fontText)

                val colIdx = when (item.procurementType.lowercase()) {
                    "stock" -> 0
                    "order" -> 1
                    "modifikasi" -> 2
                    "pending" -> 3
                    else -> 0
                }
                canvas.drawText("√", procStartX + (colIdx * subProcW) + (subProcW / 2f), rY + 9.5f, centerBold)
            }
        }
        // Vertical column lines across 5 rows
        val partsBodyH = partRowH * 5
        canvas.drawLine(MARGIN + colNoW, curY, MARGIN + colNoW, curY + partsBodyH, borderThin)
        canvas.drawLine(MARGIN + colNoW + colPartNoW, curY, MARGIN + colNoW + colPartNoW, curY + partsBodyH, borderThin)
        canvas.drawLine(procStartX, curY, procStartX, curY + partsBodyH, borderThin)
        for (k in 1..3) {
            canvas.drawLine(procStartX + (k * subProcW), curY, procStartX + (k * subProcW), curY + partsBodyH, borderThin)
        }

        curY += partsBodyH

        // -------------------------------------------------------------
        // SECTION: SIGNATURES (MENGETAHUI & DILAPORKAN OLEH)
        // -------------------------------------------------------------
        val signH = 80f
        val signDividerX = MARGIN + (contentWidth * 0.55f)
        canvas.drawRect(MARGIN, curY, MARGIN + contentWidth, curY + signH, borderThin)
        canvas.drawLine(signDividerX, curY, signDividerX, curY + signH, borderThin)

        // Left: Mengetahui,
        canvas.drawText("Mengetahui,", MARGIN + (signDividerX - MARGIN) / 2f, curY + 12f, centerBold)
        // Signature lines at bottom
        val signBottomY = curY + signH - 12f
        val halfMengetahuiW = (signDividerX - MARGIN) / 2f
        canvas.drawText("(...............................)", MARGIN + 10f, signBottomY, fontBold)
        canvas.drawText("(...............................)", MARGIN + halfMengetahuiW + 10f, signBottomY, fontBold)

        // Right: Dilaporkan Oleh:
        canvas.drawLine(signDividerX, curY + 16f, MARGIN + contentWidth, curY + 16f, borderThin)
        canvas.drawLine(signDividerX, curY + 30f, MARGIN + contentWidth, curY + 30f, borderThin)
        canvas.drawLine(signDividerX, curY + 44f, MARGIN + contentWidth, curY + 44f, borderThin)

        val rightSignCenterX = signDividerX + ((MARGIN + contentWidth - signDividerX) / 2f)
        canvas.drawText("Dilaporkan Oleh:", rightSignCenterX, curY + 11.5f, centerBold)

        canvas.drawText("Nama    : ${report.reportedByName.ifBlank { "Yudi Indrawan" }}", signDividerX + 8f, curY + 25f, fontBold)
        canvas.drawText("Jabatan : ${report.reportedByTitle.ifBlank { "Wa.Ka.Bengkel" }}", signDividerX + 8f, curY + 39f, fontBold)

        // Draw signatures and names: SUHERMAN & YUDI INDRAWAN
        val sig1X = signDividerX + 30f
        val sig2X = signDividerX + 130f
        drawSimulatedSignature(canvas, sig1X, curY + 46f)
        drawSimulatedSignature(canvas, sig2X, curY + 46f)

        canvas.drawText(report.knownBy2.ifBlank { "SUHERMAN" }, sig1X - 5f, signBottomY, fontBold)
        canvas.drawText(report.reportedByName.ifBlank { "YUDI INDRAWAN" }, sig2X - 10f, signBottomY, fontBold)
    }

    private fun drawSimulatedSignature(canvas: Canvas, startX: Float, startY: Float) {
        val sigPaint = Paint().apply {
            color = Color.rgb(30, 41, 59)
            style = Paint.Style.STROKE
            strokeWidth = 1.3f
            isAntiAlias = true
        }
        val path = Path()
        path.moveTo(startX, startY + 14f)
        path.cubicTo(startX + 6f, startY - 4f, startX + 14f, startY + 18f, startX + 22f, startY + 4f)
        path.cubicTo(startX + 26f, startY + 16f, startX + 34f, startY - 2f, startX + 42f, startY + 12f)
        path.lineTo(startX + 48f, startY + 8f)
        canvas.drawPath(path, sigPaint)
    }

    private fun loadReportBitmap(context: Context, report: TechnicalReport): Bitmap? {
        if (report.damagePhotoUri.isNotBlank()) {
            if (report.damagePhotoUri == "sample") {
                return try {
                    BitmapFactory.decodeResource(context.resources, R.drawable.sample_damaged_tire)
                } catch (_: Exception) { null }
            }
            try {
                val uri = Uri.parse(report.damagePhotoUri)
                if (uri.scheme == "file") {
                    return BitmapFactory.decodeFile(uri.path)
                } else {
                    context.contentResolver.openInputStream(uri)?.use { stream ->
                        return BitmapFactory.decodeStream(stream)
                    }
                }
            } catch (_: Exception) { }
        }
        return null
    }

    private fun drawSquareCheckbox(canvas: Canvas, x: Float, y: Float, isChecked: Boolean) {
        val boxPaint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 1.1f
        }
        canvas.drawRect(x, y, x + 10f, y + 10f, boxPaint)

        if (isChecked) {
            val checkPaint = Paint().apply {
                color = Color.BLACK
                style = Paint.Style.STROKE
                strokeWidth = 1.5f
                isAntiAlias = true
            }
            canvas.drawLine(x + 1.8f, y + 5.2f, x + 4.2f, y + 8.5f, checkPaint)
            canvas.drawLine(x + 4.2f, y + 8.5f, x + 9f, y + 2.2f, checkPaint)
        }
    }

    private fun drawWrappedText(canvas: Canvas, text: String, x: Float, y: Float, maxWidth: Float, paint: Paint, lineSpacing: Float) {
        val words = text.split(" ")
        var line = ""
        var curY = y
        for (w in words) {
            val candidate = if (line.isEmpty()) w else "$line $w"
            if (paint.measureText(candidate) <= maxWidth) {
                line = candidate
            } else {
                canvas.drawText(line, x, curY, paint)
                curY += lineSpacing
                line = w
            }
        }
        if (line.isNotEmpty()) {
            canvas.drawText(line, x, curY, paint)
        }
    }

    private fun drawWrappedTextCenter(canvas: Canvas, text: String, centerX: Float, y: Float, maxWidth: Float, paint: Paint, lineSpacing: Float) {
        val words = text.split(" ")
        var line = ""
        var curY = y
        for (w in words) {
            val candidate = if (line.isEmpty()) w else "$line $w"
            if (paint.measureText(candidate) <= maxWidth) {
                line = candidate
            } else {
                canvas.drawText(line, centerX, curY, paint)
                curY += lineSpacing
                line = w
            }
        }
        if (line.isNotEmpty()) {
            canvas.drawText(line, centerX, curY, paint)
        }
    }

    // =========================================================================
    // DESAIN 1: FORMAT STANDAR DEALER
    // =========================================================================
    private fun drawDocumentStandard(canvas: Canvas, report: TechnicalReport) {
        val bgPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, PAGE_WIDTH.toFloat(), PAGE_HEIGHT.toFloat(), bgPaint)

        val borderPaint = Paint().apply {
            color = Color.rgb(30, 41, 59)
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
        }
        val innerBorderPaint = Paint().apply {
            color = Color.rgb(100, 116, 139)
            style = Paint.Style.STROKE
            strokeWidth = 0.5f
        }
        canvas.drawRect(MARGIN - 8, MARGIN - 8, PAGE_WIDTH - MARGIN + 8, PAGE_HEIGHT - MARGIN + 8, borderPaint)
        canvas.drawRect(MARGIN - 5, MARGIN - 5, PAGE_WIDTH - MARGIN + 5, PAGE_HEIGHT - MARGIN + 5, innerBorderPaint)

        var curY = MARGIN + 10f
        val contentWidth = PAGE_WIDTH - (MARGIN * 2)

        val titlePaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("LAPORAN TEKNIK", PAGE_WIDTH / 2f, curY, titlePaint)
        curY += 6f

        val headerLinePaint = Paint().apply {
            color = Color.rgb(30, 58, 138)
            strokeWidth = 2f
        }
        canvas.drawLine(MARGIN, curY, PAGE_WIDTH - MARGIN, curY, headerLinePaint)
        curY += 14f

        val metaPaint = Paint().apply {
            color = Color.rgb(30, 41, 59)
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }
        val metaBoldPaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        canvas.drawText("No. Laporan", MARGIN, curY, metaBoldPaint)
        canvas.drawText(": ${report.reportNumber.ifBlank { "-" }}", MARGIN + 65, curY, metaPaint)

        canvas.drawText("Bengkel", MARGIN + 210, curY, metaBoldPaint)
        canvas.drawText(": ${report.workshop.ifBlank { "-" }}", MARGIN + 260, curY, metaPaint)

        canvas.drawText("Tanggal", MARGIN + 380, curY, metaBoldPaint)
        canvas.drawText(": ${report.reportDate.ifBlank { "-" }}", MARGIN + 430, curY, metaPaint)

        curY += 14f

        curY = drawSectionHeader(canvas, "1. INFORMASI UNIT / ALAT", curY, contentWidth)

        val tableBoxPaint = Paint().apply {
            color = Color.rgb(203, 213, 225)
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
        }
        val unitBoxTop = curY
        val rowHeight = 13.5f
        val halfWidth = contentWidth / 2f

        val leftData = listOf(
            "Pabrik Pembuat" to report.manufacturer,
            "Tipe" to report.unitType,
            "Model" to report.model,
            "Kode Unit" to report.unitCode
        )
        val rightData = listOf(
            "Nama Alat" to report.toolName,
            "Tanggal Rusak" to report.damageDate,
            "KM / HM" to report.mileageKmHm,
            "Komponen" to report.component
        )

        for (i in 0 until 4) {
            val rY = curY + (i * rowHeight)
            canvas.drawText("${leftData[i].first}", MARGIN + 4, rY + 10, metaBoldPaint)
            canvas.drawText(": ${leftData[i].second.ifBlank { "-" }}", MARGIN + 85, rY + 10, metaPaint)
            canvas.drawText("${rightData[i].first}", MARGIN + halfWidth + 4, rY + 10, metaBoldPaint)
            canvas.drawText(": ${rightData[i].second.ifBlank { "-" }}", MARGIN + halfWidth + 85, rY + 10, metaPaint)
        }
        curY += (4 * rowHeight) + 4
        canvas.drawRect(MARGIN, unitBoxTop, MARGIN + contentWidth, curY, tableBoxPaint)
        canvas.drawLine(MARGIN + halfWidth, unitBoxTop, MARGIN + halfWidth, curY, tableBoxPaint)
        curY += 8f

        curY = drawSectionHeader(canvas, "2. STATUS GARANSI", curY, contentWidth)
        val isWarranty = report.warrantyStatus == WarrantyStatus.IN_WARRANTY
        val isAfterWarranty = report.warrantyStatus == WarrantyStatus.AFTER_WARRANTY

        drawCheckbox(canvas, MARGIN + 10, curY - 1, isWarranty)
        canvas.drawText("Masa Garansi", MARGIN + 26, curY + 8, metaPaint)

        drawCheckbox(canvas, MARGIN + 180, curY - 1, isAfterWarranty)
        canvas.drawText("Setelah Masa Garansi", MARGIN + 196, curY + 8, metaPaint)
        curY += 16f

        curY = drawSectionHeader(canvas, "3. DETAIL KERUSAKAN & LOKASI", curY, contentWidth)
        val damageTop = curY
        canvas.drawText("Kerusakan", MARGIN + 4, curY + 10, metaBoldPaint)
        canvas.drawText(": ${report.damageDetail.ifBlank { "-" }}", MARGIN + 90, curY + 10, metaPaint)
        curY += 13f

        canvas.drawText("Lokasi", MARGIN + 4, curY + 10, metaBoldPaint)
        canvas.drawText(": ${report.location.ifBlank { "-" }}", MARGIN + 90, curY + 10, metaPaint)
        curY += 13f

        canvas.drawText("History Bengkel", MARGIN + 4, curY + 10, metaBoldPaint)
        canvas.drawText(": ${report.workshopHistory.ifBlank { "-" }}", MARGIN + 90, curY + 10, metaPaint)
        curY += 13f

        canvas.drawText("History Ban/Part", MARGIN + 4, curY + 10, metaBoldPaint)
        canvas.drawText(": ${report.tireHistory.ifBlank { "-" }}", MARGIN + 90, curY + 10, metaPaint)
        curY += 13f

        canvas.drawText("Lampiran", MARGIN + 4, curY + 10, metaBoldPaint)
        canvas.drawText(": ${report.attachments.ifBlank { "-" }}", MARGIN + 90, curY + 10, metaPaint)
        curY += 15f
        canvas.drawRect(MARGIN, damageTop, MARGIN + contentWidth, curY, tableBoxPaint)
        curY += 8f

        curY = drawSectionHeader(canvas, "4. PENYEBAB KERUSAKAN", curY, contentWidth)
        val causes = listOf(
            Triple("1. Pemasangan", report.causeInstallation, report.causeInstallationNotes),
            Triple("2. Kualitas", report.causeQuality, report.causeQualityNotes),
            Triple("3. Kesalahan Operasional", report.causeOperational, report.causeOperationalNotes),
            Triple("4. Sudah Waktunya", report.causeTimeExpired, report.causeTimeExpiredNotes),
            Triple("5. Lain-lain", report.causeOthers, report.causeOthersNotes)
        )
        for ((label, checked, notes) in causes) {
            drawCheckbox(canvas, MARGIN + 4, curY - 1, checked)
            canvas.drawText(label, MARGIN + 18, curY + 7.5f, metaBoldPaint)
            if (notes.isNotBlank()) {
                val safeNotes = if (notes.startsWith("-") || notes.startsWith("Kesimpulan:")) notes else "- $notes"
                canvas.drawText(safeNotes, MARGIN + 140, curY + 7.5f, metaPaint)
            }
            curY += 12f
        }
        curY += 5f

        curY = drawSectionHeader(canvas, "5. CARA MENGATASI KERUSAKAN", curY, contentWidth)
        val solutions = listOf(
            Triple("1. Ganti Part Baru", report.solutionReplacePart, report.solutionReplacePartNotes),
            Triple("2. Pemasangan / Penyetelan Ulang", report.solutionReinstallAdjust, report.solutionReinstallAdjustNotes),
            Triple("3. Modifikasi", report.solutionModification, report.solutionModificationNotes)
        )
        for ((label, checked, notes) in solutions) {
            drawCheckbox(canvas, MARGIN + 4, curY - 1, checked)
            canvas.drawText(label, MARGIN + 18, curY + 7.5f, metaBoldPaint)
            if (notes.isNotBlank()) {
                val safeNotes = if (notes.startsWith("-")) notes else "- $notes"
                canvas.drawText(safeNotes, MARGIN + 180, curY + 7.5f, metaPaint)
            }
            curY += 12f
        }
        curY += 6f

        curY = drawSectionHeader(canvas, "6. TABEL PARTS YANG HARUS DIGANTI", curY, contentWidth)
        val tableTop = curY
        val colWidths = floatArrayOf(24f, 110f, 150f, 95f, contentWidth - 24f - 110f - 150f - 95f)

        val thBgPaint = Paint().apply {
            color = Color.rgb(241, 245, 249)
            style = Paint.Style.FILL
        }
        canvas.drawRect(MARGIN, curY, MARGIN + contentWidth, curY + 14f, thBgPaint)

        var xOffset = MARGIN
        val headers = arrayOf("NO", "No. Part", "Nama Parts", "Jenis Pengadaan", "Keterangan")
        for (idx in headers.indices) {
            canvas.drawText(headers[idx], xOffset + 3, curY + 10f, metaBoldPaint)
            xOffset += colWidths[idx]
        }
        curY += 14f
        canvas.drawLine(MARGIN, curY, MARGIN + contentWidth, curY, tableBoxPaint)

        val parts = report.partsList.ifEmpty {
            listOf(com.example.data.model.PartItem("-", "Tidak ada pergantian part", "Stock", "-"))
        }

        for (pIdx in parts.indices) {
            val part = parts[pIdx]
            val rowY = curY
            var xPos = MARGIN
            val rowValues = arrayOf(
                (pIdx + 1).toString(),
                part.partNumber.ifBlank { "-" },
                part.partName.ifBlank { "-" },
                part.procurementType.ifBlank { "Stock" },
                part.notes.ifBlank { "-" }
            )
            for (idx in rowValues.indices) {
                canvas.drawText(rowValues[idx], xPos + 3, rowY + 10f, metaPaint)
                xPos += colWidths[idx]
            }
            curY += 13.5f
            canvas.drawLine(MARGIN, curY, MARGIN + contentWidth, curY, tableBoxPaint)
        }

        var vX = MARGIN
        for (w in colWidths) {
            canvas.drawLine(vX, tableTop, vX, curY, tableBoxPaint)
            vX += w
        }
        canvas.drawLine(MARGIN + contentWidth, tableTop, MARGIN + contentWidth, curY, tableBoxPaint)
        curY += 12f

        val signBoxTop = curY
        val signBoxWidth = (contentWidth - 20) / 2f
        val signBoxHeight = 54f

        canvas.drawRect(MARGIN, signBoxTop, MARGIN + signBoxWidth, signBoxTop + signBoxHeight, tableBoxPaint)
        canvas.drawText("Disetujui Oleh:", MARGIN + 8, signBoxTop + 12f, metaBoldPaint)
        canvas.drawText(report.approvedByTitle.ifBlank { "WA.KA. Bengkel" }, MARGIN + 8, signBoxTop + 22f, metaPaint)
        canvas.drawLine(MARGIN + 8, signBoxTop + 42f, MARGIN + signBoxWidth - 8, signBoxTop + 42f, tableBoxPaint)
        canvas.drawText(report.approvedByName.ifBlank { "Yudi Indrawan" }, MARGIN + 8, signBoxTop + 50f, metaBoldPaint)

        val rightSignX = MARGIN + signBoxWidth + 20
        canvas.drawRect(rightSignX, signBoxTop, rightSignX + signBoxWidth, signBoxTop + signBoxHeight, tableBoxPaint)
        canvas.drawText("Dilaporkan Oleh:", rightSignX + 8, signBoxTop + 12f, metaBoldPaint)
        canvas.drawText(report.reportedByTitle.ifBlank { "Pelapor / Mekanik" }, rightSignX + 8, signBoxTop + 22f, metaPaint)
        canvas.drawLine(rightSignX + 8, signBoxTop + 42f, rightSignX + signBoxWidth - 8, signBoxTop + 42f, tableBoxPaint)
        canvas.drawText(report.reportedByName.ifBlank { "Ahmad Supriyadi" }, rightSignX + 8, signBoxTop + 50f, metaBoldPaint)

        val footerPaint = Paint().apply {
            color = Color.rgb(148, 163, 184)
            textSize = 7.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
        }
        canvas.drawText("Dokumen Resmi Laporan Teknik - Dibuat secara otomatis", MARGIN, PAGE_HEIGHT - MARGIN + 2, footerPaint)
        canvas.drawText("Tgl Cetak: ${report.signDate.ifBlank { report.reportDate }}", PAGE_WIDTH - MARGIN - 80, PAGE_HEIGHT - MARGIN + 2, footerPaint)
    }

    private fun drawSectionHeader(canvas: Canvas, title: String, y: Float, width: Float): Float {
        val bgPaint = Paint().apply {
            color = Color.rgb(226, 232, 240)
            style = Paint.Style.FILL
        }
        canvas.drawRect(MARGIN, y, MARGIN + width, y + 14f, bgPaint)

        val borderPaint = Paint().apply {
            color = Color.rgb(203, 213, 225)
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
        }
        canvas.drawRect(MARGIN, y, MARGIN + width, y + 14f, borderPaint)

        val textPaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText(title, MARGIN + 6, y + 10.5f, textPaint)
        return y + 18f
    }

    private fun drawCheckbox(canvas: Canvas, x: Float, y: Float, isChecked: Boolean) {
        val boxPaint = Paint().apply {
            color = Color.rgb(71, 85, 105)
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        canvas.drawRect(x, y, x + 9f, y + 9f, boxPaint)

        if (isChecked) {
            val checkPaint = Paint().apply {
                color = Color.rgb(30, 58, 138)
                style = Paint.Style.STROKE
                strokeWidth = 1.6f
            }
            canvas.drawLine(x + 1.5f, y + 4.5f, x + 3.8f, y + 7.5f, checkPaint)
            canvas.drawLine(x + 3.8f, y + 7.5f, x + 8f, y + 1.5f, checkPaint)
        }
    }

    // =========================================================================
    // PRINT MANAGER (PRIN LANGSUNG / SIMPAN KE PRINTER)
    // =========================================================================
    fun printPdf(context: Context, file: File, jobName: String = "Laporan_Teknik") {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
        if (printManager != null) {
            val adapter = object : PrintDocumentAdapter() {
                override fun onLayout(
                    oldAttributes: PrintAttributes?,
                    newAttributes: PrintAttributes?,
                    cancellationSignal: CancellationSignal?,
                    callback: LayoutResultCallback?,
                    extras: Bundle?
                ) {
                    if (cancellationSignal?.isCanceled == true) {
                        callback?.onLayoutCancelled()
                        return
                    }
                    val info = PrintDocumentInfo.Builder("${file.name}")
                        .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .setPageCount(1)
                        .build()
                    callback?.onLayoutFinished(info, true)
                }

                override fun onWrite(
                    pages: Array<out PageRange>?,
                    destination: ParcelFileDescriptor?,
                    cancellationSignal: CancellationSignal?,
                    callback: WriteResultCallback?
                ) {
                    try {
                        FileInputStream(file).use { input ->
                            FileOutputStream(destination?.fileDescriptor).use { output ->
                                input.copyTo(output)
                            }
                        }
                        callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                    } catch (e: Exception) {
                        callback?.onWriteFailed(e.message)
                    }
                }
            }
            printManager.print(jobName, adapter, PrintAttributes.Builder().build())
        } else {
            openPdf(context, file)
        }
    }

    fun sharePdf(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Laporan Teknik - ${file.name}")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(shareIntent, "Bagikan Laporan Teknik (PDF)")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    fun openPdf(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val viewIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooser = Intent.createChooser(viewIntent, "Buka Dokumen PDF")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }
}
