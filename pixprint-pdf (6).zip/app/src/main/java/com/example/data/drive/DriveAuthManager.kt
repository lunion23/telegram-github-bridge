package com.example.data.drive

import android.content.Context
import android.content.Intent
import android.content.IntentSender
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import kotlin.coroutines.resume
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request

sealed interface DriveAuthOutcome {
    data class Granted(val accessToken: String) : DriveAuthOutcome
    data class NeedsResolution(val intentSender: IntentSender) : DriveAuthOutcome
    data class Failed(val message: String) : DriveAuthOutcome
}

interface DriveAuthManager {
    suspend fun authorizeDriveScope(context: Context): DriveAuthOutcome
    fun extractTokenFromActivityResult(context: Context, resultData: Intent?): Result<String>
    suspend fun clearCachedToken(context: Context, staleToken: String)
    suspend fun revokeTokenBestEffort(accessToken: String)

    companion object {
        const val DRIVE_FILE_SCOPE = "https://www.googleapis.com/auth/drive.file"
    }
}

class PlayServicesDriveAuthManager(
    private val httpClient: OkHttpClient = OkHttpClient()
) : DriveAuthManager {

    @Volatile
    private var lastKnownAccessToken: String? = null

    override suspend fun authorizeDriveScope(context: Context): DriveAuthOutcome {
        val request = AuthorizationRequest.builder()
            .setRequestedScopes(listOf(Scope(DriveAuthManager.DRIVE_FILE_SCOPE)))
            .build()

        return suspendCancellableCoroutine { cont ->
            Identity.getAuthorizationClient(context)
                .authorize(request)
                .addOnSuccessListener { result ->
                    if (!cont.isActive) return@addOnSuccessListener
                    if (result.hasResolution()) {
                        val pendingIntent = result.pendingIntent
                        if (pendingIntent != null) {
                            cont.resume(DriveAuthOutcome.NeedsResolution(pendingIntent.intentSender))
                        } else {
                            cont.resume(
                                DriveAuthOutcome.Failed("PendingIntent otorisasi Google tidak tersedia")
                            )
                        }
                    } else {
                        val token = result.accessToken
                        if (!token.isNullOrBlank()) {
                            lastKnownAccessToken = token
                            cont.resume(DriveAuthOutcome.Granted(token))
                        } else {
                            cont.resume(
                                DriveAuthOutcome.Failed("Token akses Google Drive kosong")
                            )
                        }
                    }
                }
                .addOnFailureListener { error ->
                    if (!cont.isActive) return@addOnFailureListener
                    cont.resume(
                        DriveAuthOutcome.Failed(
                            error.localizedMessage ?: "Gagal meminta izin Google Drive"
                        )
                    )
                }
        }
    }

    override fun extractTokenFromActivityResult(
        context: Context,
        resultData: Intent?
    ): Result<String> {
        return runCatching {
            val authResult = Identity.getAuthorizationClient(context)
                .getAuthorizationResultFromIntent(resultData)
            val token = authResult.accessToken
            require(!token.isNullOrBlank()) {
                "Izin Google Drive belum diberikan"
            }
            lastKnownAccessToken = token
            token
        }
    }

    override suspend fun clearCachedToken(context: Context, staleToken: String) {
        if (staleToken.isBlank()) return
        withContext(Dispatchers.IO) {
            runCatching {
                GoogleAuthUtil.clearToken(context.applicationContext, staleToken)
            }
        }
        if (lastKnownAccessToken == staleToken) {
            lastKnownAccessToken = null
        }
    }

    override suspend fun revokeTokenBestEffort(accessToken: String) {
        val tokenToRevoke = accessToken.ifBlank { lastKnownAccessToken.orEmpty() }
        lastKnownAccessToken = null
        if (tokenToRevoke.isBlank()) return

        withContext(Dispatchers.IO) {
            runCatching {
                val formBody = FormBody.Builder()
                    .add("token", tokenToRevoke)
                    .build()
                val request = Request.Builder()
                    .url("https://oauth2.googleapis.com/revoke")
                    .post(formBody)
                    .build()
                httpClient.newCall(request).execute().close()
            }
        }
    }
}
