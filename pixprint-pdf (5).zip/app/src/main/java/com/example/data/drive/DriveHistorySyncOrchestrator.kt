package com.example.data.drive

import com.example.data.local.CapturedDocumentStorage
import com.example.data.repository.LabelHistoryRepository
import com.example.model.DriveSyncExecutionResult
import com.example.model.DriveSyncMode
import com.example.model.DriveSyncPayload
import com.example.model.DriveSyncPreferences
import com.example.model.HistoryActionType
import com.example.model.LabelHistoryItem
import com.example.model.PaperSizePreset
import com.example.model.PdfRenderSource
import com.example.model.resolvedPaperPreset
import com.example.model.resolvedRenderSource
import com.example.model.toShippingLabelData
import com.example.pdf.ShippingLabelPdfGenerator
import java.io.ByteArrayOutputStream
import org.json.JSONArray
import org.json.JSONObject

data class HistoryMergeComputation(
    val finalItems: List<LabelHistoryItem>,
    val mergedTombstones: Map<String, Long>,
    val itemsToUpsertLocally: List<LabelHistoryItem>,
    val idsToDeleteLocally: Set<String>,
    val shouldUploadRemoteJson: Boolean,
    val uploadedItemCount: Int,
    val restoredItemCount: Int
)

object DriveSyncPayloadCodec {

    fun encode(payload: DriveSyncPayload): String {
        val root = JSONObject()
        root.put("schemaVersion", payload.schemaVersion)
        root.put("exportedAtMillis", payload.exportedAtMillis)

        val itemsArray = JSONArray()
        for (item in payload.items) {
            itemsArray.put(encodeItem(item))
        }
        root.put("items", itemsArray)

        val tombstonesObj = JSONObject()
        for ((id, deletedAt) in payload.deletedTombstones) {
            if (id.isNotBlank() && deletedAt > 0L) {
                tombstonesObj.put(id, deletedAt)
            }
        }
        root.put("deletedTombstones", tombstonesObj)

        return root.toString(2)
    }

    fun decode(rawJson: String): DriveSyncPayload {
        if (rawJson.isBlank()) return DriveSyncPayload()
        val root = JSONObject(rawJson)
        val schemaVersion = root.optInt("schemaVersion", 1)
        val exportedAt = root.optLong("exportedAtMillis", 0L)

        val items = mutableListOf<LabelHistoryItem>()
        val itemsArray = root.optJSONArray("items")
        if (itemsArray != null) {
            for (i in 0 until itemsArray.length()) {
                val obj = itemsArray.optJSONObject(i) ?: continue
                val parsed = decodeItem(obj)
                if (parsed.id.isNotBlank()) {
                    items.add(parsed)
                }
            }
        }

        val tombstones = mutableMapOf<String, Long>()
        val tombstonesObj = root.optJSONObject("deletedTombstones")
        if (tombstonesObj != null) {
            val keys = tombstonesObj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val ts = tombstonesObj.optLong(key, 0L)
                if (key.isNotBlank() && ts > 0L) {
                    tombstones[key] = ts
                }
            }
        }

        return DriveSyncPayload(
            schemaVersion = schemaVersion,
            exportedAtMillis = exportedAt,
            items = items,
            deletedTombstones = tombstones
        )
    }

    private fun encodeItem(item: LabelHistoryItem): JSONObject {
        return JSONObject().apply {
            put("id", item.id)
            put("badgeLeft", item.badgeLeft)
            put("badgeRight", item.badgeRight)
            put("routingCode", item.routingCode)
            put("waybillNumber", item.waybillNumber)
            put("destinationBanner", item.destinationBanner)
            put("recipientName", item.recipientName)
            put("recipientPhone", item.recipientPhone)
            put("recipientAddress", item.recipientAddress)
            put("senderName", item.senderName)
            put("senderPhone", item.senderPhone)
            put("senderArea", item.senderArea)
            put("shippingFeeLabel", item.shippingFeeLabel)
            put("shippingFeeAmount", item.shippingFeeAmount)
            put("taxIncludedText", item.taxIncludedText)
            put("paymentMethod", item.paymentMethod)
            put("weight", item.weight)
            put("printDate", item.printDate)
            put("orderNumber", item.orderNumber)
            put("expCode", item.expCode)
            put("quantityText", item.quantityText)
            put("itemCategory", item.itemCategory)
            put("notes", item.notes)
            put("companyNameAndTax", item.companyNameAndTax)
            put("companyAddressLine1", item.companyAddressLine1)
            put("companyAddressLine2", item.companyAddressLine2)
            put("websiteUrl", item.websiteUrl)
            put("stubBadgeText", item.stubBadgeText)
            put("paperPreset", item.paperPreset)
            put("renderSourceName", item.renderSourceName)
            put("actionLabel", item.actionLabel)
            put("createdAtMillis", item.createdAtMillis)
            put("updatedAtMillis", item.updatedAtMillis)
            put("drivePdfFileId", item.drivePdfFileId)
            put("lastSyncedAtMillis", item.lastSyncedAtMillis)
        }
    }

    private fun decodeItem(obj: JSONObject): LabelHistoryItem {
        val rawAction = obj.optString("actionLabel", HistoryActionType.SAVED)
        val safeAction = if (rawAction in HistoryActionType.allowedValues) {
            rawAction
        } else {
            HistoryActionType.SAVED
        }
        val rawPreset = obj.optString("paperPreset", PaperSizePreset.THERMAL_100X200.name)
        val safePreset = PaperSizePreset.entries.firstOrNull { it.name == rawPreset }?.name
            ?: PaperSizePreset.THERMAL_100X200.name
        val rawRenderSource = obj.optString("renderSourceName", PdfRenderSource.VECTOR_RECONSTRUCTION.name)
        val safeRenderSource = PdfRenderSource.entries.firstOrNull { it.name == rawRenderSource }?.name
            ?: PdfRenderSource.VECTOR_RECONSTRUCTION.name

        return LabelHistoryItem(
            id = obj.optString("id", "").trim(),
            badgeLeft = obj.optString("badgeLeft", "NP"),
            badgeRight = obj.optString("badgeRight", "EZ"),
            routingCode = obj.optString("routingCode", ""),
            waybillNumber = obj.optString("waybillNumber", "SCAN-DOC"),
            destinationBanner = obj.optString("destinationBanner", ""),
            recipientName = obj.optString("recipientName", "-"),
            recipientPhone = obj.optString("recipientPhone", ""),
            recipientAddress = obj.optString("recipientAddress", ""),
            senderName = obj.optString("senderName", ""),
            senderPhone = obj.optString("senderPhone", ""),
            senderArea = obj.optString("senderArea", ""),
            shippingFeeLabel = obj.optString("shippingFeeLabel", "BIAYA PENGIRIMAN"),
            shippingFeeAmount = obj.optString("shippingFeeAmount", ""),
            taxIncludedText = obj.optString("taxIncludedText", "Sudah Termasuk PPN"),
            paymentMethod = obj.optString("paymentMethod", ""),
            weight = obj.optString("weight", ""),
            printDate = obj.optString("printDate", ""),
            orderNumber = obj.optString("orderNumber", ""),
            expCode = obj.optString("expCode", ""),
            quantityText = obj.optString("quantityText", ""),
            itemCategory = obj.optString("itemCategory", ""),
            notes = obj.optString("notes", ""),
            companyNameAndTax = obj.optString(
                "companyNameAndTax",
                ""
            ),
            companyAddressLine1 = obj.optString(
                "companyAddressLine1",
                ""
            ),
            companyAddressLine2 = obj.optString(
                "companyAddressLine2",
                ""
            ),
            websiteUrl = obj.optString("websiteUrl", ""),
            stubBadgeText = obj.optString("stubBadgeText", "Lembar Pengirim"),
            paperPreset = safePreset,
            renderSourceName = safeRenderSource,
            capturedImagePath = "",
            actionLabel = safeAction,
            createdAtMillis = obj.optLong("createdAtMillis", 0L),
            updatedAtMillis = obj.optLong("updatedAtMillis", 0L),
            drivePdfFileId = obj.optString("drivePdfFileId", ""),
            lastSyncedAtMillis = obj.optLong("lastSyncedAtMillis", 0L)
        )
    }
}

class DriveHistorySyncOrchestrator(
    private val historyRepository: LabelHistoryRepository,
    private val prefsRepository: DriveSyncPreferencesRepository,
    private val remoteDataSource: DriveRemoteDataSource,
    private val pdfRenderer: (LabelHistoryItem) -> ByteArray = ::defaultRenderItemPdfBytes
) {

    suspend fun performSync(
        accessToken: String,
        overrideMode: DriveSyncMode? = null,
        nowMillis: Long = System.currentTimeMillis()
    ): DriveSyncExecutionResult {
        val prefs = prefsRepository.getSnapshot()
        val effectiveMode = overrideMode ?: prefs.syncMode
        val folderName = prefs.sanitizedFolderName

        val folderId = remoteDataSource.ensureFolder(
            accessToken = accessToken,
            folderName = folderName,
            cachedFolderId = prefs.cachedFolderId
        )

        val remoteFile = remoteDataSource.downloadSyncJson(
            accessToken = accessToken,
            folderId = folderId,
            fileName = DriveSyncPreferences.SYNC_JSON_FILE_NAME,
            cachedFileId = prefs.cachedSyncFileId
        )
        val remotePayload = remoteFile?.content?.let { raw ->
            runCatching { DriveSyncPayloadCodec.decode(raw) }.getOrNull()
        } ?: DriveSyncPayload()

        val localItems = historyRepository.getAllHistory()

        val mergeResult = computeMerge(
            mode = effectiveMode,
            localItems = localItems,
            localTombstones = prefs.deletedTombstones,
            remoteItems = remotePayload.items,
            remoteTombstones = remotePayload.deletedTombstones,
            syncTimestampMillis = nowMillis
        )

        // Optional automatic PDF backup to Google Drive folder
        var uploadedPdfCount = 0
        val finalItemsWithPdfs = if (prefs.autoUploadPdf && effectiveMode != DriveSyncMode.RESTORE_ONLY) {
            mergeResult.finalItems.map { item ->
                val needsPdfUpload = item.drivePdfFileId.isBlank() || item.updatedAtMillis > item.lastSyncedAtMillis
                if (needsPdfUpload) {
                    val pdfBytes = pdfRenderer(item)
                    val pdfName = buildDrivePdfFileName(item)
                    val uploadedPdfId = remoteDataSource.uploadPdfFile(
                        accessToken = accessToken,
                        folderId = folderId,
                        existingFileId = item.drivePdfFileId.takeIf { it.isNotBlank() },
                        fileName = pdfName,
                        pdfBytes = pdfBytes
                    )
                    uploadedPdfCount++
                    item.copy(
                        drivePdfFileId = uploadedPdfId,
                        lastSyncedAtMillis = maxOf(nowMillis, item.updatedAtMillis)
                    )
                } else {
                    item
                }
            }
        } else {
            mergeResult.finalItems
        }

        // Persist local database updates & deletions
        if (mergeResult.idsToDeleteLocally.isNotEmpty()) {
            historyRepository.deleteMultipleByIds(mergeResult.idsToDeleteLocally)
        }
        val itemsToSaveLocally = if (uploadedPdfCount > 0) {
            finalItemsWithPdfs
        } else {
            mergeResult.itemsToUpsertLocally
        }
        if (itemsToSaveLocally.isNotEmpty()) {
            historyRepository.upsertSyncedItems(itemsToSaveLocally)
        }

        // Upload merged JSON snapshot to Google Drive unless strictly restoring locally
        val syncFileId = if (mergeResult.shouldUploadRemoteJson || uploadedPdfCount > 0 || remoteFile == null) {
            val outgoingJson = DriveSyncPayloadCodec.encode(
                DriveSyncPayload(
                    schemaVersion = 1,
                    exportedAtMillis = nowMillis,
                    items = finalItemsWithPdfs,
                    deletedTombstones = mergeResult.mergedTombstones
                )
            )
            remoteDataSource.uploadSyncJson(
                accessToken = accessToken,
                folderId = folderId,
                existingFileId = remoteFile?.fileId ?: prefs.cachedSyncFileId.takeIf { it.isNotBlank() },
                fileName = DriveSyncPreferences.SYNC_JSON_FILE_NAME,
                jsonContent = outgoingJson
            )
        } else {
            remoteFile.fileId
        }

        val summaryText = buildString {
            append("Sinkron ke \"$folderName\"")
            append(" • ${finalItemsWithPdfs.size} resi")
            if (uploadedPdfCount > 0) {
                append(" • +$uploadedPdfCount PDF")
            }
        }

        prefsRepository.updateAfterSyncSuccess(
            folderId = folderId,
            syncFileId = syncFileId,
            mergedTombstones = mergeResult.mergedTombstones,
            syncedAtMillis = nowMillis,
            statusMessage = summaryText
        )

        return DriveSyncExecutionResult(
            uploadedItemCount = mergeResult.uploadedItemCount,
            restoredItemCount = mergeResult.restoredItemCount,
            deletedLocalCount = mergeResult.idsToDeleteLocally.size,
            uploadedPdfCount = uploadedPdfCount,
            folderName = folderName,
            syncedAtMillis = nowMillis
        )
    }

    suspend fun uploadSingleItemPdf(
        accessToken: String,
        item: LabelHistoryItem,
        nowMillis: Long = System.currentTimeMillis()
    ): Pair<LabelHistoryItem, String> {
        val prefs = prefsRepository.getSnapshot()
        val folderName = prefs.sanitizedFolderName
        val folderId = remoteDataSource.ensureFolder(
            accessToken = accessToken,
            folderName = folderName,
            cachedFolderId = prefs.cachedFolderId
        )

        val pdfBytes = pdfRenderer(item)
        val fileName = buildDrivePdfFileName(item)
        val drivePdfId = remoteDataSource.uploadPdfFile(
            accessToken = accessToken,
            folderId = folderId,
            existingFileId = item.drivePdfFileId.takeIf { it.isNotBlank() },
            fileName = fileName,
            pdfBytes = pdfBytes
        )

        val syncedTimestamp = maxOf(nowMillis, item.updatedAtMillis)
        val updatedItem = historyRepository.updateDriveMetadata(
            item = item,
            drivePdfFileId = drivePdfId,
            lastSyncedAtMillis = syncedTimestamp
        )

        prefsRepository.setDriveConnected(true)
        return updatedItem to folderName
    }

    suspend fun uploadAllHistoryPdfs(
        accessToken: String,
        nowMillis: Long = System.currentTimeMillis()
    ): Pair<Int, String> {
        val prefs = prefsRepository.getSnapshot()
        val folderName = prefs.sanitizedFolderName
        val folderId = remoteDataSource.ensureFolder(
            accessToken = accessToken,
            folderName = folderName,
            cachedFolderId = prefs.cachedFolderId
        )

        val localItems = historyRepository.getAllHistory()
        var uploadedCount = 0
        val updatedItems = localItems.map { item ->
            val pdfBytes = pdfRenderer(item)
            val fileName = buildDrivePdfFileName(item)
            val pdfId = remoteDataSource.uploadPdfFile(
                accessToken = accessToken,
                folderId = folderId,
                existingFileId = item.drivePdfFileId.takeIf { it.isNotBlank() },
                fileName = fileName,
                pdfBytes = pdfBytes
            )
            uploadedCount++
            item.copy(
                drivePdfFileId = pdfId,
                lastSyncedAtMillis = maxOf(nowMillis, item.updatedAtMillis)
            )
        }

        if (updatedItems.isNotEmpty()) {
            historyRepository.upsertSyncedItems(updatedItems)
        }

        val remoteFile = remoteDataSource.downloadSyncJson(
            accessToken = accessToken,
            folderId = folderId,
            fileName = DriveSyncPreferences.SYNC_JSON_FILE_NAME,
            cachedFileId = prefs.cachedSyncFileId
        )
        val outgoingJson = DriveSyncPayloadCodec.encode(
            DriveSyncPayload(
                schemaVersion = 1,
                exportedAtMillis = nowMillis,
                items = updatedItems,
                deletedTombstones = prefs.deletedTombstones
            )
        )
        val syncFileId = remoteDataSource.uploadSyncJson(
            accessToken = accessToken,
            folderId = folderId,
            existingFileId = remoteFile?.fileId ?: prefs.cachedSyncFileId.takeIf { it.isNotBlank() },
            fileName = DriveSyncPreferences.SYNC_JSON_FILE_NAME,
            jsonContent = outgoingJson
        )

        prefsRepository.updateAfterSyncSuccess(
            folderId = folderId,
            syncFileId = syncFileId,
            mergedTombstones = prefs.deletedTombstones,
            syncedAtMillis = nowMillis,
            statusMessage = "$uploadedCount PDF dicadangkan ke \"$folderName\""
        )

        return uploadedCount to folderName
    }

    companion object {
        fun buildDrivePdfFileName(item: LabelHistoryItem): String {
            val cleanWaybill = item.waybillNumber
                .replace(Regex("[^A-Za-z0-9_-]"), "_")
                .take(40)
                .ifBlank { "Resi" }
            val shortId = item.id
                .replace(Regex("[^A-Za-z0-9]"), "")
                .take(6)
                .ifBlank { "001" }
            return "Resi_${cleanWaybill}_${shortId}.pdf"
        }

        fun computeMerge(
            mode: DriveSyncMode,
            localItems: List<LabelHistoryItem>,
            localTombstones: Map<String, Long>,
            remoteItems: List<LabelHistoryItem>,
            remoteTombstones: Map<String, Long>,
            syncTimestampMillis: Long
        ): HistoryMergeComputation {
            val localMap = localItems.associateBy { it.id }
            val remoteMap = remoteItems.associateBy { it.id }

            return when (mode) {
                DriveSyncMode.UPLOAD_ONLY -> {
                    val syncedLocals = localItems.map { item ->
                        val inheritedPdfId = item.drivePdfFileId.ifBlank {
                            remoteMap[item.id]?.drivePdfFileId.orEmpty()
                        }
                        item.copy(
                            drivePdfFileId = inheritedPdfId,
                            lastSyncedAtMillis = maxOf(syncTimestampMillis, item.updatedAtMillis)
                        )
                    }.sortedByDescending { it.updatedAtMillis }

                    val uploadedCount = localItems.count { local ->
                        val remote = remoteMap[local.id]
                        remote == null || local.updatedAtMillis > remote.updatedAtMillis
                    }

                    HistoryMergeComputation(
                        finalItems = syncedLocals,
                        mergedTombstones = localTombstones,
                        itemsToUpsertLocally = syncedLocals,
                        idsToDeleteLocally = emptySet(),
                        shouldUploadRemoteJson = true,
                        uploadedItemCount = uploadedCount,
                        restoredItemCount = 0
                    )
                }

                DriveSyncMode.RESTORE_ONLY -> {
                    var restoredCount = 0
                    val toUpsert = mutableListOf<LabelHistoryItem>()
                    val mergedMap = localMap.toMutableMap()

                    for (remote in remoteItems) {
                        if (remote.id.isBlank()) continue
                        val local = localMap[remote.id]
                        if (local == null || remote.updatedAtMillis > local.updatedAtMillis) {
                            val syncedItem = remote.copy(
                                capturedImagePath = remote.capturedImagePath.ifBlank {
                                    local?.capturedImagePath.orEmpty()
                                },
                                lastSyncedAtMillis = maxOf(syncTimestampMillis, remote.updatedAtMillis)
                            )
                            mergedMap[remote.id] = syncedItem
                            toUpsert.add(syncedItem)
                            restoredCount++
                        }
                    }

                    val finalSorted = mergedMap.values.sortedByDescending { it.updatedAtMillis }
                    HistoryMergeComputation(
                        finalItems = finalSorted,
                        mergedTombstones = localTombstones,
                        itemsToUpsertLocally = toUpsert,
                        idsToDeleteLocally = emptySet(),
                        shouldUploadRemoteJson = false,
                        uploadedItemCount = 0,
                        restoredItemCount = restoredCount
                    )
                }

                DriveSyncMode.TWO_WAY_MERGE -> {
                    val mergedTombstones = mutableMapOf<String, Long>()
                    for ((id, ts) in localTombstones) {
                        mergedTombstones[id] = maxOf(mergedTombstones[id] ?: 0L, ts)
                    }
                    for ((id, ts) in remoteTombstones) {
                        mergedTombstones[id] = maxOf(mergedTombstones[id] ?: 0L, ts)
                    }

                    val allIds = (localMap.keys + remoteMap.keys).filter { it.isNotBlank() }
                    val finalItems = mutableListOf<LabelHistoryItem>()
                    val toUpsertLocally = mutableListOf<LabelHistoryItem>()
                    val idsToDeleteLocally = mutableSetOf<String>()
                    var uploadedCount = 0
                    var restoredCount = 0

                    for (id in allIds) {
                        val local = localMap[id]
                        val remote = remoteMap[id]
                        val newestItem = when {
                            local != null && remote != null -> {
                                if (local.updatedAtMillis >= remote.updatedAtMillis) {
                                    local.copy(
                                        drivePdfFileId = local.drivePdfFileId.ifBlank { remote.drivePdfFileId },
                                        capturedImagePath = local.capturedImagePath.ifBlank { remote.capturedImagePath }
                                    )
                                } else {
                                    remote.copy(
                                        drivePdfFileId = remote.drivePdfFileId.ifBlank { local.drivePdfFileId },
                                        capturedImagePath = remote.capturedImagePath.ifBlank { local.capturedImagePath }
                                    )
                                }
                            }
                            local != null -> local
                            else -> remote!!
                        }

                        val deletedAt = mergedTombstones[id] ?: 0L
                        if (deletedAt > 0L && deletedAt >= newestItem.updatedAtMillis) {
                            if (local != null) {
                                idsToDeleteLocally.add(id)
                            }
                            continue
                        } else if (deletedAt > 0L) {
                            // Item was updated more recently than tombstone
                            mergedTombstones.remove(id)
                        }

                        val markedSynced = newestItem.copy(
                            lastSyncedAtMillis = maxOf(syncTimestampMillis, newestItem.updatedAtMillis)
                        )
                        finalItems.add(markedSynced)

                        if (local == null || remote != null && remote.updatedAtMillis > local.updatedAtMillis) {
                            restoredCount++
                            toUpsertLocally.add(markedSynced)
                        } else {
                            if (remote == null || local.updatedAtMillis > remote.updatedAtMillis) {
                                uploadedCount++
                            }
                            if (local.lastSyncedAtMillis < markedSynced.lastSyncedAtMillis ||
                                local.drivePdfFileId != markedSynced.drivePdfFileId
                            ) {
                                toUpsertLocally.add(markedSynced)
                            }
                        }
                    }

                    finalItems.sortByDescending { it.updatedAtMillis }

                    HistoryMergeComputation(
                        finalItems = finalItems,
                        mergedTombstones = mergedTombstones,
                        itemsToUpsertLocally = toUpsertLocally,
                        idsToDeleteLocally = idsToDeleteLocally,
                        shouldUploadRemoteJson = true,
                        uploadedItemCount = uploadedCount,
                        restoredItemCount = restoredCount
                    )
                }
            }
        }
    }
}

private fun defaultRenderItemPdfBytes(item: LabelHistoryItem): ByteArray {
    val output = ByteArrayOutputStream(16_384)
    val storedCapturedBitmap = if (item.capturedImagePath.isNotBlank()) {
        CapturedDocumentStorage.loadCapturedBitmapBlocking(item.capturedImagePath)
    } else {
        null
    }
    val effectiveSource = if (
        item.resolvedRenderSource() == PdfRenderSource.CAPTURED_DOCUMENT &&
        storedCapturedBitmap != null
    ) {
        PdfRenderSource.CAPTURED_DOCUMENT
    } else {
        PdfRenderSource.VECTOR_RECONSTRUCTION
    }
    ShippingLabelPdfGenerator.writePdfToStream(
        outputStream = output,
        data = item.toShippingLabelData(),
        paperPreset = item.resolvedPaperPreset(),
        renderSource = effectiveSource,
        referenceBitmap = null,
        capturedBitmap = storedCapturedBitmap
    )
    return output.toByteArray()
}
