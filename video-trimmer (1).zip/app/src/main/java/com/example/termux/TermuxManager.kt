package com.example.termux

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.util.Log
import com.example.util.MediaUtils
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

/**
 * Manajer untuk integrasi eksekusi perintah pemotongan video FFmpeg melalui aplikasi Termux.
 * Mendukung deteksi instalasi Termux, pembuatan perintah CLI,
 * pengiriman intent `com.termux.RUN_COMMAND`, penyalinan ke clipboard,
 * serta pembuatan file skrip shell (.sh).
 */
object TermuxManager {

    private const val TAG = "TermuxManager"
    const val TERMUX_PACKAGE_NAME = "com.termux"
    const val TERMUX_FDROID_URL = "https://f-droid.org/packages/com.termux/"
    const val TERMUX_SERVICE_NAME = "com.termux.app.RunCommandService"

    // Konstanta Intent Termux:Tasker / RUN_COMMAND
    private const val ACTION_RUN_COMMAND = "com.termux.RUN_COMMAND"
    private const val EXTRA_RUN_COMMAND_PATH = "com.termux.RUN_COMMAND_PATH"
    private const val EXTRA_RUN_COMMAND_ARGUMENTS = "com.termux.RUN_COMMAND_ARGUMENTS"
    private const val EXTRA_RUN_COMMAND_WORKDIR = "com.termux.RUN_COMMAND_WORKDIR"
    private const val EXTRA_RUN_COMMAND_BACKGROUND = "com.termux.RUN_COMMAND_BACKGROUND"
    private const val EXTRA_RUN_COMMAND_SESSION_ACTION = "com.termux.RUN_COMMAND_SESSION_ACTION"

    /**
     * Memeriksa apakah aplikasi Termux terpasang pada perangkat Android pengguna.
     */
    fun isTermuxInstalled(context: Context): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(
                    TERMUX_PACKAGE_NAME,
                    PackageManager.PackageInfoFlags.of(0)
                )
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(TERMUX_PACKAGE_NAME, 0)
            }
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        } catch (e: Exception) {
            Log.w(TAG, "Gagal memeriksa paket Termux: ${e.message}")
            false
        }
    }

    /**
     * Menghasilkan string perintah FFmpeg siap pakai yang dapat langsung dijalankan di Termux.
     *
     * @param inputPath Lokasi absolut file input
     * @param outputPath Lokasi absolut file output
     * @param startSeconds Detik awal pemotongan
     * @param endSeconds Detik akhir pemotongan
     * @param useStreamCopy Menggunakan '-c copy' jika true
     */
    fun generateTermuxCommand(
        inputPath: String,
        outputPath: String,
        startSeconds: Double,
        endSeconds: Double,
        useStreamCopy: Boolean = true
    ): String {
        val durationSec = (endSeconds - startSeconds).coerceAtLeast(0.1)
        val startStr = String.format(Locale.US, "%.3f", startSeconds)
        val durationStr = String.format(Locale.US, "%.3f", durationSec)

        val codecFlag = if (useStreamCopy) "-c copy" else "-c:v libx264 -c:a aac"

        return "ffmpeg -y -ss $startStr -t $durationStr -i \"$inputPath\" $codecFlag \"$outputPath\""
    }

    /**
     * Menghasilkan skrip instalasi paket jika pengguna baru pertama kali memasang Termux.
     */
    fun generateFullTermuxScript(
        inputPath: String,
        outputPath: String,
        startSeconds: Double,
        endSeconds: Double,
        useStreamCopy: Boolean = true
    ): String {
        val ffmpegCmd = generateTermuxCommand(inputPath, outputPath, startSeconds, endSeconds, useStreamCopy)
        return """
            # Perintah pemotongan video via Termux
            # Pastikan paket ffmpeg telah terpasang:
            # pkg update && pkg install ffmpeg -y
            
            $ffmpegCmd
            
            echo "Pemotongan video selesai: $outputPath"
        """.trimIndent()
    }

    /**
     * Mengirimkan perintah ke Termux menggunakan service intent `com.termux.RUN_COMMAND`.
     * Catatan: Memerlukan pengaturan `allow-external-apps = true` di file ~/.termux/termux.properties.
     */
    fun executeViaTermuxService(
        context: Context,
        command: String,
        runInBackground: Boolean = false
    ): Result<Unit> {
        return try {
            val intent = Intent(ACTION_RUN_COMMAND).apply {
                setPackage(TERMUX_PACKAGE_NAME)
                component = ComponentName(TERMUX_PACKAGE_NAME, TERMUX_SERVICE_NAME)
                putExtra(EXTRA_RUN_COMMAND_PATH, "/data/data/com.termux/files/usr/bin/bash")
                putExtra(EXTRA_RUN_COMMAND_ARGUMENTS, arrayOf("-c", command))
                putExtra(EXTRA_RUN_COMMAND_WORKDIR, "/data/data/com.termux/files/home")
                putExtra(EXTRA_RUN_COMMAND_BACKGROUND, runInBackground)
                putExtra(EXTRA_RUN_COMMAND_SESSION_ACTION, "0") // 0: Buka sesi terminal baru jika foreground
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }

            Log.d(TAG, "Berhasil mengirim RUN_COMMAND intent ke Termux")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Gagal menjalankan RUN_COMMAND di Termux: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Membuka aplikasi Termux secara langsung.
     */
    fun launchTermux(context: Context): Boolean {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(TERMUX_PACKAGE_NAME)
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            true
        } else {
            false
        }
    }

    /**
     * Membuka halaman unduhan F-Droid Termux pada browser.
     */
    fun openTermuxDownloadPage(context: Context) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(TERMUX_FDROID_URL)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Gagal membuka link unduhan Termux: ${e.message}")
        }
    }

    /**
     * Menyalin teks perintah ke clipboard Android.
     */
    fun copyToClipboard(context: Context, text: String, label: String = "Perintah Termux"): Boolean {
        return try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText(label, text)
            clipboard.setPrimaryClip(clip)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Gagal menyalin ke clipboard: ${e.message}")
            false
        }
    }

    /**
     * Menyimpan perintah ke file skrip shell (.sh) di cache agar mudah dieksekusi atau dibagikan.
     */
    fun exportScriptFile(context: Context, scriptContent: String): Result<File> {
        return try {
            val scriptFile = File(context.cacheDir, "trim_video_termux.sh")
            FileOutputStream(scriptFile).use { output ->
                output.write(scriptContent.toByteArray(Charsets.UTF_8))
            }
            scriptFile.setExecutable(true, false)
            scriptFile.setReadable(true, false)
            Result.success(scriptFile)
        } catch (e: Exception) {
            Log.e(TAG, "Gagal membuat file skrip: ${e.message}", e)
            Result.failure(e)
        }
    }
}
