package com.example.data.repository

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.local.LabelHistoryDao
import com.example.model.HistoryActionType
import com.example.model.LabelHistoryItem
import com.example.model.PaperSizePreset
import com.example.model.ShippingLabelData
import com.example.model.toHistoryItem
import java.util.UUID
import kotlinx.coroutines.flow.Flow

class LabelHistoryRepository(
    private val dao: LabelHistoryDao
) {
    constructor(context: Context) : this(
        AppDatabase.getInstance(context).labelHistoryDao()
    )

    fun observeHistory(): Flow<List<LabelHistoryItem>> = dao.observeAllHistory()

    suspend fun getHistoryItem(historyId: String): LabelHistoryItem? {
        return dao.getHistoryById(historyId)
    }

    suspend fun saveHistoryEntry(
        data: ShippingLabelData,
        paperPreset: PaperSizePreset,
        actionLabel: String = HistoryActionType.SAVED
    ): LabelHistoryItem {
        val now = System.currentTimeMillis()
        val item = data.toHistoryItem(
            paperPreset = paperPreset,
            actionLabel = actionLabel,
            id = UUID.randomUUID().toString(),
            createdAtMillis = now,
            updatedAtMillis = now
        )
        dao.upsertHistoryItem(item)
        return item
    }

    suspend fun updateHistoryEntry(
        existingItem: LabelHistoryItem,
        updatedData: ShippingLabelData,
        paperPreset: PaperSizePreset,
        actionLabel: String = existingItem.actionLabel
    ): LabelHistoryItem {
        require(existingItem.id.isNotBlank()) { "ID riwayat tidak boleh kosong untuk pembaruan" }
        val now = System.currentTimeMillis().coerceAtLeast(existingItem.createdAtMillis)
        val updated = updatedData.toHistoryItem(
            paperPreset = paperPreset,
            actionLabel = actionLabel,
            id = existingItem.id,
            createdAtMillis = existingItem.createdAtMillis,
            updatedAtMillis = now
        )
        dao.upsertHistoryItem(updated)
        return updated
    }

    suspend fun deleteHistoryEntry(historyId: String) {
        require(historyId.isNotBlank()) { "ID riwayat tidak boleh kosong" }
        dao.deleteHistoryById(historyId)
    }
}
