# Rencana Implementasi: Pencantuman Otomatis Dua Nama Mekanik pada Dokumen Cetak PDF

Berdasarkan permintaan pengguna dan jawaban klarifikasi:
1. **Deteksi Data Mekanik**: Pada baris item dengan nomor Work Order yang sama, sistem memeriksa kolom `tipe` yang memuat `mekanik` (atau `teknisi`/`jasa`) dan mengambil seluruh nama mekanik yang berbeda dari kolom `deskripsi`.
2. **Opsi 1 (Cetak Ringkas 2 Kolom SPJ)**: Nama kedua mekanik dicantumkan langsung di samping label *"Dikerjakan oleh, "* (misalnya: `Dikerjakan oleh, MEKANIK 1 / MEKANIK 2`) pada bagian pengesahan bawah.
3. **Opsi 2 (Cetak Full Detail A4)**: Menampilkan kedua nama mekanik secara terstruktur pada area tanda tangan pengesahan pengerjaan bengkel (baik bersandingan maupun baris terpisah Mekanik 1 & Mekanik 2).
4. **Opsi 3 (Cetak Ringkas 3 Kolom LX-300)**: Menerapkan format yang sama dengan Opsi 1 di samping label *"Dikerjakan oleh, "* agar selaras dan konsisten.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> - **Ekstraksi Otomatis Multi-Mekanik**: Sistem akan memindai seluruh item pada WO bersangkutan. Jika ditemukan lebih dari 1 nama mekanik unik (misalnya "SLAMET" dan "AZIZ"), sistem akan otomatis menggabungkannya dengan pemisah `" / "` atau format dua nama terpisah.
> - **Penempatan Opsi 1 & 3**: Sesuai instruksi khusus pengguna, nama kedua mekanik diletakkan langsung berdampingan dengan label *"Dikerjakan oleh, [NAMA 1] / [NAMA 2]"*.
> - **Penempatan Opsi 2**: Menyediakan slot identitas dan tanda tangan yang memadai untuk kedua mekanik serta mandor/ka. regu.

---

## 1. Overview & Core Concept

- **Tujuan**: Mengakomodasi pekerjaan servis armada yang ditangani oleh 2 teknisi/mekanik sekaligus dalam satu nomor Work Order, sehingga dokumen fisik maupun laporan administrasi secara akurat merefleksikan kedua personel yang bertanggung jawab.
- **Pengguna**: Petugas administrasi bengkel, Mandor/Ka. Regu, dan Teknisi Armada.

---

## 2. User Experience & Visual Design

### Alur Tampilan Dokumen Cetak

```
================================================================================
TAMPILAN AREA PENGESAHAN DOKUMEN CETAK (OPSI 1 & OPSI 3)
================================================================================
Dikerjakan oleh, AZIZ / SLAMET                           Disetujui,
                                                         ( Ka. Regu / Mandor )
Tanda Tangan : _______________________

================================================================================
TAMPILAN AREA PENGESAHAN DOKUMEN CETAK (OPSI 2 - LAPORAN DETAIL A4)
================================================================================
┌───────────────────────┬───────────────────────┬───────────────────────┐
│ Dikerjakan oleh,      │ Dikerjakan oleh,      │ Disetujui oleh,       │
│ Mekanik 1 : AZIZ      │ Mekanik 2 : SLAMET    │ Nama : (Ka. Regu)     │
│ Tanda Tangan: _______ │ Tanda Tangan: _______ │ Tanda Tangan: _______ │
└───────────────────────┴───────────────────────┴───────────────────────┘
```

---

## 3. Key Technical Decisions & Strategy

### A. Ekstraksi Nama Mekanik Dinamis (`extractDistinctMechanics`)
Membuat fungsi utilitas terpadu di `WorkOrderPdfGenerator.kt`:
1. Memeriksa setiap item pada daftar `items`:
   - Mengecek baris dengan `tipe.contains("mekanik")`, `tipe.contains("teknisi")`, atau pola teks `mekanik: ...` / `teknisi: ...` pada deskripsi dan catatan.
2. Membersihkan prefiks non-nama:
   - Menghapus awalan `MEKANIK :`, `TEKNISI -`, dll.
   - Melakukan `trim()`, `uppercase()`, serta mengabaikan entri kosong atau kata umum seperti `JASA`, `BIAYA`, `-`.
3. Menghasilkan daftar nama mekanik unik (`List<String>`).
4. Jika tidak ada mekanik yang terdeteksi, menggunakan nilai default atau pemohon armada.

### B. Pembaruan Opsi 1 (`generateCompactOrderKerjaPdf`)
- Memanggil `extractDistinctMechanics(items)`.
- Jika terdapat 2 mekanik:
  - Format label: `Dikerjakan oleh, MEKANIK 1 / MEKANIK 2`
  - Memastikan batas lebar teks aman dari area kanan (`Disetujui,`).
- Bidang *Pemohon* pada metadata atas juga menampilkan kedua nama mekanik atau menyesuaikan kapasitas lebar kolom.

### C. Pembaruan Opsi 2 (`generateFullDetailPdf`)
- Jika terdapat 2 mekanik yang berbeda:
  - Membagi area pengesahan menjadi 3 kolom:
    1. Kolom Kiri: Mekanik 1 (Nama & Tanda Tangan)
    2. Kolom Tengah: Mekanik 2 (Nama & Tanda Tangan)
    3. Kolom Kanan: Disetujui oleh Ka. Regu / Mandor
- Jika hanya 1 mekanik:
  - Tetap menggunakan tata letak standar 2 kolom (Dikerjakan oleh & Disetujui oleh).

### D. Pembaruan Opsi 3 (`generateThreeColumnSpjPdf`)
- Menyesuaikan baris footer:
  - `Dikerjakan oleh, MEKANIK 1 / MEKANIK 2`
  - Menyediakan ruang tanda tangan yang proporsional.

---

## 4. Verification Plan

### Automated Compilation
- Menjalankan `compile_applet` untuk memverifikasi bahwa perubahan kode bersih tanpa galat kompilasi.

### Verification Scenarios
1. **Skenario 1 Mekanik**:
   - Membuka WO dengan 1 mekanik, memastikan tampilan dokumen tetap normal dengan 1 nama mekanik.
2. **Skenario 2 Mekanik Berbeda**:
   - Membuka WO yang memiliki 2 baris item bertipe mekanik/jasa dengan nama berbeda (misal item 1: AZIZ, item 2: SLAMET).
   - Memeriksa Pratinjau Opsi 1: Nama tertulis `Dikerjakan oleh, AZIZ / SLAMET`.
   - Memeriksa Pratinjau Opsi 2: Kolom pengesahan menampilkan kedua mekanik terpisah.
   - Memeriksa Pratinjau Opsi 3: Nama tertulis `Dikerjakan oleh, AZIZ / SLAMET`.

---

## 5. Status Pelaksanaan
- [x] Ekstraksi otomatis multi-mekanik berdasarkan baris nomor WO yang sama pada kolom tipe dan deskripsi (`extractDistinctMechanics`).
- [x] Opsi Cetak 1: Pencantuman kedua nama mekanik di samping teks `Dikerjakan oleh, MEKANIK 1 / MEKANIK 2` serta pemohon.
- [x] Opsi Cetak 2: Pengesahan tanda tangan multi-kolom rapi untuk Mekanik 1, Mekanik 2, dan Ka. Regu, serta filter part agar tidak memuat baris mekanik.
- [x] Opsi Cetak 3: Pencantuman nama kedua mekanik di samping teks `Dikerjakan oleh, ` dan pemohon.
- [x] Verifikasi unit test (`testDebugUnitTest`) berhasil 100% dan verifikasi kompilasi build sukses.
