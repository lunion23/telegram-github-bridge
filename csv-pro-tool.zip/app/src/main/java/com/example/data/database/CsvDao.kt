package com.example.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.ColumnConfigEntity
import com.example.data.model.CsvRowEntity
import kotlinx.coroutines.flow.Flow

data class ConsolidatedGroupTuple(
    val recordId: String,
    val primaryDate: String?,
    val customerOrEntity: String?,
    val category: String?,
    val status: String?,
    val itemCount: Int
)

@Dao
interface CsvDao {
    @Query("SELECT COUNT(*) FROM csv_rows")
    suspend fun getRowCountDirect(): Int

    @Query("""
        SELECT COUNT(*) FROM csv_rows 
        WHERE (:query = '' OR 
               recordId LIKE '%' || :query || '%' OR 
               col0 LIKE '%' || :query || '%' OR 
               col1 LIKE '%' || :query || '%' OR 
               col2 LIKE '%' || :query || '%' OR 
               col3 LIKE '%' || :query || '%' OR 
               col4 LIKE '%' || :query || '%')
          AND (:status IS NULL OR :status = '' OR col9 = :status)
          AND (:category IS NULL OR :category = '' OR col3 = :category)
    """)
    suspend fun getFilteredRowCount(
        query: String,
        status: String?,
        category: String?
    ): Int

    @Query("""
        SELECT * FROM csv_rows 
        WHERE (:query = '' OR 
               recordId LIKE '%' || :query || '%' OR 
               col0 LIKE '%' || :query || '%' OR 
               col1 LIKE '%' || :query || '%' OR 
               col2 LIKE '%' || :query || '%' OR 
               col3 LIKE '%' || :query || '%' OR 
               col4 LIKE '%' || :query || '%')
          AND (:status IS NULL OR :status = '' OR col9 = :status)
          AND (:category IS NULL OR :category = '' OR col3 = :category)
        ORDER BY id ASC
        LIMIT :limit OFFSET :offset
    """)
    suspend fun getPagedFilteredRows(
        query: String,
        status: String?,
        category: String?,
        limit: Int,
        offset: Int
    ): List<CsvRowEntity>

    // Stream reading for exports in safe chunks
    @Query("""
        SELECT * FROM csv_rows 
        WHERE (:query = '' OR 
               recordId LIKE '%' || :query || '%' OR 
               col0 LIKE '%' || :query || '%' OR 
               col1 LIKE '%' || :query || '%' OR 
               col2 LIKE '%' || :query || '%' OR 
               col3 LIKE '%' || :query || '%' OR 
               col4 LIKE '%' || :query || '%')
          AND (:status IS NULL OR :status = '' OR col9 = :status)
          AND (:category IS NULL OR :category = '' OR col3 = :category)
        ORDER BY id ASC
        LIMIT :limit OFFSET :offset
    """)
    suspend fun getExportChunk(
        query: String,
        status: String?,
        category: String?,
        limit: Int,
        offset: Int
    ): List<CsvRowEntity>

    // Fast indexed distinct record IDs (Zero OOM - avoids in-memory GROUP BY on millions of rows)
    @Query("""
        SELECT DISTINCT recordId FROM csv_rows
        WHERE (:query = '' OR 
               recordId LIKE '%' || :query || '%' OR 
               col0 LIKE '%' || :query || '%' OR 
               col1 LIKE '%' || :query || '%' OR 
               col2 LIKE '%' || :query || '%' OR 
               col3 LIKE '%' || :query || '%' OR 
               col4 LIKE '%' || :query || '%')
          AND (:status IS NULL OR :status = '' OR col9 = :status)
          AND (:category IS NULL OR :category = '' OR col3 = :category)
          AND recordId != ''
        LIMIT :limit OFFSET :offset
    """)
    suspend fun getDistinctRecordIdsPaged(
        query: String,
        status: String?,
        category: String?,
        limit: Int,
        offset: Int
    ): List<String>

    @Query("""
        SELECT 
            recordId,
            col1 AS primaryDate,
            col2 AS customerOrEntity,
            col3 AS category,
            col9 AS status,
            (SELECT COUNT(*) FROM csv_rows r2 WHERE r2.recordId = :recordId OR r2.col0 = :recordId) AS itemCount
        FROM csv_rows
        WHERE recordId = :recordId OR col0 = :recordId
        LIMIT 1
    """)
    suspend fun getGroupSummaryForRecordId(recordId: String): ConsolidatedGroupTuple?

    // Lazy load child rows for a specific card
    @Query("SELECT * FROM csv_rows WHERE recordId = :recordId OR col0 = :recordId ORDER BY id ASC LIMIT :limit")
    suspend fun getRowsByRecordId(recordId: String, limit: Int = 100): List<CsvRowEntity>

    // Fast non-blocking distinct queries with LIMIT 50
    @Query("SELECT DISTINCT col9 FROM csv_rows WHERE col9 != '' LIMIT 50")
    suspend fun getDistinctStatusesDirect(): List<String>

    @Query("SELECT DISTINCT col3 FROM csv_rows WHERE col3 != '' LIMIT 50")
    suspend fun getDistinctCategoriesDirect(): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRow(row: CsvRowEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(rows: List<CsvRowEntity>)

    @Update
    suspend fun updateRow(row: CsvRowEntity)

    @Query("DELETE FROM csv_rows WHERE id = :id")
    suspend fun deleteRowById(id: Long)

    @Query("DELETE FROM csv_rows WHERE recordId = :recordId OR col0 = :recordId")
    suspend fun deleteByRecordId(recordId: String)

    @Query("DELETE FROM csv_rows")
    suspend fun clearAllRows()

    // Column Configs
    @Query("SELECT * FROM column_configs ORDER BY displayOrder ASC")
    fun getAllColumnConfigs(): Flow<List<ColumnConfigEntity>>

    @Query("SELECT * FROM column_configs ORDER BY displayOrder ASC")
    suspend fun getAllColumnConfigsDirect(): List<ColumnConfigEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertColumnConfigs(configs: List<ColumnConfigEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertColumnConfig(config: ColumnConfigEntity)

    @Update
    suspend fun updateColumnConfig(config: ColumnConfigEntity)

    @Query("DELETE FROM column_configs WHERE colIndex = :colIndex")
    suspend fun deleteColumnConfigByIndex(colIndex: Int)

    @Query("DELETE FROM column_configs")
    suspend fun clearColumnConfigs()
}
