package com.example.data.remote

import com.example.data.model.Note
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class FirestoreNote(
    @DocumentId
    val id: String = "",
    val userId: String = "",
    val title: String = "",
    val content: String = "",
    val tags: List<String> = emptyList(),
    val isPinned: Boolean = false,
    val fileExtension: String = "txt",
    @ServerTimestamp
    val createdAt: Timestamp? = null,
    @ServerTimestamp
    val updatedAt: Timestamp? = null
) {
    fun toDomain(): Note {
        val createdMillis = createdAt?.toDate()?.time ?: System.currentTimeMillis()
        val updatedMillis = updatedAt?.toDate()?.time ?: createdMillis
        return Note(
            id = id,
            userId = userId,
            title = title,
            content = content,
            tags = tags,
            isPinned = isPinned,
            fileExtension = fileExtension,
            createdAt = createdMillis,
            updatedAt = updatedMillis,
            isSynced = true
        )
    }

    companion object {
        fun fromDomain(note: Note): FirestoreNote {
            return FirestoreNote(
                id = note.id,
                userId = note.userId,
                title = note.title,
                content = note.content,
                tags = note.tags,
                isPinned = note.isPinned,
                fileExtension = note.fileExtension,
                createdAt = Timestamp(java.util.Date(note.createdAt)),
                updatedAt = Timestamp(java.util.Date(note.updatedAt))
            )
        }
    }
}
