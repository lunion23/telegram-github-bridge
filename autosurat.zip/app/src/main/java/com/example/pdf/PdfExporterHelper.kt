package com.example.pdf

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.TechnicalReport
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object PdfExporterHelper {

    fun downloadPdfToDevice(context: Context, report: TechnicalReport): Uri? {
        val tempPdf = PdfEngineGenerator.generatePdf(context, report)
        val fileName = "Laporan_Teknik_${report.noLaporan.replace("[^a-zA-Z0-9.-]".toRegex(), "_")}_${System.currentTimeMillis()}.pdf"

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(tempPdf).use { input ->
                            input.copyTo(out)
                        }
                    }
                    Toast.makeText(context, "PDF berhasil diunduh ke folder Download: $fileName", Toast.LENGTH_LONG).show()
                    uri
                } else {
                    fallbackInternalSave(context, tempPdf, fileName)
                }
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!downloadsDir.exists()) downloadsDir.mkdirs()
                val targetFile = File(downloadsDir, fileName)
                FileInputStream(tempPdf).use { input ->
                    FileOutputStream(targetFile).use { out ->
                        input.copyTo(out)
                    }
                }
                Toast.makeText(context, "PDF disimpan di: ${targetFile.absolutePath}", Toast.LENGTH_LONG).show()
                Uri.fromFile(targetFile)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            fallbackInternalSave(context, tempPdf, fileName)
        }
    }

    private fun fallbackInternalSave(context: Context, tempPdf: File, fileName: String): Uri? {
        return try {
            val docsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: context.filesDir
            val destFile = File(docsDir, fileName)
            tempPdf.copyTo(destFile, overwrite = true)
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", destFile)
            Toast.makeText(context, "PDF tersimpan: $fileName", Toast.LENGTH_SHORT).show()
            uri
        } catch (e: Exception) {
            Toast.makeText(context, "Gagal mengunduh: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            null
        }
    }

    fun sharePdf(context: Context, report: TechnicalReport) {
        val tempPdf = PdfEngineGenerator.generatePdf(context, report)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", tempPdf)

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Laporan Teknik: ${report.noLaporan} (${report.kode})")
            putExtra(Intent.EXTRA_TEXT, "Berikut adalah lampiran dokumen Laporan Teknik No: ${report.noLaporan} untuk unit ${report.kode} - ${report.kerusakan}.")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        context.startActivity(Intent.createChooser(intent, "Bagikan Laporan Teknik"))
    }

    fun printPdf(context: Context, report: TechnicalReport) {
        val tempPdf = PdfEngineGenerator.generatePdf(context, report)
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return

        val printAdapter = object : android.print.PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: android.os.CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: android.os.Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }
                val info = android.print.PrintDocumentInfo.Builder("Laporan_Teknik_${report.noLaporan}.pdf")
                    .setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build()
                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out android.print.PageRange>?,
                destination: android.os.ParcelFileDescriptor?,
                cancellationSignal: android.os.CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                try {
                    val input = FileInputStream(tempPdf)
                    val output = FileOutputStream(destination?.fileDescriptor)
                    val buffer = ByteArray(4096)
                    var bytesRead: Int
                    while (input.read(buffer).also { bytesRead = it } >= 0) {
                        output.write(buffer, 0, bytesRead)
                    }
                    input.close()
                    output.close()
                    callback?.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                }
            }
        }

        printManager.print("Laporan_Teknik_${report.kode}", printAdapter, PrintAttributes.Builder().build())
    }
}
