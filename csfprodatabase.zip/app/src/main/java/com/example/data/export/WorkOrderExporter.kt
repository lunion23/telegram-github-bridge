package com.example.data.export

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.example.data.model.WorkOrderItem
import com.example.data.model.WorkOrderSummary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object WorkOrderExporter {

    private val idrFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))

    /**
     * Exports a list of WorkOrderItem entries to CSV and triggers Android Share Intent.
     */
    suspend fun exportItemsToCsvAndShare(
        context: Context,
        items: List<WorkOrderItem>,
        title: String = "Laporan_Work_Order"
    ): File = withContext(Dispatchers.IO) {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "${title}_$timeStamp.csv"
        val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(exportDir, fileName)

        FileOutputStream(file).use { fos ->
            OutputStreamWriter(fos, Charsets.UTF_8).use { writer ->
                // Write UTF-8 BOM so Excel opens it with correct characters automatically
                fos.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))

                // Header
                writer.write("Name,MobilName,Trandate,KmCurrent,Keluhan,Tipe,Kode,Description,Catatan,StartTime,EndTime,Qty,Total,TotalPrice,ProductClass,NoChassis,NoMesin\n")

                for (item in items) {
                    val line = listOf(
                        escapeCsv(item.name),
                        escapeCsv(item.mobilName),
                        escapeCsv(item.trandateFormatted),
                        item.kmCurrent.toString(),
                        escapeCsv(item.keluhan),
                        escapeCsv(item.tipe),
                        escapeCsv(item.kode),
                        escapeCsv(item.description),
                        escapeCsv(item.catatan),
                        escapeCsv(item.startTime),
                        escapeCsv(item.endTime),
                        item.qty.toString(),
                        item.total.toString(),
                        item.totalPrice.toString(),
                        escapeCsv(item.productClass),
                        escapeCsv(item.noChassis),
                        escapeCsv(item.noMesin)
                    ).joinToString(",")
                    writer.write(line + "\n")
                }
                writer.flush()
            }
        }

        withContext(Dispatchers.Main) {
            shareFile(context, file, "text/csv", "Bagikan Laporan CSV Work Order")
        }

        return@withContext file
    }

    /**
     * Exports a specific single Work Order with aggregated summary & breakdown items.
     */
    suspend fun exportSingleWorkOrderReportAndShare(
        context: Context,
        summary: WorkOrderSummary,
        items: List<WorkOrderItem>
    ): File = withContext(Dispatchers.IO) {
        val safeWoName = summary.name.replace("/", "-").replace(" ", "_")
        val fileName = "Detail_WO_${safeWoName}.csv"
        val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(exportDir, fileName)

        FileOutputStream(file).use { fos ->
            OutputStreamWriter(fos, Charsets.UTF_8).use { writer ->
                fos.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))

                writer.write("=== LAPORAN DETAIL WORK ORDER BENGKEL & ARMADA ===\n")
                writer.write("Nomor WO,${escapeCsv(summary.name)}\n")
                writer.write("Armada / Plat,${escapeCsv(summary.mobilName)}\n")
                writer.write("Tanggal Transaksi,${escapeCsv(summary.trandateFormatted)}\n")
                writer.write("Odometer KM,${summary.kmCurrent} KM\n")
                writer.write("Keluhan Sopir,${escapeCsv(summary.keluhan)}\n")
                writer.write("Nomor Rangka (Chassis),${escapeCsv(summary.noChassis)}\n")
                writer.write("Nomor Mesin,${escapeCsv(summary.noMesin)}\n")
                writer.write("Total Item Pekerjaan,${summary.itemCount}\n")
                writer.write("Total Biaya Perbaikan,${idrFormat.format(summary.totalCost)}\n")
                writer.write("Waktu Pelaksanaan,${summary.startTime} s/d ${summary.endTime}\n\n")

                writer.write("--- RINCIAN PEKERJAAN & SPAREPART ---\n")
                writer.write("No,Tipe,Kode,Deskripsi,Kategori,Qty,Harga Total (IDR),Catatan\n")

                items.forEachIndexed { index, itm ->
                    val line = listOf(
                        (index + 1).toString(),
                        escapeCsv(itm.tipe),
                        escapeCsv(itm.kode),
                        escapeCsv(itm.description),
                        escapeCsv(itm.productClass),
                        itm.qty.toString(),
                        itm.totalPrice.toString(),
                        escapeCsv(itm.catatan)
                    ).joinToString(",")
                    writer.write(line + "\n")
                }
                writer.flush()
            }
        }

        withContext(Dispatchers.Main) {
            shareFile(context, file, "text/csv", "Laporan Detail WO ${summary.name}")
        }

        return@withContext file
    }

    private fun shareFile(context: Context, file: File, mimeType: String, chooserTitle: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, file.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(shareIntent, chooserTitle).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(chooser)
    }

    private fun escapeCsv(value: String): String {
        return if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            "\"" + value.replace("\"", "\"\"") + "\""
        } else {
            value
        }
    }
}
