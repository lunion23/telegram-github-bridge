package com.example.data.model

enum class WarrantyStatus(val label: String) {
    IN_WARRANTY("Masa Garansi"),
    AFTER_WARRANTY("Setelah Masa Garansi")
}
