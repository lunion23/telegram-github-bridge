package com.example.ui

import android.app.Application
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ffmpeg.BatchTrimParser
import com.example.ffmpeg.FFmpegBinaryLoader
import com.example.ffmpeg.FFmpegExecutionEngine
import com.example.ffmpeg.FFmpegProgressListener
import com.example.ffmpeg.TrimTimeRange
import com.example.termux.TermuxManager
import com.example.util.MediaUtils
import com.example.util.VideoMetadata
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

/**
 * Pilihan mode mesin pemotongan video:
 * - EMBEDDED: Menggunakan binary FFmpeg yang disematkan langsung di dalam aplikasi (mandiri tanpa aplikasi lain)
 * - TERMUX: Menggunakan integrasi aplikasi Termux via CLI / RUN_COMMAND Intent
 */
enum class EngineMode {
    EMBEDDED,
    TERMUX
}

/**
 * Status UI keseluruhan untuk layar Video Trimmer.
 */
data class TrimUiState(
    val engineMode: EngineMode = EngineMode.EMBEDDED,
    val isBinaryReady: Boolean = false,
    val binaryPath: String = "",
    val isTermuxInstalled: Boolean = false,
    val generatedTermuxCommand: String = "",
    val termuxFeedbackMessage: String? = null,
    val selectedVideo: VideoMetadata? = null,
    val localVideoFile: File? = null,
    val trimStartSeconds: Double = 0.0,
    val trimEndSeconds: Double = 0.0,
    val useFastStreamCopy: Boolean = true,
    val isTrimming: Boolean = false,
    val progressPercent: Int = 0,
    val currentTimeSeconds: Double = 0.0,
    val targetDurationSeconds: Double = 0.0,
    val recentLogs: List<String> = emptyList(),
    val trimmedOutputFile: File? = null,
    val trimElapsedTimeMs: Long = 0L,
    val errorMessage: String? = null,
    val statusMessage: String = "Menyiapkan aplikasi...",

    // State untuk Multi-Text Time Command Batch Trimming
    val batchTextCommand: String = "00:00-00:04\n00:04-00:08\n8-12",
    val isBatchTrimming: Boolean = false,
    val batchTotalCount: Int = 0,
    val batchCurrentIndex: Int = 0,
    val batchItemPercent: Int = 0,
    val batchOverallPercent: Int = 0,
    val batchParsedRanges: List<TrimTimeRange> = emptyList(),
    val batchTrimmedFiles: List<File> = emptyList()
)

/**
 * ViewModel yang mengelola state pemotongan video tunggal maupun batch multi-baris teks,
 * interaksi biner FFmpeg, opsi Termux, serta komunikasi antara background thread dan UI.
 */
class VideoTrimViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        private const val TAG = "VideoTrimViewModel"
        private const val MAX_LOGS_KEPT = 150
        private const val MAX_BATCH_LIMIT = 5
    }

    private val executionEngine = FFmpegExecutionEngine()
    private var batchJob: Job? = null

    private val _uiState = MutableStateFlow(TrimUiState())
    val uiState: StateFlow<TrimUiState> = _uiState.asStateFlow()

    init {
        initializeBinaryAndSample()
        checkTermuxInstallation()
        updateParsedBatchRanges(_uiState.value.batchTextCommand)
    }

    /**
     * Memeriksa status instalasi aplikasi Termux pada perangkat pengguna.
     */
    fun checkTermuxInstallation() {
        val context = getApplication<Application>()
        val installed = TermuxManager.isTermuxInstalled(context)
        _uiState.update { it.copy(isTermuxInstalled = installed) }
        updateTermuxCommand()
    }

    /**
     * Mengubah mode mesin (Biner Internal vs Termux).
     */
    fun setEngineMode(mode: EngineMode) {
        _uiState.update {
            it.copy(
                engineMode = mode,
                statusMessage = if (mode == EngineMode.TERMUX) "Mode Termux dipilih" else "Mode Biner Internal dipilih"
            )
        }
        if (mode == EngineMode.TERMUX) {
            checkTermuxInstallation()
            updateTermuxCommand()
        }
    }

    /**
     * Mempersiapkan binary FFmpeg di filesDir saat ViewModel pertama kali dibuat.
     */
    fun initializeBinaryAndSample() {
        viewModelScope.launch {
            val context = getApplication<Application>()
            _uiState.update { it.copy(statusMessage = "Memeriksa biner FFmpeg...") }

            val copyResult = FFmpegBinaryLoader.copyBinaryFromAssets(context)
            if (copyResult.isSuccess) {
                val file = copyResult.getOrThrow()
                _uiState.update {
                    it.copy(
                        isBinaryReady = true,
                        binaryPath = file.absolutePath,
                        statusMessage = "Biner FFmpeg siap dieksekusi"
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        isBinaryReady = false,
                        statusMessage = "Biner FFmpeg disiapkan dalam mode kompatibilitas"
                    )
                }
            }

            // Muat video sampel jika belum ada video yang dipilih
            if (_uiState.value.selectedVideo == null) {
                loadSampleVideo()
            }
        }
    }

    /**
     * Memuat video sampel bawaan dari assets agar pengguna dapat langsung menguji trimming.
     */
    fun loadSampleVideo() {
        viewModelScope.launch {
            val context = getApplication<Application>()
            _uiState.update { it.copy(statusMessage = "Memuat video sampel...") }

            val sampleResult = FFmpegBinaryLoader.copySampleVideoFromAssets(context)
            if (sampleResult.isSuccess) {
                val sampleFile = sampleResult.getOrThrow()
                val sampleUri = Uri.fromFile(sampleFile)
                val metadata = MediaUtils.extractVideoMetadata(context, sampleUri)

                if (metadata != null) {
                    val defaultEndSec = (metadata.durationSeconds * 0.65).coerceAtLeast(1.0)
                    _uiState.update {
                        it.copy(
                            selectedVideo = metadata,
                            localVideoFile = sampleFile,
                            trimStartSeconds = 0.0,
                            trimEndSeconds = defaultEndSec,
                            targetDurationSeconds = defaultEndSec,
                            trimmedOutputFile = null,
                            statusMessage = "Video sampel siap: ${metadata.formattedDuration}"
                        )
                    }
                    updateTermuxCommand()
                    updateParsedBatchRanges(_uiState.value.batchTextCommand)
                }
            }
        }
    }

    /**
     * Dipanggil ketika pengguna memilih video dari galeri / penyimpanan lokal.
     */
    fun onVideoSelected(uri: Uri) {
        viewModelScope.launch {
            val context = getApplication<Application>()
            _uiState.update {
                it.copy(
                    statusMessage = "Membaca metadata video...",
                    errorMessage = null
                )
            }

            val metadata = MediaUtils.extractVideoMetadata(context, uri)
            if (metadata == null) {
                _uiState.update {
                    it.copy(
                        errorMessage = "Gagal membaca format video yang dipilih",
                        statusMessage = "Format video tidak didukung"
                    )
                }
                return@launch
            }

            val cacheCopyResult = MediaUtils.copyUriToLocalCache(
                context = context,
                sourceUri = uri,
                destFileName = "input_${System.currentTimeMillis()}.mp4"
            )

            val localFile = cacheCopyResult.getOrNull()
            val totalSec = metadata.durationSeconds
            val defaultEnd = if (totalSec > 10.0) 10.0 else totalSec

            _uiState.update {
                it.copy(
                    selectedVideo = metadata,
                    localVideoFile = localFile,
                    trimStartSeconds = 0.0,
                    trimEndSeconds = defaultEnd,
                    targetDurationSeconds = defaultEnd,
                    trimmedOutputFile = null,
                    progressPercent = 0,
                    statusMessage = "Video dipilih: ${metadata.title} (${metadata.formattedDuration})"
                )
            }
            updateTermuxCommand()
            updateParsedBatchRanges(_uiState.value.batchTextCommand)
        }
    }

    /**
     * Memperbarui rentang pemotongan (start dan end dalam detik) untuk mode tunggal.
     */
    fun updateTrimRange(start: Double, end: Double) {
        val safeStart = start.coerceAtLeast(0.0)
        val maxDuration = _uiState.value.selectedVideo?.durationSeconds ?: 100.0
        val safeEnd = end.coerceIn(safeStart + 0.1, maxDuration)

        _uiState.update {
            it.copy(
                trimStartSeconds = safeStart,
                trimEndSeconds = safeEnd,
                targetDurationSeconds = safeEnd - safeStart
            )
        }
        updateTermuxCommand()
    }

    /**
     * Toggle mode stream copy (-c copy) vs re-encode.
     */
    fun toggleStreamCopy(enabled: Boolean) {
        _uiState.update { it.copy(useFastStreamCopy = enabled) }
        updateTermuxCommand()
    }

    /**
     * Memperbarui string perintah Termux secara dinamis.
     */
    private fun updateTermuxCommand() {
        val state = _uiState.value
        val context = getApplication<Application>()
        val inputPath = state.localVideoFile?.absolutePath ?: "/sdcard/Download/input_video.mp4"
        val outputDir = File(context.filesDir, "trimmed_videos")
        val outputPath = File(outputDir, "trim_termux_${System.currentTimeMillis()}.mp4").absolutePath

        val cmd = TermuxManager.generateTermuxCommand(
            inputPath = inputPath,
            outputPath = outputPath,
            startSeconds = state.trimStartSeconds,
            endSeconds = state.trimEndSeconds,
            useStreamCopy = state.useFastStreamCopy
        )

        _uiState.update { it.copy(generatedTermuxCommand = cmd) }
    }

    // =========================================================================
    // MULTI-TEXT TIME COMMAND BATCH TRIMMING
    // =========================================================================

    /**
     * Memperbarui teks perintah waktu multi-baris dari input pengguna
     * dan mem-parsing pratinjau rentang waktu yang dikenali.
     */
    fun onBatchTextChanged(newText: String) {
        _uiState.update { it.copy(batchTextCommand = newText) }
        updateParsedBatchRanges(newText)
    }

    /**
     * Mem-parsing teks multi-baris menjadi daftar rentang waktu (maksimal 5 teratas).
     */
    private fun updateParsedBatchRanges(text: String) {
        val maxDur = _uiState.value.selectedVideo?.durationSeconds ?: Double.MAX_VALUE
        val ranges = BatchTrimParser.parseMultiTextCommands(
            multiLineText = text,
            maxDurationSeconds = maxDur,
            maxLimit = MAX_BATCH_LIMIT
        )
        _uiState.update { it.copy(batchParsedRanges = ranges) }
    }

    /**
     * Menjalankan pemotongan batch berurutan berdasarkan baris teks yang dimasukkan.
     * Secara otomatis membatasi maksimal hingga 5 video teratas.
     */
    fun startBatchTrim() {
        val currentState = _uiState.value
        val context = getApplication<Application>()
        val inputFile = currentState.localVideoFile

        if (inputFile == null || !inputFile.exists()) {
            _uiState.update { it.copy(errorMessage = "Silakan pilih video terlebih dahulu.") }
            return
        }

        val maxDur = currentState.selectedVideo?.durationSeconds ?: Double.MAX_VALUE
        val ranges = BatchTrimParser.parseMultiTextCommands(
            multiLineText = currentState.batchTextCommand,
            maxDurationSeconds = maxDur,
            maxLimit = MAX_BATCH_LIMIT
        )

        if (ranges.isEmpty()) {
            _uiState.update {
                it.copy(
                    errorMessage = "Tidak ada format waktu yang valid. Contoh per baris: 00:00-00:05 atau 5-15."
                )
            }
            return
        }

        val outputDir = File(context.filesDir, "batch_trimmed_videos")
        if (!outputDir.exists()) outputDir.mkdirs()

        // Hentikan proses sebelumnya jika ada
        batchJob?.cancel()

        _uiState.update {
            it.copy(
                isBatchTrimming = true,
                batchTotalCount = ranges.size,
                batchCurrentIndex = 0,
                batchItemPercent = 0,
                batchOverallPercent = 0,
                batchTrimmedFiles = emptyList(),
                errorMessage = null,
                statusMessage = "Memulai Batch Trimming (${ranges.size} segmen)...",
                recentLogs = listOf("Memulai Batch Trimming untuk ${ranges.size} segmen...")
            )
        }

        batchJob = viewModelScope.launch {
            val completedFiles = mutableListOf<File>()
            val totalSegments = ranges.size

            try {
                for ((index, range) in ranges.withIndex()) {
                    val segmentNumber = index + 1
                    val outputFile = File(
                        outputDir,
                        "batch_seg_${segmentNumber}_${System.currentTimeMillis()}.mp4"
                    )

                    _uiState.update { current ->
                        current.copy(
                            batchCurrentIndex = segmentNumber,
                            batchItemPercent = 0,
                            statusMessage = "Memproses segmen $segmentNumber dari $totalSegments: ${range.formattedDisplay}",
                            recentLogs = (current.recentLogs + "--- Segmen $segmentNumber/$totalSegments: ${range.formattedDisplay} ---").takeLast(MAX_LOGS_KEPT)
                        )
                    }

                    // Eksekusi segmen menggunakan executeTrimSuspend
                    val result = executionEngine.executeTrimSuspend(
                        context = context,
                        inputFile = inputFile,
                        outputFile = outputFile,
                        startSeconds = range.startSeconds,
                        endSeconds = range.endSeconds,
                        useStreamCopy = currentState.useFastStreamCopy,
                        onProgress = { percent, currentSec, targetSec ->
                            val overall = (((index.toDouble() + (percent / 100.0)) / totalSegments) * 100).toInt().coerceIn(0, 100)
                            _uiState.update {
                                it.copy(
                                    batchItemPercent = percent,
                                    batchOverallPercent = overall,
                                    currentTimeSeconds = currentSec,
                                    targetDurationSeconds = targetSec
                                )
                            }
                        },
                        onLog = { logLine ->
                            _uiState.update { current ->
                                (current.copy(recentLogs = (current.recentLogs + logLine).takeLast(MAX_LOGS_KEPT)))
                            }
                        }
                    )

                    if (result.isSuccess) {
                        val file = result.getOrThrow()
                        completedFiles.add(file)
                        _uiState.update {
                            it.copy(batchTrimmedFiles = completedFiles.toList())
                        }
                    } else {
                        val err = result.exceptionOrNull()?.message ?: "Gagal memotong segmen $segmentNumber"
                        Log.e(TAG, "Error pada segmen $segmentNumber: $err")
                        _uiState.update { current ->
                            current.copy(
                                recentLogs = (current.recentLogs + "PERINGATAN: Segmen $segmentNumber gagal ($err)").takeLast(MAX_LOGS_KEPT)
                            )
                        }
                    }
                }

                _uiState.update {
                    it.copy(
                        isBatchTrimming = false,
                        batchOverallPercent = 100,
                        statusMessage = "Batch selesai! ${completedFiles.size} dari $totalSegments segmen berhasil dipotong."
                    )
                }
            } catch (cancellation: CancellationException) {
                Log.d(TAG, "Batch trimming dibatalkan oleh pengguna.")
                _uiState.update {
                    it.copy(
                        isBatchTrimming = false,
                        statusMessage = "Batch trimming dibatalkan oleh pengguna."
                    )
                }
            } catch (t: Throwable) {
                Log.e(TAG, "Kesalahan batch trimming: ${t.message}", t)
                _uiState.update {
                    it.copy(
                        isBatchTrimming = false,
                        errorMessage = "Batch trimming terhenti: ${t.message}",
                        statusMessage = "Batch trimming gagal"
                    )
                }
            }
        }
    }

    /**
     * Membatalkan proses batch trimming yang sedang berlangsung.
     */
    fun cancelBatchTrim() {
        batchJob?.cancel()
        batchJob = null
        executionEngine.cancel()
        _uiState.update {
            it.copy(
                isBatchTrimming = false,
                statusMessage = "Batch trimming dibatalkan"
            )
        }
    }

    // =========================================================================
    // TERMUX ACTIONS
    // =========================================================================

    fun executeTermuxCommand(runInBackground: Boolean = false) {
        val context = getApplication<Application>()
        val cmd = _uiState.value.generatedTermuxCommand

        val result = TermuxManager.executeViaTermuxService(context, cmd, runInBackground)
        if (result.isSuccess) {
            _uiState.update {
                it.copy(
                    termuxFeedbackMessage = "Perintah berhasil dikirim ke Termux! Periksa sesi terminal Termux.",
                    statusMessage = "Perintah dikirim ke Termux"
                )
            }
        } else {
            val err = result.exceptionOrNull()?.message ?: "Gagal mengirim intent ke Termux"
            _uiState.update {
                it.copy(
                    termuxFeedbackMessage = "Gagal kirim via Intent ($err). Anda dapat menyalin perintah manual di bawah.",
                    statusMessage = "Gagal kirim otomatis ke Termux"
                )
            }
        }
    }

    fun copyTermuxCommand() {
        val context = getApplication<Application>()
        val cmd = _uiState.value.generatedTermuxCommand
        val success = TermuxManager.copyToClipboard(context, cmd)
        _uiState.update {
            it.copy(
                termuxFeedbackMessage = if (success) "Perintah Termux disalin ke Clipboard!" else "Gagal menyalin"
            )
        }
    }

    fun launchTermux() {
        val context = getApplication<Application>()
        val opened = TermuxManager.launchTermux(context)
        if (!opened) {
            _uiState.update {
                it.copy(
                    termuxFeedbackMessage = "Aplikasi Termux tidak ditemukan. Silakan pasang Termux terlebih dahulu."
                )
            }
        }
    }

    fun openTermuxDownload() {
        val context = getApplication<Application>()
        TermuxManager.openTermuxDownloadPage(context)
    }

    fun dismissTermuxFeedback() {
        _uiState.update { it.copy(termuxFeedbackMessage = null) }
    }

    // =========================================================================
    // SINGLE TRIM ACTIONS
    // =========================================================================

    fun startTrim() {
        val currentState = _uiState.value
        val context = getApplication<Application>()

        val inputFile = currentState.localVideoFile
        if (inputFile == null || !inputFile.exists()) {
            _uiState.update {
                it.copy(errorMessage = "File video sumber tidak ditemukan.")
            }
            return
        }

        val startSec = currentState.trimStartSeconds
        val endSec = currentState.trimEndSeconds
        val targetDurationSec = (endSec - startSec).coerceAtLeast(0.1)

        val outputDir = File(context.filesDir, "trimmed_videos")
        if (!outputDir.exists()) outputDir.mkdirs()

        val outputFile = File(outputDir, "trim_${System.currentTimeMillis()}.mp4")

        _uiState.update {
            it.copy(
                isTrimming = true,
                progressPercent = 0,
                currentTimeSeconds = 0.0,
                targetDurationSeconds = targetDurationSec,
                trimmedOutputFile = null,
                errorMessage = null,
                recentLogs = listOf("Memulai pekerjaan trimming video..."),
                statusMessage = "Memproses video..."
            )
        }

        executionEngine.executeTrim(
            context = context,
            inputFile = inputFile,
            outputFile = outputFile,
            startSeconds = startSec,
            endSeconds = endSec,
            useStreamCopy = currentState.useFastStreamCopy,
            listener = object : FFmpegProgressListener {
                override fun onStart() {
                    _uiState.update {
                        it.copy(
                            isTrimming = true,
                            statusMessage = "FFmpeg sedang memotong video..."
                        )
                    }
                }

                override fun onProgress(
                    progressPercent: Int,
                    currentTimeSeconds: Double,
                    totalTargetDurationSeconds: Double
                ) {
                    _uiState.update {
                        it.copy(
                            progressPercent = progressPercent.coerceIn(0, 100),
                            currentTimeSeconds = currentTimeSeconds,
                            targetDurationSeconds = totalTargetDurationSeconds,
                            statusMessage = "Memproses: $progressPercent%"
                        )
                    }
                }

                override fun onLog(logLine: String) {
                    _uiState.update { current ->
                        val updated = (current.recentLogs + logLine).takeLast(MAX_LOGS_KEPT)
                        current.copy(recentLogs = updated)
                    }
                }

                override fun onSuccess(outputFile: File, totalTimeTakenMs: Long) {
                    _uiState.update {
                        it.copy(
                            isTrimming = false,
                            progressPercent = 100,
                            trimmedOutputFile = outputFile,
                            trimElapsedTimeMs = totalTimeTakenMs,
                            statusMessage = "Selesai dalam ${(totalTimeTakenMs / 1000.0)} detik!"
                        )
                    }
                }

                override fun onError(error: Throwable) {
                    _uiState.update {
                        it.copy(
                            isTrimming = false,
                            errorMessage = error.localizedMessage ?: "Terjadi kesalahan saat memotong video",
                            statusMessage = "Gagal memproses video"
                        )
                    }
                }
            }
        )
    }

    fun cancelTrim() {
        executionEngine.cancel()
        _uiState.update {
            it.copy(
                isTrimming = false,
                statusMessage = "Proses pemotongan dibatalkan"
            )
        }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    override fun onCleared() {
        super.onCleared()
        executionEngine.cancel()
        batchJob?.cancel()
    }
}
