package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.screens.AnalysisDetailScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.VideoAnalyzerViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: VideoAnalyzerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .safeDrawingPadding(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MomentSnapApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun MomentSnapApp(viewModel: VideoAnalyzerViewModel) {
    val savedAnalyses by viewModel.savedAnalyses.collectAsStateWithLifecycle()
    val currentAnalysis by viewModel.currentAnalysis.collectAsStateWithLifecycle()
    val isAnalyzing by viewModel.isAnalyzing.collectAsStateWithLifecycle()
    val progressMessage by viewModel.progressMessage.collectAsStateWithLifecycle()
    val targetSeekSecond by viewModel.targetSeekSecond.collectAsStateWithLifecycle()
    val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()

    val analysis = currentAnalysis
    if (analysis != null) {
        AnalysisDetailScreen(
            analysis = analysis,
            targetSeekSecond = targetSeekSecond,
            activeTab = activeTab,
            onTabSelected = { tabIndex -> viewModel.setActiveTab(tabIndex) },
            onSeekTo = { second -> viewModel.seekToSecond(second) },
            onResetSeek = { viewModel.resetSeek() },
            onBack = { viewModel.clearCurrentAnalysis() }
        )
    } else {
        HomeScreen(
            savedAnalyses = savedAnalyses,
            isAnalyzing = isAnalyzing,
            progressMessage = progressMessage,
            onAnalyzeYouTube = { url, title, notes ->
                viewModel.analyzeYouTube(url, title, notes)
            },
            onAnalyzeLocal = { uri, title, notes ->
                viewModel.analyzeLocalVideo(uri, title, notes)
            },
            onLoadSample = { sample ->
                viewModel.loadSample(sample)
            },
            onSelectSaved = { saved ->
                viewModel.selectSavedAnalysis(saved)
            },
            onDeleteSaved = { id ->
                viewModel.deleteAnalysis(id)
            },
            samplePresets = viewModel.getSamplePresets()
        )
    }
}
