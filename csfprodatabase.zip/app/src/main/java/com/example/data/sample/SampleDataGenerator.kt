package com.example.data.sample

import java.io.ByteArrayInputStream
import java.io.InputStream
import java.util.Random

object SampleDataGenerator {

    private val VEHICLES = listOf(
        "B 9281 UXT (HINO 500 TRONTON)",
        "A 8821 ZA (ISUZU GIGA FVM)",
        "B 9045 TQ (FUSO FIGHTER FN)",
        "A 9122 YB (MERCEDES AXOR 2528)",
        "B 9912 UCG (SCANIA P360)",
        "A 8503 XC (VOLVO FM 440)",
        "B 9331 VKA (HINO RANGER FL)",
        "A 9400 QA (MITSUBISHI CANTER HD)",
        "B 9110 SY (ISUZU ELF NMR)",
        "A 8762 WB (UD TRUCKS QUESTER)"
    )

    private val COMPLAINTS = listOf(
        "Rem angin kurang respon & pedal getar saat muatan penuh",
        "Overheat temperatur mesin naik saat tanjakan Merak",
        "Bocor oli pada seal gardan belakang kiri",
        "Per daun roda depan kanan patah lembar kedua",
        "Servis berkala 50.000 KM + Ganti Oli & Filter lengkap",
        "Kopling selip tidak bertenaga transmisi gigi 3 susah masuk",
        "Ban aus tidak merata, getar di stir kecepatan 60 km/jam",
        "Suara mendecit kencang dari belt alternator & fan",
        "Lampu utama mati sebelah kanan & klakson angin korslet",
        "Asap knalpot hitam pekat, tarikan berat injektor mampet"
    )

    private val JOBS_AND_PARTS = listOf(
        JobDef("PART", "FL-OIL-01", "Filter Oli Mesin Heavy Duty Hino/Isuzu", "Filtrasi Engine", 2.0, 185000.0, "Filter terpasang rapi"),
        JobDef("PART", "OIL-15W40", "Oli Mesin Diesel Meditran SX 15W-40 (Pail 20L)", "Pelumas", 2.0, 1150000.0, "Volume 40 liter terisi standar"),
        JobDef("PART", "BRK-PAD-04", "Brake Lining / Kampas Rem Tromol Roda Belakang", "Brake System", 4.0, 420000.0, "Keling kampas baru terpasang"),
        JobDef("PART", "SEAL-GRD-02", "Oil Seal Hub Gardan Belakang Heavy Duty", "Drivetrain", 2.0, 135000.0, "Seal baru tanpa rembes"),
        JobDef("PART", "SPR-LF-06", "Per Daun Lembar No. 2 Spring Steel High Grade", "Suspension", 1.0, 750000.0, "Per daun diganti & dibaut kencang"),
        JobDef("PART", "CLT-PLT-01", "Clutch Disc / Plat Kopling 15 Inch 10 Spline", "Transmission", 1.0, 2450000.0, "Plat kopling baru merk Daikin"),
        JobDef("PART", "BLT-FAN-08", "V-Belt Kipas Radiator & Alternator Bando", "Cooling System", 2.0, 95000.0, "Tegangan v-belt 10mm defleksi"),
        JobDef("PART", "INJ-NOZ-03", "Nozzle Injector Common Rail Bosch", "Fuel System", 6.0, 520000.0, "Kalibrasi tekanan 220 bar"),
        JobDef("JASA", "JS-TUNE-01", "Jasa Tune Up & Kalibrasi Injektor Mesin Diesel", "Jasa Bengkel", 1.0, 450000.0, "Pengerjaan tuntas 3 jam"),
        JobDef("JASA", "JS-OVER-02", "Jasa Turun Transmisi & Ganti Kampas Kopling", "Jasa Bengkel", 1.0, 850000.0, "Transmisi disetel ulang"),
        JobDef("JASA", "JS-BRAKE-03", "Jasa Bubut Tromol & Ganti Kampas Rem 4 Roda", "Jasa Bengkel", 1.0, 550000.0, "Tes rem pakem di tanjakan"),
        JobDef("JASA", "JS-SERV-00", "Jasa Servis Berkala Pemeriksaan 50 Titik Armada", "Jasa Bengkel", 1.0, 350000.0, "Checklist inspeksi lengkap")
    )

    data class JobDef(
        val tipe: String,
        val kode: String,
        val desc: String,
        val prodClass: String,
        val defaultQty: Double,
        val unitPrice: Double,
        val note: String
    )

    /**
     * Generates a sample CSV InputStream containing realistic Cilegon Work Order records.
     */
    fun createSampleCsvStream(targetRows: Int = 1200): InputStream {
        val sb = StringBuilder()
        sb.append("Name,MobilName,Trandate,KmCurrent,Keluhan,Tipe,Kode,Description,Catatan,StartTime,EndTime,Qty,Total,TotalPrice,ProductClass,NoChassis,NoMesin\n")

        val random = Random(42) // Fixed seed for reproducible test dataset
        var rowCount = 0
        var woIndex = 1

        while (rowCount < targetRows) {
            val woId = "WO-CLG-2024-${String.format("%04d", woIndex)}"
            val vehicle = VEHICLES[random.nextInt(VEHICLES.size)]
            val day = 1 + random.nextInt(28)
            val month = 1 + random.nextInt(12)
            val trandate = String.format("%02d/%02d/2024", day, month)
            val km = 45000L + random.nextInt(120000)
            val complaint = COMPLAINTS[random.nextInt(COMPLAINTS.size)]
            val chassis = "MHM" + (100000000 + random.nextInt(900000000)).toString()
            val mesin = "J08E-" + (100000 + random.nextInt(900000)).toString()

            // 1 Work Order contains 2 to 6 line items
            val itemsInThisWo = 2 + random.nextInt(5)
            for (i in 0 until itemsInThisWo) {
                if (rowCount >= targetRows) break

                val job = JOBS_AND_PARTS[random.nextInt(JOBS_AND_PARTS.size)]
                val qty = job.defaultQty
                val totalPrice = qty * job.unitPrice
                val startTime = String.format("%02d:00", 8 + random.nextInt(4))
                val endTime = String.format("%02d:00", 13 + random.nextInt(5))

                sb.append("\"$woId\",")
                sb.append("\"$vehicle\",")
                sb.append("\"$trandate\",")
                sb.append("$km,")
                sb.append("\"$complaint\",")
                sb.append("\"${job.tipe}\",")
                sb.append("\"${job.kode}\",")
                sb.append("\"${job.desc}\",")
                sb.append("\"${job.note}\",")
                sb.append("\"$startTime\",")
                sb.append("\"$endTime\",")
                sb.append("$qty,")
                sb.append("$qty,")
                sb.append("$totalPrice,")
                sb.append("\"${job.prodClass}\",")
                sb.append("\"$chassis\",")
                sb.append("\"$mesin\"\n")

                rowCount++
            }
            woIndex++
        }

        return ByteArrayInputStream(sb.toString().toByteArray(Charsets.UTF_8))
    }
}
