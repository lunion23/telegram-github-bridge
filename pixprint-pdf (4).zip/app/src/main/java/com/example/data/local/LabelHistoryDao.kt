package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.model.LabelHistoryItem
import kotlinx.coroutines.flow.Flow

@Dao
interface LabelHistoryDao {
    @Query("SELECT * FROM label_history ORDER BY updatedAtMillis DESC, createdAtMillis DESC")
    fun observeAllHistory(): Flow<List<LabelHistoryItem>>

    @Query("SELECT * FROM label_history WHERE id = :id LIMIT 1")
    suspend fun getHistoryById(id: String): LabelHistoryItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertHistoryItem(item: LabelHistoryItem)

    @Query("DELETE FROM label_history WHERE id = :id")
    suspend fun deleteHistoryById(id: String)
}
