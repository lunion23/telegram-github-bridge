package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "technical_reports")
data class TechnicalReport(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val companyName: String = "Hiba Group",
    val reportTitle: String = "LAPORAN TEKNIK",
    val reportNumber: String = "1/LT-CLG/III/2026",
    val workshop: String = "Cilegon",
    val date: String = "12-Mar-26",
    val toolName: String = "Ban",
    val component: String = "Underbody",
    val manufacturer: String = "HINO",
    val vehicleType: String = "DUTRO",
    val model: String = "W04DTPJ-53447",
    val unitCode: String = "D127",
    val damageDate: String = "12-Mar-26",
    val odometer: String = "598916",
    val warrantyStatus: String = "SETELAH_GARANSI", // MASA_GARANSI or SETELAH_GARANSI
    val status: String = "Storing",
    val damageDescription: String = "Ban kempes",
    val damageLocation: String = "Tol tangerang - merak",
    val analysis: String = "Setelah di lakukan storing oleh team cikupa di temukan ban depan kiri kempes",
    val lastReplacement: String = "9-5-2022 (km.415513)",
    val lastReplacementWo: String = "KLD1-WO-2205-00381",
    val lastWeekly: String = "5-3-2026 (km.598234)",
    val lastWeeklyWo: String = "CLG1-WO-2603-00225",
    val photoPath: String? = null,
    val causePemasangan: Boolean = false,
    val causeKwalitasParts: Boolean = false,
    val causeKesalahanOperasional: Boolean = false,
    val causeSudahWaktunya: Boolean = true,
    val causeLainLain: Boolean = false,
    val causeExplanation: String = "",
    val solutionGantiPartBaru: Boolean = false,
    val solutionPemasanganUlang: Boolean = true,
    val solutionModifikasi: Boolean = false,
    val solutionActionText: String = "Ganti ban stip",
    val delayedReason: String = "",
    val reporterSuggestion: String = "Segera akan di lakukan program pengecekan atau penggantian terkait part tersebut terhadap RK8J supaya tidak terjadi kejadian serupa",
    val parts: List<ReplacementPart> = emptyList(),
    val knownBy1: String = "",
    val knownBy2: String = "",
    val reporterName: String = "Yudi Indrawan",
    val reporterTitle: String = "Wa.Ka.Bengkel",
    val createdAt: Long = System.currentTimeMillis(),
    val pdfPath: String? = null
)
