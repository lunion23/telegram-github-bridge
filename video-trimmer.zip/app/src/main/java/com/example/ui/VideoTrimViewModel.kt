package com.example.ui

import android.app.Application
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ffmpeg.FFmpegBinaryLoader
import com.example.ffmpeg.FFmpegExecutionEngine
import com.example.ffmpeg.FFmpegProgressListener
import com.example.util.MediaUtils
import com.example.util.VideoMetadata
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

/**
 * Status UI keseluruhan untuk layar Video Trimmer.
 */
data class TrimUiState(
    val isBinaryReady: Boolean = false,
    val binaryPath: String = "",
    val selectedVideo: VideoMetadata? = null,
    val localVideoFile: File? = null,
    val trimStartSeconds: Double = 0.0,
    val trimEndSeconds: Double = 0.0,
    val useFastStreamCopy: Boolean = true,
    val isTrimming: Boolean = false,
    val progressPercent: Int = 0,
    val currentTimeSeconds: Double = 0.0,
    val targetDurationSeconds: Double = 0.0,
    val recentLogs: List<String> = emptyList(),
    val trimmedOutputFile: File? = null,
    val trimElapsedTimeMs: Long = 0L,
    val errorMessage: String? = null,
    val statusMessage: String = "Menyiapkan aplikasi..."
)

/**
 * ViewModel yang mengelola state pemotongan video, interaksi biner FFmpeg,
 * serta komunikasi antara thread background dan antarmuka Jetpack Compose.
 */
class VideoTrimViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        private const val TAG = "VideoTrimViewModel"
        private const val MAX_LOGS_KEPT = 150
    }

    private val executionEngine = FFmpegExecutionEngine()

    private val _uiState = MutableStateFlow(TrimUiState())
    val uiState: StateFlow<TrimUiState> = _uiState.asStateFlow()

    init {
        initializeBinaryAndSample()
    }

    /**
     * Mempersiapkan binary FFmpeg di filesDir saat ViewModel pertama kali dibuat.
     */
    fun initializeBinaryAndSample() {
        viewModelScope.launch {
            val context = getApplication<Application>()
            _uiState.update { it.copy(statusMessage = "Memeriksa biner FFmpeg...") }

            val copyResult = FFmpegBinaryLoader.copyBinaryFromAssets(context)
            if (copyResult.isSuccess) {
                val file = copyResult.getOrThrow()
                _uiState.update {
                    it.copy(
                        isBinaryReady = true,
                        binaryPath = file.absolutePath,
                        statusMessage = "Biner FFmpeg siap dieksekusi"
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        isBinaryReady = false,
                        statusMessage = "Biner FFmpeg disiapkan dalam mode kompatibilitas"
                    )
                }
            }

            // Muat video sampel jika belum ada video yang dipilih
            if (_uiState.value.selectedVideo == null) {
                loadSampleVideo()
            }
        }
    }

    /**
     * Memuat video sampel bawaan dari assets agar pengguna dapat langsung menguji trimming.
     */
    fun loadSampleVideo() {
        viewModelScope.launch {
            val context = getApplication<Application>()
            _uiState.update { it.copy(statusMessage = "Memuat video sampel...") }

            val sampleResult = FFmpegBinaryLoader.copySampleVideoFromAssets(context)
            if (sampleResult.isSuccess) {
                val sampleFile = sampleResult.getOrThrow()
                val sampleUri = Uri.fromFile(sampleFile)
                val metadata = MediaUtils.extractVideoMetadata(context, sampleUri)

                if (metadata != null) {
                    val defaultEndSec = (metadata.durationSeconds * 0.65).coerceAtLeast(1.0)
                    _uiState.update {
                        it.copy(
                            selectedVideo = metadata,
                            localVideoFile = sampleFile,
                            trimStartSeconds = 0.0,
                            trimEndSeconds = defaultEndSec,
                            targetDurationSeconds = defaultEndSec,
                            trimmedOutputFile = null,
                            statusMessage = "Video sampel siap: ${metadata.formattedDuration}"
                        )
                    }
                }
            }
        }
    }

    /**
     * Dipanggil ketika pengguna memilih video dari galeri / penyimpanan lokal.
     */
    fun onVideoSelected(uri: Uri) {
        viewModelScope.launch {
            val context = getApplication<Application>()
            _uiState.update {
                it.copy(
                    statusMessage = "Membaca metadata video...",
                    errorMessage = null
                )
            }

            val metadata = MediaUtils.extractVideoMetadata(context, uri)
            if (metadata == null) {
                _uiState.update {
                    it.copy(
                        errorMessage = "Gagal membaca format video yang dipilih",
                        statusMessage = "Format video tidak didukung"
                    )
                }
                return@launch
            }

            // Salin file Uri ke cache internal agar FFmpeg ProcessBuilder dapat mengakses path lokal
            val cacheCopyResult = MediaUtils.copyUriToLocalCache(
                context = context,
                sourceUri = uri,
                destFileName = "input_${System.currentTimeMillis()}.mp4"
            )

            val localFile = cacheCopyResult.getOrNull()
            val totalSec = metadata.durationSeconds
            val defaultEnd = if (totalSec > 10.0) 10.0 else totalSec

            _uiState.update {
                it.copy(
                    selectedVideo = metadata,
                    localVideoFile = localFile,
                    trimStartSeconds = 0.0,
                    trimEndSeconds = defaultEnd,
                    targetDurationSeconds = defaultEnd,
                    trimmedOutputFile = null,
                    progressPercent = 0,
                    statusMessage = "Video dipilih: ${metadata.title} (${metadata.formattedDuration})"
                )
            }
        }
    }

    /**
     * Memperbarui rentang pemotongan (start dan end dalam detik).
     */
    fun updateTrimRange(start: Double, end: Double) {
        val safeStart = start.coerceAtLeast(0.0)
        val maxDuration = _uiState.value.selectedVideo?.durationSeconds ?: 100.0
        val safeEnd = end.coerceIn(safeStart + 0.1, maxDuration)

        _uiState.update {
            it.copy(
                trimStartSeconds = safeStart,
                trimEndSeconds = safeEnd,
                targetDurationSeconds = safeEnd - safeStart
            )
        }
    }

    /**
     * Toggle mode stream copy (-c copy) vs re-encode.
     */
    fun toggleStreamCopy(enabled: Boolean) {
        _uiState.update { it.copy(useFastStreamCopy = enabled) }
    }

    /**
     * Memulai proses pemotongan video di background thread.
     */
    fun startTrim() {
        val currentState = _uiState.value
        val context = getApplication<Application>()

        val inputFile = currentState.localVideoFile
        if (inputFile == null || !inputFile.exists()) {
            _uiState.update {
                it.copy(errorMessage = "File video sumber tidak ditemukan.")
            }
            return
        }

        val startSec = currentState.trimStartSeconds
        val endSec = currentState.trimEndSeconds
        val targetDurationSec = (endSec - startSec).coerceAtLeast(0.1)

        val outputDir = File(context.filesDir, "trimmed_videos")
        if (!outputDir.exists()) outputDir.mkdirs()

        val outputFile = File(outputDir, "trim_${System.currentTimeMillis()}.mp4")

        // Reset log dan siapkan state awal
        _uiState.update {
            it.copy(
                isTrimming = true,
                progressPercent = 0,
                currentTimeSeconds = 0.0,
                targetDurationSeconds = targetDurationSec,
                trimmedOutputFile = null,
                errorMessage = null,
                recentLogs = listOf("Memulai pekerjaan trimming video..."),
                statusMessage = "Memproses video..."
            )
        }

        // Jalankan FFmpeg melalui Execution Engine dengan listener callback
        executionEngine.executeTrim(
            context = context,
            inputFile = inputFile,
            outputFile = outputFile,
            startSeconds = startSec,
            endSeconds = endSec,
            useStreamCopy = currentState.useFastStreamCopy,
            listener = object : FFmpegProgressListener {
                override fun onStart() {
                    _uiState.update {
                        it.copy(
                            isTrimming = true,
                            statusMessage = "FFmpeg sedang memotong video..."
                        )
                    }
                }

                override fun onProgress(
                    progressPercent: Int,
                    currentTimeSeconds: Double,
                    totalTargetDurationSeconds: Double
                ) {
                    _uiState.update {
                        it.copy(
                            progressPercent = progressPercent.coerceIn(0, 100),
                            currentTimeSeconds = currentTimeSeconds,
                            targetDurationSeconds = totalTargetDurationSeconds,
                            statusMessage = "Memproses: $progressPercent%"
                        )
                    }
                }

                override fun onLog(logLine: String) {
                    _uiState.update { current ->
                        val updated = (current.recentLogs + logLine).takeLast(MAX_LOGS_KEPT)
                        current.copy(recentLogs = updated)
                    }
                }

                override fun onSuccess(outputFile: File, totalTimeTakenMs: Long) {
                    _uiState.update {
                        it.copy(
                            isTrimming = false,
                            progressPercent = 100,
                            trimmedOutputFile = outputFile,
                            trimElapsedTimeMs = totalTimeTakenMs,
                            statusMessage = "Selesai dalam ${(totalTimeTakenMs / 1000.0)} detik!"
                        )
                    }
                }

                override fun onError(error: Throwable) {
                    _uiState.update {
                        it.copy(
                            isTrimming = false,
                            errorMessage = error.localizedMessage ?: "Terjadi kesalahan saat memotong video",
                            statusMessage = "Gagal memproses video"
                        )
                    }
                }
            }
        )
    }

    /**
     * Membatalkan proses pemotongan yang sedang berlangsung.
     */
    fun cancelTrim() {
        executionEngine.cancel()
        _uiState.update {
            it.copy(
                isTrimming = false,
                statusMessage = "Proses pemotongan dibatalkan"
            )
        }
    }

    /**
     * Membersihkan pesan error.
     */
    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    override fun onCleared() {
        super.onCleared()
        executionEngine.cancel()
    }
}
