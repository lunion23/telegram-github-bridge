package com.example.data.drive

import android.content.Context
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.repository.LabelHistoryRepository
import com.example.model.DriveSyncMode
import com.example.model.DriveSyncPayload
import com.example.model.HistoryActionType
import com.example.model.LabelHistoryItem
import com.example.model.PaperSizePreset
import com.example.model.ShippingLabelData
import java.io.File
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

private class FakeDriveRemoteDataSource : DriveRemoteDataSource {
    val foldersByName = mutableMapOf<String, String>()
    var remoteJsonFileId: String? = null
    var remoteJsonContent: String? = null
    val uploadedPdfs = mutableMapOf<String, ByteArray>()

    override suspend fun ensureFolder(
        accessToken: String,
        folderName: String,
        cachedFolderId: String
    ): String {
        if (cachedFolderId.isNotBlank() && foldersByName.values.contains(cachedFolderId)) {
            return cachedFolderId
        }
        return foldersByName.getOrPut(folderName) {
            "folder_${foldersByName.size + 1}"
        }
    }

    override suspend fun downloadSyncJson(
        accessToken: String,
        folderId: String,
        fileName: String,
        cachedFileId: String
    ): RemoteDriveSyncFile? {
        val id = remoteJsonFileId ?: return null
        val content = remoteJsonContent ?: return null
        return RemoteDriveSyncFile(fileId = id, content = content)
    }

    override suspend fun uploadSyncJson(
        accessToken: String,
        folderId: String,
        existingFileId: String?,
        fileName: String,
        jsonContent: String
    ): String {
        val resolvedId = existingFileId ?: remoteJsonFileId ?: "sync_json_file_1"
        remoteJsonFileId = resolvedId
        remoteJsonContent = jsonContent
        return resolvedId
    }

    override suspend fun uploadPdfFile(
        accessToken: String,
        folderId: String,
        existingFileId: String?,
        fileName: String,
        pdfBytes: ByteArray
    ): String {
        val resolvedId = existingFileId ?: "pdf_${uploadedPdfs.size + 1}_$fileName"
        uploadedPdfs[resolvedId] = pdfBytes
        return resolvedId
    }
}

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class DriveSyncOrchestratorTest {

    private lateinit var database: AppDatabase
    private lateinit var historyRepository: LabelHistoryRepository
    private lateinit var prefsScope: CoroutineScope
    private lateinit var tempPrefsFile: File
    private lateinit var prefsRepository: DriveSyncPreferencesRepository
    private lateinit var fakeRemote: FakeDriveRemoteDataSource
    private lateinit var orchestrator: DriveHistorySyncOrchestrator

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        historyRepository = LabelHistoryRepository(database.labelHistoryDao())

        prefsScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        tempPrefsFile = File(context.cacheDir, "test_drive_prefs_${UUID.randomUUID()}.preferences_pb")
        val dataStore = PreferenceDataStoreFactory.create(
            scope = prefsScope,
            produceFile = { tempPrefsFile }
        )
        prefsRepository = DriveSyncPreferencesRepository(dataStore)
        fakeRemote = FakeDriveRemoteDataSource()
        orchestrator = DriveHistorySyncOrchestrator(
            historyRepository = historyRepository,
            prefsRepository = prefsRepository,
            remoteDataSource = fakeRemote,
            pdfRenderer = { item ->
                "%PDF-1.4\n% Waybill: ${item.waybillNumber} | Recipient: ${item.recipientName}\n%%EOF"
                    .repeat(6)
                    .toByteArray(Charsets.UTF_8)
            }
        )
    }

    @After
    fun tearDown() {
        database.close()
        prefsScope.cancel()
        tempPrefsFile.delete()
    }

    @Test
    fun `two-way merge combines local and Drive items, respects tombstones, and backs up PDFs when enabled`() = runBlocking {
        // 1. Seed a local item
        val localCreated = historyRepository.saveHistoryEntry(
            data = ShippingLabelData.defaultFromReferenceImage().copy(
                waybillNumber = "JD_LOCAL_001",
                recipientName = "Penerima Lokal"
            ),
            paperPreset = PaperSizePreset.THERMAL_100X200,
            actionLabel = HistoryActionType.SAVED
        )

        // 2. Seed an item that exists locally AND was deleted remotely more recently
        val localToBeDeleted = historyRepository.saveHistoryEntry(
            data = ShippingLabelData.defaultFromReferenceImage().copy(
                waybillNumber = "JD_DELETED_ON_CLOUD",
                recipientName = "Akan Dihapus"
            ),
            paperPreset = PaperSizePreset.THERMAL_100X200
        )

        // 3. Seed a remote item in Drive JSON + tombstone for localToBeDeleted
        val remoteOnlyItem = LabelHistoryItem(
            id = "remote_item_99",
            waybillNumber = "JD_CLOUD_999",
            recipientName = "Penerima Dari Drive",
            destinationBanner = "SURABAYA",
            createdAtMillis = 1765000000000L,
            updatedAtMillis = 1765000000000L
        )
        fakeRemote.remoteJsonFileId = "existing_sync_json"
        fakeRemote.remoteJsonContent = DriveSyncPayloadCodec.encode(
            DriveSyncPayload(
                items = listOf(remoteOnlyItem),
                deletedTombstones = mapOf(localToBeDeleted.id to (localToBeDeleted.updatedAtMillis + 5000L))
            )
        )

        prefsRepository.setDriveFolderName("Arsip Resi Toko")
        prefsRepository.setAutoUploadPdf(true)

        val result = orchestrator.performSync(
            accessToken = "fake_oauth_token",
            overrideMode = DriveSyncMode.TWO_WAY_MERGE,
            nowMillis = System.currentTimeMillis() + 10_000L
        )

        assertEquals("Arsip Resi Toko", result.folderName)
        assertEquals(1, result.uploadedItemCount)
        assertEquals(1, result.restoredItemCount)
        assertEquals(1, result.deletedLocalCount)
        assertEquals(2, result.uploadedPdfCount)

        // Verify local database now has both localCreated & remoteOnlyItem, and deleted item is removed
        assertNull(historyRepository.getHistoryItem(localToBeDeleted.id))
        val mergedLocal = historyRepository.getAllHistory()
        assertEquals(2, mergedLocal.size)
        assertTrue(mergedLocal.all { it.isSyncedToDrive && it.drivePdfFileId.isNotBlank() })
        assertTrue(fakeRemote.uploadedPdfs.values.all { bytes -> bytes.size > 200 })
    }

    @Test
    fun `restore-only mode pulls remote items without modifying remote Drive JSON`() = runBlocking {
        val remoteItem = LabelHistoryItem(
            id = "restore_only_id",
            waybillNumber = "JD_RESTORE_777",
            recipientName = "Rina Kartika",
            createdAtMillis = 1760000000000L,
            updatedAtMillis = 1760000000000L
        )
        val originalRemoteJson = DriveSyncPayloadCodec.encode(
            DriveSyncPayload(items = listOf(remoteItem))
        )
        fakeRemote.remoteJsonFileId = "remote_json_id"
        fakeRemote.remoteJsonContent = originalRemoteJson

        prefsRepository.setSyncMode(DriveSyncMode.RESTORE_ONLY)

        val summary = orchestrator.performSync(
            accessToken = "fake_token",
            nowMillis = 1760000100000L
        )

        assertEquals(0, summary.uploadedItemCount)
        assertEquals(1, summary.restoredItemCount)
        assertEquals(originalRemoteJson, fakeRemote.remoteJsonContent)
        assertEquals("Rina Kartika", historyRepository.getHistoryItem("restore_only_id")?.recipientName)
    }
}
