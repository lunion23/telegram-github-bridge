package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.model.LabelHistoryItem

@Database(
    entities = [LabelHistoryItem::class],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun labelHistoryDao(): LabelHistoryDao

    companion object {
        val MIGRATION_1_2: Migration = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE label_history ADD COLUMN drivePdfFileId TEXT NOT NULL DEFAULT ''"
                )
                db.execSQL(
                    "ALTER TABLE label_history ADD COLUMN lastSyncedAtMillis INTEGER NOT NULL DEFAULT 0"
                )
            }
        }

        val MIGRATION_2_3: Migration = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE label_history ADD COLUMN renderSourceName TEXT NOT NULL DEFAULT 'VECTOR_RECONSTRUCTION'"
                )
                db.execSQL(
                    "ALTER TABLE label_history ADD COLUMN capturedImagePath TEXT NOT NULL DEFAULT ''"
                )
            }
        }

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "cetak_resi_pdf.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .fallbackToDestructiveMigration(true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
