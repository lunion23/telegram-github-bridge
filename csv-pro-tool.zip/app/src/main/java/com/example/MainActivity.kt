package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material.icons.filled.ViewColumn
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.InputChip
import androidx.compose.material3.InputChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.ColumnManagerDialog
import com.example.ui.components.ConsolidatedCardsView
import com.example.ui.components.EditRowDialog
import com.example.ui.components.ExportDialog
import com.example.ui.components.FilterDialog
import com.example.ui.components.ImportMethodDialog
import com.example.ui.components.InteractiveImportGuide
import com.example.ui.components.SpreadsheetGridView
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.CsvViewerViewModel
import com.example.ui.viewmodel.ViewDisplayMode

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: CsvViewerViewModel = viewModel()
            val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()

            MyApplicationTheme(darkTheme = isDarkMode) {
                CsvViewerApp(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CsvViewerApp(viewModel: CsvViewerViewModel) {
    val snackbarHostState = remember { SnackbarHostState() }

    val displayMode by viewModel.displayMode.collectAsStateWithLifecycle()
    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val filterCriteria by viewModel.filterCriteria.collectAsStateWithLifecycle()
    val columnConfigs by viewModel.columnConfigs.collectAsStateWithLifecycle()
    val consolidatedGroups by viewModel.consolidatedGroups.collectAsStateWithLifecycle()
    val spreadsheetRows by viewModel.spreadsheetRows.collectAsStateWithLifecycle()
    val rowCount by viewModel.rowCount.collectAsStateWithLifecycle()
    val totalFilteredCount by viewModel.totalFilteredCount.collectAsStateWithLifecycle()
    val currentPage by viewModel.currentPage.collectAsStateWithLifecycle()
    val distinctStatuses by viewModel.distinctStatuses.collectAsStateWithLifecycle()
    val distinctCategories by viewModel.distinctCategories.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val progressMessage by viewModel.progressMessage.collectAsStateWithLifecycle()
    val userMessage by viewModel.userMessage.collectAsStateWithLifecycle()

    val showFilterDialog by viewModel.showFilterDialog.collectAsStateWithLifecycle()
    val showColumnManagerDialog by viewModel.showColumnManagerDialog.collectAsStateWithLifecycle()
    val showAddRowDialog by viewModel.showAddRowDialog.collectAsStateWithLifecycle()
    val editingRow by viewModel.editingRow.collectAsStateWithLifecycle()
    val showExportDialog by viewModel.showExportDialog.collectAsStateWithLifecycle()
    val showHelpGuide by viewModel.showHelpGuide.collectAsStateWithLifecycle()
    val showImportMethodDialog by viewModel.showImportMethodDialog.collectAsStateWithLifecycle()

    var showMenu by remember { mutableStateOf(false) }
    var showColumn2Picker by remember { mutableStateOf(false) }

    LaunchedEffect(userMessage) {
        userMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.dismissUserMessage()
        }
    }

    // SAF Launchers
    val csvPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { viewModel.promptImportCsv(it) }
    }

    val dbRestoreLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { viewModel.restoreDatabase(it) }
    }

    val csvExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        uri?.let { viewModel.exportToCsv(it) }
    }

    val excelExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri ->
        uri?.let { viewModel.exportToExcel(it) }
    }

    val pdfExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        uri?.let { viewModel.exportToPdf(it) }
    }

    val dbBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/x-sqlite3")
    ) { uri ->
        uri?.let { viewModel.backupDatabase(it) }
    }

    val selectedCol2Name = columnConfigs.find { it.colIndex == filterCriteria.searchColumn2Index }?.headerName
        ?: "Kolom ${filterCriteria.searchColumn2Index + 1}"

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(CyanAccent.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.TableChart,
                                contentDescription = null,
                                tint = CyanAccent,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "CSV Viewer & DB",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (rowCount > 0) "$rowCount Baris Tersimpan" else "Belum Ada Data",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.toggleDisplayMode() },
                        modifier = Modifier.testTag("toggle_view_mode_button")
                    ) {
                        Icon(
                            imageVector = if (displayMode == ViewDisplayMode.CONSOLIDATED_CARDS) {
                                Icons.Default.TableChart
                            } else {
                                Icons.Default.ViewAgenda
                            },
                            contentDescription = if (displayMode == ViewDisplayMode.CONSOLIDATED_CARDS) {
                                "Beralih ke Spreadsheet"
                            } else {
                                "Beralih ke Kartu Konsolidasi"
                            },
                            tint = CyanAccent
                        )
                    }

                    IconButton(
                        onClick = { viewModel.openColumnManager() },
                        modifier = Modifier.testTag("open_column_manager_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ViewColumn,
                            contentDescription = "Pengaturan Kolom",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    IconButton(
                        onClick = { viewModel.toggleDarkMode() },
                        modifier = Modifier.testTag("toggle_dark_mode_button")
                    ) {
                        Icon(
                            imageVector = if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Ganti Mode Tema",
                            tint = if (isDarkMode) Color(0xFFFBBF24) else Color(0xFF64748B)
                        )
                    }

                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.testTag("overflow_menu_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "Menu Lainnya"
                        )
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Muat Sampel Data (Replace All)") },
                            leadingIcon = {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CyanAccent)
                            },
                            onClick = {
                                showMenu = false
                                viewModel.loadSampleData(isReplaceAll = true)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Muat Sampel Data (Append / Tambah)") },
                            leadingIcon = {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = EmeraldAccent)
                            },
                            onClick = {
                                showMenu = false
                                viewModel.loadSampleData(isReplaceAll = false)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Impor File CSV (.csv)") },
                            leadingIcon = {
                                Icon(Icons.Default.FileUpload, contentDescription = null, tint = EmeraldAccent)
                            },
                            onClick = {
                                showMenu = false
                                csvPickerLauncher.launch(arrayOf("text/*", "text/csv", "application/csv"))
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Pulihkan Database (.db)") },
                            leadingIcon = {
                                Icon(Icons.Default.Storage, contentDescription = null, tint = CyanAccent)
                            },
                            onClick = {
                                showMenu = false
                                dbRestoreLauncher.launch(arrayOf("*/*"))
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Buka Panduan Interaktif") },
                            leadingIcon = {
                                Icon(Icons.Default.HelpOutline, contentDescription = null)
                            },
                            onClick = {
                                showMenu = false
                                viewModel.openHelpGuide()
                            }
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Kosongkan Semua Data", color = MaterialTheme.colorScheme.error) },
                            leadingIcon = {
                                Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            },
                            onClick = {
                                showMenu = false
                                viewModel.clearAllData()
                            }
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { viewModel.openAddRowDialog() },
                containerColor = CyanAccent,
                contentColor = Color.Black,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Tambah Baris", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("add_row_fab")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // 2 KOLOM PENCARIAN (Two-Column Search Header)
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    // Row 1: Kolom Pencarian 1 (Semua Kolom) + Tombol Aksi
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = filterCriteria.searchQuery,
                            onValueChange = { viewModel.updateSearchQuery(it) },
                            placeholder = { Text("Pencarian 1: Semua Kolom...", fontSize = 12.sp) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "Cari Semua",
                                    tint = CyanAccent,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            trailingIcon = {
                                if (filterCriteria.searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                        Icon(
                                            imageVector = Icons.Default.Clear,
                                            contentDescription = "Hapus",
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanAccent,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("search_column_1_input")
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = { viewModel.openFilterDialog() },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .testTag("open_filter_dialog_button")
                        ) {
                            BadgedBox(
                                badge = {
                                    if (filterCriteria.activeCount > 0) {
                                        Badge(
                                            containerColor = CyanAccent,
                                            contentColor = Color.Black
                                        ) {
                                            Text("${filterCriteria.activeCount}")
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FilterAlt,
                                    contentDescription = "Filter Lanjutan",
                                    tint = if (filterCriteria.isActive) CyanAccent else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        IconButton(
                            onClick = { viewModel.openExportDialog() },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(EmeraldAccent.copy(alpha = 0.15f))
                                .testTag("open_export_dialog_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.FileDownload,
                                contentDescription = "Ekspor Dokumen",
                                tint = EmeraldAccent
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Row 2: Kolom Pencarian 2 (Target Kolom Spesifik)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .height(44.dp)
                                    .clickable { showColumn2Picker = true }
                                    .border(
                                        width = 1.dp,
                                        color = CyanAccent.copy(alpha = 0.4f),
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .testTag("search_col2_selector")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = selectedCol2Name,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = CyanAccent,
                                        maxLines = 1
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = "Pilih Kolom",
                                        tint = CyanAccent,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            DropdownMenu(
                                expanded = showColumn2Picker,
                                onDismissRequest = { showColumn2Picker = false }
                            ) {
                                columnConfigs.forEach { col ->
                                    DropdownMenuItem(
                                        text = { Text("Kolom ${col.colIndex + 1}: ${col.headerName}") },
                                        onClick = {
                                            viewModel.updateSearchColumn2Index(col.colIndex)
                                            showColumn2Picker = false
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        OutlinedTextField(
                            value = filterCriteria.searchQuery2,
                            onValueChange = { viewModel.updateSearchQuery2(it) },
                            placeholder = { Text("Pencarian 2: $selectedCol2Name...", fontSize = 12.sp) },
                            trailingIcon = {
                                if (filterCriteria.searchQuery2.isNotEmpty()) {
                                    IconButton(onClick = { viewModel.clearSearch2() }) {
                                        Icon(
                                            imageVector = Icons.Default.Clear,
                                            contentDescription = "Hapus",
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = EmeraldAccent,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("search_column_2_input")
                        )
                    }

                    // Baris Filter Chips Ringkas
                    AnimatedVisibility(visible = filterCriteria.isActive) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 6.dp)
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            InputChip(
                                selected = true,
                                onClick = { viewModel.clearAllFilters() },
                                label = { Text("Reset Filter", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                trailingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Reset",
                                        modifier = Modifier.size(12.dp)
                                    )
                                },
                                colors = InputChipDefaults.inputChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.15f),
                                    selectedLabelColor = MaterialTheme.colorScheme.error
                                )
                            )

                            if (filterCriteria.searchQuery.isNotEmpty()) {
                                InputChip(
                                    selected = true,
                                    onClick = { viewModel.updateSearchQuery("") },
                                    label = { Text("Semua: \"${filterCriteria.searchQuery}\"", fontSize = 11.sp) },
                                    trailingIcon = { Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(12.dp)) }
                                )
                            }

                            if (filterCriteria.searchQuery2.isNotEmpty()) {
                                InputChip(
                                    selected = true,
                                    onClick = { viewModel.clearSearch2() },
                                    label = { Text("$selectedCol2Name: \"${filterCriteria.searchQuery2}\"", fontSize = 11.sp) },
                                    trailingIcon = { Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(12.dp)) }
                                )
                            }

                            filterCriteria.statusFilter?.let { st ->
                                InputChip(
                                    selected = true,
                                    onClick = { viewModel.setStatusFilter(null) },
                                    label = { Text("Status: $st", fontSize = 11.sp) },
                                    trailingIcon = { Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(12.dp)) }
                                )
                            }

                            filterCriteria.categoryFilter?.let { cat ->
                                InputChip(
                                    selected = true,
                                    onClick = { viewModel.setCategoryFilter(null) },
                                    label = { Text("Kategori: $cat", fontSize = 11.sp) },
                                    trailingIcon = { Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(12.dp)) }
                                )
                            }
                        }
                    }
                }
            }

            // Main Body Content
            Box(modifier = Modifier.fillMaxSize()) {
                if (rowCount == 0 || showHelpGuide) {
                    InteractiveImportGuide(
                        onLoadSampleData = {
                            viewModel.closeHelpGuide()
                            viewModel.loadSampleData(isReplaceAll = true)
                        },
                        onImportCsv = {
                            viewModel.closeHelpGuide()
                            csvPickerLauncher.launch(arrayOf("text/*", "text/csv", "application/csv"))
                        },
                        onRestoreDb = {
                            viewModel.closeHelpGuide()
                            dbRestoreLauncher.launch(arrayOf("*/*"))
                        },
                        onDismiss = if (rowCount > 0) { { viewModel.closeHelpGuide() } } else null
                    )
                } else {
                    when (displayMode) {
                        ViewDisplayMode.CONSOLIDATED_CARDS -> {
                            ConsolidatedCardsView(
                                groups = consolidatedGroups,
                                columns = columnConfigs,
                                currentPage = currentPage,
                                totalCount = totalFilteredCount,
                                onNextPage = { viewModel.nextPage() },
                                onPreviousPage = { viewModel.previousPage() },
                                onExpandGroup = { viewModel.loadChildRowsForGroup(it) },
                                onEditRow = { viewModel.startEditingRow(it) },
                                onDeleteRow = { viewModel.deleteRow(it) },
                                onDeleteGroup = { viewModel.deleteGroup(it) },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        ViewDisplayMode.SPREADSHEET_TABLE -> {
                            SpreadsheetGridView(
                                rows = spreadsheetRows,
                                columns = columnConfigs,
                                currentPage = currentPage,
                                totalCount = totalFilteredCount,
                                pageSize = viewModel.pageSize,
                                onNextPage = { viewModel.nextPage() },
                                onPreviousPage = { viewModel.previousPage() },
                                sortColumnIndex = filterCriteria.sortColumnIndex,
                                isSortAscending = filterCriteria.isSortAscending,
                                onSortColumn = { viewModel.setSortColumn(it) },
                                onEditRow = { viewModel.startEditingRow(it) },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }

                if (isLoading) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surface,
                                tonalElevation = 8.dp,
                                modifier = Modifier.padding(24.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(20.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    CircularProgressIndicator(
                                        color = CyanAccent,
                                        modifier = Modifier.size(32.dp)
                                    )
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Text(
                                        text = progressMessage ?: "Memproses data...",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialog Metode Simpan (Append vs Replace All)
    if (showImportMethodDialog) {
        ImportMethodDialog(
            onConfirm = { isReplaceAll ->
                viewModel.executeImportWithMethod(isReplaceAll)
            },
            onDismiss = {
                viewModel.dismissImportMethodDialog()
            }
        )
    }

    if (showFilterDialog) {
        FilterDialog(
            currentFilter = filterCriteria,
            columns = columnConfigs,
            statuses = distinctStatuses,
            categories = distinctCategories,
            onApply = { updated ->
                viewModel.setStatusFilter(updated.statusFilter)
                viewModel.setCategoryFilter(updated.categoryFilter)
                updated.columnFilters.forEach { (col, text) ->
                    viewModel.setColumnFilter(col, text)
                }
            },
            onReset = { viewModel.clearAllFilters() },
            onDismiss = { viewModel.closeFilterDialog() }
        )
    }

    if (showColumnManagerDialog) {
        ColumnManagerDialog(
            configs = columnConfigs,
            onSave = { updatedList ->
                viewModel.updateAllColumnConfigs(updatedList)
            },
            onAddNewColumn = { name ->
                viewModel.addNewColumn(name)
            },
            onDeleteColumn = { colIndex ->
                viewModel.deleteColumn(colIndex)
            },
            onDismiss = { viewModel.closeColumnManager() }
        )
    }

    if (showAddRowDialog) {
        EditRowDialog(
            initialRow = null,
            columns = columnConfigs,
            onSave = { newRow -> viewModel.addRow(newRow) },
            onDismiss = { viewModel.closeAddRowDialog() }
        )
    }

    editingRow?.let { rowToEdit ->
        EditRowDialog(
            initialRow = rowToEdit,
            columns = columnConfigs,
            onSave = { updatedRow -> viewModel.updateRow(updatedRow) },
            onDismiss = { viewModel.closeEditingRow() }
        )
    }

    if (showExportDialog) {
        ExportDialog(
            filterCriteria = filterCriteria,
            filteredRowCount = spreadsheetRows.size,
            visibleColumnCount = columnConfigs.count { it.isVisible },
            onExportCsv = {
                val filename = "ekspor_data_${System.currentTimeMillis()}.csv"
                csvExportLauncher.launch(filename)
            },
            onExportExcel = {
                val filename = "ekspor_data_${System.currentTimeMillis()}.xls"
                excelExportLauncher.launch(filename)
            },
            onExportPdf = {
                val filename = "laporan_data_${System.currentTimeMillis()}.pdf"
                pdfExportLauncher.launch(filename)
            },
            onBackupDb = {
                val filename = "backup_database_${System.currentTimeMillis()}.db"
                dbBackupLauncher.launch(filename)
            },
            onDismiss = { viewModel.closeExportDialog() }
        )
    }
}
