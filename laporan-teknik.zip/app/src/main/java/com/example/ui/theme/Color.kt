package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NavyPrimary = Color(0xFF1E3A8A)
val NavyOnPrimary = Color(0xFFFFFFFF)
val NavyPrimaryContainer = Color(0xFFDBEAFE)
val NavyOnPrimaryContainer = Color(0xFF1E293B)

val SlateSecondary = Color(0xFF334155)
val SlateOnSecondary = Color(0xFFFFFFFF)
val SlateSecondaryContainer = Color(0xFFF1F5F9)
val SlateOnSecondaryContainer = Color(0xFF0F172A)

val AmberTertiary = Color(0xFFD97706)
val AmberOnTertiary = Color(0xFFFFFFFF)
val AmberTertiaryContainer = Color(0xFFFEF3C7)

val IndustrialBackground = Color(0xFFF8FAFC)
val IndustrialSurface = Color(0xFFFFFFFF)
val IndustrialOnSurface = Color(0xFF0F172A)
val IndustrialSurfaceVariant = Color(0xFFF1F5F9)
val IndustrialOutline = Color(0xFFCBD5E1)

// Dark scheme
val NavyPrimaryDark = Color(0xFF93C5FD)
val NavyOnPrimaryDark = Color(0xFF172554)
val IndustrialBackgroundDark = Color(0xFF0F172A)
val IndustrialSurfaceDark = Color(0xFF1E293B)
val IndustrialOnSurfaceDark = Color(0xFFF8FAFC)
val IndustrialSurfaceVariantDark = Color(0xFF334155)
val IndustrialOutlineDark = Color(0xFF475569)
