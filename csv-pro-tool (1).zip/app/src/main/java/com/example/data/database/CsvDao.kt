package com.example.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.ColumnConfigEntity
import com.example.data.model.CsvRowEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CsvDao {
    @Query("SELECT COUNT(*) FROM csv_rows")
    fun getRowCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM csv_rows")
    suspend fun getRowCountDirect(): Int

    @Query("SELECT * FROM csv_rows ORDER BY id ASC")
    fun getAllRows(): Flow<List<CsvRowEntity>>

    @Query("SELECT * FROM csv_rows ORDER BY id ASC")
    suspend fun getAllRowsDirect(): List<CsvRowEntity>

    @Query("SELECT * FROM csv_rows ORDER BY id ASC LIMIT :limit OFFSET :offset")
    suspend fun getPagedRows(limit: Int, offset: Int): List<CsvRowEntity>

    @Query("""
        SELECT * FROM csv_rows 
        WHERE (:query = '' OR 
               col0 LIKE '%' || :query || '%' OR 
               col1 LIKE '%' || :query || '%' OR 
               col2 LIKE '%' || :query || '%' OR 
               col3 LIKE '%' || :query || '%' OR 
               col4 LIKE '%' || :query || '%' OR 
               col5 LIKE '%' || :query || '%' OR 
               col6 LIKE '%' || :query || '%' OR 
               col7 LIKE '%' || :query || '%' OR 
               col8 LIKE '%' || :query || '%' OR 
               col9 LIKE '%' || :query || '%')
          AND (:status IS NULL OR col9 = :status)
          AND (:category IS NULL OR col3 = :category)
        ORDER BY id ASC
    """)
    suspend fun filterAllRows(
        query: String,
        status: String?,
        category: String?
    ): List<CsvRowEntity>

    @Query("SELECT DISTINCT col9 FROM csv_rows WHERE col9 != ''")
    fun getDistinctStatuses(): Flow<List<String>>

    @Query("SELECT DISTINCT col3 FROM csv_rows WHERE col3 != ''")
    fun getDistinctCategories(): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRow(row: CsvRowEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(rows: List<CsvRowEntity>)

    @Update
    suspend fun updateRow(row: CsvRowEntity)

    @Query("DELETE FROM csv_rows WHERE id = :id")
    suspend fun deleteRowById(id: Long)

    @Query("DELETE FROM csv_rows WHERE recordId = :recordId")
    suspend fun deleteByRecordId(recordId: String)

    @Query("DELETE FROM csv_rows")
    suspend fun clearAllRows()

    // Column Configs
    @Query("SELECT * FROM column_configs ORDER BY displayOrder ASC")
    fun getAllColumnConfigs(): Flow<List<ColumnConfigEntity>>

    @Query("SELECT * FROM column_configs ORDER BY displayOrder ASC")
    suspend fun getAllColumnConfigsDirect(): List<ColumnConfigEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertColumnConfigs(configs: List<ColumnConfigEntity>)

    @Update
    suspend fun updateColumnConfig(config: ColumnConfigEntity)

    @Query("DELETE FROM column_configs")
    suspend fun clearColumnConfigs()
}
