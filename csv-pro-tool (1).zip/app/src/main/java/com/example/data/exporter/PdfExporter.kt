package com.example.data.exporter

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.example.data.model.ColumnConfigEntity
import com.example.data.model.CsvRowEntity
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfExporter {

    private const val PAGE_WIDTH = 842
    private const val PAGE_HEIGHT = 595
    private const val MARGIN = 36f
    private const val HEADER_ROW_HEIGHT = 26f
    private const val DATA_ROW_HEIGHT = 20f

    fun export(
        outputStream: OutputStream,
        columns: List<ColumnConfigEntity>,
        rows: List<CsvRowEntity>,
        reportTitle: String = "Laporan Data CSV & Database",
        filterSummary: String = "Semua Data"
    ) {
        val pdfDocument = PdfDocument()
        val visibleCols = columns.filter { it.isVisible }.sortedBy { it.displayOrder }

        if (visibleCols.isEmpty()) {
            pdfDocument.close()
            return
        }

        val totalTableWidth = PAGE_WIDTH - (MARGIN * 2)
        val colWidth = totalTableWidth / visibleCols.size

        val titlePaint = Paint().apply {
            color = Color.parseColor("#0F172A")
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val subtitlePaint = Paint().apply {
            color = Color.parseColor("#64748B")
            textSize = 9f
            typeface = Typeface.DEFAULT
            isAntiAlias = true
        }

        val headerBgPaint = Paint().apply {
            color = Color.parseColor("#0F172A")
            style = Paint.Style.FILL
        }

        val headerTextPaint = Paint().apply {
            color = Color.WHITE
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val rowEvenBgPaint = Paint().apply {
            color = Color.parseColor("#F8FAFC")
            style = Paint.Style.FILL
        }

        val rowTextPaint = Paint().apply {
            color = Color.parseColor("#1E293B")
            textSize = 8.5f
            typeface = Typeface.DEFAULT
            isAntiAlias = true
        }

        val borderPaint = Paint().apply {
            color = Color.parseColor("#E2E8F0")
            strokeWidth = 0.8f
            style = Paint.Style.STROKE
        }

        val footerPaint = Paint().apply {
            color = Color.parseColor("#94A3B8")
            textSize = 8f
            isAntiAlias = true
        }

        var currentPageNumber = 1
        var rowIndex = 0
        val totalRows = rows.size
        val printDate = SimpleDateFormat("dd MMMM yyyy, HH:mm", Locale("id", "ID")).format(Date())

        while (rowIndex < totalRows || totalRows == 0) {
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, currentPageNumber).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            var currentY = MARGIN

            if (currentPageNumber == 1) {
                canvas.drawText(reportTitle, MARGIN, currentY + 14f, titlePaint)
                currentY += 24f
                val metaText = "Dicetak: $printDate | Total: $totalRows Baris | Filter: $filterSummary"
                canvas.drawText(metaText, MARGIN, currentY + 8f, subtitlePaint)
                currentY += 18f
            } else {
                canvas.drawText("$reportTitle (Lanjutan)", MARGIN, currentY + 10f, titlePaint)
                currentY += 18f
            }

            val headerRect = RectF(MARGIN, currentY, MARGIN + totalTableWidth, currentY + HEADER_ROW_HEIGHT)
            canvas.drawRect(headerRect, headerBgPaint)

            visibleCols.forEachIndexed { colIdx, col ->
                val colX = MARGIN + (colIdx * colWidth)
                val text = truncateText(col.headerName, headerTextPaint, colWidth - 8f)
                canvas.drawText(text, colX + 4f, currentY + 17f, headerTextPaint)
            }
            currentY += HEADER_ROW_HEIGHT

            val maxY = PAGE_HEIGHT - MARGIN - 24f
            while (rowIndex < totalRows && currentY + DATA_ROW_HEIGHT <= maxY) {
                val row = rows[rowIndex]
                val isEven = rowIndex % 2 == 1
                val rowRect = RectF(MARGIN, currentY, MARGIN + totalTableWidth, currentY + DATA_ROW_HEIGHT)

                if (isEven) {
                    canvas.drawRect(rowRect, rowEvenBgPaint)
                }
                canvas.drawRect(rowRect, borderPaint)

                visibleCols.forEachIndexed { colIdx, col ->
                    val colX = MARGIN + (colIdx * colWidth)
                    val rawVal = row.getCell(col.colIndex)
                    val cellText = truncateText(rawVal, rowTextPaint, colWidth - 8f)
                    canvas.drawText(cellText, colX + 4f, currentY + 13.5f, rowTextPaint)
                }

                currentY += DATA_ROW_HEIGHT
                rowIndex++
            }

            val footerText = "Halaman $currentPageNumber | CSV Viewer & DB"
            canvas.drawText(footerText, PAGE_WIDTH - MARGIN - 120f, PAGE_HEIGHT - 16f, footerPaint)

            pdfDocument.finishPage(page)
            currentPageNumber++

            if (totalRows == 0) break
        }

        pdfDocument.writeTo(outputStream)
        pdfDocument.close()
    }

    private fun truncateText(text: String, paint: Paint, maxWidth: Float): String {
        if (paint.measureText(text) <= maxWidth) return text
        var truncated = text
        while (truncated.isNotEmpty() && paint.measureText("$truncated…") > maxWidth) {
            truncated = truncated.dropLast(1)
        }
        return if (truncated.isEmpty()) "" else "$truncated…"
    }
}
