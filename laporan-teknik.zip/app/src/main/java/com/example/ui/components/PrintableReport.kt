package com.example.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import coil.compose.AsyncImage
import coil.request.ImageRequest
import java.io.File
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.TechnicalReport
import com.example.data.model.WarrantyStatus

/**
 * PrintableReport: Composable khusus untuk tata letak cetak dokumen LAPORAN TEKNIK.
 * Memastikan font, margin, dan elemen tabel terformat dengan benar saat diprint/ekspor ke PDF.
 * Menyediakan fitur import gambar bila tersedia; bila tidak diinput gambar, tampilan polos kosong bersih.
 */
@Composable
fun PrintableReport(
    report: TechnicalReport,
    modifier: Modifier = Modifier,
    templateOption: Int = report.activeTemplate,
    onSelectPhoto: (() -> Unit)? = null,
    onRemovePhoto: (() -> Unit)? = null
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.White)
    ) {
        if (templateOption == 2) {
            PrintableHibaGroupReport(
                report = report,
                onSelectPhoto = onSelectPhoto,
                onRemovePhoto = onRemovePhoto
            )
        } else {
            PrintableStandardReport(
                report = report,
                onSelectPhoto = onSelectPhoto,
                onRemovePhoto = onRemovePhoto
            )
        }
    }
}

// =============================================================================
// DESAIN 2: FORMAT HIBA GROUP (SESUAI DOKUMEN / GAMBAR REFERENSI)
// =============================================================================
@Composable
fun PrintableHibaGroupReport(
    report: TechnicalReport,
    modifier: Modifier = Modifier,
    onSelectPhoto: (() -> Unit)? = null,
    onRemovePhoto: (() -> Unit)? = null
) {
    // Bingkai ganda terluar sesuai dokumen asli
    Box(
        modifier = modifier
            .fillMaxWidth()
            .border(2.dp, Color.Black)
            .padding(2.5.dp)
            .border(0.8.dp, Color.Black)
            .background(Color.White)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // -----------------------------------------------------------------
            // 1. HEADER ROW: [Logo + LAPORAN TEKNIK] | [No.Laporan, Bengkel, Tanggal Table]
            // -----------------------------------------------------------------
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.8.dp, Color.Black)
            ) {
                // Left Header: Logo & Title
                Row(
                    modifier = Modifier
                        .weight(1.5f)
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .background(Color(0xFF64748B), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(11.dp)
                                .background(Color.White, CircleShape)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = report.companyName.ifBlank { "Hiba Group" },
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = Color(0xFF334155)
                    )

                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = report.title.ifBlank { "LAPORAN TEKNIK" },
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.Black,
                        textDecoration = TextDecoration.Underline
                    )
                }

                // Vertical Divider
                Box(
                    modifier = Modifier
                        .width(0.8.dp)
                        .height(46.dp)
                        .background(Color.Black)
                )

                // Right Meta Table: 3 rows
                Column(modifier = Modifier.weight(1.1f)) {
                    MetaTableRow(label = "No.Laporan", value = report.reportNumber.ifBlank { "1/LT-CLG/III/2026" })
                    HorizontalDivider(thickness = 0.8.dp, color = Color.Black)
                    MetaTableRow(label = "Bengkel", value = report.workshop.ifBlank { "Cilegon" })
                    HorizontalDivider(thickness = 0.8.dp, color = Color.Black)
                    MetaTableRow(label = "Tanggal", value = report.reportDate.ifBlank { "12-Mar-26" })
                }
            }

            // -----------------------------------------------------------------
            // 2. INFORMASI UNIT / ALAT TABLE (3 rows)
            // -----------------------------------------------------------------
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.8.dp, Color.Black)
            ) {
                // Row 1: Pabrik Pembuat | HINO | Tipe | DUTRO
                Row(modifier = Modifier.fillMaxWidth()) {
                    TableCell(label = "Pabrik Pembuat", value = report.manufacturer.ifBlank { "HINO" }, modifier = Modifier.weight(1.2f))
                    TableCell(label = "Tipe", value = report.unitType.ifBlank { "DUTRO" }, modifier = Modifier.weight(1f))
                }
                HorizontalDivider(thickness = 0.8.dp, color = Color.Black)

                // Row 2: Model | W04DTPJ-53447 | Kode | D127 | Nama Alat | Ban
                Row(modifier = Modifier.fillMaxWidth()) {
                    TableCell(label = "Model", value = report.model.ifBlank { "W04DTPJ-53447" }, modifier = Modifier.weight(1.2f))
                    TableCell(label = "Kode", value = report.unitCode.ifBlank { "D127" }, modifier = Modifier.weight(0.7f))
                    TableCell(label = "Nama Alat", value = report.toolName.ifBlank { "Ban" }, modifier = Modifier.weight(0.7f))
                }
                HorizontalDivider(thickness = 0.8.dp, color = Color.Black)

                // Row 3: Tanggal Rusak | 12-Mar-26 | Km / Hm | 598916 | Komponen | Underbody
                Row(modifier = Modifier.fillMaxWidth()) {
                    TableCell(label = "Tanggal Rusak", value = report.damageDate.ifBlank { "12-Mar-26" }, modifier = Modifier.weight(1.2f))
                    TableCell(label = "Km / Hm", value = report.mileageKmHm.ifBlank { "598916" }, modifier = Modifier.weight(0.7f))
                    TableCell(label = "Komponen", value = report.component.ifBlank { "Underbody" }, modifier = Modifier.weight(0.7f))
                }
            }

            // -----------------------------------------------------------------
            // 3. SECTION: URAIAN KERUSAKAN & FOTO KERUSAKAN (Side-by-Side)
            // -----------------------------------------------------------------
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.8.dp, Color.Black)
                    .background(Color(0xFFF1F5F9))
                    .padding(vertical = 3.dp, horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1.4f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Uraian Kerusakan", fontWeight = FontWeight.Bold, fontSize = 10.5.sp, color = Color.Black)

                    val isIn = report.warrantyStatus == WarrantyStatus.IN_WARRANTY
                    val isAfter = report.warrantyStatus == WarrantyStatus.AFTER_WARRANTY

                    DocSquareCheckbox(checked = isIn, label = "Masa Garansi")
                    DocSquareCheckbox(checked = isAfter, label = "Setelah Masa Garansi")
                }

                Box(
                    modifier = Modifier
                        .width(0.8.dp)
                        .height(16.dp)
                        .background(Color.Black)
                )

                Row(
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Foto Kerusakan :",
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.5.sp,
                        color = Color.Black
                    )
                    if (onSelectPhoto != null) {
                        Surface(
                            shape = RoundedCornerShape(3.dp),
                            color = Color(0xFFDBEAFE),
                            modifier = Modifier.clickable { onSelectPhoto() }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (report.damagePhotoUri.isNotBlank()) Icons.Default.Edit else Icons.Default.AddPhotoAlternate,
                                    contentDescription = "Pilih Foto",
                                    tint = Color(0xFF1E3A8A),
                                    modifier = Modifier.size(11.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = if (report.damagePhotoUri.isNotBlank()) "Ganti" else "+ Foto",
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1E3A8A)
                                )
                            }
                        }
                    }
                }
            }

            // Body: Left details vs Right Photo
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.8.dp, Color.Black)
            ) {
                // Left details column
                Column(
                    modifier = Modifier
                        .weight(1.4f)
                        .padding(6.dp)
                ) {
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Text("Tanggal : ${report.reportDate.ifBlank { "12 Maret 2026" }}", fontWeight = FontWeight.Bold, fontSize = 9.5.sp, modifier = Modifier.weight(1f))
                        Text("Status : ${report.storingStatus.ifBlank { "Storing" }}", fontWeight = FontWeight.Bold, fontSize = 9.5.sp, modifier = Modifier.weight(1f))
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Text("Kerusakan : ${report.damageDetail.ifBlank { "Ban kempes" }}", fontWeight = FontWeight.Bold, fontSize = 9.5.sp, modifier = Modifier.weight(1f))
                        Text("Lokasi : ${report.location.ifBlank { "Tol tangerang - merak" }}", fontWeight = FontWeight.Bold, fontSize = 9.5.sp, modifier = Modifier.weight(1f))
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    Text("Analisa :", fontWeight = FontWeight.Bold, fontSize = 9.5.sp)
                    Text(
                        text = report.analysisNotes.ifBlank { "Setelah di lakukan storing oleh team cikupa di temukan ban depan kiri kempes" },
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.Black,
                        modifier = Modifier.padding(start = 4.dp, top = 1.dp)
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Row {
                        Text("Kesimpulan : ", fontWeight = FontWeight.Bold, fontSize = 9.5.sp)
                        Text(report.conclusionNotes.ifBlank { "-" }, fontSize = 9.5.sp)
                    }

                    Spacer(modifier = Modifier.height(5.dp))
                    HorizontalDivider(thickness = 0.5.dp, color = Color.Black)
                    Text("Penggantian terakhir : ${report.lastReplacement.ifBlank { "9-5-2022 (km.415513)" }}", fontWeight = FontWeight.Bold, fontSize = 9.sp, modifier = Modifier.padding(vertical = 1.5.dp))
                    HorizontalDivider(thickness = 0.5.dp, color = Color.Black)
                    Text("No. Work Order          : ${report.lastReplacementWo.ifBlank { "KLD1-WO-2205-00381" }}", fontWeight = FontWeight.Bold, fontSize = 9.sp, modifier = Modifier.padding(vertical = 1.5.dp))
                    HorizontalDivider(thickness = 0.5.dp, color = Color.Black)
                    Text("Weekly terakhir          : ${report.lastWeeklyCheck.ifBlank { "5-3-2026 (km.598234)" }}", fontWeight = FontWeight.Bold, fontSize = 9.sp, modifier = Modifier.padding(vertical = 1.5.dp))
                    HorizontalDivider(thickness = 0.5.dp, color = Color.Black)
                    Text("No. Work Order          : ${report.lastWeeklyCheckWo.ifBlank { "CLG1-WO-2603-00225" }}", fontWeight = FontWeight.Bold, fontSize = 9.sp, modifier = Modifier.padding(vertical = 1.5.dp))
                }

                // Vertical Divider
                Box(
                    modifier = Modifier
                        .width(0.8.dp)
                        .height(152.dp)
                        .background(Color.Black)
                )

                // Right photo container (Dynamic: displays image if available, else clean plain empty box)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(152.dp)
                        .padding(5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    PrintableDamagePhotoView(
                        photoUri = report.damagePhotoUri,
                        borderWidth = 0.8.dp,
                        borderColor = Color.Black,
                        onSelectPhoto = onSelectPhoto,
                        onRemovePhoto = onRemovePhoto
                    )
                }
            }

            // -----------------------------------------------------------------
            // 4. SECTION: PENYEBAB KERUSAKAN
            // -----------------------------------------------------------------
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.8.dp, Color.Black)
                    .background(Color(0xFFF1F5F9))
                    .padding(vertical = 2.5.dp, horizontal = 6.dp)
            ) {
                Text(
                    text = "Penyebab Kerusakan :  √ = YA   X = TIDAK",
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.5.sp,
                    color = Color.Black,
                    modifier = Modifier.weight(1.3f)
                )
                Text(
                    text = ".......................jika YA, tolong jelaskan!",
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.5.sp,
                    color = Color.Black,
                    modifier = Modifier.weight(1.5f)
                )
            }

            val causes = listOf(
                Triple("1. Pemasangan", report.causeInstallation, report.causeInstallationNotes),
                Triple("2. Kwalitas Parts", report.causeQuality, report.causeQualityNotes),
                Triple("3. Kesalahan Operasional", report.causeOperational, report.causeOperationalNotes),
                Triple("4. Sudah waktunya", report.causeTimeExpired, report.causeTimeExpiredNotes),
                Triple("5. Lain-lain", report.causeOthers, report.causeOthersNotes)
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.8.dp, Color.Black)
            ) {
                causes.forEachIndexed { idx, (label, checked, notes) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 1.5.dp, horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(label, fontWeight = FontWeight.Bold, fontSize = 9.sp, modifier = Modifier.weight(1.1f))
                        Text(
                            text = if (checked) "√" else "X",
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.5.sp,
                            color = if (checked) Color(0xFF1E3A8A) else Color(0xFF64748B),
                            modifier = Modifier.width(24.dp),
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = notes.ifBlank { "" },
                            fontSize = 9.sp,
                            modifier = Modifier.weight(1.5f)
                        )
                    }
                    if (idx < causes.size - 1) {
                        HorizontalDivider(thickness = 0.5.dp, color = Color.Black)
                    }
                }
            }

            // -----------------------------------------------------------------
            // 5. SECTION: CARA MENGATASI KERUSAKAN
            // -----------------------------------------------------------------
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.8.dp, Color.Black)
                    .background(Color(0xFFF1F5F9))
                    .padding(vertical = 2.5.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Cara mengatasi kerusakan :", fontWeight = FontWeight.Bold, fontSize = 9.5.sp, color = Color.Black)
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.8.dp, Color.Black)
            ) {
                Column(
                    modifier = Modifier
                        .weight(1.3f)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("1.Ganti Part Baru", fontWeight = FontWeight.Bold, fontSize = 9.sp, modifier = Modifier.weight(1f))
                        Text(if (report.solutionReplacePart) "√" else "", fontWeight = FontWeight.Bold, fontSize = 10.5.sp, modifier = Modifier.width(18.dp))
                    }
                    HorizontalDivider(thickness = 0.5.dp, color = Color.Black)
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("2.Pemasangan atau Penyetelan Ulang", fontWeight = FontWeight.Bold, fontSize = 9.sp, modifier = Modifier.weight(1f))
                        Text(if (report.solutionReinstallAdjust) "√" else "", fontWeight = FontWeight.Bold, fontSize = 10.5.sp, modifier = Modifier.width(18.dp))
                    }
                    HorizontalDivider(thickness = 0.5.dp, color = Color.Black)
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("3.Modifikasi", fontWeight = FontWeight.Bold, fontSize = 9.sp, modifier = Modifier.weight(1f))
                        Text(if (report.solutionModification) "√" else "", fontWeight = FontWeight.Bold, fontSize = 10.5.sp, modifier = Modifier.width(18.dp))
                    }
                }

                Box(
                    modifier = Modifier
                        .width(0.8.dp)
                        .height(46.dp)
                        .background(Color.Black)
                )

                Box(
                    modifier = Modifier
                        .weight(1.5f)
                        .height(46.dp)
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    val noteText = when {
                        report.solutionReinstallAdjustNotes.isNotBlank() -> report.solutionReinstallAdjustNotes
                        report.solutionReplacePartNotes.isNotBlank() -> report.solutionReplacePartNotes
                        else -> "Ganti ban stip"
                    }
                    Text(noteText, fontWeight = FontWeight.Bold, fontSize = 9.5.sp, textAlign = TextAlign.Center)
                }
            }

            // -----------------------------------------------------------------
            // 6. SECTION: TERTUNDA KARENA & USULAN PELAPOR
            // -----------------------------------------------------------------
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.8.dp, Color.Black)
                    .background(Color(0xFFF1F5F9))
                    .padding(vertical = 2.5.dp)
            ) {
                Text("Tertunda Karena", fontWeight = FontWeight.Bold, fontSize = 9.5.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1.3f))
                Box(modifier = Modifier.width(0.8.dp).height(13.dp).background(Color.Black))
                Text("Usulan Pelapor", fontWeight = FontWeight.Bold, fontSize = 9.5.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1.5f))
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.8.dp, Color.Black)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1.3f)
                        .height(42.dp)
                        .padding(4.dp)
                ) {
                    Text(report.pendingReason.ifBlank { "" }, fontSize = 9.sp)
                }

                Box(modifier = Modifier.width(0.8.dp).height(42.dp).background(Color.Black))

                Box(
                    modifier = Modifier
                        .weight(1.5f)
                        .height(42.dp)
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = report.reporterProposal.ifBlank {
                            "Segera akan di lakukan program pengecekan atau penggantian terkait part tersebut terhadap RK8J supaya tidak terjadi kejadian serupa"
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 8.5.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }

            // -----------------------------------------------------------------
            // 7. SECTION: PARTS YANG HARUS DIGANTI TABLE
            // -----------------------------------------------------------------
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.8.dp, Color.Black)
                    .background(Color(0xFFF1F5F9))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text("Parts yang harus diganti :", fontWeight = FontWeight.Bold, fontSize = 9.5.sp)
            }

            // Table Header with spanning columns
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.8.dp, Color.Black)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF8FAFC)),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("No", fontWeight = FontWeight.Bold, fontSize = 8.5.sp, textAlign = TextAlign.Center, modifier = Modifier.width(22.dp))
                    Box(modifier = Modifier.width(0.8.dp).height(22.dp).background(Color.Black))
                    Text("No Parts", fontWeight = FontWeight.Bold, fontSize = 8.5.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                    Box(modifier = Modifier.width(0.8.dp).height(22.dp).background(Color.Black))
                    Text("Nama Parts", fontWeight = FontWeight.Bold, fontSize = 8.5.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1.4f))
                    Box(modifier = Modifier.width(0.8.dp).height(22.dp).background(Color.Black))

                    // Jenis Pengadaan Part (Spanning)
                    Column(modifier = Modifier.weight(1.8f)) {
                        Text("Jenis Pengadaan Part", fontWeight = FontWeight.Bold, fontSize = 8.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp))
                        HorizontalDivider(thickness = 0.8.dp, color = Color.Black)
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Text("Stock", fontWeight = FontWeight.Bold, fontSize = 7.5.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                            Box(modifier = Modifier.width(0.8.dp).height(11.dp).background(Color.Black))
                            Text("Order", fontWeight = FontWeight.Bold, fontSize = 7.5.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                            Box(modifier = Modifier.width(0.8.dp).height(11.dp).background(Color.Black))
                            Text("Modifikasi", fontWeight = FontWeight.Bold, fontSize = 7.5.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                            Box(modifier = Modifier.width(0.8.dp).height(11.dp).background(Color.Black))
                            Text("Pending", fontWeight = FontWeight.Bold, fontSize = 7.5.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                        }
                    }
                }
                HorizontalDivider(thickness = 0.8.dp, color = Color.Black)

                // 5 Rows of Parts Table
                for (p in 0 until 5) {
                    val item = if (p < report.partsList.size) report.partsList[p] else null
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(17.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${p + 1}", fontSize = 8.sp, textAlign = TextAlign.Center, modifier = Modifier.width(22.dp))
                        Box(modifier = Modifier.width(0.8.dp).height(17.dp).background(Color.Black))
                        Text(item?.partNumber ?: "", fontSize = 8.sp, modifier = Modifier.weight(1f).padding(horizontal = 4.dp))
                        Box(modifier = Modifier.width(0.8.dp).height(17.dp).background(Color.Black))
                        Text(item?.partName ?: "", fontSize = 8.sp, modifier = Modifier.weight(1.4f).padding(horizontal = 4.dp))
                        Box(modifier = Modifier.width(0.8.dp).height(17.dp).background(Color.Black))

                        // 4 Procurement columns
                        val proc = item?.procurementType?.lowercase() ?: ""
                        Row(modifier = Modifier.weight(1.8f)) {
                            Text(if (proc == "stock") "√" else "", fontWeight = FontWeight.Bold, fontSize = 8.5.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                            Box(modifier = Modifier.width(0.8.dp).height(17.dp).background(Color.Black))
                            Text(if (proc == "order") "√" else "", fontWeight = FontWeight.Bold, fontSize = 8.5.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                            Box(modifier = Modifier.width(0.8.dp).height(17.dp).background(Color.Black))
                            Text(if (proc == "modifikasi") "√" else "", fontWeight = FontWeight.Bold, fontSize = 8.5.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                            Box(modifier = Modifier.width(0.8.dp).height(17.dp).background(Color.Black))
                            Text(if (proc == "pending") "√" else "", fontWeight = FontWeight.Bold, fontSize = 8.5.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                        }
                    }
                    if (p < 4) {
                        HorizontalDivider(thickness = 0.5.dp, color = Color.Black)
                    }
                }
            }

            // -----------------------------------------------------------------
            // 8. SECTION: SIGNATURES (MENGETAHUI & DILAPORKAN OLEH)
            // -----------------------------------------------------------------
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.8.dp, Color.Black)
            ) {
                // Left: Mengetahui,
                Column(
                    modifier = Modifier
                        .weight(1.4f)
                        .height(84.dp)
                        .padding(5.dp)
                ) {
                    Text("Mengetahui,", fontWeight = FontWeight.Bold, fontSize = 9.5.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.weight(1f))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Text("(...............................)", fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                        Text("(...............................)", fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Box(modifier = Modifier.width(0.8.dp).height(84.dp).background(Color.Black))

                // Right: Dilaporkan Oleh
                Column(
                    modifier = Modifier
                        .weight(1.5f)
                        .height(84.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFF1F5F9))
                            .padding(vertical = 1.5.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Dilaporkan Oleh:", fontWeight = FontWeight.Bold, fontSize = 9.5.sp)
                    }
                    HorizontalDivider(thickness = 0.8.dp, color = Color.Black)
                    Text("Nama    : ${report.reportedByName.ifBlank { "Yudi Indrawan" }}", fontWeight = FontWeight.Bold, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.5.dp))
                    HorizontalDivider(thickness = 0.8.dp, color = Color.Black)
                    Text("Jabatan : ${report.reportedByTitle.ifBlank { "Wa.Ka.Bengkel" }}", fontWeight = FontWeight.Bold, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.5.dp))
                    HorizontalDivider(thickness = 0.8.dp, color = Color.Black)

                    // Signatures Canvas
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(horizontal = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            SimulatedSignaturePath()
                            Text(report.knownBy2.ifBlank { "SUHERMAN" }, fontWeight = FontWeight.Bold, fontSize = 8.5.sp)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            SimulatedSignaturePath()
                            Text(report.reportedByName.ifBlank { "YUDI INDRAWAN" }, fontWeight = FontWeight.Bold, fontSize = 8.5.sp)
                        }
                    }
                }
            }
        }
    }
}

// =============================================================================
// DESAIN 1: FORMAT STANDAR DEALER (PRINTABLE)
// =============================================================================
@Composable
fun PrintableStandardReport(
    report: TechnicalReport,
    modifier: Modifier = Modifier,
    onSelectPhoto: (() -> Unit)? = null,
    onRemovePhoto: (() -> Unit)? = null
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .border(1.5.dp, Color(0xFF1E293B))
            .background(Color.White)
            .padding(12.dp)
    ) {
        // Document Header
        Text(
            text = report.title.ifBlank { "LAPORAN TEKNIK" },
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0F172A),
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), thickness = 2.dp, color = Color(0xFF1E3A8A))

        // No Laporan, Bengkel, Tanggal
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1.2f)) {
                Text(
                    text = "No. Laporan: ${report.reportNumber.ifBlank { "-" }}",
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Bengkel: ${report.workshop.ifBlank { "-" }}",
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Tanggal: ${report.reportDate.ifBlank { "-" }}",
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 1. INFORMASI UNIT / ALAT
        DocSectionBar("1. INFORMASI UNIT / ALAT")
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFFCBD5E1))
                .padding(8.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth()) {
                DocKeyValue("Pabrik Pembuat", report.manufacturer, Modifier.weight(1f))
                DocKeyValue("Nama Alat", report.toolName, Modifier.weight(1f))
            }
            Row(modifier = Modifier.fillMaxWidth()) {
                DocKeyValue("Tipe", report.unitType, Modifier.weight(1f))
                DocKeyValue("Tanggal Rusak", report.damageDate, Modifier.weight(1f))
            }
            Row(modifier = Modifier.fillMaxWidth()) {
                DocKeyValue("Model", report.model, Modifier.weight(1f))
                DocKeyValue("KM / HM", report.mileageKmHm, Modifier.weight(1f))
            }
            Row(modifier = Modifier.fillMaxWidth()) {
                DocKeyValue("Kode Unit", report.unitCode, Modifier.weight(1f))
                DocKeyValue("Komponen", report.component, Modifier.weight(1f))
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 2. STATUS GARANSI
        DocSectionBar("2. STATUS GARANSI")
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFFCBD5E1))
                .padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            val isIn = report.warrantyStatus == WarrantyStatus.IN_WARRANTY
            val isAfter = report.warrantyStatus == WarrantyStatus.AFTER_WARRANTY

            DocCheckboxItem(checked = isIn, label = "Masa Garansi")
            DocCheckboxItem(checked = isAfter, label = "Setelah Masa Garansi")
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 3. DETAIL KERUSAKAN, LOKASI & FOTO DOKUMENTASI
        DocSectionBar("3. DETAIL KERUSAKAN & LOKASI")
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFFCBD5E1))
                .padding(8.dp)
        ) {
            Column(modifier = Modifier.weight(1.3f)) {
                DocRowText("Kerusakan", report.damageDetail)
                DocRowText("Lokasi", report.location)
                DocRowText("History Bengkel", report.workshopHistory)
                DocRowText("History Ban/Part", report.tireHistory)
                DocRowText("Lampiran", report.attachments)
            }

            // Dynamic Photo Slot for Desain 1
            Box(
                modifier = Modifier
                    .width(130.dp)
                    .height(95.dp)
                    .padding(start = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                PrintableDamagePhotoView(
                    photoUri = report.damagePhotoUri,
                    borderWidth = 1.dp,
                    borderColor = if (report.damagePhotoUri.isNotBlank()) Color(0xFF94A3B8) else Color(0xFFCBD5E1),
                    shape = RoundedCornerShape(4.dp),
                    onSelectPhoto = onSelectPhoto,
                    onRemovePhoto = onRemovePhoto
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 4. PENYEBAB KERUSAKAN
        DocSectionBar("4. PENYEBAB KERUSAKAN")
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFFCBD5E1))
                .padding(8.dp)
        ) {
            DocCauseRow("1. Pemasangan", report.causeInstallation, report.causeInstallationNotes)
            DocCauseRow("2. Kualitas", report.causeQuality, report.causeQualityNotes)
            DocCauseRow("3. Kesalahan Operasional", report.causeOperational, report.causeOperationalNotes)
            DocCauseRow("4. Sudah Waktunya", report.causeTimeExpired, report.causeTimeExpiredNotes)
            DocCauseRow("5. Lain-lain", report.causeOthers, report.causeOthersNotes)
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 5. CARA MENGATASI KERUSAKAN
        DocSectionBar("5. CARA MENGATASI KERUSAKAN")
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFFCBD5E1))
                .padding(8.dp)
        ) {
            DocCauseRow("1. Ganti Part Baru", report.solutionReplacePart, report.solutionReplacePartNotes)
            DocCauseRow("2. Pemasangan / Penyetelan Ulang", report.solutionReinstallAdjust, report.solutionReinstallAdjustNotes)
            DocCauseRow("3. Modifikasi", report.solutionModification, report.solutionModificationNotes)
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 6. TABEL PARTS YANG HARUS DIGANTI
        DocSectionBar("6. TABEL PARTS YANG HARUS DIGANTI")
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFFCBD5E1))
        ) {
            // Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFE2E8F0))
                    .padding(vertical = 3.5.dp, horizontal = 6.dp)
            ) {
                Text("NO", fontWeight = FontWeight.Bold, fontSize = 9.5.sp, color = Color.Black, modifier = Modifier.width(26.dp))
                Text("No. Part", fontWeight = FontWeight.Bold, fontSize = 9.5.sp, color = Color.Black, modifier = Modifier.weight(1.2f))
                Text("Nama Parts", fontWeight = FontWeight.Bold, fontSize = 9.5.sp, color = Color.Black, modifier = Modifier.weight(1.5f))
                Text("Pengadaan", fontWeight = FontWeight.Bold, fontSize = 9.5.sp, color = Color.Black, modifier = Modifier.weight(1f))
                Text("Keterangan", fontWeight = FontWeight.Bold, fontSize = 9.5.sp, color = Color.Black, modifier = Modifier.weight(1.2f))
            }
            HorizontalDivider(thickness = 1.dp, color = Color(0xFFCBD5E1))

            if (report.partsList.isEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(5.dp)
                ) {
                    Text("1", fontSize = 9.sp, color = Color.Black, modifier = Modifier.width(26.dp))
                    Text("-", fontSize = 9.sp, color = Color.Black, modifier = Modifier.weight(1.2f))
                    Text("Tidak ada pergantian part", fontSize = 9.sp, color = Color.Black, modifier = Modifier.weight(1.5f))
                    Text("Stock", fontSize = 9.sp, color = Color.Black, modifier = Modifier.weight(1f))
                    Text("-", fontSize = 9.sp, color = Color.Black, modifier = Modifier.weight(1.2f))
                }
            } else {
                report.partsList.forEachIndexed { idx, part ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp, horizontal = 6.dp)
                    ) {
                        Text("${idx + 1}", fontSize = 9.sp, color = Color.Black, modifier = Modifier.width(26.dp))
                        Text(part.partNumber.ifBlank { "-" }, fontSize = 9.sp, color = Color.Black, modifier = Modifier.weight(1.2f))
                        Text(part.partName.ifBlank { "-" }, fontSize = 9.sp, color = Color.Black, modifier = Modifier.weight(1.5f))
                        Text(part.procurementType.ifBlank { "Stock" }, fontSize = 9.sp, color = Color.Black, modifier = Modifier.weight(1f))
                        Text(part.notes.ifBlank { "-" }, fontSize = 9.sp, color = Color.Black, modifier = Modifier.weight(1.2f))
                    }
                    if (idx < report.partsList.size - 1) {
                        HorizontalDivider(thickness = 0.5.dp, color = Color(0xFFE2E8F0))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 7. BAGIAN PENANDATANGAN
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Disetujui Oleh
            Column(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, Color(0xFFCBD5E1))
                    .padding(6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Disetujui Oleh:", fontWeight = FontWeight.Bold, fontSize = 10.5.sp, color = Color.Black)
                Text(report.approvedByTitle.ifBlank { "WA.KA. Bengkel" }, fontSize = 9.5.sp, color = Color(0xFF475569))
                Spacer(modifier = Modifier.height(30.dp))
                HorizontalDivider(modifier = Modifier.width(120.dp), thickness = 1.dp, color = Color.Black)
                Spacer(modifier = Modifier.height(2.dp))
                Text(report.approvedByName.ifBlank { "Yudi Indrawan" }, fontWeight = FontWeight.Bold, fontSize = 10.5.sp, color = Color.Black)
                Text("Tgl: ${report.signDate.ifBlank { report.reportDate }}", fontSize = 8.5.sp, color = Color(0xFF64748B))
            }

            // Dilaporkan Oleh
            Column(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, Color(0xFFCBD5E1))
                    .padding(6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Dilaporkan Oleh:", fontWeight = FontWeight.Bold, fontSize = 10.5.sp, color = Color.Black)
                Text(report.reportedByTitle.ifBlank { "Pelapor / Mekanik" }, fontSize = 9.5.sp, color = Color(0xFF475569))
                Spacer(modifier = Modifier.height(30.dp))
                HorizontalDivider(modifier = Modifier.width(120.dp), thickness = 1.dp, color = Color.Black)
                Spacer(modifier = Modifier.height(2.dp))
                Text(report.reportedByName.ifBlank { "Ahmad Supriyadi" }, fontWeight = FontWeight.Bold, fontSize = 10.5.sp, color = Color.Black)
                Text("Tgl: ${report.signDate.ifBlank { report.reportDate }}", fontSize = 8.5.sp, color = Color(0xFF64748B))
            }
        }
    }
}

// =============================================================================
// SUB-KOMPONEN BANTUAN TATA LETAK CETAK
// =============================================================================
@Composable
private fun SimulatedSignaturePath() {
    Canvas(modifier = Modifier.size(width = 50.dp, height = 18.dp)) {
        val path = Path().apply {
            moveTo(2f, size.height * 0.7f)
            cubicTo(size.width * 0.2f, 0f, size.width * 0.4f, size.height, size.width * 0.6f, size.height * 0.2f)
            cubicTo(size.width * 0.7f, size.height * 0.9f, size.width * 0.85f, 0f, size.width - 2f, size.height * 0.5f)
        }
        drawPath(path, color = Color(0xFF1E293B), style = Stroke(width = 1.4f))
    }
}

@Composable
private fun MetaTableRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontWeight = FontWeight.Bold, fontSize = 8.5.sp, modifier = Modifier.width(60.dp), color = Color.Black)
        Box(modifier = Modifier.width(0.8.dp).height(11.dp).background(Color.Black))
        Spacer(modifier = Modifier.width(4.dp))
        Text(value, fontSize = 8.5.sp, color = Color.Black, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun TableCell(label: String, value: String, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.padding(horizontal = 4.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontWeight = FontWeight.Bold, fontSize = 8.sp, color = Color.Black, modifier = Modifier.width(76.dp))
        Box(modifier = Modifier.width(0.8.dp).height(13.dp).background(Color.Black))
        Spacer(modifier = Modifier.width(4.dp))
        Text(value, fontWeight = FontWeight.Bold, fontSize = 8.sp, color = Color.Black)
    }
}

@Composable
private fun DocSquareCheckbox(checked: Boolean, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(9.dp)
                .border(1.dp, Color.Black),
            contentAlignment = Alignment.Center
        ) {
            if (checked) {
                Text("√", fontSize = 7.5.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            }
        }
        Spacer(modifier = Modifier.width(3.dp))
        Text(text = label, fontSize = 8.sp, color = Color.Black, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun DocSectionBar(title: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFE2E8F0))
            .border(0.5.dp, Color(0xFFCBD5E1))
            .padding(horizontal = 6.dp, vertical = 2.5.dp)
    ) {
        Text(
            text = title,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0F172A)
        )
    }
}

@Composable
private fun DocKeyValue(key: String, value: String, modifier: Modifier = Modifier) {
    Row(modifier = modifier.padding(vertical = 1.5.dp)) {
        Text(
            text = "$key",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black,
            modifier = Modifier.width(85.dp)
        )
        Text(
            text = ": ${value.ifBlank { "-" }}",
            fontSize = 9.sp,
            color = Color.Black
        )
    }
}

@Composable
private fun DocRowText(key: String, value: String) {
    Row(modifier = Modifier.padding(vertical = 1.5.dp)) {
        Text(
            text = "$key",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black,
            modifier = Modifier.width(100.dp)
        )
        Text(
            text = ": ${value.ifBlank { "-" }}",
            fontSize = 9.sp,
            color = Color.Black
        )
    }
}

@Composable
private fun DocCheckboxItem(checked: Boolean, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .border(1.dp, Color.Black)
                .background(if (checked) Color(0xFF1E3A8A) else Color.Transparent),
            contentAlignment = Alignment.Center
        ) {
            if (checked) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(10.dp)
                )
            }
        }
        Spacer(modifier = Modifier.width(5.dp))
        Text(text = label, fontSize = 10.sp, color = Color.Black, fontWeight = if (checked) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun DocCauseRow(label: String, checked: Boolean, notes: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 1.5.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .padding(top = 2.dp)
                .size(12.dp)
                .border(1.dp, Color.Black)
                .background(if (checked) Color(0xFF1E3A8A) else Color.Transparent),
            contentAlignment = Alignment.Center
        ) {
            if (checked) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(10.dp)
                )
            }
        }
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = label,
            fontSize = 9.5.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black,
            modifier = Modifier.width(145.dp)
        )
        if (notes.isNotBlank()) {
            val safeNotes = if (notes.startsWith("-") || notes.startsWith("Kesimpulan:")) notes else "- $notes"
            Text(
                text = safeNotes,
                fontSize = 9.5.sp,
                color = Color.Black,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

private fun loadReportBitmapSafely(context: Context, uriString: String): Bitmap? {
    if (uriString.isBlank()) return null
    if (uriString == "sample") {
        return try {
            BitmapFactory.decodeResource(context.resources, R.drawable.sample_damaged_tire)
        } catch (_: Exception) { null }
    }
    return try {
        val uri = Uri.parse(uriString)
        if (uri.scheme == "file") {
            BitmapFactory.decodeFile(uri.path)
        } else {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream)
            }
        }
    } catch (_: Exception) { null }
}

/**
 * PrintableDamagePhotoView:
 * Memanfaatkan pustaka Coil (AsyncImage) untuk memuat gambar bagian rusak secara asinkron dan efisien.
 * Bila tidak diinput gambar (kosong), menampilkan bidang polos bersih rapi sesuai standar dokumen resmi.
 */
@Composable
fun PrintableDamagePhotoView(
    photoUri: String,
    modifier: Modifier = Modifier,
    borderWidth: androidx.compose.ui.unit.Dp = 0.8.dp,
    borderColor: Color = Color.Black,
    shape: androidx.compose.ui.graphics.Shape = RoundedCornerShape(0.dp),
    onSelectPhoto: (() -> Unit)? = null,
    onRemovePhoto: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val imageModel: Any? = remember(photoUri) {
        when {
            photoUri.isBlank() -> null
            photoUri == "sample" -> R.drawable.sample_damaged_tire
            photoUri.startsWith("content://") || photoUri.startsWith("file://") -> Uri.parse(photoUri)
            else -> File(photoUri).takeIf { it.exists() } ?: Uri.parse(photoUri)
        }
    }

    if (imageModel != null) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .border(borderWidth, borderColor, shape)
                .clip(shape)
                .background(Color.White)
        ) {
            AsyncImage(
                model = ImageRequest.Builder(context)
                    .data(imageModel)
                    .crossfade(true)
                    .build(),
                contentDescription = "Foto Bagian Rusak",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            if (onRemovePhoto != null) {
                Surface(
                    shape = CircleShape,
                    color = Color.Black.copy(alpha = 0.65f),
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .size(20.dp)
                        .clickable { onRemovePhoto() }
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Hapus Foto",
                        tint = Color.White,
                        modifier = Modifier
                            .padding(3.dp)
                            .fillMaxSize()
                    )
                }
            }
        }
    } else {
        // TAMPILAN POLOS KOSONG BERSIH (Sesuai Preferensi: bersih polos bila tanpa input gambar)
        Box(
            modifier = modifier
                .fillMaxSize()
                .border(borderWidth, borderColor, shape)
                .background(Color.White)
                .clickable(enabled = onSelectPhoto != null) { onSelectPhoto?.invoke() },
            contentAlignment = Alignment.Center
        ) {
            if (onSelectPhoto != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(Color(0xFFF8FAFC), RoundedCornerShape(4.dp))
                        .border(0.5.dp, Color(0xFFCBD5E1), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AddPhotoAlternate,
                        contentDescription = "Import Gambar",
                        tint = Color(0xFF64748B),
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Import Gambar",
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF64748B)
                    )
                }
            }
        }
    }
}
