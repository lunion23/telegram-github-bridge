package com.example.util

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.content.FileProvider
import com.example.data.model.PrintFormatMode
import com.example.data.model.ReceiptData
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

object PdfReceiptGenerator {

    /**
     * Generates a PDF file from receipt data based on selected format.
     */
    fun generatePdfFile(context: Context, receipt: ReceiptData): File {
        val (pdfWidth, pdfHeight) = when (receipt.selectedFormat) {
            PrintFormatMode.MAIN_LABEL -> Pair(420, 650)
            PrintFormatMode.SENDER_COPY -> Pair(420, 360)
            PrintFormatMode.COMBO_ALL -> Pair(420, 1010)
        }

        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pdfWidth, pdfHeight, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        when (receipt.selectedFormat) {
            PrintFormatMode.MAIN_LABEL -> drawReceiptOnCanvas(canvas, receipt, pdfWidth.toFloat(), pdfHeight.toFloat())
            PrintFormatMode.SENDER_COPY -> drawSenderCopyOnCanvas(canvas, receipt, pdfWidth.toFloat(), pdfHeight.toFloat())
            PrintFormatMode.COMBO_ALL -> drawComboOnCanvas(canvas, receipt, pdfWidth.toFloat(), pdfHeight.toFloat())
        }

        pdfDocument.finishPage(page)

        val outputDir = File(context.cacheDir, "receipt_pdfs").apply { mkdirs() }
        val sanitizedResi = receipt.resiCode.replace("[^a-zA-Z0-9]".toRegex(), "_")
        val outputFile = File(outputDir, "Struk_${receipt.selectedFormat.name}_${sanitizedResi}.pdf")

        FileOutputStream(outputFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
        return outputFile
    }

    /**
     * Renders a PDF file into a preview Bitmap using PdfRenderer.
     */
    fun renderPdfToBitmap(pdfFile: File): Bitmap? {
        if (!pdfFile.exists()) return null
        return try {
            val fileDescriptor = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
            val renderer = PdfRenderer(fileDescriptor)
            if (renderer.pageCount == 0) {
                renderer.close()
                fileDescriptor.close()
                return null
            }
            val page = renderer.openPage(0)
            val scale = 2.0f
            val bitmap = Bitmap.createBitmap(
                (page.width * scale).toInt(),
                (page.height * scale).toInt(),
                Bitmap.Config.ARGB_8888
            )
            bitmap.eraseColor(Color.WHITE)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            page.close()
            renderer.close()
            fileDescriptor.close()
            bitmap
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Unwraps context to obtain the enclosing Activity.
     */
    fun findActivity(context: Context): Activity? {
        var ctx = context
        while (ctx is ContextWrapper) {
            if (ctx is Activity) return ctx
            ctx = ctx.baseContext
        }
        return null
    }

    /**
     * Launches the system PrintManager to print the PDF.
     */
    fun printPdf(context: Context, pdfFile: File, jobName: String = "Cetak Struk"): Boolean {
        val activity = findActivity(context) ?: return false
        val printManager = activity.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return false
        val printAdapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder("$jobName.pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build()
                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                var input: FileInputStream? = null
                var output: FileOutputStream? = null
                try {
                    input = FileInputStream(pdfFile)
                    output = FileOutputStream(destination?.fileDescriptor)
                    val buf = ByteArray(1024)
                    var bytesRead: Int
                    while (input.read(buf).also { bytesRead = it } > 0) {
                        if (cancellationSignal?.isCanceled == true) {
                            callback?.onWriteCancelled()
                            return
                        }
                        output.write(buf, 0, bytesRead)
                    }
                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                } finally {
                    try { input?.close() } catch (_: IOException) {}
                    try { output?.close() } catch (_: IOException) {}
                }
            }
        }

        val attributes = PrintAttributes.Builder()
            .setMediaSize(PrintAttributes.MediaSize.ISO_A6)
            .setResolution(PrintAttributes.Resolution("thermal", "Thermal", 300, 300))
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .build()

        printManager.print(jobName, printAdapter, attributes)
        return true
    }

    /**
     * Shares the generated PDF file using standard Android Intent.
     */
    fun sharePdf(context: Context, pdfFile: File) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.provider",
                pdfFile
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Struk Resi ${pdfFile.name}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, "Bagikan Struk PDF")
            if (context !is Activity) {
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * OPSI 1: Draws Main Label on Canvas.
     */
    fun drawReceiptOnCanvas(
        canvas: Canvas,
        receipt: ReceiptData,
        width: Float,
        height: Float
    ) {
        val bgPaint = Paint().apply { color = Color.WHITE; style = Paint.Style.FILL }
        canvas.drawRect(0f, 0f, width, height, bgPaint)

        val borderPaint = Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 2f; isAntiAlias = true }
        val fillBlackPaint = Paint().apply { color = Color.BLACK; style = Paint.Style.FILL; isAntiAlias = true }
        val textPaint = Paint().apply { color = Color.BLACK; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL) }
        val boldTextPaint = Paint().apply { color = Color.BLACK; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }
        val whiteBoldPaint = Paint().apply { color = Color.WHITE; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }

        val leftBorder = 26f
        val rightBorder = width - 26f
        val topBorder = 12f
        val bottomBorder = height - 12f

        canvas.drawRect(leftBorder, topBorder, rightBorder, bottomBorder, borderPaint)

        // Vertical side texts
        drawVerticalSideResi(canvas, receipt.resiCode, leftBorder, rightBorder, topBorder, bottomBorder, 4)

        // Top Badges [NP] [EZ]
        val badgeWidth = 44f
        val badgeHeight = 22f
        val badge2Left = rightBorder - badgeWidth - 4f
        val badge1Left = badge2Left - badgeWidth - 4f
        val badgeTop = topBorder + 4f

        canvas.drawRect(badge1Left, badgeTop, badge1Left + badgeWidth, badgeTop + badgeHeight, fillBlackPaint)
        canvas.drawRect(badge2Left, badgeTop, badge2Left + badgeWidth, badgeTop + badgeHeight, fillBlackPaint)

        whiteBoldPaint.textSize = 13f
        whiteBoldPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.badge1, badge1Left + (badgeWidth / 2), badgeTop + 16f, whiteBoldPaint)
        canvas.drawText(receipt.badge2, badge2Left + (badgeWidth / 2), badgeTop + 16f, whiteBoldPaint)

        // Routing Code
        boldTextPaint.textSize = 23f
        boldTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText(receipt.routingCode, leftBorder + 8f, badgeTop + 20f, boldTextPaint)

        var currentY = badgeTop + badgeHeight + 6f
        canvas.drawLine(leftBorder, currentY, rightBorder, currentY, borderPaint)

        // Barcode
        currentY += 4f
        val barcodeBitmap = BarcodeGenerator.generateBarcode128(receipt.resiCode, width = 500, height = 90)
        val barcodeRect = RectF(leftBorder + 18f, currentY, rightBorder - 18f, currentY + 54f)
        if (barcodeBitmap != null) {
            canvas.drawBitmap(barcodeBitmap, null, barcodeRect, null)
        }

        currentY += 58f
        boldTextPaint.textSize = 12f
        boldTextPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.resiCode, (leftBorder + rightBorder) / 2f, currentY + 10f, boldTextPaint)

        // Drop point banner
        currentY += 15f
        canvas.drawRect(leftBorder, currentY, rightBorder, currentY + 22f, fillBlackPaint)
        whiteBoldPaint.textSize = 11.5f
        whiteBoldPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.dropPoint, (leftBorder + rightBorder) / 2f, currentY + 16f, whiteBoldPaint)
        currentY += 22f

        // Recipient
        currentY += 12f
        boldTextPaint.textSize = 10f
        boldTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Penerima: ${receipt.recipientName}", leftBorder + 6f, currentY, boldTextPaint)
        boldTextPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(receipt.getDisplayRecipientPhone(), rightBorder - 6f, currentY, boldTextPaint)

        currentY += 4f
        textPaint.textSize = 8.5f
        textPaint.textAlign = Paint.Align.LEFT
        currentY = drawMultilineText(canvas, receipt.recipientAddress, leftBorder + 6f, currentY + 10f, rightBorder - leftBorder - 12f, textPaint, 11f, 4)

        currentY += 6f
        canvas.drawLine(leftBorder, currentY, rightBorder, currentY, borderPaint)

        // Sender
        currentY += 12f
        boldTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Pengirim: ${receipt.senderName}", leftBorder + 6f, currentY, boldTextPaint)
        boldTextPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(receipt.getDisplaySenderPhone(), rightBorder - 6f, currentY, boldTextPaint)

        currentY += 4f
        currentY = drawMultilineText(canvas, receipt.senderAddress, leftBorder + 6f, currentY + 10f, rightBorder - leftBorder - 12f, textPaint, 11f, 3)

        currentY += 6f
        canvas.drawLine(leftBorder, currentY, rightBorder, currentY, borderPaint)

        // Shipping Table
        val tableTop = currentY
        val col1Width = 84f
        val col2Width = 60f
        val col3Width = 75f
        val row1Height = 32f
        val row2Height = 20f
        val row3Height = 18f
        val tableHeight = row1Height + row2Height + row3Height

        canvas.drawLine(leftBorder, tableTop + row1Height, rightBorder, tableTop + row1Height, borderPaint)
        canvas.drawLine(leftBorder, tableTop + row1Height + row2Height, rightBorder, tableTop + row1Height + row2Height, borderPaint)
        canvas.drawLine(leftBorder, tableTop + tableHeight, rightBorder, tableTop + tableHeight, borderPaint)

        val col1Right = leftBorder + col1Width
        val col2Right = col1Right + col2Width
        val col3Right = col2Right + col3Width

        canvas.drawLine(col1Right, tableTop, col1Right, tableTop + row1Height + row2Height, borderPaint)
        canvas.drawLine(col2Right, tableTop, col2Right, tableTop + row1Height, borderPaint)
        canvas.drawLine(col3Right, tableTop, col3Right, tableTop + row1Height + row2Height, borderPaint)

        // Col 1
        canvas.drawRect(leftBorder, tableTop, col1Right, tableTop + 11f, fillBlackPaint)
        whiteBoldPaint.textSize = 6.8f
        whiteBoldPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("BIAYA PENGIRIMAN", leftBorder + (col1Width / 2f), tableTop + 8.5f, whiteBoldPaint)

        boldTextPaint.textSize = 10.5f
        boldTextPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.getFormattedFee(), leftBorder + (col1Width / 2f), tableTop + 21f, boldTextPaint)

        textPaint.textSize = 6.2f
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("Sudah Termasuk PPH", leftBorder + (col1Width / 2f), tableTop + 29f, textPaint)

        // Col 2
        boldTextPaint.textSize = 9.5f
        canvas.drawText(receipt.paymentType, col1Right + (col2Width / 2f), tableTop + 18f, boldTextPaint)

        // Col 3
        canvas.drawText("• ${receipt.weightKg}", col2Right + (col3Width / 2f), tableTop + 18f, boldTextPaint)

        // Col 4
        textPaint.textSize = 8f
        canvas.drawText("Cetak ${receipt.printDate}", col3Right + ((rightBorder - col3Right) / 2f), tableTop + 18f, textPaint)

        // Row 2
        textPaint.textSize = 7.5f
        textPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Order No. ${receipt.orderNo}", col1Right + 5f, tableTop + row1Height + 14f, textPaint)
        canvas.drawText("Exp: ${receipt.expNote}", col3Right + 5f, tableTop + row1Height + 14f, textPaint)

        // Row 3
        textPaint.textSize = 7.8f
        canvas.drawText("Notes: ${receipt.notes}", leftBorder + 6f, tableTop + row1Height + row2Height + 13f, textPaint)

        // Footer
        currentY = tableTop + tableHeight + 8f
        val qrSize = 68f
        val qrLeft = rightBorder - qrSize - 4f
        val qrBitmap = BarcodeGenerator.generateQrCode(receipt.resiCode, size = 180)
        if (qrBitmap != null) {
            canvas.drawBitmap(qrBitmap, null, RectF(qrLeft, currentY, qrLeft + qrSize, currentY + qrSize), null)
        }

        textPaint.textSize = 6.5f
        textPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Syarat dan ketentuan pengiriman dilihat pada website", leftBorder + 6f, currentY + 8f, textPaint)

        val lines = receipt.footerCompany.split("\n")
        var footerY = currentY + 18f
        for (line in lines) {
            canvas.drawText(line.trim(), leftBorder + 6f, footerY, textPaint)
            footerY += 9f
        }
    }

    /**
     * OPSI 2: Draws Sender Copy (Lembar Pengirim - Gambar 1) on Canvas.
     */
    fun drawSenderCopyOnCanvas(
        canvas: Canvas,
        receipt: ReceiptData,
        width: Float,
        height: Float
    ) {
        val bgPaint = Paint().apply { color = Color.WHITE; style = Paint.Style.FILL }
        canvas.drawRect(0f, 0f, width, height, bgPaint)

        val borderPaint = Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 2f; isAntiAlias = true }
        val fillBlackPaint = Paint().apply { color = Color.BLACK; style = Paint.Style.FILL; isAntiAlias = true }
        val textPaint = Paint().apply { color = Color.BLACK; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL) }
        val boldTextPaint = Paint().apply { color = Color.BLACK; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }
        val whiteBoldPaint = Paint().apply { color = Color.WHITE; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }

        val leftBorder = 26f
        val rightBorder = width - 26f
        val topBorder = 10f
        val bottomBorder = height - 10f

        canvas.drawRect(leftBorder, topBorder, rightBorder, bottomBorder, borderPaint)

        // Vertical side texts (2 repeats)
        drawVerticalSideResi(canvas, receipt.resiCode, leftBorder, rightBorder, topBorder, bottomBorder, 2)

        // Top Barcode
        var currentY = topBorder + 6f
        val barcodeBitmap = BarcodeGenerator.generateBarcode128(receipt.resiCode, width = 500, height = 75)
        val barcodeRect = RectF(leftBorder + 24f, currentY, rightBorder - 24f, currentY + 45f)
        if (barcodeBitmap != null) {
            canvas.drawBitmap(barcodeBitmap, null, barcodeRect, null)
        }

        currentY += 48f
        boldTextPaint.textSize = 11.5f
        boldTextPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.resiCode, (leftBorder + rightBorder) / 2f, currentY + 10f, boldTextPaint)

        currentY += 16f
        canvas.drawLine(leftBorder, currentY, rightBorder, currentY, borderPaint)

        // Sender & Recipient lines
        currentY += 13f
        boldTextPaint.textSize = 10f
        boldTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Pengirim: ${receipt.senderName}", leftBorder + 6f, currentY, boldTextPaint)
        boldTextPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(receipt.getDisplaySenderPhone(), rightBorder - 6f, currentY, boldTextPaint)

        currentY += 14f
        boldTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Penerima: ${receipt.recipientName}", leftBorder + 6f, currentY, boldTextPaint)
        boldTextPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(receipt.getDisplayRecipientPhone(), rightBorder - 6f, currentY, boldTextPaint)

        currentY += 4f
        textPaint.textSize = 8.2f
        textPaint.textAlign = Paint.Align.LEFT
        currentY = drawMultilineText(canvas, receipt.recipientAddress, leftBorder + 6f, currentY + 9f, rightBorder - leftBorder - 12f, textPaint, 10f, 2)

        currentY += 6f
        canvas.drawLine(leftBorder, currentY, rightBorder, currentY, borderPaint)

        // Split Section: Left (Total Biaya + Lembar Pengirim), Right (Qty, Barang, Notes, Cetak, Exp, Legal)
        val splitTop = currentY
        val splitHeight = bottomBorder - splitTop
        val leftColWidth = 135f
        val splitDividerX = leftBorder + leftColWidth

        // Vertical Divider
        canvas.drawLine(splitDividerX, splitTop, splitDividerX, bottomBorder, borderPaint)

        // Left Column: Total Biaya
        boldTextPaint.textSize = 11.5f
        boldTextPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("TOTAL BIAYA", leftBorder + (leftColWidth / 2f), splitTop + 24f, boldTextPaint)

        boldTextPaint.textSize = 13.5f
        canvas.drawText(receipt.getFormattedFee(), leftBorder + (leftColWidth / 2f), splitTop + 48f, boldTextPaint)

        textPaint.textSize = 7.5f
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("Sudah Termasuk PPN", leftBorder + (leftColWidth / 2f), splitTop + 62f, textPaint)

        // Lembar Pengirim Black Badge
        val badgeHeight = 26f
        canvas.drawRect(leftBorder, bottomBorder - badgeHeight, splitDividerX, bottomBorder, fillBlackPaint)
        whiteBoldPaint.textSize = 10f
        whiteBoldPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("Lembar Pengirim", leftBorder + (leftColWidth / 2f), bottomBorder - 8.5f, whiteBoldPaint)

        // Right Column rows
        val rRow1H = 22f
        val rRow2H = 24f
        val rRow3H = 22f

        // Row 1: Qty & Barang
        canvas.drawLine(splitDividerX, splitTop + rRow1H, rightBorder, splitTop + rRow1H, borderPaint)
        val rSubColW = 55f
        canvas.drawLine(splitDividerX + rSubColW, splitTop, splitDividerX + rSubColW, splitTop + rRow1H, borderPaint)

        boldTextPaint.textSize = 8.5f
        boldTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Qty ${receipt.itemQty}", splitDividerX + 5f, splitTop + 15f, boldTextPaint)
        canvas.drawText("BARANG ${receipt.itemName}", splitDividerX + rSubColW + 5f, splitTop + 15f, boldTextPaint)

        // Row 2: Notes
        canvas.drawLine(splitDividerX, splitTop + rRow1H + rRow2H, rightBorder, splitTop + rRow1H + rRow2H, borderPaint)
        textPaint.textSize = 8.2f
        canvas.drawText("Notes: ${receipt.notes}", splitDividerX + 5f, splitTop + rRow1H + 16f, textPaint)

        // Row 3: Cetak & Exp
        canvas.drawLine(splitDividerX, splitTop + rRow1H + rRow2H + rRow3H, rightBorder, splitTop + rRow1H + rRow2H + rRow3H, borderPaint)
        val rSubExpW = (rightBorder - splitDividerX) / 2f
        canvas.drawLine(splitDividerX + rSubExpW, splitTop + rRow1H + rRow2H, splitDividerX + rSubExpW, splitTop + rRow1H + rRow2H + rRow3H, borderPaint)

        textPaint.textSize = 8f
        canvas.drawText("Cetak ${receipt.printDate}", splitDividerX + 5f, splitTop + rRow1H + rRow2H + 15f, textPaint)
        canvas.drawText("Exp ${receipt.expDate}", splitDividerX + rSubExpW + 5f, splitTop + rRow1H + rRow2H + 15f, textPaint)

        // Row 4: Legal & PT GLOBAL JET EXPRESS
        var legalY = splitTop + rRow1H + rRow2H + rRow3H + 11f
        textPaint.textSize = 6f
        canvas.drawText("Syarat dan ketentuan pengiriman dilihat pada website www.jet.co.id", splitDividerX + 5f, legalY, textPaint)
        legalY += 8.5f
        canvas.drawText("PT GLOBAL JET EXPRESS, 0735697740 041 000", splitDividerX + 5f, legalY, textPaint)
        legalY += 8.5f
        canvas.drawText("LANDMARK PLUIT TOWER BLOK B1, LANTAI 8, 9A,", splitDividerX + 5f, legalY, textPaint)
    }

    /**
     * OPSI 3: Draws Combo 2-in-1 (Main Label + Lembar Pengirim - Gambar 2) on Canvas.
     */
    fun drawComboOnCanvas(
        canvas: Canvas,
        receipt: ReceiptData,
        width: Float,
        height: Float
    ) {
        val bgPaint = Paint().apply { color = Color.WHITE; style = Paint.Style.FILL }
        canvas.drawRect(0f, 0f, width, height, bgPaint)

        val borderPaint = Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 2f; isAntiAlias = true }
        val leftBorder = 26f
        val rightBorder = width - 26f
        val topBorder = 10f
        val bottomBorder = height - 10f

        canvas.drawRect(leftBorder, topBorder, rightBorder, bottomBorder, borderPaint)

        // Draw side vertical resi continuously (6 repeats down the entire combined length)
        drawVerticalSideResi(canvas, receipt.resiCode, leftBorder, rightBorder, topBorder, bottomBorder, 6)

        // Top Part: Draw Main Label
        drawMainLabelInternal(canvas, receipt, leftBorder, rightBorder, topBorder)

        // Perforation Divider Line
        val perforationY = 645f
        val perfPaint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
        }
        canvas.drawLine(leftBorder, perforationY, rightBorder, perforationY, perfPaint)

        // Bottom Part: Draw Sender Copy
        drawSenderCopyInternal(canvas, receipt, leftBorder, rightBorder, perforationY + 4f, bottomBorder)
    }

    private fun drawMainLabelInternal(
        canvas: Canvas,
        receipt: ReceiptData,
        leftBorder: Float,
        rightBorder: Float,
        topBorder: Float
    ) {
        val borderPaint = Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 1.5f; isAntiAlias = true }
        val fillBlackPaint = Paint().apply { color = Color.BLACK; style = Paint.Style.FILL; isAntiAlias = true }
        val textPaint = Paint().apply { color = Color.BLACK; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL) }
        val boldTextPaint = Paint().apply { color = Color.BLACK; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }
        val whiteBoldPaint = Paint().apply { color = Color.WHITE; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }

        // Top Badges
        val badgeWidth = 44f
        val badgeHeight = 22f
        val badge2Left = rightBorder - badgeWidth - 4f
        val badge1Left = badge2Left - badgeWidth - 4f
        val badgeTop = topBorder + 4f

        canvas.drawRect(badge1Left, badgeTop, badge1Left + badgeWidth, badgeTop + badgeHeight, fillBlackPaint)
        canvas.drawRect(badge2Left, badgeTop, badge2Left + badgeWidth, badgeTop + badgeHeight, fillBlackPaint)

        whiteBoldPaint.textSize = 13f
        whiteBoldPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.badge1, badge1Left + (badgeWidth / 2), badgeTop + 16f, whiteBoldPaint)
        canvas.drawText(receipt.badge2, badge2Left + (badgeWidth / 2), badgeTop + 16f, whiteBoldPaint)

        // Routing Code
        boldTextPaint.textSize = 23f
        boldTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText(receipt.routingCode, leftBorder + 8f, badgeTop + 20f, boldTextPaint)

        var currentY = badgeTop + badgeHeight + 6f
        canvas.drawLine(leftBorder, currentY, rightBorder, currentY, borderPaint)

        // Barcode
        currentY += 4f
        val barcodeBitmap = BarcodeGenerator.generateBarcode128(receipt.resiCode, width = 500, height = 90)
        val barcodeRect = RectF(leftBorder + 18f, currentY, rightBorder - 18f, currentY + 54f)
        if (barcodeBitmap != null) {
            canvas.drawBitmap(barcodeBitmap, null, barcodeRect, null)
        }

        currentY += 58f
        boldTextPaint.textSize = 12f
        boldTextPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.resiCode, (leftBorder + rightBorder) / 2f, currentY + 10f, boldTextPaint)

        // Drop point banner
        currentY += 15f
        canvas.drawRect(leftBorder, currentY, rightBorder, currentY + 22f, fillBlackPaint)
        whiteBoldPaint.textSize = 11.5f
        whiteBoldPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.dropPoint, (leftBorder + rightBorder) / 2f, currentY + 16f, whiteBoldPaint)
        currentY += 22f

        // Recipient
        currentY += 12f
        boldTextPaint.textSize = 10f
        boldTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Penerima: ${receipt.recipientName}", leftBorder + 6f, currentY, boldTextPaint)
        boldTextPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(receipt.getDisplayRecipientPhone(), rightBorder - 6f, currentY, boldTextPaint)

        currentY += 4f
        textPaint.textSize = 8.5f
        textPaint.textAlign = Paint.Align.LEFT
        currentY = drawMultilineText(canvas, receipt.recipientAddress, leftBorder + 6f, currentY + 10f, rightBorder - leftBorder - 12f, textPaint, 11f, 4)

        currentY += 6f
        canvas.drawLine(leftBorder, currentY, rightBorder, currentY, borderPaint)

        // Sender
        currentY += 12f
        boldTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Pengirim: ${receipt.senderName}", leftBorder + 6f, currentY, boldTextPaint)
        boldTextPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(receipt.getDisplaySenderPhone(), rightBorder - 6f, currentY, boldTextPaint)

        currentY += 4f
        currentY = drawMultilineText(canvas, receipt.senderAddress, leftBorder + 6f, currentY + 10f, rightBorder - leftBorder - 12f, textPaint, 11f, 3)

        currentY += 6f
        canvas.drawLine(leftBorder, currentY, rightBorder, currentY, borderPaint)

        // Shipping Table
        val tableTop = currentY
        val col1Width = 84f
        val col2Width = 60f
        val col3Width = 75f
        val row1Height = 32f
        val row2Height = 20f
        val row3Height = 18f
        val tableHeight = row1Height + row2Height + row3Height

        canvas.drawLine(leftBorder, tableTop + row1Height, rightBorder, tableTop + row1Height, borderPaint)
        canvas.drawLine(leftBorder, tableTop + row1Height + row2Height, rightBorder, tableTop + row1Height + row2Height, borderPaint)
        canvas.drawLine(leftBorder, tableTop + tableHeight, rightBorder, tableTop + tableHeight, borderPaint)

        val col1Right = leftBorder + col1Width
        val col2Right = col1Right + col2Width
        val col3Right = col2Right + col3Width

        canvas.drawLine(col1Right, tableTop, col1Right, tableTop + row1Height + row2Height, borderPaint)
        canvas.drawLine(col2Right, tableTop, col2Right, tableTop + row1Height, borderPaint)
        canvas.drawLine(col3Right, tableTop, col3Right, tableTop + row1Height + row2Height, borderPaint)

        // Col 1
        canvas.drawRect(leftBorder, tableTop, col1Right, tableTop + 11f, fillBlackPaint)
        whiteBoldPaint.textSize = 6.8f
        whiteBoldPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("BIAYA PENGIRIMAN", leftBorder + (col1Width / 2f), tableTop + 8.5f, whiteBoldPaint)

        boldTextPaint.textSize = 10.5f
        boldTextPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.getFormattedFee(), leftBorder + (col1Width / 2f), tableTop + 21f, boldTextPaint)

        textPaint.textSize = 6.2f
        canvas.drawText("Sudah Termasuk PPH", leftBorder + (col1Width / 2f), tableTop + 29f, textPaint)

        // Col 2
        boldTextPaint.textSize = 9.5f
        canvas.drawText(receipt.paymentType, col1Right + (col2Width / 2f), tableTop + 18f, boldTextPaint)

        // Col 3
        canvas.drawText("• ${receipt.weightKg}", col2Right + (col3Width / 2f), tableTop + 18f, boldTextPaint)

        // Col 4
        textPaint.textSize = 8f
        canvas.drawText("Cetak ${receipt.printDate}", col3Right + ((rightBorder - col3Right) / 2f), tableTop + 18f, textPaint)

        // Row 2
        textPaint.textSize = 7.5f
        textPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Order No. ${receipt.orderNo}", col1Right + 5f, tableTop + row1Height + 14f, textPaint)
        canvas.drawText("Exp: ${receipt.expNote}", col3Right + 5f, tableTop + row1Height + 14f, textPaint)

        // Row 3
        textPaint.textSize = 7.8f
        canvas.drawText("Notes: ${receipt.notes}", leftBorder + 6f, tableTop + row1Height + row2Height + 13f, textPaint)

        // Footer
        currentY = tableTop + tableHeight + 8f
        val qrSize = 64f
        val qrLeft = rightBorder - qrSize - 4f
        val qrBitmap = BarcodeGenerator.generateQrCode(receipt.resiCode, size = 180)
        if (qrBitmap != null) {
            canvas.drawBitmap(qrBitmap, null, RectF(qrLeft, currentY, qrLeft + qrSize, currentY + qrSize), null)
        }

        textPaint.textSize = 6.5f
        textPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Syarat dan ketentuan pengiriman dilihat pada website", leftBorder + 6f, currentY + 8f, textPaint)

        val lines = receipt.footerCompany.split("\n")
        var footerY = currentY + 18f
        for (line in lines) {
            canvas.drawText(line.trim(), leftBorder + 6f, footerY, textPaint)
            footerY += 9f
        }
    }

    private fun drawSenderCopyInternal(
        canvas: Canvas,
        receipt: ReceiptData,
        leftBorder: Float,
        rightBorder: Float,
        topY: Float,
        bottomBorder: Float
    ) {
        val borderPaint = Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 1.5f; isAntiAlias = true }
        val fillBlackPaint = Paint().apply { color = Color.BLACK; style = Paint.Style.FILL; isAntiAlias = true }
        val textPaint = Paint().apply { color = Color.BLACK; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL) }
        val boldTextPaint = Paint().apply { color = Color.BLACK; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }
        val whiteBoldPaint = Paint().apply { color = Color.WHITE; isAntiAlias = true; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }

        // Barcode
        var currentY = topY + 4f
        val barcodeBitmap = BarcodeGenerator.generateBarcode128(receipt.resiCode, width = 500, height = 75)
        val barcodeRect = RectF(leftBorder + 24f, currentY, rightBorder - 24f, currentY + 45f)
        if (barcodeBitmap != null) {
            canvas.drawBitmap(barcodeBitmap, null, barcodeRect, null)
        }

        currentY += 48f
        boldTextPaint.textSize = 11.5f
        boldTextPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.resiCode, (leftBorder + rightBorder) / 2f, currentY + 10f, boldTextPaint)

        currentY += 16f
        canvas.drawLine(leftBorder, currentY, rightBorder, currentY, borderPaint)

        // Sender & Recipient
        currentY += 13f
        boldTextPaint.textSize = 10f
        boldTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Pengirim: ${receipt.senderName}", leftBorder + 6f, currentY, boldTextPaint)
        boldTextPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(receipt.getDisplaySenderPhone(), rightBorder - 6f, currentY, boldTextPaint)

        currentY += 14f
        boldTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Penerima: ${receipt.recipientName}", leftBorder + 6f, currentY, boldTextPaint)
        boldTextPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(receipt.getDisplayRecipientPhone(), rightBorder - 6f, currentY, boldTextPaint)

        currentY += 4f
        textPaint.textSize = 8.2f
        textPaint.textAlign = Paint.Align.LEFT
        currentY = drawMultilineText(canvas, receipt.recipientAddress, leftBorder + 6f, currentY + 9f, rightBorder - leftBorder - 12f, textPaint, 10f, 2)

        currentY += 6f
        canvas.drawLine(leftBorder, currentY, rightBorder, currentY, borderPaint)

        // Split Section
        val splitTop = currentY
        val leftColWidth = 135f
        val splitDividerX = leftBorder + leftColWidth

        canvas.drawLine(splitDividerX, splitTop, splitDividerX, bottomBorder, borderPaint)

        // Left Column: Total Biaya
        boldTextPaint.textSize = 11.5f
        boldTextPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("TOTAL BIAYA", leftBorder + (leftColWidth / 2f), splitTop + 24f, boldTextPaint)

        boldTextPaint.textSize = 13.5f
        canvas.drawText(receipt.getFormattedFee(), leftBorder + (leftColWidth / 2f), splitTop + 48f, boldTextPaint)

        textPaint.textSize = 7.5f
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("Sudah Termasuk PPN", leftBorder + (leftColWidth / 2f), splitTop + 62f, textPaint)

        val badgeHeight = 26f
        canvas.drawRect(leftBorder, bottomBorder - badgeHeight, splitDividerX, bottomBorder, fillBlackPaint)
        whiteBoldPaint.textSize = 10f
        whiteBoldPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("Lembar Pengirim", leftBorder + (leftColWidth / 2f), bottomBorder - 8.5f, whiteBoldPaint)

        // Right Column
        val rRow1H = 22f
        val rRow2H = 24f
        val rRow3H = 22f

        canvas.drawLine(splitDividerX, splitTop + rRow1H, rightBorder, splitTop + rRow1H, borderPaint)
        val rSubColW = 55f
        canvas.drawLine(splitDividerX + rSubColW, splitTop, splitDividerX + rSubColW, splitTop + rRow1H, borderPaint)

        boldTextPaint.textSize = 8.5f
        boldTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Qty ${receipt.itemQty}", splitDividerX + 5f, splitTop + 15f, boldTextPaint)
        canvas.drawText("BARANG ${receipt.itemName}", splitDividerX + rSubColW + 5f, splitTop + 15f, boldTextPaint)

        canvas.drawLine(splitDividerX, splitTop + rRow1H + rRow2H, rightBorder, splitTop + rRow1H + rRow2H, borderPaint)
        textPaint.textSize = 8.2f
        canvas.drawText("Notes: ${receipt.notes}", splitDividerX + 5f, splitTop + rRow1H + 16f, textPaint)

        canvas.drawLine(splitDividerX, splitTop + rRow1H + rRow2H + rRow3H, rightBorder, splitTop + rRow1H + rRow2H + rRow3H, borderPaint)
        val rSubExpW = (rightBorder - splitDividerX) / 2f
        canvas.drawLine(splitDividerX + rSubExpW, splitTop + rRow1H + rRow2H, splitDividerX + rSubExpW, splitTop + rRow1H + rRow2H + rRow3H, borderPaint)

        textPaint.textSize = 8f
        canvas.drawText("Cetak ${receipt.printDate}", splitDividerX + 5f, splitTop + rRow1H + rRow2H + 15f, textPaint)
        canvas.drawText("Exp ${receipt.expDate}", splitDividerX + rSubExpW + 5f, splitTop + rRow1H + rRow2H + 15f, textPaint)

        var legalY = splitTop + rRow1H + rRow2H + rRow3H + 11f
        textPaint.textSize = 6f
        canvas.drawText("Syarat dan ketentuan pengiriman dilihat pada website www.jet.co.id", splitDividerX + 5f, legalY, textPaint)
        legalY += 8.5f
        canvas.drawText("PT GLOBAL JET EXPRESS, 0735697740 041 000", splitDividerX + 5f, legalY, textPaint)
        legalY += 8.5f
        canvas.drawText("LANDMARK PLUIT TOWER BLOK B1, LANTAI 8, 9A,", splitDividerX + 5f, legalY, textPaint)
    }

    private fun drawVerticalSideResi(
        canvas: Canvas,
        resiCode: String,
        leftBorder: Float,
        rightBorder: Float,
        topBorder: Float,
        bottomBorder: Float,
        repeatCount: Int
    ) {
        val sidePaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 7.5f
            isAntiAlias = true
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }

        val segmentHeight = (bottomBorder - topBorder) / repeatCount.toFloat()
        for (i in 0 until repeatCount) {
            val yPos = topBorder + (i * segmentHeight) + (segmentHeight * 0.7f)
            // Left
            canvas.save()
            canvas.rotate(-90f, 14f, yPos)
            canvas.drawText(resiCode, 14f - 24f, yPos, sidePaint)
            canvas.restore()

            // Right
            canvas.save()
            canvas.rotate(90f, rightBorder + 12f, yPos)
            canvas.drawText(resiCode, (rightBorder + 12f) - 24f, yPos, sidePaint)
            canvas.restore()
        }
    }

    private fun drawMultilineText(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        maxWidth: Float,
        paint: Paint,
        lineSpacing: Float,
        maxLines: Int
    ): Float {
        val words = text.split(" ")
        var currentLine = StringBuilder()
        var currentY = y
        var lineCount = 0

        for (word in words) {
            val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
            val width = paint.measureText(testLine)
            if (width > maxWidth && currentLine.isNotEmpty()) {
                canvas.drawText(currentLine.toString(), x, currentY, paint)
                currentLine = StringBuilder(word)
                currentY += lineSpacing
                lineCount++
                if (lineCount >= maxLines - 1) break
            } else {
                currentLine = StringBuilder(testLine)
            }
        }
        if (currentLine.isNotEmpty()) {
            canvas.drawText(currentLine.toString(), x, currentY, paint)
            currentY += lineSpacing
        }
        return currentY
    }
}
