package com.example.repository

import com.example.database.TechnicalReportDao
import com.example.model.ReplacementPart
import com.example.model.TechnicalReport
import kotlinx.coroutines.flow.Flow

class ReportRepository(private val dao: TechnicalReportDao) {

    val allReports: Flow<List<TechnicalReport>> = dao.getAllReports()

    fun searchReports(query: String): Flow<List<TechnicalReport>> = dao.searchReports(query)

    fun getReportById(id: Long): Flow<TechnicalReport?> = dao.getReportById(id)

    suspend fun getReportByIdSync(id: Long): TechnicalReport? = dao.getReportByIdSync(id)

    suspend fun insertOrUpdate(report: TechnicalReport): Long = dao.insertReport(report)

    suspend fun delete(report: TechnicalReport) = dao.deleteReport(report)

    suspend fun deleteById(id: Long) = dao.deleteReportById(id)

    suspend fun seedSampleReportIfEmpty() {
        val existing = dao.getReportByIdSync(1)
        if (existing == null) {
            val sampleParts = listOf(
                ReplacementPart(partNumber = "42611-EW010", partName = "Velg Roda 7.50-16", procurementType = "Stock"),
                ReplacementPart(partNumber = "BAN-BRIDGE-1000", partName = "Ban Luar 10.00 R20", procurementType = "Order"),
                ReplacementPart(partNumber = "FLAP-1000-20", partName = "Selendang Ban (Flap)", procurementType = "Stock"),
                ReplacementPart(partNumber = "TUBE-1000-20", partName = "Ban Dalam Heavy Duty", procurementType = "Stock")
            )

            val sample = TechnicalReport(
                id = 1,
                companyName = "Hiba Group",
                reportTitle = "LAPORAN TEKNIK",
                reportNumber = "1/LT-CLG/III/2026",
                workshop = "Cilegon",
                date = "12-Mar-26",
                toolName = "Ban",
                component = "Underbody",
                manufacturer = "HINO",
                vehicleType = "DUTRO",
                model = "W04DTPJ-53447",
                unitCode = "D127",
                damageDate = "12-Mar-26",
                odometer = "598916",
                warrantyStatus = "SETELAH_GARANSI",
                status = "Storing",
                damageDescription = "Ban kempes",
                damageLocation = "Tol tangerang - merak",
                analysis = "Setelah di lakukan storing oleh team cikupa di temukan ban depan kiri kempes",
                lastReplacement = "9-5-2022 (km.415513)",
                lastReplacementWo = "KLD1-WO-2205-00381",
                lastWeekly = "5-3-2026 (km.598234)",
                lastWeeklyWo = "CLG1-WO-2603-00225",
                photoPath = "sample_damage.jpg",
                causePemasangan = false,
                causeKwalitasParts = false,
                causeKesalahanOperasional = false,
                causeSudahWaktunya = true,
                causeLainLain = false,
                causeExplanation = "Ban sudah aus mencapai batas TWI",
                solutionGantiPartBaru = false,
                solutionPemasanganUlang = true,
                solutionModifikasi = false,
                solutionActionText = "Ganti ban stip",
                delayedReason = "-",
                reporterSuggestion = "Segera akan di lakukan program pengecekan atau penggantian terkait part tersebut terhadap RK8J supaya tidak terjadi kejadian serupa",
                parts = sampleParts,
                knownBy1 = "Kepala Operasional",
                knownBy2 = "Manager Teknik",
                reporterName = "Yudi Indrawan",
                reporterTitle = "Wa.Ka.Bengkel"
            )
            dao.insertReport(sample)
        } else if (existing.photoPath == null || existing.photoPath.startsWith("public/")) {
            // Update seed to use sample_damage.jpg asset
            dao.insertReport(existing.copy(photoPath = "sample_damage.jpg"))
        }
    }
}
