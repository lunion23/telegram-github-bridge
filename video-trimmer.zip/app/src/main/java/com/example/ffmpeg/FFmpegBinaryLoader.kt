package com.example.ffmpeg

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/**
 * Helper untuk menyalin file binary FFmpeg dari folder assets aplikasi
 * ke direktori internal aplikasi (`context.filesDir`) saat aplikasi dijalankan,
 * serta memberikan izin eksekusi (`setExecutable(true)`).
 */
object FFmpegBinaryLoader {

    private const val TAG = "FFmpegBinaryLoader"
    const val FFMPEG_BINARY_NAME = "ffmpeg"
    const val SAMPLE_VIDEO_NAME = "sample_video.mp4"

    /**
     * Mendapatkan referensi File ke binary FFmpeg di direktori internal aplikasi.
     */
    fun getBinaryFile(context: Context): File {
        return File(context.filesDir, FFMPEG_BINARY_NAME)
    }

    /**
     * Memeriksa apakah binary FFmpeg sudah ada dan memiliki izin eksekusi.
     */
    fun isBinaryExecutable(context: Context): Boolean {
        val file = getBinaryFile(context)
        return file.exists() && file.isFile && file.canExecute()
    }

    /**
     * Menyalin binary FFmpeg dari folder assets ke context.filesDir.
     * Dijalankan pada thread latar belakang (Dispatchers.IO) agar tidak membebani main thread.
     *
     * @param context Context Android
     * @param assetName Nama file binary di dalam folder assets (default: "ffmpeg")
     * @param forceOverwrite True jika ingin menimpa file yang sudah ada
     * @return Result berisi File yang berhasil disiapkan, atau exception jika gagal
     */
    suspend fun copyBinaryFromAssets(
        context: Context,
        assetName: String = FFMPEG_BINARY_NAME,
        forceOverwrite: Boolean = false
    ): Result<File> = withContext(Dispatchers.IO) {
        val targetFile = getBinaryFile(context)

        try {
            // Jika binary sudah ada dan dapat dieksekusi, gunakan langsung kecuali jika di-force
            if (targetFile.exists() && targetFile.canExecute() && !forceOverwrite) {
                Log.d(TAG, "Binary FFmpeg sudah tersedia di: ${targetFile.absolutePath}")
                return@withContext Result.success(targetFile)
            }

            Log.d(TAG, "Mulai menyalin binary FFmpeg dari assets/$assetName ke ${targetFile.absolutePath}...")

            // Salin stream dari assets ke direktori internal aplikasi
            context.assets.open(assetName).use { inputStream ->
                // Gunakan file sementara untuk penulisan atomik agar file tidak rusak jika terputus
                val tempFile = File(context.filesDir, "$assetName.tmp")
                FileOutputStream(tempFile).use { outputStream ->
                    val buffer = ByteArray(16 * 1024)
                    var bytesRead: Int
                    while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                        outputStream.write(buffer, 0, bytesRead)
                    }
                    outputStream.flush()
                }

                // Hapus target lama jika ada dan ubah nama file sementara
                if (targetFile.exists()) {
                    targetFile.delete()
                }
                if (!tempFile.renameTo(targetFile)) {
                    // Fallback copy jika rename gagal
                    tempFile.copyTo(targetFile, overwrite = true)
                    tempFile.delete()
                }
            }

            // Memberikan izin eksekusi (executable) pada binary tersebut
            val executableSet = targetFile.setExecutable(true, false)
            targetFile.setReadable(true, false)

            Log.d(TAG, "Izin setExecutable(true): $executableSet (canExecute: ${targetFile.canExecute()})")

            // Jika setExecutable mengembalikan false atau belum efektif di beberapa sistem,
            // jalankan perintah chmod 755 melalui Runtime sebagai proteksi tambahan
            if (!targetFile.canExecute()) {
                try {
                    val chmodProcess = Runtime.getRuntime().exec(
                        arrayOf("chmod", "755", targetFile.absolutePath)
                    )
                    chmodProcess.waitFor()
                    Log.d(TAG, "chmod 755 selesai dengan kode: ${chmodProcess.exitValue()}")
                } catch (e: Exception) {
                    Log.w(TAG, "Upaya fallback chmod gagal: ${e.message}")
                }
            }

            Result.success(targetFile)
        } catch (e: IOException) {
            Log.e(TAG, "Gagal menyalin binary FFmpeg dari assets: ${e.message}", e)
            Result.failure(e)
        } catch (e: Exception) {
            Log.e(TAG, "Terjadi kesalahan tak terduga saat menyiapkan FFmpeg: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Menyalin video sampel dari assets ke direktori cache aplikasi
     * sehingga pengguna dapat langsung menguji fitur trimming tanpa harus mengunduh video.
     */
    suspend fun copySampleVideoFromAssets(context: Context): Result<File> = withContext(Dispatchers.IO) {
        val sampleFile = File(context.cacheDir, SAMPLE_VIDEO_NAME)
        try {
            if (sampleFile.exists() && sampleFile.length() > 0) {
                return@withContext Result.success(sampleFile)
            }

            context.assets.open(SAMPLE_VIDEO_NAME).use { input ->
                FileOutputStream(sampleFile).use { output ->
                    input.copyTo(output)
                }
            }
            Result.success(sampleFile)
        } catch (e: Exception) {
            Log.e(TAG, "Gagal menyalin video sampel: ${e.message}", e)
            Result.failure(e)
        }
    }
}
