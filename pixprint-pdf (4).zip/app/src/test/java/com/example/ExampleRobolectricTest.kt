package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.test.performTextReplacement
import androidx.test.core.app.ApplicationProvider
import com.example.model.HistoryActionType
import com.example.model.LabelHistoryItem
import com.example.model.PaperSizePreset
import com.example.model.PdfRenderSource
import com.example.model.ShippingLabelData
import com.example.pdf.BarcodeVectorHelper
import com.example.pdf.ShippingLabelPdfGenerator
import com.example.ui.ShippingLabelScreen
import com.example.ui.components.LabelHistoryScreen
import com.example.ui.components.applyHighContrastDocumentFilter
import com.example.ui.components.rotateBitmapIfNeeded
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.HistoryUiState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun `app name matches Cetak Resi PDF`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Cetak Resi PDF", appName)
    }

    @Test
    fun `renderer draws non-blank pages across all paper presets and render sources`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val refBitmap = ShippingLabelPdfGenerator.loadReferenceBitmap(context)
        assertNotNull("Bundled reference_label.jpg asset must load", refBitmap)

        val fakeCaptured = Bitmap.createBitmap(400, 600, Bitmap.Config.ARGB_8888).also { bmp ->
            val c = Canvas(bmp)
            c.drawColor(Color.DKGRAY)
        }
        val rotated = rotateBitmapIfNeeded(fakeCaptured, 90)
        assertEquals(600, rotated.width)
        assertEquals(400, rotated.height)

        val filtered = applyHighContrastDocumentFilter(fakeCaptured)
        assertEquals(400, filtered.width)

        val sampleData = ShippingLabelData.defaultFromReferenceImage()

        for (preset in PaperSizePreset.entries) {
            assertTrue("PDF widthPt must be positive", preset.widthPt > 100)
            assertTrue("PDF heightPt must be positive", preset.heightPt > 100)

            for (source in PdfRenderSource.entries) {
                val rendered = ShippingLabelPdfGenerator.renderPreviewBitmap(
                    data = sampleData,
                    paperPreset = preset,
                    renderSource = source,
                    referenceBitmap = refBitmap,
                    capturedBitmap = fakeCaptured,
                    targetWidthPx = 300
                )
                assertEquals(300, rendered.width)

                var hasInkPixels = false
                val step = 5
                var y = 0
                while (y < rendered.height && !hasInkPixels) {
                    var x = 0
                    while (x < rendered.width) {
                        if (rendered.getPixel(x, y) != Color.WHITE) {
                            hasInkPixels = true
                            break
                        }
                        x += step
                    }
                    y += step
                }
                assertTrue("Rendered page for $preset / $source must contain ink pixels", hasInkPixels)
            }
        }
    }

    @Test
    fun `barcode sanitization strips zero width unicode and caps length safely`() {
        val pastedWithZeroWidth = "\u200BJD0600216038\uFEFF\n"
        assertEquals("JD0600216038", BarcodeVectorHelper.sanitizeForCode128(pastedWithZeroWidth))

        val emptyOrEmojiOnly = "📦🚚"
        assertEquals("JD0600216038", BarcodeVectorHelper.sanitizeForCode128(emptyOrEmojiOnly))

        val overlong = "A".repeat(120)
        assertEquals(80, BarcodeVectorHelper.sanitizeForCode128(overlong).length)

        val extremeData = ShippingLabelData(
            waybillNumber = pastedWithZeroWidth,
            recipientAddress = "Jl.SangatPanjangTanpaSpasiSamaSekaliMelewatiBatasKotakResiPengiriman1234567890\nBaris Kedua\nBaris Ketiga\nBaris Keempat\nBaris Kelima",
            senderPhone = "********",
            notes = "Catatanbaris1\nCatatanbaris2\nCatatanbaris3"
        )
        val preview = ShippingLabelPdfGenerator.renderPreviewBitmap(
            data = extremeData,
            paperPreset = PaperSizePreset.THERMAL_100X200,
            renderSource = PdfRenderSource.VECTOR_RECONSTRUCTION,
            referenceBitmap = null,
            targetWidthPx = 400
        )
        assertEquals(400, preview.width)
        assertEquals(800, preview.height)
    }

    @Test
    fun `compose CUJ - direct launch without login, history navigation, camera capture, and edit flow`() {
        composeTestRule.setContent {
            MyApplicationTheme {
                ShippingLabelScreen()
            }
        }
        composeTestRule.waitForIdle()

        // Primary actions displayed immediately without any login gate
        composeTestRule.onNodeWithTag("print_pdf_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("save_pdf_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("share_pdf_button").assertIsDisplayed()

        // Navigate to Riwayat Data screen and back
        composeTestRule.onNodeWithTag("top_open_history_button").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("history_empty_state").assertIsDisplayed()
        composeTestRule.onNodeWithTag("history_back_button").performClick()
        composeTestRule.waitForIdle()

        // Navigate to CameraX Document Capture screen and back
        composeTestRule.onNodeWithTag("top_open_camera_button").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("camera_back_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("camera_back_button").performClick()
        composeTestRule.waitForIdle()

        // Scroll to A4 paper preset, select it, then scroll back up to toggle side-by-side comparison
        composeTestRule.onNodeWithTag("preset_a4").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("mode_compare_chip").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        // Open editor, modify recipient name, and apply
        composeTestRule.onNodeWithTag("top_edit_data_button").performClick()
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("input_recipient_name")
            .performScrollTo()
            .performTextReplacement("Budi Santoso")
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("editor_done_button").performClick()
        composeTestRule.waitForIdle()

        // Scroll to summary card and verify updated recipient name appears
        composeTestRule.onNodeWithText("Budi Santoso (PT MCDERMOTT)")
            .performScrollTo()
            .assertIsDisplayed()
    }

    @Test
    fun `compose CUJ - history list search and load callback without login`() {
        var loadedWaybill: String? = null
        val sampleItems = listOf(
            LabelHistoryItem(
                id = "item_1",
                waybillNumber = "JD1111111111",
                routingCode = "160-BTH",
                recipientName = "Andi Pratama",
                destinationBanner = "BATAM CENTER",
                shippingFeeAmount = "IDR 32,000",
                paymentMethod = "TUNAI",
                weight = "1.0 KG",
                actionLabel = HistoryActionType.PRINTED,
                createdAtMillis = 1760000000000L,
                updatedAtMillis = 1760000000000L
            ),
            LabelHistoryItem(
                id = "item_2",
                waybillNumber = "JD2222222222",
                routingCode = "210-JKT",
                recipientName = "Dewi Lestari",
                destinationBanner = "JAKARTA BARAT",
                shippingFeeAmount = "IDR 18,000",
                paymentMethod = "NON-TUNAI",
                weight = "0.5 KG",
                actionLabel = HistoryActionType.SAVED,
                createdAtMillis = 1760000500000L,
                updatedAtMillis = 1760000500000L
            )
        )

        composeTestRule.setContent {
            MyApplicationTheme {
                LabelHistoryScreen(
                    historyState = HistoryUiState.Success(sampleItems),
                    onSaveCurrentClick = {},
                    onLoadItem = { loadedWaybill = it.waybillNumber },
                    onEditItem = {},
                    onDeleteItem = {},
                    onClose = {}
                )
            }
        }
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("history_item_card_item_1").assertIsDisplayed()
        composeTestRule.onNodeWithTag("history_search_input").performTextInput("Dewi")
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("history_item_card_item_2").assertIsDisplayed()
        composeTestRule.onNodeWithTag("load_history_button_item_2").performClick()
        assertEquals("JD2222222222", loadedWaybill)
    }

    @Test
    fun `AppContent launches directly into ShippingLabelScreen without login screen`() {
        composeTestRule.setContent {
            MyApplicationTheme {
                AppContent()
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("print_pdf_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("top_open_history_button").assertIsDisplayed()
    }
}
