package com.example.pdf

import android.graphics.Bitmap
import android.graphics.Matrix
import com.example.model.ShippingLabelData
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.GlobalHistogramBinarizer
import com.google.zxing.common.HybridBinarizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext

data class ExtractedCameraLabel(
    val labelData: ShippingLabelData,
    val rawRecognizedText: String = "",
    val detectedBarcode: String? = null,
    val hasStructuredShippingFields: Boolean = false
)

/**
 * Extracts real barcode/QR and OCR text from camera-captured documents or shipping labels
 * completely offline on-device (ZXing + bundled ML Kit Latin Text Recognition).
 *
 * Always produces a clean, fresh [ShippingLabelData] derived strictly from the captured photo —
 * NEVER falling back to old sample data (`Muhamad Arif` / `JD0600216038`).
 */
object CameraLabelExtractor {

    private val barcodeHints: Map<DecodeHintType, Any> = mapOf(
        DecodeHintType.TRY_HARDER to true,
        DecodeHintType.POSSIBLE_FORMATS to listOf(
            BarcodeFormat.CODE_128,
            BarcodeFormat.CODE_39,
            BarcodeFormat.CODE_93,
            BarcodeFormat.EAN_13,
            BarcodeFormat.ITF,
            BarcodeFormat.QR_CODE,
            BarcodeFormat.DATA_MATRIX
        )
    )

    suspend fun extractFromBitmap(
        bitmap: Bitmap,
        timestampMillis: Long = System.currentTimeMillis()
    ): ExtractedCameraLabel = withContext(Dispatchers.Default) {
        val barcodeValue = runCatching { decodeBarcodeFromBitmap(bitmap) }.getOrNull()
        val ocrText = runCatching { recognizeTextWithMlKit(bitmap) }.getOrDefault("")
        parseFromTextAndBarcode(
            rawText = ocrText,
            detectedBarcode = barcodeValue,
            timestampMillis = timestampMillis
        )
    }

    /**
     * Pure JVM/Android bitmap barcode & QR decoder using ZXing with multi-band horizontal strip scanning,
     * dual binarizers, and 90-degree rotation passes so 1D Code 128 barcodes at the top, middle, or bottom
     * of tall shipping labels are reliably detected.
     */
    fun decodeBarcodeFromBitmap(bitmap: Bitmap): String? {
        val working = downscaleForAnalysis(bitmap, maxDim = 1600)
        decodeMultiBand(working)?.let { return it }

        // Try 90-degree rotation in case label was photographed sideways
        val rotated90 = rotateBitmap90(working)
        return decodeMultiBand(rotated90)
    }

    private fun decodeMultiBand(bitmap: Bitmap): String? {
        // 1. Full bitmap pass (ideal for large QR codes and centered barcodes)
        decodeSinglePass(bitmap)?.let { return it }

        // 2. Overlapping horizontal bands (ZXing OneDReader samples ~15 rows around band center)
        if (bitmap.height >= 120 && bitmap.width >= 60) {
            val bands = listOf(
                0.00f to 0.28f,
                0.14f to 0.42f,
                0.30f to 0.62f,
                0.50f to 0.80f,
                0.70f to 1.00f
            )
            for ((startFrac, endFrac) in bands) {
                val top = (bitmap.height * startFrac).roundToInt().coerceIn(0, bitmap.height - 20)
                val bottom = (bitmap.height * endFrac).roundToInt().coerceIn(top + 20, bitmap.height)
                val bandHeight = bottom - top
                if (bandHeight >= 20) {
                    val crop = Bitmap.createBitmap(bitmap, 0, top, bitmap.width, bandHeight)
                    decodeSinglePass(crop)?.let { return it }
                }
            }
        }
        return null
    }

    private fun decodeSinglePass(bitmap: Bitmap): String? {
        val width = bitmap.width
        val height = bitmap.height
        if (width <= 4 || height <= 4) return null

        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        val source = RGBLuminanceSource(width, height, pixels)
        val reader = MultiFormatReader().apply { setHints(barcodeHints) }

        val hybridResult = runCatching {
            reader.decodeWithState(BinaryBitmap(HybridBinarizer(source)))
        }.getOrNull()
        if (hybridResult != null && hybridResult.text.isNotBlank()) {
            return hybridResult.text.trim()
        }

        reader.reset()
        val globalResult = runCatching {
            reader.decodeWithState(BinaryBitmap(GlobalHistogramBinarizer(source)))
        }.getOrNull()
        return globalResult?.text?.trim()?.takeIf { it.isNotBlank() }
    }

    /**
     * Runs bundled on-device ML Kit Text Recognition without network or login.
     */
    suspend fun recognizeTextWithMlKit(bitmap: Bitmap): String {
        val analysisBitmap = downscaleForAnalysis(bitmap, maxDim = 1800)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        return try {
            val visionText = suspendCancellableCoroutine<com.google.mlkit.vision.text.Text?> { continuation ->
                val image = InputImage.fromBitmap(analysisBitmap, 0)
                recognizer.process(image)
                    .addOnSuccessListener { result ->
                        if (continuation.isActive) {
                            continuation.resume(result)
                        }
                    }
                    .addOnFailureListener {
                        if (continuation.isActive) {
                            continuation.resume(null)
                        }
                    }
            } ?: return ""

            val orderedLines = visionText.textBlocks
                .flatMap { it.lines }
                .sortedWith(
                    compareBy<com.google.mlkit.vision.text.Text.Line>(
                        { (it.boundingBox?.top ?: 0) / 18 },
                        { it.boundingBox?.left ?: 0 }
                    )
                )
                .map { it.text.trim() }
                .filter { it.isNotBlank() }

            orderedLines.joinToString("\n")
        } catch (_: Throwable) {
            ""
        } finally {
            runCatching { recognizer.close() }
        }
    }

    /**
     * Parses OCR text and/or barcode into a brand-new [ShippingLabelData].
     * Never reuses any fields from `ShippingLabelData.defaultFromReferenceImage()`.
     */
    fun parseFromTextAndBarcode(
        rawText: String,
        detectedBarcode: String?,
        timestampMillis: Long = System.currentTimeMillis()
    ): ExtractedCameraLabel {
        val dateScanIdFmt = SimpleDateFormat("ddMM-HHmmss", Locale.US)
        val datePrintFmt = SimpleDateFormat("dd-MM-yyyy", Locale.US)
        val timeShortFmt = SimpleDateFormat("HH:mm", Locale.US)
        val nowDate = Date(timestampMillis)

        val fallbackScanId = "SCAN-${dateScanIdFmt.format(nowDate)}"
        val defaultPrintDate = datePrintFmt.format(nowDate)

        val cleanedBarcode = detectedBarcode
            ?.replace(Regex("[\\r\\n\\t]+"), " ")
            ?.trim()
            ?.takeIf { it.isNotBlank() }

        val lines = rawText
            .lineSequence()
            .map { it.replace(Regex("\\s+"), " ").trim() }
            .filter { it.isNotBlank() }
            .toList()

        val joinedUpper = lines.joinToString("\n").uppercase(Locale.ROOT)

        // 1. Waybill / Tracking / Document Number
        val labeledWaybill = findLabeledValue(
            lines = lines,
            keyRegex = Regex(
                "(?i)^(?:no\\.?\\s*resi|nomor\\s*resi|resi|awb|waybill|tracking(?:\\s*no)?|no\\.?\\s*nota|invoice)\\s*[:#\\-]?\\s*(.+)$"
            )
        )?.let { extractCleanToken(it) }

        val courierCodeRegex = Regex(
            "\\b(JD\\d{8,16}|JP\\d{8,16}|JX\\d{8,16}|JT\\d{8,16}|SPXID[A-Z0-9]{7,18}|ID\\d{12,18}|TKP[A-Z0-9\\-]{6,18}|JNE[A-Z0-9]{6,16}|00\\d{10,16}|NV[A-Z0-9]{8,16}|ANTERAJA[A-Z0-9\\-]{5,16})\\b",
            RegexOption.IGNORE_CASE
        )
        val regexWaybill = lines.firstNotNullOfOrNull { line ->
            courierCodeRegex.find(line)?.groupValues?.getOrNull(1)?.uppercase(Locale.ROOT)
        }

        val resolvedWaybill = (cleanedBarcode ?: labeledWaybill ?: regexWaybill ?: fallbackScanId)
            .take(64)

        // 2. Routing / Sort Code (e.g., 160-1BTH04-05 or CGK-02A-01)
        val routingRegex = Regex("\\b([A-Z0-9]{2,5}-[A-Z0-9]{2,8}(?:-[A-Z0-9]{1,6})?)\\b")
        val resolvedRoutingCode = lines.firstNotNullOfOrNull { line ->
            routingRegex.findAll(line)
                .map { it.value.uppercase(Locale.ROOT) }
                .firstOrNull { candidate ->
                    candidate != resolvedWaybill.uppercase(Locale.ROOT) &&
                        !Regex("^\\d{2}-\\d{2}-\\d{4}$").matches(candidate) &&
                        candidate.any { ch -> ch.isDigit() } &&
                        candidate.any { ch -> ch.isLetter() }
                }
        }.orEmpty()

        // 3. Service Badges (EZ, REG, ECO, COD, NP, ND, CARGO, YES, EXPRESS)
        val knownBadges = setOf("NP", "EZ", "REG", "ECO", "COD", "DFOD", "ND", "YES", "HALU", "JTR", "STD")
        val foundBadges = lines
            .flatMap { it.split(Regex("[\\s|/•,]+")) }
            .map { it.trim().uppercase(Locale.ROOT) }
            .filter { it in knownBadges }
            .distinct()

        // 4. Recipient & Sender extraction
        val recipientBlock = extractPartySection(
            lines = lines,
            headerRegex = Regex("(?i)^(?:penerima|kepada|kpd|tujuan|ship\\s*to|deliver\\s*to|to)\\b\\s*[:\\-]?\\s*(.*)$"),
            stopRegex = Regex("(?i)^(?:pengirim|dari|from|seller|penjual|biaya|ongkir|berat|weight|qty|jumlah|order|catatan|notes|barang|produk)\\b")
        )
        val senderBlock = extractPartySection(
            lines = lines,
            headerRegex = Regex("(?i)^(?:pengirim|dari|from|shipper|penjual|seller)\\b\\s*[:\\-]?\\s*(.*)$"),
            stopRegex = Regex("(?i)^(?:penerima|kepada|kpd|tujuan|to|biaya|ongkir|berat|weight|qty|jumlah|order|catatan|notes|barang|produk)\\b")
        )

        // Phone numbers
        val phoneRegex = Regex("(?:\\+62|62|08|\\*{3,})[0-9*\\-\\s]{6,16}")
        val allPhones = lines.mapNotNull { line ->
            phoneRegex.find(line)?.value?.trim()
        }.distinct()

        val recipientPhone = recipientBlock.phone
            .ifBlank { allPhones.firstOrNull().orEmpty() }
            .take(40)

        val senderPhone = senderBlock.phone
            .ifBlank {
                allPhones.firstOrNull { it != recipientPhone }.orEmpty()
            }
            .take(40)

        // Shipping Fee / Amount (IDR / Rp)
        val feeRegex = Regex("(?i)\\b(?:IDR|Rp\\.?)[\\s]*([0-9][0-9.,]{1,14})\\b")
        val resolvedFee = lines.firstNotNullOfOrNull { line ->
            val m = feeRegex.find(line) ?: return@firstNotNullOfOrNull null
            val prefix = if (line.contains("IDR", ignoreCase = true)) "IDR" else "Rp"
            "$prefix ${m.groupValues[1].trim()}"
        }.orEmpty()

        // Payment Method
        val paymentRegex = Regex("(?i)\\b(NON\\s*TUNAI|TUNAI|CASHLESS|COD|DFOD|TRANSFER|LUNAS)\\b")
        val resolvedPayment = lines.firstNotNullOfOrNull { line ->
            paymentRegex.find(line)?.groupValues?.getOrNull(1)?.uppercase(Locale.ROOT)?.replace(Regex("\\s+"), " ")
        }.orEmpty()

        // Weight (KG / GR)
        val weightRegex = Regex("(?i)\\b(\\d+(?:[.,]\\d+)?\\s*(?:KG|GR|GRAM))\\b")
        val resolvedWeight = lines.firstNotNullOfOrNull { line ->
            weightRegex.find(line)?.groupValues?.getOrNull(1)?.uppercase(Locale.ROOT)
        }.orEmpty()

        // Print / Document Date
        val dateRegex = Regex("\\b(\\d{2}[/-]\\d{2}[/-]\\d{4}|\\d{4}[/-]\\d{2}[/-]\\d{2})\\b")
        val resolvedDate = lines.firstNotNullOfOrNull { line ->
            dateRegex.find(line)?.groupValues?.getOrNull(1)
        } ?: defaultPrintDate

        // Order Number
        val resolvedOrder = findLabeledValue(
            lines = lines,
            keyRegex = Regex("(?i)^(?:no\\.?\\s*order|order(?:\\s*id|\\s*no)?|no\\.?\\s*pesanan|pesanan)\\s*[:#\\-]?\\s*(.+)$")
        )?.take(80).orEmpty()

        // Quantity
        val qtyLabeled = findLabeledValue(
            lines = lines,
            keyRegex = Regex("(?i)^(?:qty|jumlah|kuantitas)\\s*[:#\\-]?\\s*(.+)$")
        )
        val qtyRegex = Regex("(?i)\\b(\\d+\\s*(?:PCS|PC|BUAH|UNIT|PAKET|BOX|ITEM))\\b")
        val resolvedQty = (qtyLabeled ?: lines.firstNotNullOfOrNull { line ->
            qtyRegex.find(line)?.groupValues?.getOrNull(1)?.uppercase(Locale.ROOT)
        }).orEmpty().take(40)

        // Item Category / Product Name
        val resolvedItemCategory = findLabeledValue(
            lines = lines,
            keyRegex = Regex("(?i)^(?:barang|nama\\s*barang|kategori|produk|item|isi\\s*paket)\\s*[:#\\-]?\\s*(.+)$")
        )?.take(160).orEmpty()

        // Notes
        val labeledNotes = findLabeledValue(
            lines = lines,
            keyRegex = Regex("(?i)^(?:catatan|notes?|keterangan|pesan)\\s*[:#\\-]?\\s*(.+)$")
        )

        val hasStructuredShipping = cleanedBarcode != null ||
            labeledWaybill != null ||
            regexWaybill != null ||
            resolvedRoutingCode.isNotBlank() ||
            recipientBlock.name.isNotBlank() ||
            senderBlock.name.isNotBlank()

        // Determine clean recipientName, recipientAddress, destinationBanner, and notes
        // when scanning either a structured shipping label OR a general document/receipt/photo.
        val meaningfulBodyLines = lines.filterNot { line ->
            line.equals(resolvedWaybill, ignoreCase = true) ||
                line.equals(resolvedRoutingCode, ignoreCase = true) ||
                line.length <= 1
        }

        val resolvedRecipientName: String
        val resolvedRecipientAddress: String
        val resolvedNotes: String

        if (recipientBlock.name.isNotBlank()) {
            resolvedRecipientName = recipientBlock.name.take(120)
            resolvedRecipientAddress = recipientBlock.address.take(500)
            resolvedNotes = labeledNotes?.take(500).orEmpty()
        } else if (meaningfulBodyLines.isNotEmpty()) {
            val headingCandidate = meaningfulBodyLines.firstOrNull { candidate ->
                candidate.any { it.isLetter() } &&
                    !candidate.contains("BIAYA PENGIRIMAN", ignoreCase = true) &&
                    !candidate.equals("NP", ignoreCase = true) &&
                    !candidate.equals("EZ", ignoreCase = true)
            } ?: meaningfulBodyLines.first()

            resolvedRecipientName = headingCandidate.take(100)
            val remainingLines = meaningfulBodyLines
                .dropWhile { it == headingCandidate }
                .filterNot { it == senderBlock.name }
            resolvedRecipientAddress = remainingLines.take(4).joinToString(", ").take(500)
            resolvedNotes = (labeledNotes ?: remainingLines.drop(4).joinToString(" | ").takeIf { it.isNotBlank() })
                ?.take(500)
                .orEmpty()
        } else {
            resolvedRecipientName = if (cleanedBarcode != null) {
                "Hasil Scan $cleanedBarcode"
            } else {
                "Dokumen Kamera (${timeShortFmt.format(nowDate)})"
            }
            resolvedRecipientAddress = ""
            resolvedNotes = labeledNotes ?: "Foto dokumen kamera tersimpan"
        }

        // Destination Banner (e.g., city/hub banner on courier labels)
        val labeledDestination = findLabeledValue(
            lines = lines,
            keyRegex = Regex("(?i)^(?:kota\\s*tujuan|area\\s*tujuan|destinasi|hub)\\s*[:#\\-]?\\s*(.+)$")
        )
        val resolvedBanner = (labeledDestination ?: "").take(100)

        val resolvedBadgeLeft = when {
            foundBadges.isNotEmpty() -> foundBadges[0]
            hasStructuredShipping -> "SCAN"
            else -> "DOC"
        }
        val resolvedBadgeRight = foundBadges.getOrNull(1).orEmpty()

        val isJetLabel = joinedUpper.contains("GLOBAL JET") || joinedUpper.contains("JET.CO.ID")

        val extractedData = ShippingLabelData(
            badgeLeft = resolvedBadgeLeft,
            badgeRight = resolvedBadgeRight,
            routingCode = resolvedRoutingCode,
            waybillNumber = resolvedWaybill,
            destinationBanner = resolvedBanner,
            recipientName = resolvedRecipientName,
            recipientPhone = recipientPhone,
            recipientAddress = resolvedRecipientAddress,
            senderName = senderBlock.name.take(120),
            senderPhone = senderPhone,
            senderArea = senderBlock.address.take(200),
            shippingFeeLabel = if (resolvedFee.isNotBlank()) "BIAYA PENGIRIMAN" else "DOKUMEN KAMERA",
            shippingFeeAmount = resolvedFee,
            taxIncludedText = if (resolvedFee.isNotBlank() && joinedUpper.contains("PPN")) {
                "Sudah Termasuk PPN"
            } else {
                ""
            },
            paymentMethod = resolvedPayment,
            weight = resolvedWeight,
            printDate = resolvedDate,
            orderNumber = resolvedOrder,
            expCode = "",
            quantityText = resolvedQty,
            itemCategory = resolvedItemCategory,
            notes = resolvedNotes,
            companyNameAndTax = if (isJetLabel) "PT GLOBAL JET EXPRESS, 0735697740041000" else "",
            companyAddressLine1 = if (isJetLabel) "LANDMARK PLUIT TOWER BLCK B1, LANTAI 8, 9A," else "",
            companyAddressLine2 = if (isJetLabel) "10A JL. PLUIT SELATAN RAYA, PENJARINGAN" else "",
            websiteUrl = if (isJetLabel) "www.jet.co.id" else "",
            stubBadgeText = if (hasStructuredShipping) "Lembar Pengirim" else "Arsip Kamera"
        )

        return ExtractedCameraLabel(
            labelData = extractedData,
            rawRecognizedText = lines.joinToString("\n"),
            detectedBarcode = cleanedBarcode,
            hasStructuredShippingFields = hasStructuredShipping
        )
    }

    private data class PartyExtract(
        val name: String = "",
        val phone: String = "",
        val address: String = ""
    )

    private fun extractPartySection(
        lines: List<String>,
        headerRegex: Regex,
        stopRegex: Regex
    ): PartyExtract {
        val phoneRegex = Regex("(?:\\+62|62|08|\\*{3,})[0-9*\\-\\s]{6,16}")
        for (i in lines.indices) {
            val match = headerRegex.find(lines[i]) ?: continue
            val inlineRemainder = match.groupValues.getOrNull(1)?.trim().orEmpty()
            val collected = mutableListOf<String>()
            if (inlineRemainder.isNotBlank()) {
                collected.add(inlineRemainder)
            }
            var j = i + 1
            while (j < lines.size && collected.size < 5) {
                val nextLine = lines[j]
                if (stopRegex.containsMatchIn(nextLine)) break
                collected.add(nextLine)
                j++
            }
            if (collected.isEmpty()) continue

            var detectedPhone = ""
            val cleanedParts = collected.mapNotNull { part ->
                val pMatch = phoneRegex.find(part)
                if (pMatch != null && detectedPhone.isEmpty()) {
                    detectedPhone = pMatch.value.trim()
                }
                val withoutPhone = if (pMatch != null) {
                    part.replace(pMatch.value, " ")
                        .replace(Regex("[(),|]+"), " ")
                        .replace(Regex("\\s+"), " ")
                        .trim()
                } else {
                    part.trim()
                }
                withoutPhone.takeIf { it.isNotBlank() }
            }

            val name = cleanedParts.firstOrNull().orEmpty()
            val address = cleanedParts.drop(1).joinToString(", ")
            return PartyExtract(name = name, phone = detectedPhone, address = address)
        }
        return PartyExtract()
    }

    private fun findLabeledValue(lines: List<String>, keyRegex: Regex): String? {
        for (i in lines.indices) {
            val m = keyRegex.find(lines[i]) ?: continue
            val value = m.groupValues.getOrNull(1)?.trim().orEmpty()
            if (value.isNotBlank()) return value
            if (i + 1 < lines.size) {
                val next = lines[i + 1].trim()
                if (next.isNotBlank()) return next
            }
        }
        return null
    }

    private fun extractCleanToken(raw: String): String {
        val token = raw.trim().split(Regex("[\\s,;]+")).firstOrNull().orEmpty()
        return token.replace(Regex("[^A-Za-z0-9\\-_]"), "").ifBlank { raw.trim() }
    }

    private fun downscaleForAnalysis(bitmap: Bitmap, maxDim: Int): Bitmap {
        val largest = max(bitmap.width, bitmap.height)
        if (largest <= maxDim || largest <= 0) return bitmap
        val scale = maxDim.toFloat() / largest.toFloat()
        val w = (bitmap.width * scale).roundToInt().coerceAtLeast(1)
        val h = (bitmap.height * scale).roundToInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, w, h, true)
    }

    private fun rotateBitmap90(source: Bitmap): Bitmap {
        val matrix = Matrix().apply { postRotate(90f) }
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }
}
