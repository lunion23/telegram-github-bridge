package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.model.PartItem
import com.example.data.model.TechnicalReport
import com.example.ui.components.AdaptivePhotoSection
import com.example.ui.components.SignatureDialog

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportEditScreen(
    report: TechnicalReport,
    parts: List<PartItem>,
    onUpdateReport: ((TechnicalReport) -> TechnicalReport) -> Unit,
    onUpdatePart: (Int, (PartItem) -> PartItem) -> Unit,
    onSetCompanyLogo: (String) -> Unit,
    onAddPhotos: (List<String>) -> Unit,
    onRemovePhoto: (Int) -> Unit,
    onClearAllPhotos: () -> Unit,
    onSaveDraft: () -> Unit,
    onPreviewPdf: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var activeSignatureTarget by remember { mutableStateOf<String?>(null) } // "mengetahui1", "mengetahui2", "pelapor"

    val logoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onSetCompanyLogo(uri.toString())
        }
    }

    val tabs = listOf(
        "Identitas & Unit",
        "Uraian Kerusakan",
        "Foto Kerusakan",
        "Penyebab & Solusi",
        "Suku Cadang",
        "Tanda Tangan"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (report.id == 0L) "Buat Laporan Baru" else "Edit Laporan ${report.kode}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "No: ${report.noLaporan}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("edit_back_btn")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                },
                actions = {
                    IconButton(onClick = onSaveDraft, modifier = Modifier.testTag("save_draft_top_btn")) {
                        Icon(Icons.Default.Save, contentDescription = "Simpan Draf", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = onPreviewPdf, modifier = Modifier.testTag("preview_pdf_top_btn")) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = "Pratinjau PDF", tint = MaterialTheme.colorScheme.secondary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            Surface(
                tonalElevation = 6.dp,
                shadowElevation = 8.dp,
                color = MaterialTheme.colorScheme.surface
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onSaveDraft,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("bottom_save_draft_btn")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Simpan Draf")
                    }

                    Button(
                        onClick = onPreviewPdf,
                        modifier = Modifier
                            .weight(1.3f)
                            .height(48.dp)
                            .testTag("bottom_preview_pdf_btn")
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Pratinjau PDF")
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Scrollable Tab Row
            TabRow(
                selectedTabIndex = selectedTabIndex,
                modifier = Modifier.fillMaxWidth()
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = title,
                                maxLines = 1,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (selectedTabIndex) {
                    0 -> {
                        // TAB 1: IDENTITAS PERUSAHAAN & KENDARAAN
                        item {
                            SectionHeader(title = "Kop & Identitas Perusahaan", icon = Icons.Default.Business)
                        }
                        item {
                            OutlinedTextField(
                                value = report.companyName,
                                onValueChange = { value -> onUpdateReport { it.copy(companyName = value) } },
                                label = { Text("Nama Instansi / Perusahaan") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (!report.companyLogoUri.isNullOrBlank()) {
                                        AsyncImage(
                                            model = report.companyLogoUri,
                                            contentDescription = "Logo Perusahaan",
                                            modifier = Modifier
                                                .size(48.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                                .border(1.dp, Color.Gray, RoundedCornerShape(6.dp)),
                                            contentScale = ContentScale.Fit
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                    }
                                    Text(
                                        text = if (report.companyLogoUri.isNullOrBlank()) "Gunakan Logo Default" else "Logo Kustom Terpasang",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                                OutlinedButton(
                                    onClick = {
                                        logoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    }
                                ) {
                                    Icon(Icons.Default.Image, contentDescription = null)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Ganti Logo")
                                }
                            }
                        }

                        item {
                            SectionHeader(title = "Informasi Dokumen", icon = Icons.Default.Edit)
                        }
                        item {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = report.noLaporan,
                                    onValueChange = { value -> onUpdateReport { it.copy(noLaporan = value) } },
                                    label = { Text("No. Laporan") },
                                    modifier = Modifier.weight(1.2f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = report.tanggalLaporan,
                                    onValueChange = { value -> onUpdateReport { it.copy(tanggalLaporan = value) } },
                                    label = { Text("Tanggal") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }
                        }
                        item {
                            OutlinedTextField(
                                value = report.bengkel,
                                onValueChange = { value -> onUpdateReport { it.copy(bengkel = value) } },
                                label = { Text("Bengkel (Lokasi)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }

                        item {
                            SectionHeader(title = "Spesifikasi Kendaraan / Alat", icon = Icons.Default.Build)
                        }
                        item {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = report.pabrikPembuat,
                                    onValueChange = { value -> onUpdateReport { it.copy(pabrikPembuat = value) } },
                                    label = { Text("Pabrik Pembuat (e.g. HINO)") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = report.tipe,
                                    onValueChange = { value -> onUpdateReport { it.copy(tipe = value) } },
                                    label = { Text("Tipe (e.g. DUTRO)") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }
                        }
                        item {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = report.model,
                                    onValueChange = { value -> onUpdateReport { it.copy(model = value) } },
                                    label = { Text("Model Mesin/Rangka") },
                                    modifier = Modifier.weight(1.2f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = report.kode,
                                    onValueChange = { value -> onUpdateReport { it.copy(kode = value) } },
                                    label = { Text("Kode Unit (e.g. D127)") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }
                        }
                        item {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = report.tanggalRusak,
                                    onValueChange = { value -> onUpdateReport { it.copy(tanggalRusak = value) } },
                                    label = { Text("Tanggal Rusak") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = report.kmHm,
                                    onValueChange = { value -> onUpdateReport { it.copy(kmHm = value) } },
                                    label = { Text("Km / Hm") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }
                        }
                        item {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = report.namaAlat,
                                    onValueChange = { value -> onUpdateReport { it.copy(namaAlat = value) } },
                                    label = { Text("Nama Alat (e.g. Ban)") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = report.komponen,
                                    onValueChange = { value -> onUpdateReport { it.copy(komponen = value) } },
                                    label = { Text("Komponen (e.g. Underbody)") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }
                        }
                    }

                    1 -> {
                        // TAB 2: URAIAN KERUSAKAN & ANALISA
                        item {
                            SectionHeader(title = "Garansi & Status Armada", icon = Icons.Default.Tune)
                        }
                        item {
                            Text(text = "Status Masa Garansi:", style = MaterialTheme.typography.bodyMedium)
                            Row(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clickable { onUpdateReport { it.copy(isMasaGaransi = true) } }
                                        .padding(end = 16.dp)
                                ) {
                                    RadioButton(
                                        selected = report.isMasaGaransi,
                                        onClick = { onUpdateReport { it.copy(isMasaGaransi = true) } }
                                    )
                                    Text("Masa Garansi")
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.clickable { onUpdateReport { it.copy(isMasaGaransi = false) } }
                                ) {
                                    RadioButton(
                                        selected = !report.isMasaGaransi,
                                        onClick = { onUpdateReport { it.copy(isMasaGaransi = false) } }
                                    )
                                    Text("Setelah Masa Garansi")
                                }
                            }
                        }
                        item {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = report.tanggalKejadian,
                                    onValueChange = { value -> onUpdateReport { it.copy(tanggalKejadian = value) } },
                                    label = { Text("Tanggal Kejadian") },
                                    modifier = Modifier.weight(1.2f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = report.statusArmada,
                                    onValueChange = { value -> onUpdateReport { it.copy(statusArmada = value) } },
                                    label = { Text("Status (e.g. Storing)") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }
                        }
                        item {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = report.kerusakan,
                                    onValueChange = { value -> onUpdateReport { it.copy(kerusakan = value) } },
                                    label = { Text("Kerusakan (e.g. Ban kempes)") },
                                    modifier = Modifier.weight(1.2f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = report.lokasi,
                                    onValueChange = { value -> onUpdateReport { it.copy(lokasi = value) } },
                                    label = { Text("Lokasi Kejadian") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }
                        }
                        item {
                            OutlinedTextField(
                                value = report.analisa,
                                onValueChange = { value -> onUpdateReport { it.copy(analisa = value) } },
                                label = { Text("Analisa Kerusakan") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 3,
                                maxLines = 5
                            )
                        }

                        item {
                            SectionHeader(title = "Kesimpulan (Teks Bebas)", icon = Icons.Default.Build)
                        }
                        item {
                            OutlinedTextField(
                                value = report.kesimpulan,
                                onValueChange = { value -> onUpdateReport { it.copy(kesimpulan = value) } },
                                label = { Text("Isi Kesimpulan (Bebas / Otomatis Rapi)") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 5,
                                maxLines = 8,
                                placeholder = {
                                    Text("Ketikkan kesimpulan teknis atau riwayat work order di sini. Teks akan tersusun rapi otomatis pada dokumen PDF.")
                                }
                            )
                        }
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        onUpdateReport {
                                            it.copy(
                                                kesimpulan = "Penggantian terakhir : 9-5-2022 (km.415513)\nNo. Work Order      : KLD1-WO-2205-00381\nWeekly terakhir       : 5-3-2026 (km.598234)\nNo. Work Order      : CLG1-WO-2603-00225"
                                            )
                                        }
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Pakai Template WO")
                                }
                                OutlinedButton(
                                    onClick = {
                                        onUpdateReport { it.copy(kesimpulan = "") }
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Kosongkan")
                                }
                            }
                        }
                    }

                    2 -> {
                        // TAB 3: FOTO KERUSAKAN (ADAPTIVE PHOTO GRID)
                        item {
                            AdaptivePhotoSection(
                                photos = report.getPhotoList(),
                                onAddPhotos = onAddPhotos,
                                onRemovePhoto = onRemovePhoto,
                                onClearAll = onClearAllPhotos
                            )
                        }
                    }

                    3 -> {
                        // TAB 4: PENYEBAB KERUSAKAN & SOLUSI
                        item {
                            SectionHeader(title = "Penyebab Kerusakan (Checklist)", icon = Icons.Default.Warning)
                        }
                        item {
                            CauseCheckItem(
                                label = "1. Pemasangan",
                                checked = report.penyebabPemasangan,
                                onCheckedChange = { v -> onUpdateReport { it.copy(penyebabPemasangan = v) } }
                            )
                            CauseCheckItem(
                                label = "2. Kwalitas Parts",
                                checked = report.penyebabKwalitasParts,
                                onCheckedChange = { v -> onUpdateReport { it.copy(penyebabKwalitasParts = v) } }
                            )
                            CauseCheckItem(
                                label = "3. Kesalahan Operasional",
                                checked = report.penyebabKesalahanOperasional,
                                onCheckedChange = { v -> onUpdateReport { it.copy(penyebabKesalahanOperasional = v) } }
                            )
                            CauseCheckItem(
                                label = "4. Sudah waktunya",
                                checked = report.penyebabSudahWaktunya,
                                onCheckedChange = { v -> onUpdateReport { it.copy(penyebabSudahWaktunya = v) } }
                            )
                            CauseCheckItem(
                                label = "5. Lain-lain",
                                checked = report.penyebabLainLain,
                                onCheckedChange = { v -> onUpdateReport { it.copy(penyebabLainLain = v) } }
                            )
                        }
                        item {
                            OutlinedTextField(
                                value = report.penyebabPenjelasan,
                                onValueChange = { value -> onUpdateReport { it.copy(penyebabPenjelasan = value) } },
                                label = { Text("Penjelasan Penyebab Kerusakan (Jika YA)") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 2
                            )
                        }

                        item {
                            SectionHeader(title = "Cara Mengatasi Kerusakan", icon = Icons.Default.Build)
                        }
                        item {
                            CauseCheckItem(
                                label = "1. Ganti Part Baru",
                                checked = report.caraGantiPartBaru,
                                onCheckedChange = { v -> onUpdateReport { it.copy(caraGantiPartBaru = v) } }
                            )
                            CauseCheckItem(
                                label = "2. Pemasangan atau Penyetelan Ulang",
                                checked = report.caraPenyetelanUlang,
                                onCheckedChange = { v -> onUpdateReport { it.copy(caraPenyetelanUlang = v) } }
                            )
                            CauseCheckItem(
                                label = "3. Modifikasi",
                                checked = report.caraModifikasi,
                                onCheckedChange = { v -> onUpdateReport { it.copy(caraModifikasi = v) } }
                            )
                        }
                        item {
                            OutlinedTextField(
                                value = report.caraDeskripsi,
                                onValueChange = { value -> onUpdateReport { it.copy(caraDeskripsi = value) } },
                                label = { Text("Tindakan Penanganan (e.g. Ganti ban stip)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        item {
                            SectionHeader(title = "Keterangan & Usulan", icon = Icons.Default.Edit)
                        }
                        item {
                            OutlinedTextField(
                                value = report.tertundaKarena,
                                onValueChange = { value -> onUpdateReport { it.copy(tertundaKarena = value) } },
                                label = { Text("Tertunda Karena (Opsional)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        item {
                            OutlinedTextField(
                                value = report.usulanPelapor,
                                onValueChange = { value -> onUpdateReport { it.copy(usulanPelapor = value) } },
                                label = { Text("Usulan Pelapor") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 2
                            )
                        }
                    }

                    4 -> {
                        // TAB 5: PARTS YANG HARUS DIGANTI
                        item {
                            SectionHeader(title = "Tabel Suku Cadang (Parts Yang Harus Diganti)", icon = Icons.Default.Build)
                        }
                        item {
                            Text(
                                text = "Isi daftar spare parts dan masukkan teks/jumlah pada kolom jenis pengadaan: Stock, Order, Modifikasi, atau Pending.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        items(parts.size) { index ->
                            val part = parts[index]
                            PartRowEditor(
                                part = part,
                                onUpdate = { transform -> onUpdatePart(index, transform) }
                            )
                        }
                    }

                    5 -> {
                        // TAB 6: TANDA TANGAN & PENGESAHAN
                        item {
                            SectionHeader(title = "Pengesahan & Tanda Tangan Digital", icon = Icons.Default.Draw)
                        }

                        // Mengetahui 1
                        item {
                            SignatureCardItem(
                                roleTitle = "Mengetahui (Pihak 1)",
                                name = report.mengetahui1Nama,
                                onNameChange = { v -> onUpdateReport { it.copy(mengetahui1Nama = v) } },
                                signaturePath = report.mengetahui1SignaturePath,
                                onOpenPad = { activeSignatureTarget = "mengetahui1" },
                                onClearSignature = { onUpdateReport { it.copy(mengetahui1SignaturePath = null) } }
                            )
                        }

                        // Mengetahui 2
                        item {
                            SignatureCardItem(
                                roleTitle = "Mengetahui (Pihak 2)",
                                name = report.mengetahui2Nama,
                                onNameChange = { v -> onUpdateReport { it.copy(mengetahui2Nama = v) } },
                                signaturePath = report.mengetahui2SignaturePath,
                                onOpenPad = { activeSignatureTarget = "mengetahui2" },
                                onClearSignature = { onUpdateReport { it.copy(mengetahui2SignaturePath = null) } }
                            )
                        }

                        // Dilaporkan Oleh
                        item {
                            SignatureCardItem(
                                roleTitle = "Dilaporkan Oleh (Wajib)",
                                name = report.pelaporNama,
                                onNameChange = { v -> onUpdateReport { it.copy(pelaporNama = v) } },
                                jabatan = report.pelaporJabatan,
                                onJabatanChange = { v -> onUpdateReport { it.copy(pelaporJabatan = v) } },
                                signaturePath = report.pelaporSignaturePath,
                                onOpenPad = { activeSignatureTarget = "pelapor" },
                                onClearSignature = { onUpdateReport { it.copy(pelaporSignaturePath = null) } }
                            )
                        }
                    }
                }
            }
        }
    }

    // Interactive Signature Pad Dialog
    activeSignatureTarget?.let { target ->
        val title = when (target) {
            "mengetahui1" -> "Tanda Tangan Mengetahui 1"
            "mengetahui2" -> "Tanda Tangan Mengetahui 2"
            else -> "Tanda Tangan Pelapor (${report.pelaporNama})"
        }
        SignatureDialog(
            title = title,
            onDismiss = { activeSignatureTarget = null },
            onSaveSignature = { path ->
                when (target) {
                    "mengetahui1" -> onUpdateReport { it.copy(mengetahui1SignaturePath = path) }
                    "mengetahui2" -> onUpdateReport { it.copy(mengetahui2SignaturePath = path) }
                    "pelapor" -> onUpdateReport { it.copy(pelaporSignaturePath = path) }
                }
                activeSignatureTarget = null
            }
        )
    }
}

@Composable
private fun SectionHeader(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.primary
        )
    }
}

@Composable
private fun CauseCheckItem(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = label, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun PartRowEditor(
    part: PartItem,
    onUpdate: ((PartItem) -> PartItem) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "Item #${part.no}",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = part.noParts,
                    onValueChange = { v -> onUpdate { it.copy(noParts = v) } },
                    label = { Text("No Parts") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = part.namaParts,
                    onValueChange = { v -> onUpdate { it.copy(namaParts = v) } },
                    label = { Text("Nama Parts") },
                    modifier = Modifier.weight(1.5f),
                    singleLine = true
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Jenis Pengadaan Part (Isi teks/jumlah pada kolom yang sesuai):",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedTextField(
                    value = part.stock,
                    onValueChange = { v -> onUpdate { it.copy(stock = v) } },
                    label = { Text("Stock", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = part.order,
                    onValueChange = { v -> onUpdate { it.copy(order = v) } },
                    label = { Text("Order", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = part.modifikasi,
                    onValueChange = { v -> onUpdate { it.copy(modifikasi = v) } },
                    label = { Text("Modif", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = part.pending,
                    onValueChange = { v -> onUpdate { it.copy(pending = v) } },
                    label = { Text("Pending", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }
        }
    }
}

@Composable
private fun SignatureCardItem(
    roleTitle: String,
    name: String,
    onNameChange: (String) -> Unit,
    jabatan: String? = null,
    onJabatanChange: ((String) -> Unit)? = null,
    signaturePath: String?,
    onOpenPad: () -> Unit,
    onClearSignature: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = roleTitle,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = name,
                onValueChange = onNameChange,
                label = { Text("Nama Penandatangan") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            if (jabatan != null && onJabatanChange != null) {
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = jabatan,
                    onValueChange = onJabatanChange,
                    label = { Text("Jabatan") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
            Spacer(modifier = Modifier.height(10.dp))

            // Signature box / pad trigger
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White)
                    .border(1.dp, Color.LightGray, RoundedCornerShape(8.dp))
                    .clickable(onClick = onOpenPad),
                contentAlignment = Alignment.Center
            ) {
                if (!signaturePath.isNullOrBlank()) {
                    AsyncImage(
                        model = signaturePath,
                        contentDescription = "Tanda tangan",
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Draw, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Ketuk untuk tanda tangan digital",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                if (!signaturePath.isNullOrBlank()) {
                    OutlinedButton(onClick = onClearSignature) {
                        Text("Hapus Tanda Tangan")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Button(onClick = onOpenPad) {
                    Icon(Icons.Default.Draw, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (signaturePath.isNullOrBlank()) "Beri Tanda Tangan" else "Ubah Tanda Tangan")
                }
            }
        }
    }
}
