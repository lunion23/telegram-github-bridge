package com.example.util

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID

object FileUtil {

    /**
     * Copies a transient URI (e.g. from PhotoPicker) to persistent app internal storage.
     * Prevents SecurityException / permission expiration upon app relaunch.
     */
    fun saveUriToInternalStorage(context: Context, uriString: String, subFolder: String = "photos"): String {
        return try {
            val uri = Uri.parse(uriString)
            if (uri.scheme == "file") {
                return uri.path ?: uriString
            }
            if (uri.scheme != "content") {
                val f = File(uriString)
                if (f.exists()) return f.absolutePath
            }

            val dir = File(context.filesDir, subFolder)
            if (!dir.exists()) dir.mkdirs()

            val fileName = "img_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.jpg"
            val destFile = File(dir, fileName)

            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            if (inputStream != null) {
                FileOutputStream(destFile).use { output ->
                    inputStream.copyTo(output)
                }
                inputStream.close()
                destFile.absolutePath
            } else {
                uriString
            }
        } catch (e: Exception) {
            e.printStackTrace()
            uriString
        }
    }
}
