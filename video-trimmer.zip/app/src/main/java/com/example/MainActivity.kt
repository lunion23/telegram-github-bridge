package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.ui.VideoTrimScreen
import com.example.ui.VideoTrimViewModel
import com.example.ui.theme.VideoTrimmerTheme

/**
 * Aktivitas utama aplikasi pemotong video FFmpeg.
 * Mengatur edge-to-edge layout dan menghubungkan [VideoTrimViewModel] ke antarmuka Jetpack Compose.
 */
class MainActivity : ComponentActivity() {

    private val viewModel: VideoTrimViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            VideoTrimmerTheme(darkTheme = true) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    VideoTrimScreen(viewModel = viewModel)
                }
            }
        }
    }
}
