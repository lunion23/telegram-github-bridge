const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function buildValidPayload(userId, serverTimestamp, overrides = {}) {
  return {
    userId,
    badgeLeft: "NP",
    badgeRight: "EZ",
    routingCode: "160-1BTH04-05",
    waybillNumber: "JD0600216038",
    destinationBanner: "PT MCDERMOTT",
    recipientName: "Muhamad Arif",
    recipientPhone: "********2959",
    recipientAddress: "BATAM, BATU AMPAR-BTH, PT Mcdermott Gate 6",
    senderName: "Adinda",
    senderPhone: "********3923",
    senderArea: "KAB.SERANG, serdang",
    shippingFeeLabel: "BIAYA PENGIRIMAN",
    shippingFeeAmount: "IDR 45,000",
    taxIncludedText: "Sudah Termasuk PPN",
    paymentMethod: "TUNAI",
    weight: "0.56 KG",
    printDate: "25-10-2026",
    orderNumber: "19821215842810173",
    expCode: "",
    quantityText: "1 PCS",
    itemCategory: "BARANG MAKANAN LAINNYA",
    notes: "",
    companyNameAndTax: "PT GLOBAL JET EXPRESS, 0735697740041000",
    companyAddressLine1: "LANDMARK PLUIT TOWER BLCK B1, LANTAI 8, 9A,",
    companyAddressLine2: "10A JL. PLUIT SELATAN RAYA, PENJARINGAN",
    websiteUrl: "www.jet.co.id",
    stubBadgeText: "Lembar Pengirim",
    paperPreset: "THERMAL_100X200",
    actionLabel: "DISIMPAN",
    createdAt: serverTimestamp,
    updatedAt: serverTimestamp,
    ...overrides,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read or create label history", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(
    unauthDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("labelHistory")
      .where("userId", "==", ALICE_UID)
      .get()
  );
  await assertFails(
    unauthDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("labelHistory")
      .doc("item_1")
      .set(buildValidPayload(ALICE_UID, new Date(Date.now() - 1000)))
  );
});

test("Authenticated owner: can create, get, list with aligned query, update, and delete own label history", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const docRef = aliceDb.collection("users").doc(ALICE_UID).collection("labelHistory").doc("item_1");
  const initialTime = new Date(Date.now() - 2000);

  await assertSucceeds(docRef.set(buildValidPayload(ALICE_UID, initialTime)));
  await assertSucceeds(docRef.get());
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("labelHistory")
      .where("userId", "==", ALICE_UID)
      .get()
  );

  await assertSucceeds(
    docRef.update({
      recipientName: "Budi Santoso",
      actionLabel: "DICETAK_PDF",
      updatedAt: new Date(Date.now() - 500),
    })
  );

  await assertSucceeds(docRef.delete());
});

test("Cross-user isolation: Bob cannot get, list, update, or delete Alice's label history", async () => {
  const createdTime = new Date(Date.now() - 2000);
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx
      .firestore()
      .collection("users")
      .doc(ALICE_UID)
      .collection("labelHistory")
      .doc("alice_doc")
      .set(buildValidPayload(ALICE_UID, createdTime));
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const aliceDocAsBob = bobDb.collection("users").doc(ALICE_UID).collection("labelHistory").doc("alice_doc");

  await assertFails(aliceDocAsBob.get());
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("labelHistory")
      .where("userId", "==", ALICE_UID)
      .get()
  );
  await assertFails(aliceDocAsBob.update({ recipientName: "Hacked", updatedAt: new Date() }));
  await assertFails(aliceDocAsBob.delete());
});

test("Shadow update & schema tampering: rejects ghost fields, invalid enums, and immutable field mutation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const docRef = aliceDb.collection("users").doc(ALICE_UID).collection("labelHistory").doc("item_sec");
  const createdTime = new Date(Date.now() - 2000);

  // Rejects ghost field on create
  await assertFails(
    docRef.set({
      ...buildValidPayload(ALICE_UID, createdTime),
      isVerified: true,
    })
  );

  // Rejects spoofed userId in payload
  await assertFails(docRef.set(buildValidPayload(BOB_UID, createdTime)));

  // Rejects invalid paperPreset enum
  await assertFails(
    docRef.set(buildValidPayload(ALICE_UID, createdTime, { paperPreset: "CUSTOM_HUGE" }))
  );

  // Seed valid document, then test immutable createdAt & ghost field on update
  await assertSucceeds(docRef.set(buildValidPayload(ALICE_UID, createdTime)));
  await assertFails(
    docRef.update({
      createdAt: new Date(),
      updatedAt: new Date(),
    })
  );
  await assertFails(
    docRef.update({
      isAdmin: true,
      updatedAt: new Date(),
    })
  );
});
