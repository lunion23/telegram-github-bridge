package com.example.ui.components

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.model.PaperSizePreset
import com.example.model.PdfRenderSource
import com.example.model.PreviewDisplayMode

@Composable
fun LabelPreviewStage(
    previewBitmap: Bitmap?,
    comparisonLabelBitmap: Bitmap?,
    referenceBitmap: Bitmap?,
    paperPreset: PaperSizePreset,
    displayMode: PreviewDisplayMode,
    onSelectDisplayMode: (PreviewDisplayMode) -> Unit,
    onOpenZoom: () -> Unit,
    modifier: Modifier = Modifier,
    capturedBitmap: Bitmap? = null,
    renderSource: PdfRenderSource = PdfRenderSource.VECTOR_RECONSTRUCTION
) {
    val gridDotColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)
    val effectiveSourceReference = capturedBitmap ?: referenceBitmap

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .drawBehind {
                    val step = 18.dp.toPx()
                    val radius = 1.3.dp.toPx()
                    var x = step / 2f
                    while (x < size.width) {
                        var y = step / 2f
                        while (y < size.height) {
                            drawCircle(
                                color = gridDotColor,
                                radius = radius,
                                center = Offset(x, y)
                            )
                            y += step
                        }
                        x += step
                    }
                }
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Mode Switcher Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val primaryChipLabel = if (renderSource == PdfRenderSource.CAPTURED_DOCUMENT) {
                    stringResource(R.string.mode_pdf_camera)
                } else {
                    stringResource(R.string.mode_pdf_vector)
                }
                FilterChip(
                    selected = displayMode == PreviewDisplayMode.GENERATED_PDF,
                    onClick = { onSelectDisplayMode(PreviewDisplayMode.GENERATED_PDF) },
                    label = { Text(primaryChipLabel) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Filled.PictureAsPdf,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimaryContainer
                    ),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("mode_generated_pdf_chip")
                )

                if (effectiveSourceReference != null) {
                    FilterChip(
                        selected = displayMode == PreviewDisplayMode.COMPARE_SIDE_BY_SIDE,
                        onClick = { onSelectDisplayMode(PreviewDisplayMode.COMPARE_SIDE_BY_SIDE) },
                        label = { Text(stringResource(R.string.mode_compare_side_by_side)) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.Compare,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("mode_compare_chip")
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Paper Dimension Badge
            Surface(
                shape = RoundedCornerShape(50),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
                tonalElevation = 1.dp
            ) {
                Text(
                    text = "${paperPreset.widthMm.toInt()} × ${paperPreset.heightMm.toInt()} mm • 1 Halaman PDF",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            AnimatedContent(
                targetState = displayMode,
                label = "preview_mode_transition"
            ) { currentMode ->
                when (currentMode) {
                    PreviewDisplayMode.GENERATED_PDF -> {
                        val paperAspect = paperPreset.widthMm / paperPreset.heightMm
                        Box(
                            modifier = Modifier
                                .widthIn(max = 310.dp)
                                .fillMaxWidth(0.84f)
                                .aspectRatio(paperAspect)
                                .shadow(
                                    elevation = 10.dp,
                                    shape = RoundedCornerShape(4.dp),
                                    clip = false
                                )
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color.White)
                                .border(
                                    width = 1.dp,
                                    color = Color(0xFFD1D5DB),
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .clickable(onClick = onOpenZoom)
                                .testTag("pdf_preview_paper_card"),
                            contentAlignment = Alignment.Center
                        ) {
                            if (previewBitmap != null) {
                                Image(
                                    bitmap = previewBitmap.asImageBitmap(),
                                    contentDescription = stringResource(R.string.cd_label_preview_image),
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                CircularProgressIndicator(modifier = Modifier.size(32.dp))
                            }
                        }
                    }

                    PreviewDisplayMode.COMPARE_SIDE_BY_SIDE -> {
                        val isCameraPdfMode = renderSource == PdfRenderSource.CAPTURED_DOCUMENT
                        val leftAspect = if (isCameraPdfMode) {
                            (paperPreset.widthMm / paperPreset.heightMm).coerceIn(0.42f, 1.5f)
                        } else {
                            629f / 1272f
                        }
                        val rightAspect = if (isCameraPdfMode) {
                            leftAspect
                        } else {
                            629f / 1272f
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = stringResource(R.string.label_generated_pdf),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(leftAspect)
                                        .shadow(6.dp, RoundedCornerShape(4.dp))
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color.White)
                                        .clickable(onClick = onOpenZoom),
                                    contentAlignment = Alignment.Center
                                ) {
                                    val sideBitmap = if (isCameraPdfMode) {
                                        previewBitmap
                                    } else {
                                        comparisonLabelBitmap ?: previewBitmap
                                    }
                                    if (sideBitmap != null) {
                                        Image(
                                            bitmap = sideBitmap.asImageBitmap(),
                                            contentDescription = stringResource(R.string.cd_label_preview_image),
                                            contentScale = ContentScale.Fit,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                }
                            }

                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                val rightHeaderLabel = if (capturedBitmap != null) {
                                    stringResource(R.string.label_captured_camera_reference)
                                } else {
                                    stringResource(R.string.label_original_reference)
                                }
                                Text(
                                    text = rightHeaderLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(rightAspect)
                                        .shadow(6.dp, RoundedCornerShape(4.dp))
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color.White),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (effectiveSourceReference != null) {
                                        Image(
                                            bitmap = effectiveSourceReference.asImageBitmap(),
                                            contentDescription = stringResource(R.string.cd_reference_image),
                                            contentScale = ContentScale.Fit,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable(onClick = onOpenZoom)
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .testTag("zoom_preview_hint_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.ZoomIn,
                    contentDescription = stringResource(R.string.cd_zoom_in),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = stringResource(R.string.preview_zoom_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun ZoomablePreviewDialog(
    previewBitmap: Bitmap?,
    onDismiss: () -> Unit
) {
    BackHandler(onBack = onDismiss)

    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xEB0B0F19)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                if (previewBitmap != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                detectTransformGestures { _, pan, zoom, _ ->
                                    val newScale = (scale * zoom).coerceIn(1f, 4f)
                                    scale = newScale
                                    if (newScale > 1f) {
                                        offsetX += pan.x
                                        offsetY += pan.y
                                    } else {
                                        offsetX = 0f
                                        offsetY = 0f
                                    }
                                }
                            }
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            bitmap = previewBitmap.asImageBitmap(),
                            contentDescription = stringResource(R.string.cd_label_preview_image),
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer(
                                    scaleX = scale,
                                    scaleY = scale,
                                    translationX = offsetX,
                                    translationY = offsetY
                                )
                        )
                    }
                }

                // Top Header Controls with safeDrawing insets against notch/status bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.safeDrawing)
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                        .align(Alignment.TopCenter),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.dialog_zoom_title),
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("close_zoom_dialog_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Close,
                            contentDescription = stringResource(R.string.action_close),
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }
}
