package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.ApiClient
import com.example.data.model.DownloadHistoryItem
import com.example.data.model.ExtractRequest
import com.example.data.model.VideoFormatOption
import com.example.data.model.VideoInfoResponse
import com.example.download.AndroidDownloader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface DownloaderUiState {
    data object Idle : DownloaderUiState
    data class Loading(val message: String = "Mengekstrak data video...") : DownloaderUiState
    data class Success(
        val videoInfo: VideoInfoResponse,
        val selectedFormat: VideoFormatOption?
    ) : DownloaderUiState
    data class Error(val message: String) : DownloaderUiState
}

sealed interface ServerHealthState {
    data object Unknown : ServerHealthState
    data object Checking : ServerHealthState
    data class Online(val message: String = "Server Terhubung") : ServerHealthState
    data class Offline(val reason: String) : ServerHealthState
}

class DownloaderViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("downloader_prefs", Context.MODE_PRIVATE)
    private val downloader = AndroidDownloader(application)

    private val _urlInput = MutableStateFlow("")
    val urlInput: StateFlow<String> = _urlInput.asStateFlow()

    private val _backendUrl = MutableStateFlow(
        prefs.getString("backend_url", ApiClient.DEFAULT_BASE_URL) ?: ApiClient.DEFAULT_BASE_URL
    )
    val backendUrl: StateFlow<String> = _backendUrl.asStateFlow()

    private val _uiState = MutableStateFlow<DownloaderUiState>(DownloaderUiState.Idle)
    val uiState: StateFlow<DownloaderUiState> = _uiState.asStateFlow()

    private val _serverHealth = MutableStateFlow<ServerHealthState>(ServerHealthState.Unknown)
    val serverHealth: StateFlow<ServerHealthState> = _serverHealth.asStateFlow()

    private val _history = MutableStateFlow<List<DownloadHistoryItem>>(emptyList())
    val history: StateFlow<List<DownloadHistoryItem>> = _history.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    init {
        ApiClient.setBaseUrl(_backendUrl.value)
        testServerConnection()
    }

    fun onUrlChange(newUrl: String) {
        _urlInput.value = newUrl
    }

    fun clearInput() {
        _urlInput.value = ""
        _uiState.value = DownloaderUiState.Idle
    }

    fun setUrlFromClipboard(text: String) {
        val trimmed = text.trim()
        if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
            _urlInput.value = trimmed
            analyzeUrl()
        } else {
            _toastMessage.value = "Teks di clipboard bukan URL yang valid"
        }
    }

    fun updateBackendUrl(newUrl: String) {
        val clean = newUrl.trim()
        if (clean.isNotEmpty()) {
            _backendUrl.value = clean
            prefs.edit().putString("backend_url", clean).apply()
            ApiClient.setBaseUrl(clean)
            testServerConnection()
        }
    }

    fun testServerConnection() {
        viewModelScope.launch {
            _serverHealth.value = ServerHealthState.Checking
            try {
                val service = ApiClient.getService(_backendUrl.value)
                val health = withContext(Dispatchers.IO) {
                    service.checkHealth()
                }
                if (health.status == "ok") {
                    _serverHealth.value = ServerHealthState.Online(health.message ?: "Online")
                } else {
                    _serverHealth.value = ServerHealthState.Offline("Status tidak dikenal: ${health.status}")
                }
            } catch (e: Exception) {
                _serverHealth.value = ServerHealthState.Offline(
                    e.localizedMessage ?: "Tidak dapat terhubung ke server"
                )
            }
        }
    }

    fun analyzeUrl() {
        val target = _urlInput.value.trim()
        if (target.isEmpty()) {
            _toastMessage.value = "Silakan masukkan URL terlebih dahulu"
            return
        }

        if (!target.startsWith("http://") && !target.startsWith("https://")) {
            _toastMessage.value = "URL harus diawali dengan http:// atau https://"
            return
        }

        viewModelScope.launch {
            _uiState.value = DownloaderUiState.Loading("Sedang menganalisis link dengan yt-dlp...")
            try {
                val service = ApiClient.getService(_backendUrl.value)
                val response = withContext(Dispatchers.IO) {
                    service.extractVideo(ExtractRequest(url = target))
                }

                val defaultFormat = response.formats.firstOrNull { !it.isAudioOnly }
                    ?: response.formats.firstOrNull()

                _uiState.value = DownloaderUiState.Success(
                    videoInfo = response,
                    selectedFormat = defaultFormat
                )
            } catch (e: retrofit2.HttpException) {
                val errorBody = e.response()?.errorBody()?.string() ?: ""
                val msg = if (errorBody.contains("detail")) {
                    errorBody.substringAfter("\"detail\":\"").substringBefore("\"")
                } else {
                    "Error server HTTP ${e.code()}"
                }
                _uiState.value = DownloaderUiState.Error(msg)
            } catch (e: Exception) {
                _uiState.value = DownloaderUiState.Error(
                    "Gagal menghubungkan ke backend (${_backendUrl.value}): ${e.localizedMessage ?: "Koneksi terputus. Pastikan server FastAPI sedang berjalan."}"
                )
            }
        }
    }

    fun selectFormat(format: VideoFormatOption) {
        val current = _uiState.value
        if (current is DownloaderUiState.Success) {
            _uiState.value = current.copy(selectedFormat = format)
        }
    }

    fun startDownload() {
        val current = _uiState.value
        if (current is DownloaderUiState.Success) {
            val format = current.selectedFormat ?: current.videoInfo.formats.firstOrNull()
            if (format == null) {
                _toastMessage.value = "Tidak ada format yang dapat diunduh"
                return
            }

            val title = current.videoInfo.title
            val ext = format.extension
            val isAudio = format.isAudioOnly
            val url = format.downloadUrl

            val downloadId = downloader.downloadFile(
                url = url,
                title = title,
                extension = ext,
                isAudio = isAudio
            )

            if (downloadId > 0) {
                val newItem = DownloadHistoryItem(
                    id = downloadId,
                    title = title,
                    platform = current.videoInfo.platform ?: "Video",
                    fileName = "$title.$ext"
                )
                _history.value = listOf(newItem) + _history.value
                _toastMessage.value = "Mengunduh: $title"
            }
        }
    }

    fun clearToast() {
        _toastMessage.value = null
    }
}
